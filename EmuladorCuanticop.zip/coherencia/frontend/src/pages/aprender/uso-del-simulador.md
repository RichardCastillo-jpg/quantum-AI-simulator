---
layout: ../../layouts/LessonLayout.astro
title: "Cómo usar el simulador"
kicker: "Lección 3"
description: "Todo lo que puedes hacer en el editor de circuitos, en orden de uso: colocar compuertas, configurar la ejecución, leer los resultados y reutilizar bloques."
---

## La pantalla

- **Izquierda:** la paleta de compuertas y la biblioteca de subcircuitos.
- **Centro:** la cuadrícula del circuito. Cada fila es un cúbit (q0 arriba) y cada columna un paso de tiempo.
  Debajo aparecen los resultados, que se recalculan solos.
- **Derecha:** el inspector de la compuerta seleccionada y la pestaña **Ejecución**.

## Colocar y quitar compuertas

1. **Arrastra** una compuerta de la paleta hasta la línea de un cúbit. Si la celda está ocupada, el editor abre
   una columna nueva.
2. También puedes **pulsar** una compuerta para "armarla" y después hacer clic en las celdas donde la quieras.
   `Esc` la suelta.
3. Las compuertas de dos cúbits se colocan con **dos clics**: CNOT y CZ piden primero el control y después el
   objetivo; SWAP, iSWAP o RZZ piden los dos cúbits. Toffoli pide tres clics (dos controles y el objetivo).
4. Para **mover** una compuerta, arrástrala a otra celda. Para **eliminarla**, selecciónala y pulsa `Supr`,
   arrástrala fuera del lienzo o usa el clic derecho.
5. Suelta un **control ●** o un **anticontrol ○** en la columna de una compuerta para controlarla desde otro cúbit.

El estado inicial de cada cúbit se cambia pulsando el <span class="ket">|0⟩</span> que aparece a la izquierda de su línea.

## Parámetros

Al seleccionar una rotación o una fase, el inspector muestra su parámetro con un deslizador y un campo de texto
que acepta expresiones: `pi/4`, `2pi/3`, `sqrt(2)`, `atan2(1, 2)`… Mientras arrastras el deslizador el resultado se
actualiza en tiempo real (con control de frecuencia para no saturar el servidor).

## Ciclos for

Para repetir una secuencia sin llenar el lienzo:

1. Selecciona sus compuertas arrastrando un rectángulo en una zona vacía.
2. Pulsa **Repetir** y elige el número de iteraciones y el nombre de la variable (por defecto `i`).
3. Dentro del ciclo puedes usar la variable en los parámetros: `RZ(i*pi/8)` gira un ángulo distinto en cada vuelta.

El ciclo aparece como una banda sobre las columnas que repite; al pulsar su etiqueta lo editas o lo quitas.
Los ciclos pueden anidarse.

## Subcircuitos

- **Guardar:** selecciona varias compuertas y pulsa **Subcircuito**. Ponle nombre y descripción; el número de
  cúbits se calcula solo. Si sus parámetros usan nombres libres (por ejemplo `theta`), se convierten en
  parámetros del subcircuito. Puedes reemplazar la selección por el bloque.
- **Insertar:** arrastra un subcircuito de la biblioteca a la línea del primer cúbit donde lo quieras. Ocupa
  cúbits consecutivos y el editor avisa si no caben; después puedes reasignar cada cúbit en el inspector.
- **Ver:** doble clic en el bloque (o el icono del ojo en la biblioteca) abre la vista de inspección con sus
  compuertas internas, el orden de capas y el flujo de cúbits.
- **Editar:** el icono del lápiz abre un editor completo. Al guardar, todas las instancias se actualizan y el
  circuito se vuelve a ejecutar. Desde el menú ⋯ puedes renombrar, duplicar o eliminar.

Los subcircuitos se guardan en el servidor (un volumen de Docker), así que siguen ahí al reiniciar.

## Ejecución

En la pestaña **Ejecución** se configura:

| Opción | Efecto |
| --- | --- |
| Cúbits y bits clásicos | Tamaño de los registros. |
| Estado inicial | Cadena de bits; el carácter de la derecha es q0. |
| Modo | **Statevector**: estado exacto. **Shots**: muestreo con mediciones reales. |
| Disparos y semilla | Número de repeticiones y semilla para resultados reproducibles. |
| Ruido | Ninguno, **despolarizante** (p1, p2) o **relajación térmica** (T1, T2 y tiempos de compuerta), más error de lectura. |

La ejecución es **automática**: cualquier cambio dispara un nuevo cálculo, los cálculos obsoletos se cancelan y
solo se muestra el más reciente. El indicador de la cabecera dice si todo está sincronizado; con **Pausar**
puedes acumular cambios en circuitos grandes y ejecutarlos con `Ctrl + Enter`.

## Leer los resultados

- **Estado dominante:** el resultado más probable y su probabilidad.
- **Probabilidades:** histograma sobre los cúbits (o los bits clásicos). En modo exacto el color de cada barra es
  la fase de su amplitud.
- **Esferas de Bloch:** una por cúbit, animadas desde el estado inicial. Puedes girarlas; un vector corto indica
  entrelazamiento o ruido.
- **Amplitudes:** valores complejos, probabilidad y fase. Si hay mediciones intermedias verás una **rama** por cada
  resultado clásico.
- **Análisis:** los algoritmos precargados añaden su propio panel (factores de Shor, XEB, fidelidad…).

### Barras en 3D

El botón **3D** de la tarjeta de probabilidades cambia a una figura tridimensional como las de los artículos:

- **Probabilidades:** cada barra es un resultado. Un eje agrupa los bits altos y el otro los bajos, así que el
  estado de una barra se lee juntando la fila y la columna.
- **Re ρ e Im ρ:** la matriz densidad del estado, elemento a elemento. Las barras positivas suben y las negativas
  cuelgan bajo el suelo. La diagonal son las poblaciones (las probabilidades) y lo que está fuera de ella son las
  **coherencias**, que desaparecen cuando el ruido destruye la superposición.
- **|ρ| y fase:** la altura es el módulo de cada elemento y el color su fase, todo en una sola figura.

Arrastra para girar, usa Mayús + arrastrar para desplazar, Ctrl + rueda (o los botones − y +) para acercar y doble
clic para volver a la vista inicial. Con **PNG** descargas la figura con fondo blanco, lista para un informe. La
matriz densidad se muestra hasta 5 cúbits (32 × 32 barras).

## Depurador paso a paso

El botón **Depurar paso a paso** recorre el estado después de cada columna, con los ciclos desenrollados. Puedes
reproducirlo, avanzar columna a columna y ver cómo se entrelazan los cúbits o cómo el ruido acorta los vectores.

## Programar en Qiskit

La pestaña **Código** del panel derecho muestra tu circuito como un programa de Qiskit. Funciona en los dos
sentidos:

- Si cambias el circuito en la cuadrícula, el código se reescribe solo.
- Si escribes o pegas código de Qiskit, al dejar de escribir (o con `Ctrl Enter`) el circuito se reconstruye y se
  vuelve a simular: verás cambiar el histograma, las amplitudes y las esferas de Bloch.

Puedes usar variables, bucles `for`, funciones y la API habitual (`qc.h(0)`, `qc.cx(0, 1)`, `qc.measure_all()`,
`with qc.if_test(...)`, `qc.append(QFTGate(3), [0, 1, 2])`…). Las líneas que solo sirven para ejecutar o dibujar,
como `AerSimulator` o `plot_histogram`, se ignoran porque el simulador ya ejecuta el circuito. Si algo falla, la
línea aparece marcada en rojo con una explicación.

Al seleccionar una compuerta se resalta la línea que la crea, y al hacer clic en una línea se selecciona su
compuerta. Con **Desde el circuito** vuelves a la versión generada y con **.py** descargas el programa.

## Atajos

| Teclas | Acción |
| --- | --- |
| `Supr` | Eliminar la selección |
| `Esc` | Cancelar una colocación o soltar la herramienta |
| `Ctrl Z` / `Ctrl ⇧ Z` | Deshacer / rehacer |
| `Ctrl D` | Duplicar |
| `← →` `↑ ↓` | Mover la compuerta seleccionada |
| `Ctrl ↵` | Ejecutar ahora |
