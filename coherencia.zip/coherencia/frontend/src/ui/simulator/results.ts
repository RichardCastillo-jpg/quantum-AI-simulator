// Panel de resultados: estado dominante, histograma, esferas de Bloch, amplitudes y análisis.

import { clear, h } from '../../lib/dom';
import { fmtAngle, fmtComplex, fmtProb, ket, trimNum } from '../../lib/format';
import { phaseColor } from '../../lib/phase';
import type { Amplitude, BlochVector, ProbEntry, SimResult } from '../../lib/types';
import { BlochSphere, DEFAULT_VIEW, type View } from '../bloch';
import { iconButton } from '../common';
import { renderAnalysis } from './analysis';
import type { SimController, SimState } from './controller';
import { phaseLegend, renderHistogram } from './histogram';

interface View3 {
  entries: ProbEntry[];
  other: number;
  truncated: boolean;
  colorByPhase: boolean;
  shots: number | null;
  register: string;
  bloch: BlochVector[];
  amplitudes: Amplitude[] | null;
  label: string;
}

export class ResultsPanel {
  readonly element: HTMLElement;
  private ctrl: SimController;
  private spheres: { sphere: BlochSphere; card: HTMLElement; info: HTMLElement }[] = [];
  private view: View = { ...DEFAULT_VIEW };
  private syncViews = true;
  private histMode: 'qubits' | 'clbits' = 'qubits';
  private branchIndex = 0;
  private fixPhase = false;
  private sortByProb = false;
  private els: Record<string, HTMLElement> = {};
  private lastResult: SimResult | null = null;
  private lastStep = -2;
  private resizeObs: ResizeObserver;

  constructor(container: HTMLElement, ctrl: SimController) {
    this.element = container;
    this.ctrl = ctrl;
    container.classList.add('results');
    this.build();
    ctrl.store.subscribe((s, prev) => {
      if (s.result !== prev.result || s.debug !== prev.debug) this.update(s);
      if (s.status !== prev.status) this.updateStatus(s);
    });
    this.resizeObs = new ResizeObserver(() => this.renderHistogramOnly());
    this.resizeObs.observe(this.els.hist);
    this.update(ctrl.store.get());
  }

  private build(): void {
    const e = this.els;
    e.head = h('div', { class: 'results-head' });
    e.dominant = h('div', { class: 'card dominant' });
    e.histCard = h('div', { class: 'card hist-card' });
    e.hist = h('div', { class: 'hist' });
    e.blochCard = h('div', { class: 'card bloch-card' });
    e.blochGrid = h('div', { class: 'bloch-grid' });
    e.ampCard = h('div', { class: 'card amp-card' });
    e.analysis = h('div', { class: 'card analysis-card', hidden: true });
    e.footer = h('div', { class: 'results-foot' });
    e.empty = h('div', { class: 'card empty-results' }, 'Construye un circuito: los resultados aparecerán aquí automáticamente.');

    const replay = iconButton('play', 'Repetir la animación desde el estado inicial', () => this.animateFromInitial());
    const syncBox = h('input', { type: 'checkbox', checked: true }) as HTMLInputElement;
    syncBox.addEventListener('change', () => (this.syncViews = syncBox.checked));
    e.blochCard.append(
      h('div', { class: 'card-head' }, h('h3', null, 'Esferas de Bloch'), h('div', { class: 'grow' }),
        h('label', { class: 'check' }, syncBox, 'Girar juntas'), replay),
      e.blochGrid,
      h('p', { class: 'hint' }, 'Arrastra una esfera para girarla; doble clic para volver a la vista inicial. Un vector más corto que el radio indica un cúbit entrelazado o con ruido.'),
    );
    this.element.append(e.head, e.empty, h('div', { class: 'results-grid' }, e.dominant, e.histCard, e.blochCard, e.analysis, e.ampCard), e.footer);
  }

  private updateStatus(s: SimState): void {
    this.element.classList.toggle('stale', s.status.state === 'running' || s.status.state === 'scheduled');
  }

  private currentView(s: SimState): View3 | null {
    const r = s.result;
    const d = s.debug;
    if (d.active && d.data && d.data.steps[d.index]) {
      const step = d.data.steps[d.index];
      return {
        entries: step.probabilities,
        other: step.probabilities_other,
        truncated: step.probabilities_truncated,
        colorByPhase: !!step.amplitudes,
        shots: null,
        register: 'cúbits',
        bloch: step.bloch,
        amplitudes: step.amplitudes,
        label: `${step.index < 0 ? 'Estado inicial' : `Paso ${step.index + 1} de ${d.data.steps.length - 1}`} · ${step.index < 0 ? 'antes de la primera columna' : step.label}`,
      };
    }
    if (!r) return null;
    const state = r.state;
    let entries = r.histogram?.entries ?? [];
    let other = r.histogram?.other ?? 0;
    let truncated = r.histogram?.truncated ?? false;
    let register = r.histogram?.register === 'clbits' ? 'bits clásicos' : 'cúbits';
    let colorByPhase = r.mode === 'statevector' && !!state?.amplitudes;
    if (r.mode === 'statevector' && this.histMode === 'clbits' && r.classical) {
      entries = r.classical.entries;
      other = r.classical.other;
      truncated = r.classical.truncated;
      register = 'bits clásicos';
      colorByPhase = false;
    }
    const label = r.mode === 'shots'
      ? `${r.shots?.shots ?? 0} disparos · método ${r.shots?.method ?? ''}`
      : state?.kind === 'mixed' ? `Estado exacto (mixto, pureza ${trimNum(state.purity, 3)})` : 'Estado exacto (vector de estado)';
    return {
      entries, other, truncated, colorByPhase, shots: r.histogram?.shots ?? null, register,
      bloch: state?.bloch ?? [], amplitudes: state?.amplitudes ?? null, label,
    };
  }

  private update(s: SimState): void {
    const r = s.result;
    const v = this.currentView(s);
    this.els.empty.hidden = !!v;
    for (const k of ['dominant', 'histCard', 'blochCard', 'ampCard']) this.els[k].hidden = !v;
    if (!v) {
      this.els.analysis.hidden = true;
      clear(this.els.head);
      return;
    }
    this.renderHead(s, v);
    this.renderDominant(s, v);
    this.renderHistCard(s, v);
    const debugIndex = s.debug.active && s.debug.data ? s.debug.index : -2;
    const fromInitial = !s.debug.active && r !== this.lastResult && !s.continuous;
    const quick = s.continuous || (s.debug.active && debugIndex !== this.lastStep);
    this.renderBloch(v.bloch, r?.bloch_initial ?? [], fromInitial, quick);
    this.lastResult = r;
    this.lastStep = debugIndex;
    this.renderAmplitudes(s, v);
    const analysis = s.debug.active ? null : renderAnalysis(r?.analysis);
    this.els.analysis.hidden = !analysis;
    clear(this.els.analysis);
    if (analysis) {
      this.els.analysis.append(h('div', { class: 'card-head' }, h('h3', null, r?.analysis?.title ?? 'Análisis')), analysis);
    }
    this.renderFooter(s);
  }

  private renderHead(s: SimState, v: View3): void {
    clear(this.els.head);
    this.els.head.append(
      h('h2', null, s.debug.active ? 'Depurador paso a paso' : 'Resultados'),
      h('span', { class: 'chip' }, v.label),
    );
  }

  private renderDominant(s: SimState, v: View3): void {
    const el = this.els.dominant;
    clear(el);
    const best = v.entries.reduce<ProbEntry | null>((acc, e) => (!acc || e.p > acc.p ? e : acc), null);
    el.append(h('div', { class: 'card-head' }, h('h3', null, 'Estado dominante')));
    if (!best) {
      el.append(h('p', { class: 'muted' }, 'Sin datos'));
      return;
    }
    const ring = h('div', { class: 'prob-ring', style: { background: `conic-gradient(var(--accent) ${best.p * 360}deg, var(--panel-3) 0)` } },
      h('div', { class: 'prob-ring-in' }, h('span', null, `${(best.p * 100).toFixed(best.p > 0.9995 ? 0 : 1)}`), h('small', null, '%')));
    const len = best.state.length;
    const size = len <= 4 ? '' : len <= 7 ? 'mid' : len <= 11 ? 'small' : 'tiny';
    el.append(
      h('div', { class: 'dominant-row' },
        h('div', { class: `dominant-ket math ${size}` }, ket(best.state)),
        ring,
      ),
      h('p', { class: 'soft' },
        best.count !== undefined ? `${best.count} de ${v.shots} disparos en ${v.register}` : `Probabilidad ${fmtProb(best.p)} sobre los ${v.register}`),
      h('p', { class: 'hint' }, 'Orden de Qiskit: el bit de la derecha corresponde a q0 (o c0).'),
    );
    const r = s.result;
    if (r?.state && r.state.kind === 'mixed' && !s.debug.active) {
      el.append(h('p', { class: 'hint' }, `Estado mixto: pureza Tr(ρ²) = ${trimNum(r.state.purity, 3)}.`));
    }
  }

  private renderHistCard(s: SimState, v: View3): void {
    const card = this.els.histCard;
    clear(card);
    const r = s.result;
    const head = h('div', { class: 'card-head' }, h('h3', null, 'Probabilidades'), h('div', { class: 'grow' }));
    if (v.colorByPhase) head.append(phaseLegend());
    if (!s.debug.active && r?.mode === 'statevector' && r.classical) {
      const seg = h('div', { class: 'seg' },
        h('button', { 'aria-pressed': this.histMode === 'qubits' ? 'true' : 'false', onclick: () => { this.histMode = 'qubits'; this.update(this.ctrl.store.get()); } }, 'Cúbits'),
        h('button', { 'aria-pressed': this.histMode === 'clbits' ? 'true' : 'false', onclick: () => { this.histMode = 'clbits'; this.update(this.ctrl.store.get()); } }, 'Bits clásicos'),
      );
      head.append(seg);
    }
    card.append(head, this.els.hist);
    this.lastHist = v;
    this.renderHistogramOnly();
  }

  private lastHist: View3 | null = null;

  private renderHistogramOnly(): void {
    const v = this.lastHist;
    if (!v) return;
    renderHistogram(this.els.hist, v.entries, {
      colorByPhase: v.colorByPhase,
      shots: v.shots,
      other: v.other,
      truncated: v.truncated,
      registerLabel: v.register,
    });
  }

  private ensureSpheres(n: number): void {
    const narrow = window.matchMedia('(max-width: 760px)').matches;
    const size = narrow ? (n <= 1 ? 156 : 128) : n <= 4 ? 156 : n <= 10 ? 132 : 112;
    while (this.spheres.length > n) {
      const s = this.spheres.pop()!;
      s.sphere.destroy();
      s.card.remove();
    }
    while (this.spheres.length < n) {
      const q = this.spheres.length;
      const canvas = h('canvas', { 'aria-label': `Esfera de Bloch del cúbit q${q}`, role: 'img' }) as HTMLCanvasElement;
      const info = h('div', { class: 'bloch-info' });
      const card = h('figure', { class: 'bloch-item' }, canvas, h('figcaption', null, h('strong', null, `q${q}`), info));
      this.els.blochGrid.appendChild(card);
      const sphere = new BlochSphere(canvas, size, this.view);
      sphere.onViewChange = (view) => {
        this.view = view;
        if (this.syncViews) this.spheres.forEach((o) => o.sphere !== sphere && o.sphere.setView(view));
      };
      this.spheres.push({ sphere, card, info });
    }
    this.spheres.forEach((s) => {
      if (s.sphere.canvas.width !== Math.round(size * Math.min(window.devicePixelRatio || 1, 2))) s.sphere.resize(size);
    });
  }

  private renderBloch(bloch: BlochVector[], initial: BlochVector[], fromInitial: boolean, quick: boolean): void {
    this.ensureSpheres(bloch.length);
    bloch.forEach((b, q) => {
      const s = this.spheres[q];
      const target = { x: b.x, y: b.y, z: b.z };
      if (fromInitial && initial[q]) {
        s.sphere.setVector(target, { from: { x: initial[q].x, y: initial[q].y, z: initial[q].z }, duration: 850 });
      } else {
        s.sphere.setVector(target, { duration: quick ? 260 : 500 });
      }
      clear(s.info);
      const mixed = b.r < 0.999;
      s.info.append(
        h('span', { class: 'mono' }, `θ ${fmtAngle(b.theta)} · φ ${fmtAngle(b.phi)}`),
        h('span', { class: 'mono soft' }, `P(1) ${fmtProb(b.p1)}`),
        h('span', { class: 'purity', title: `Pureza del cúbit ${trimNum(b.purity, 3)} · entropía ${trimNum(b.entropy, 3)} bits` },
          h('i', { style: { width: `${Math.max(0, Math.min(1, (b.purity - 0.5) / 0.5)) * 100}%` } })),
      );
      if (mixed) s.info.append(h('span', { class: 'hint' }, `|r| = ${trimNum(b.r, 3)}`));
    });
  }

  private animateFromInitial(): void {
    const s = this.ctrl.store.get();
    const v = this.currentView(s);
    if (!v) return;
    const init = s.result?.bloch_initial ?? [];
    v.bloch.forEach((b, q) => {
      const from = init[q] ?? { x: 0, y: 0, z: 1 };
      this.spheres[q]?.sphere.setVector({ x: b.x, y: b.y, z: b.z }, { from: { x: from.x, y: from.y, z: from.z }, duration: 1000 });
    });
  }

  private renderAmplitudes(s: SimState, v: View3): void {
    const card = this.els.ampCard;
    clear(card);
    const r = s.result;
    const head = h('div', { class: 'card-head' }, h('h3', null, 'Amplitudes'), h('div', { class: 'grow' }));
    let amps = v.amplitudes;
    let note: string | null = null;
    const branches = !s.debug.active ? r?.state?.branches ?? [] : [];
    if (!amps && branches.length) {
      if (this.branchIndex >= branches.length) this.branchIndex = 0;
      const sel = h('select', { class: 'field', 'aria-label': 'Rama clásica' }) as HTMLSelectElement;
      branches.forEach((b, i) => sel.appendChild(h('option', { value: String(i), selected: i === this.branchIndex }, `${b.label} · ${(b.probability * 100).toFixed(1)} %`)));
      sel.addEventListener('change', () => {
        this.branchIndex = Number(sel.value);
        this.renderAmplitudes(this.ctrl.store.get(), v);
      });
      head.append(h('label', { class: 'branch-pick' }, h('span', { class: 'muted' }, 'Rama'), sel));
      amps = branches[this.branchIndex].amplitudes;
      note = 'El circuito mide a mitad de camino: cada resultado clásico deja un estado condicionado distinto (rama). Selecciona una rama para ver sus amplitudes.';
    }
    if (!amps) {
      card.append(head, h('p', { class: 'muted amp-mixed' },
        s.debug.active ? 'Con ruido o mediciones el estado es mixto en este paso: consulta las probabilidades y las esferas de Bloch.'
          : `Estado mixto (pureza ${trimNum(r?.state?.purity ?? 0, 3)}): no existe un único vector de amplitudes. Las probabilidades y las esferas de Bloch describen el estado.`));
      return;
    }
    const fixBox = h('input', { type: 'checkbox', checked: this.fixPhase }) as HTMLInputElement;
    fixBox.addEventListener('change', () => {
      this.fixPhase = fixBox.checked;
      this.renderAmplitudes(this.ctrl.store.get(), v);
    });
    const sortBox = h('input', { type: 'checkbox', checked: this.sortByProb }) as HTMLInputElement;
    sortBox.addEventListener('change', () => {
      this.sortByProb = sortBox.checked;
      this.renderAmplitudes(this.ctrl.store.get(), v);
    });
    head.append(h('label', { class: 'check', title: 'Multiplica por una fase global para que la mayor amplitud sea real y positiva' }, fixBox, 'Fijar fase global'),
      h('label', { class: 'check' }, sortBox, 'Ordenar por P'));
    let list = [...amps];
    if (this.fixPhase && list.length) {
      const ref = list.reduce((a, b) => (b.p > a.p ? b : a));
      const rot = -ref.phase;
      const c = Math.cos(rot), sn = Math.sin(rot);
      list = list.map((a) => {
        const re = a.re * c - a.im * sn;
        const im = a.re * sn + a.im * c;
        return { ...a, re, im, phase: Math.atan2(im, re) };
      });
    }
    if (this.sortByProb) list.sort((a, b) => b.p - a.p);
    const tbody = h('tbody');
    for (const a of list) {
      const zero = a.p < 1e-12;
      tbody.appendChild(h('tr', { class: zero ? 'zero' : '' },
        h('td', { class: 'math ketcell' }, ket(a.state)),
        h('td', { class: 'mono' }, fmtComplex(a.re, a.im, 4)),
        h('td', null, h('div', { class: 'pbar' }, h('i', { style: { width: `${a.p * 100}%`, background: zero ? 'transparent' : phaseColor(a.phase) } })), h('span', { class: 'mono soft' }, fmtProb(a.p))),
        h('td', { class: 'mono' }, zero ? '—' : h('span', { class: 'phase-cell' }, h('i', { class: 'swatch', style: { background: phaseColor(a.phase) } }), fmtAngle(a.phase))),
      ));
    }
    card.append(head);
    if (note) card.append(h('p', { class: 'hint' }, note));
    card.append(h('div', { class: 'table-scroll amp-scroll' },
      h('table', { class: 'data-table amp-table' },
        h('thead', null, h('tr', null, h('th', null, 'Estado'), h('th', null, 'Amplitud'), h('th', null, 'Probabilidad'), h('th', null, 'Fase'))),
        tbody)));
    if (r?.state?.amplitudes_truncated && !s.debug.active) card.append(h('p', { class: 'hint' }, `Se muestran las ${list.length} amplitudes de mayor magnitud de 2^${r.num_qubits}.`));
  }

  private renderFooter(s: SimState): void {
    const f = this.els.footer;
    clear(f);
    const r = s.result;
    if (!r) return;
    const chip = (t: string, title?: string) => h('span', { class: 'chip', title }, t);
    const chips = [
      chip(`profundidad ${r.stats.depth}`),
      chip(`${r.stats.gates} compuertas`),
      chip(`${r.stats.steps} pasos`),
      r.stats.noise_channels ? chip(`${r.stats.noise_channels} canales de ruido`) : null,
      r.stats.dynamic ? chip('circuito dinámico', 'Mediciones intermedias o control clásico') : null,
      chip(`${r.engine} · ${r.elapsed_ms.toFixed(1)} ms`, r.engine_version),
    ];
    f.append(...chips.filter((x): x is HTMLSpanElement => !!x));
    const warnings = [...(s.debug.active ? s.debug.data?.warnings ?? [] : r.warnings)];
    if (warnings.length) {
      f.append(h('ul', { class: 'warnings' }, ...warnings.map((w) => h('li', null, w))));
    }
  }
}
