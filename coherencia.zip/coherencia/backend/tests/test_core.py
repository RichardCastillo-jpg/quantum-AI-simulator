"""Pruebas del núcleo: expresiones, matrices, IR, medición diferida y ruido."""

import math

import numpy as np
import pytest

from app.core.analysis import bloch_pure
from app.core.deferred import defer_measurements
from app.core.expressions import ExpressionError, evaluate, free_variables
from app.core.gates import GATES, controlled_matrix, gate_matrix, is_unitary, modmul_matrix
from app.core.ir import CircuitError, build_program
from app.core.models import Circuit
from app.core.noise import controlled_kraus, depolarizing_kraus, thermal_kraus
from app.engines.reference import ReferenceEngine, apply_matrix

from .conftest import gate, measure


# --- Expresiones ------------------------------------------------------------------------
@pytest.mark.parametrize(
    "src,expected",
    [
        ("pi/4", math.pi / 4),
        ("2pi", 2 * math.pi),
        ("-2^2", -4),
        ("2^3^2", 2**9),
        ("3(pi/4)", 3 * math.pi / 4),
        ("sqrt(2)/2", math.sqrt(2) / 2),
        ("atan2(1, 1)", math.pi / 4),
        ("π - τ/2", 0.0),
        ("1e-3 * 2", 0.002),
        ("i*pi/8", 3 * math.pi / 8),
    ],
)
def test_expressions(src, expected):
    assert evaluate(src, {"i": 3}) == pytest.approx(expected)


@pytest.mark.parametrize("src", ["", "1/0", "pi +", "foo", "sin(1, 2)", "2 ** (", "__import__('os')", "1..2"])
def test_expression_errors(src):
    with pytest.raises(ExpressionError):
        evaluate(src)


def test_free_variables():
    assert free_variables("theta*2 + sin(phi) - pi") == {"theta", "phi"}


# --- Compuertas --------------------------------------------------------------------------
def test_all_gates_unitary():
    rng = np.random.default_rng(1)
    for spec in GATES.values():
        if spec.matrix is None:
            continue
        params = tuple(rng.uniform(-math.pi, math.pi, len(spec.params)))
        assert is_unitary(gate_matrix(spec.name, params)), spec.name


def test_square_roots():
    sx, sy, sw = (gate_matrix(g) for g in ("sx", "sy", "sw"))
    x, y = gate_matrix("x"), gate_matrix("y")
    assert np.allclose(sx @ sx, x)
    assert np.allclose(sy @ sy, y)
    assert np.allclose(sw @ sw, (x + y) / math.sqrt(2))
    assert np.allclose(gate_matrix("t") @ gate_matrix("t"), gate_matrix("s"))
    assert np.allclose(gate_matrix("s") @ gate_matrix("s"), gate_matrix("z"))


def test_u_reproduces_standard_gates():
    assert np.allclose(gate_matrix("u", (math.pi / 2, 0, math.pi)), gate_matrix("h"))
    assert np.allclose(gate_matrix("u", (math.pi, 0, math.pi)), gate_matrix("x"))


def test_controlled_matrix_is_cnot():
    cx = controlled_matrix(gate_matrix("x"), 1)
    # qargs = [control, target]; el control es el bit menos significativo.
    expected = np.array([[1, 0, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0], [0, 1, 0, 0]])
    assert np.allclose(cx, expected)


def test_modmul_is_permutation():
    mat = modmul_matrix(7, 15, 4)
    assert is_unitary(mat)
    assert mat[7, 1] == 1 and mat[(7 * 7) % 15, 7] == 1 and mat[15, 15] == 1


# --- Motor de referencia ------------------------------------------------------------------
def test_apply_matrix_against_kron():
    rng = np.random.default_rng(3)
    n = 4
    psi = rng.normal(size=16) + 1j * rng.normal(size=16)
    psi /= np.linalg.norm(psi)
    u = gate_matrix("u", (0.3, 1.1, -0.4))
    # Compuerta en q2: I ⊗ U ⊗ I ⊗ I en orden big-endian (q3 q2 q1 q0).
    full = np.kron(np.kron(np.eye(2), u), np.eye(4))
    assert np.allclose(apply_matrix(psi.copy(), n, u, [2]), full @ psi)
    # CNOT control q0 → objetivo q3.
    cx = controlled_matrix(gate_matrix("x"), 1)
    out = apply_matrix(psi.copy(), n, gate_matrix("x"), [3], [0])
    expected = psi.copy()
    for i in range(16):
        if i & 1:
            expected[i] = psi[i ^ 8]
    assert np.allclose(out, expected)
    assert cx.shape == (4, 4)


def test_anticontrol():
    eng = ReferenceEngine()
    prog = build_program(Circuit(num_qubits=2, ops=[gate(0, "x", [1], anticontrols=[0])]))
    psi, _ = eng.statevector(prog.ops, 2)
    assert abs(psi[0b10]) == pytest.approx(1)


# --- IR -------------------------------------------------------------------------------------
def test_nested_loops_unroll():
    circuit = Circuit(
        num_qubits=1,
        ops=[gate(0, "rz", [0], params=["i + 10*j"]), gate(1, "x", [0])],
        loops=[
            {"col_start": 0, "col_end": 1, "iterations": 3, "var": "j"},
            {"col_start": 0, "col_end": 0, "iterations": 2, "var": "i"},
        ],
    )
    prog = build_program(circuit)
    angles = [p.params[0] for p in prog.ops if p.name == "rz"]
    assert angles == [0, 1, 10, 11, 20, 21]
    assert sum(1 for p in prog.ops if p.name == "x") == 3
    assert len(prog.steps) == 9


def test_partial_loop_overlap_rejected():
    circuit = Circuit(
        num_qubits=1,
        ops=[gate(c, "x", [0]) for c in range(4)],
        loops=[{"col_start": 0, "col_end": 2}, {"col_start": 1, "col_end": 3}],
    )
    with pytest.raises(CircuitError):
        build_program(circuit)


def test_column_conflict_detected():
    circuit = Circuit(num_qubits=2, ops=[gate(0, "h", [0]), gate(0, "x", [1], controls=[0])])
    with pytest.raises(CircuitError) as err:
        build_program(circuit)
    assert "columna 0" in err.value.errors[0]["message"].lower()


def test_qubit_out_of_range_reports_op():
    circuit = Circuit(num_qubits=2, ops=[{**gate(0, "h", [5]), "id": "malo"}])
    with pytest.raises(CircuitError) as err:
        build_program(circuit)
    assert err.value.errors[0]["op_id"] == "malo"


class _Sub:
    def __init__(self, sid, nq, ops, params=(), loops=(), nc=0):
        self.id, self.name, self.num_qubits, self.num_clbits = sid, sid, nq, nc
        self.params, self.ops, self.loops = list(params), [Circuit.model_validate({"ops": [o]}).ops[0] for o in ops], list(loops)


def test_subcircuit_mapping_controls_and_params():
    lib = {"rot": _Sub("rot", 2, [gate(0, "ry", [0], params=["theta"]), gate(1, "x", [1], controls=[0])], params=["theta"])}
    circuit = Circuit(
        num_qubits=4,
        ops=[{"kind": "subcircuit", "col": 0, "subcircuit_id": "rot", "targets": [3, 1], "controls": [0],
              "sub_params": {"theta": "pi/3"}}],
    )
    prog = build_program(circuit, lib)
    ry, cx = prog.ops
    assert ry.qubits == (3,) and ry.controls == (0,) and ry.params[0] == pytest.approx(math.pi / 3)
    assert cx.qubits == (1,) and set(cx.controls) == {0, 3}


def test_subcircuit_recursion_detected():
    lib = {
        "a": _Sub("a", 1, [{"kind": "subcircuit", "col": 0, "subcircuit_id": "b", "targets": [0]}]),
        "b": _Sub("b", 1, [{"kind": "subcircuit", "col": 0, "subcircuit_id": "a", "targets": [0]}]),
    }
    circuit = Circuit(num_qubits=1, ops=[{"kind": "subcircuit", "col": 0, "subcircuit_id": "a", "targets": [0]}])
    with pytest.raises(CircuitError) as err:
        build_program(circuit, lib)
    assert "recursión" in err.value.errors[0]["message"]


def test_qft_macro_matches_dft():
    eng = ReferenceEngine()
    n = 4
    dim = 2**n
    for x in (0, 3, 9):
        prog = build_program(Circuit(num_qubits=n, initial_state=format(x, "04b"), ops=[gate(0, "qft", range(n))]))
        psi, _ = eng.statevector(prog.ops, n)
        expected = np.exp(2j * np.pi * x * np.arange(dim) / dim) / 4
        assert np.allclose(psi, expected)
        prog_inv = build_program(Circuit(num_qubits=n, initial_state=format(x, "04b"),
                                         ops=[gate(0, "qft", range(n)), gate(1, "iqft", range(n))]))
        back, _ = eng.statevector(prog_inv.ops, n)
        assert abs(back[x]) == pytest.approx(1)


# --- Medición diferida ------------------------------------------------------------------
def test_deferred_teleportation_exact():
    eng = ReferenceEngine()
    rng = np.random.default_rng(5)
    for _ in range(5):
        theta, phi = rng.uniform(0, math.pi), rng.uniform(-math.pi, math.pi)
        circuit = Circuit(
            num_qubits=3,
            num_clbits=2,
            ops=[
                gate(0, "u", [0], params=[theta, phi, 0]),
                gate(1, "h", [1]),
                gate(2, "x", [2], controls=[1]),
                gate(3, "x", [1], controls=[0]),
                gate(4, "h", [0]),
                measure(5, 0, 0),
                measure(5, 1, 1),
                gate(6, "x", [2], condition=[(1, 1)]),
                gate(7, "z", [2], condition=[(0, 1)]),
            ],
        )
        deferred = defer_measurements(build_program(circuit))
        assert deferred.num_total == 5
        psi, _ = eng.statevector(deferred.ops, deferred.num_total)
        b = bloch_pure(psi, 5, [2])[0]
        assert (b["x"], b["y"], b["z"]) == pytest.approx(
            (math.sin(theta) * math.cos(phi), math.sin(theta) * math.sin(phi), math.cos(theta)), abs=1e-9
        )


def test_reset_semantics(run):
    circuit = {"num_qubits": 1, "num_clbits": 1, "ops": [gate(0, "h", [0]), {"kind": "reset", "col": 1, "targets": [0]},
                                                          measure(2, 0, 0)]}
    exact = run(circuit)
    assert exact["classical"]["entries"][0]["p"] == pytest.approx(1)
    shots = run(circuit, "shots", shots=200, seed=1)
    assert shots["shots"]["counts"] == {"0": 200}


# --- Ruido ---------------------------------------------------------------------------------
@pytest.mark.parametrize("kraus", [depolarizing_kraus(0.1, 1), depolarizing_kraus(0.2, 2), thermal_kraus(40, 30, 1.5)])
def test_channels_are_cptp(kraus):
    dim = kraus[0].shape[0]
    total = sum(k.conj().T @ k for k in kraus)
    assert np.allclose(total, np.eye(dim))
    ctrl = controlled_kraus(kraus, 1, 1)
    total_c = sum(k.conj().T @ k for k in ctrl)
    assert np.allclose(total_c, np.eye(dim * 4))


def test_depolarizing_shrinks_bloch(run):
    circuit = {"num_qubits": 1, "ops": [gate(0, "h", [0])]}
    res = run(circuit, noise={"model": "depolarizing", "p1": 0.2})
    assert res["state"]["bloch"][0]["x"] == pytest.approx(0.8)
    assert res["state"]["kind"] == "mixed"


def test_thermal_relaxation_matches_analytic(run):
    t1, t2, t = 10.0, 8.0, 0.5
    circuit = {"num_qubits": 1, "initial_state": "1", "ops": [gate(k, "id", [0]) for k in range(10)]}
    res = run(circuit, noise={"model": "thermal", "t1": t1, "t2": t2, "time_1q": t})
    assert res["state"]["bloch"][0]["p1"] == pytest.approx(math.exp(-10 * t / t1))


def test_readout_error_exact_and_sampled(run):
    circuit = {"num_qubits": 1, "num_clbits": 1, "ops": [measure(0, 0, 0)]}
    exact = run(circuit, noise={"model": "depolarizing", "p1": 0, "p2": 0, "readout": 0.1})
    probs = {e["state"]: e["p"] for e in exact["classical"]["entries"]}
    assert probs["1"] == pytest.approx(0.1)
    sampled = run(circuit, "shots", shots=20000, seed=2, noise={"model": "depolarizing", "p1": 0, "p2": 0, "readout": 0.1})
    assert sampled["shots"]["counts"]["1"] / 20000 == pytest.approx(0.1, abs=0.01)


def test_invalid_t2_rejected(run):
    with pytest.raises(CircuitError):
        run({"num_qubits": 1, "ops": [gate(0, "x", [0])]}, noise={"model": "thermal", "t1": 10, "t2": 30})
