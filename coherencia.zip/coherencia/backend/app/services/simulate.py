"""Orquestación de una simulación: JSON → IR → motor → observables → análisis."""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, replace
from typing import Mapping

import numpy as np

from ..algorithms import analyze_algorithm
from ..config import Settings
from ..core.analysis import (
    amplitude_entries,
    bloch_basis,
    bloch_density,
    bloch_pure,
    branch_entries,
    classical_distribution,
    counts_to_probabilities,
    dominant_branch_state,
    marginal_low,
    probability_entries,
    purity_pure_reduced,
    reduce_density,
)
from ..core.deferred import DeferredProgram, UnsupportedExact, defer_measurements
from ..core.ir import CircuitError, Prim, Program, build_program
from ..core.models import Circuit, SimRequest
from ..core.noise import insert_noise


@dataclass
class StateView:
    kind: str  # pure | mixed
    n: int
    n_total: int
    probs: np.ndarray  # sobre los cúbits originales
    classical: np.ndarray | None
    bloch: list[dict]
    purity: float
    psi: np.ndarray | None = None  # estado reducido puro (si existe)
    deferred: DeferredProgram | None = None
    psi_ext: np.ndarray | None = None
    rho: np.ndarray | None = None


def check_limits(circuit: Circuit, settings: Settings) -> None:
    errors = []
    if circuit.num_qubits > settings.max_qubits:
        errors.append(f"El servidor admite hasta {settings.max_qubits} cúbits (QSIM_MAX_QUBITS)")
    if circuit.num_clbits > settings.max_clbits:
        errors.append(f"El servidor admite hasta {settings.max_clbits} bits clásicos")
    if errors:
        raise CircuitError("Circuito demasiado grande", [{"op_id": None, "message": e} for e in errors])


def _readout(req: SimRequest) -> float:
    noise = req.config.noise
    return noise.readout if noise.model != "none" else 0.0


def prepare(req: SimRequest, library: Mapping, settings: Settings) -> tuple[Program, Program, float]:
    check_limits(req.circuit, settings)
    prog = build_program(req.circuit, library, settings.max_ops)
    noisy = insert_noise(prog, req.config.noise)
    return prog, noisy, _readout(req)


def compute_state(engine, noisy: Program, ideal: Program, readout: float, settings: Settings,
                  warnings: list[str]) -> StateView | None:
    try:
        deferred = defer_measurements(noisy, readout)
    except UnsupportedExact as exc:
        warnings.append(exc.errors[0]["message"] if exc.errors else exc.message)
        return None
    n = noisy.num_qubits
    n_total = deferred.num_total
    if deferred.num_ancillas:
        warnings.append(
            f"Medición diferida: {deferred.num_ancillas} cúbit(s) auxiliar(es) representan las mediciones "
            "intermedias y reinicios para obtener la estadística exacta."
        )
    if deferred.has_channels and n_total > settings.max_density_qubits:
        warnings.append(
            f"El estado exacto con ruido (matriz densidad) se limita a {settings.max_density_qubits} cúbits; "
            "se muestra el estado ideal sin ruido."
        )
        deferred = defer_measurements(ideal, 0.0)
        n_total = deferred.num_total
    if n_total > settings.max_qubits:
        warnings.append(f"El estado completo necesita {n_total} cúbits y el límite es {settings.max_qubits}.")
        return None
    if deferred.has_channels:
        rho, _ = engine.density_matrix(deferred.ops, n_total)
        probs_total = np.clip(np.real(np.diag(rho)), 0.0, None)
        reduced = reduce_density(rho, n, n_total)
        purity = float(np.sum(np.abs(reduced) ** 2).real)
        bloch = bloch_density(rho, n_total, range(n))
        classical = classical_distribution(probs_total, n_total, deferred.clbit_sources, deferred.terminal_readout, readout)
        probs = marginal_low(probs_total, n_total, n)
        return StateView("mixed", n, n_total, probs / max(probs.sum(), 1e-300), classical, bloch, purity,
                         deferred=deferred, rho=rho)
    psi, _ = engine.statevector(deferred.ops, n_total)
    probs_total = np.abs(psi) ** 2
    purity = purity_pure_reduced(psi, n, n_total)
    bloch = bloch_pure(psi, n_total, range(n))
    classical = classical_distribution(probs_total, n_total, deferred.clbit_sources, deferred.terminal_readout, readout)
    probs = marginal_low(probs_total, n_total, n)
    pure = purity > 1 - 1e-9
    reduced_psi = dominant_branch_state(psi, n, n_total) if pure else None
    return StateView("pure" if pure else "mixed", n, n_total, probs, classical, bloch, purity, psi=reduced_psi,
                     deferred=deferred, psi_ext=psi)


def _state_payload(view: StateView, opts) -> dict:
    entries, other, truncated = probability_entries(view.probs, view.n, opts.max_probabilities)
    payload = {
        "kind": view.kind,
        "purity": view.purity,
        "probabilities": entries,
        "probabilities_other": other,
        "probabilities_truncated": truncated,
        "bloch": view.bloch,
        "num_ancillas": view.n_total - view.n,
        "amplitudes": None,
        "amplitudes_truncated": False,
        "branches": [],
    }
    if view.psi is not None:
        amps, amps_trunc = amplitude_entries(view.psi, view.n, opts.max_amplitudes)
        payload["amplitudes"] = amps
        payload["amplitudes_truncated"] = amps_trunc
        phase_of = {a["state"]: a["phase"] for a in amps}
        for e in entries:
            if e["state"] in phase_of:
                e["phase"] = phase_of[e["state"]]
    elif view.psi_ext is not None and view.deferred is not None and view.deferred.only_measure_ancillas:
        payload["branches"] = branch_entries(view.psi_ext, view.n, view.n_total, view.deferred.ancillas, 16, 64)
    return payload


def _implicit_measurement(prog: Program) -> Program:
    n, m = prog.num_qubits, prog.num_clbits
    last_step = prog.steps[-1].index if prog.steps else 0
    ops = list(prog.ops)
    for q in range(n):
        ops.append(Prim("measure", "measure", qubits=(q,), clbit=m + q, step=last_step, source=None))
    return replace(prog, ops=ops, num_clbits=m + n)


def compute_shots(engine, noisy: Program, ideal: Program, req: SimRequest, readout: float, settings: Settings,
                  warnings: list[str]) -> dict:
    cfg, opts = req.config, req.options
    shots = min(cfg.shots, settings.max_shots)
    if shots < cfg.shots:
        warnings.append(f"Se limitaron los disparos a {settings.max_shots} (QSIM_MAX_SHOTS).")
    memory = bool(opts.memory and shots <= settings.max_memory_shots)
    if opts.memory and not memory:
        warnings.append(f"La memoria por disparo solo está disponible hasta {settings.max_memory_shots} disparos.")
    register = "clbits"
    prog = noisy
    if not ideal.has_measurements:
        prog = _implicit_measurement(noisy)
        register = "qubits"
        warnings.append("El circuito no tiene mediciones: se midieron todos los cúbits al final.")
    sample = engine.sample(prog, shots, cfg.seed, readout, memory, settings.max_density_qubits)
    counts = sample.counts
    mem = sample.memory
    width = prog.num_clbits
    if register == "qubits":
        n = noisy.num_qubits
        merged: dict[str, int] = {}
        for key, val in counts.items():
            k = key.zfill(width)[:n]
            merged[k] = merged.get(k, 0) + val
        counts = merged
        width = n
        if mem is not None:
            mem = [s.zfill(prog.num_clbits)[:n] for s in mem]
    else:
        counts = {key.zfill(width): val for key, val in counts.items()}
    total = sum(counts.values()) or 1
    ordered = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    entries = [{"state": k, "p": v / total, "count": v} for k, v in ordered]
    if width <= 6:
        present = {e["state"] for e in entries}
        for i in range(1 << width):
            key = format(i, f"0{width}b") if width else ""
            if key not in present:
                entries.append({"state": key, "p": 0.0, "count": 0})
        entries.sort(key=lambda e: e["state"])
    limit = opts.max_probabilities
    truncated = len(entries) > limit
    shown = entries[:limit] if truncated else entries
    other = sum(e["p"] for e in entries[limit:]) if truncated else 0.0
    return {
        "shots": shots,
        "register": register,
        "width": width,
        "counts": dict(ordered[:4096]),
        "entries": shown,
        "other": other,
        "truncated": truncated,
        "memory": mem,
        "method": sample.method,
    }


def simulate(req: SimRequest, library: Mapping, engine, settings: Settings) -> dict:
    t0 = time.perf_counter()
    prog, noisy, readout = prepare(req, library, settings)
    warnings = list(prog.warnings)
    circuit, cfg, opts = req.circuit, req.config, req.options
    n, m = circuit.num_qubits, circuit.num_clbits
    init_bits = circuit.initial_state or "0" * n

    view = None
    if cfg.mode == "statevector" or opts.include_state:
        view = compute_state(engine, noisy, prog, readout, settings, warnings)

    shots_payload = compute_shots(engine, noisy, prog, req, readout, settings, warnings) if cfg.mode == "shots" else None

    state_payload = _state_payload(view, opts) if view is not None else None
    classical_payload = None
    if view is not None and view.classical is not None and m > 0 and prog.has_measurements:
        c_entries, c_other, c_trunc = probability_entries(view.classical, m, opts.max_probabilities)
        classical_payload = {"entries": c_entries, "other": c_other, "truncated": c_trunc, "width": m}

    if shots_payload is not None:
        histogram = {
            "source": "counts",
            "register": shots_payload["register"],
            "width": shots_payload["width"],
            "entries": shots_payload["entries"],
            "other": shots_payload["other"],
            "truncated": shots_payload["truncated"],
            "shots": shots_payload["shots"],
        }
    elif state_payload is not None:
        histogram = {
            "source": "state",
            "register": "qubits",
            "width": n,
            "entries": state_payload["probabilities"],
            "other": state_payload["probabilities_other"],
            "truncated": state_payload["probabilities_truncated"],
            "shots": None,
        }
    else:
        histogram = None

    dominant = None
    if histogram and histogram["entries"]:
        best = max(histogram["entries"], key=lambda e: e["p"])
        dominant = {"state": best["state"], "p": best["p"], "register": histogram["register"],
                    "count": best.get("count")}

    context = {
        "circuit": circuit,
        "program": prog,
        "view": view,
        "shots": shots_payload,
        "engine": engine,
        "settings": settings,
        "noise": cfg.noise,
        "mode": cfg.mode,
    }
    analysis = None
    algo = (circuit.meta or {}).get("algorithm")
    if algo:
        try:
            analysis = analyze_algorithm(algo, context)
        except Exception as exc:  # el análisis nunca debe romper la simulación
            warnings.append(f"No se pudo completar el análisis de «{algo}»: {exc}")

    noise_channels = sum(1 for p in noisy.ops if p.kind == "channel")
    return {
        "ok": True,
        "engine": engine.name,
        "engine_version": engine.version,
        "mode": cfg.mode,
        "num_qubits": n,
        "num_clbits": m,
        "initial_state": init_bits,
        "bloch_initial": bloch_basis(init_bits),
        "stats": {
            "depth": prog.depth(),
            "gates": prog.gate_count,
            "ops": prog.count_ops(),
            "steps": len(prog.steps),
            "dynamic": prog.is_dynamic,
            "noise_channels": noise_channels,
        },
        "state": state_payload,
        "classical": classical_payload,
        "shots": shots_payload,
        "histogram": histogram,
        "dominant": dominant,
        "analysis": analysis,
        "warnings": warnings,
        "elapsed_ms": round((time.perf_counter() - t0) * 1000, 2),
    }


def simulate_steps(req: SimRequest, library: Mapping, engine, settings: Settings) -> dict:
    """Depurador temporal: estado tras cada columna del circuito (con ciclos desenrollados)."""
    t0 = time.perf_counter()
    prog, noisy, readout = prepare(req, library, settings)
    warnings = list(prog.warnings)
    n = prog.num_qubits
    if len(prog.steps) > settings.max_steps:
        raise CircuitError(
            "Demasiados pasos para el depurador",
            [{"op_id": None, "message": f"El circuito tiene {len(prog.steps)} pasos; el depurador admite {settings.max_steps}."}],
        )
    try:
        deferred = defer_measurements(noisy, readout)
    except UnsupportedExact as exc:
        raise CircuitError("El depurador no admite este circuito", exc.errors) from exc
    n_total = deferred.num_total
    use_density = deferred.has_channels
    limit = settings.max_step_qubits if not use_density else min(settings.max_step_qubits, settings.max_density_qubits)
    if n_total > limit:
        if use_density and deferred.num_total <= settings.max_step_qubits:
            warnings.append("Con ruido el depurador muestra la evolución ideal (sin ruido) por tamaño.")
            deferred = defer_measurements(prog, 0.0)
            n_total = deferred.num_total
            use_density = False
        else:
            raise CircuitError(
                "Circuito demasiado grande para el depurador",
                [{"op_id": None, "message": f"El depurador admite hasta {limit} cúbits (incluidos los auxiliares); este necesita {n_total}."}],
            )
    num_steps = len(prog.steps)
    if use_density:
        _, snaps = engine.density_matrix(deferred.ops, n_total, num_steps, snapshots=True)
    else:
        _, snaps = engine.statevector(deferred.ops, n_total, num_steps, snapshots=True)

    out_steps = []
    labels = {s.index: s for s in prog.steps}
    for s in [-1] + list(range(num_steps)):
        snap = snaps.get(s)
        if snap is None:
            continue
        if use_density:
            probs = marginal_low(np.clip(np.real(np.diag(snap)), 0, None), n_total, n)
            bloch = bloch_density(snap, n_total, range(n))
            reduced = reduce_density(snap, n, n_total)
            purity = float(np.sum(np.abs(reduced) ** 2).real)
            amps = None
        else:
            probs = marginal_low(np.abs(snap) ** 2, n_total, n)
            bloch = bloch_pure(snap, n_total, range(n))
            purity = purity_pure_reduced(snap, n, n_total)
            amps = None
            if purity > 1 - 1e-9 and n <= 6:
                amps, _ = amplitude_entries(dominant_branch_state(snap, n, n_total), n, 64)
        entries, other, truncated = probability_entries(probs, n, 32)
        if amps:
            phase_of = {a["state"]: a["phase"] for a in amps}
            for e in entries:
                if e["state"] in phase_of:
                    e["phase"] = phase_of[e["state"]]
        info = labels.get(s)
        out_steps.append(
            {
                "index": s,
                "label": "Estado inicial" if s < 0 else info.label,
                "col": None if s < 0 else info.col,
                "ops": [] if s < 0 else info.ops,
                "bloch": bloch,
                "purity": purity,
                "probabilities": entries,
                "probabilities_other": other,
                "probabilities_truncated": truncated,
                "amplitudes": amps,
            }
        )
    return {
        "ok": True,
        "engine": engine.name,
        "num_qubits": n,
        "noisy": use_density,
        "steps": out_steps,
        "warnings": warnings,
        "elapsed_ms": round((time.perf_counter() - t0) * 1000, 2),
    }
