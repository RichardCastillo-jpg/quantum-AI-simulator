import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.config import Settings  # noqa: E402
from app.core.models import SimRequest  # noqa: E402
from app.engines.reference import ReferenceEngine  # noqa: E402
from app.services.simulate import simulate  # noqa: E402


@pytest.fixture()
def settings(tmp_path):
    return Settings(engine="reference", data_dir=tmp_path, seed_library=True)


@pytest.fixture(scope="session")
def ref_engine():
    return ReferenceEngine()


@pytest.fixture()
def run(ref_engine, settings):
    def _run(circuit, mode="statevector", library=None, engine=None, options=None, **config):
        req = SimRequest.model_validate(
            {"circuit": circuit, "config": {"mode": mode, **config}, "options": options or {}}
        )
        return simulate(req, library or {}, engine or ref_engine, settings)

    return _run


def gate(col, name, targets, controls=(), params=(), anticontrols=(), condition=None, **extra):
    op = {
        "kind": "gate",
        "gate": name,
        "col": col,
        "targets": list(targets),
        "controls": list(controls),
        "anticontrols": list(anticontrols),
        "params": list(params),
    }
    if condition:
        op["condition"] = [{"clbit": c, "value": v} for c, v in condition]
    op.update(extra)
    return op


def measure(col, q, c):
    return {"kind": "measure", "col": col, "targets": [q], "clbits": [c]}
