"""Validación cruzada Qiskit Aer ↔ motor de referencia NumPy (se ejecuta en el contenedor)."""

import math

import numpy as np
import pytest

pytest.importorskip("qiskit")
pytest.importorskip("qiskit_aer")

from qiskit.quantum_info import Operator  # noqa: E402

from app.algorithms import build_preset  # noqa: E402
from app.core.deferred import defer_measurements  # noqa: E402
from app.core.gates import GATES, gate_matrix  # noqa: E402
from app.core.ir import build_program  # noqa: E402
from app.core.models import Circuit, NoiseConfig  # noqa: E402
from app.core.noise import insert_noise  # noqa: E402
from app.engines.qiskit_engine import QiskitEngine, _single_native  # noqa: E402
from app.engines.reference import ReferenceEngine  # noqa: E402

from .conftest import gate, measure  # noqa: E402


@pytest.fixture(scope="module")
def engines():
    return QiskitEngine(), ReferenceEngine()


def test_gate_matrices_match_qiskit():
    rng = np.random.default_rng(0)
    for spec in GATES.values():
        if spec.matrix is None:
            continue
        params = tuple(rng.uniform(-3, 3, len(spec.params)))
        native = _single_native(spec.name, params)
        if native is None:
            continue
        assert np.allclose(Operator(native).data, gate_matrix(spec.name, params)), spec.name


def _random_circuit(rng, n, depth):
    names = ["h", "x", "y", "z", "s", "sdg", "t", "tdg", "sx", "sxdg", "sy", "sw", "rx", "ry", "rz", "p", "u",
             "swap", "iswap", "rxx", "ryy", "rzz", "fsim"]
    ops = []
    for col in range(depth):
        name = rng.choice(names)
        spec = GATES[name]
        k = spec.num_targets
        qubits = list(rng.permutation(n))
        targets = [int(q) for q in qubits[:k]]
        rest = [int(q) for q in qubits[k:]]
        n_ctrl = int(rng.integers(0, min(3, len(rest)) + 1))
        controls = rest[:n_ctrl]
        anti = rest[n_ctrl:n_ctrl + int(rng.integers(0, 2))] if len(rest) > n_ctrl else []
        params = [float(v) for v in rng.uniform(-math.pi, math.pi, len(spec.params))]
        ops.append(gate(col, name, targets, controls=controls, anticontrols=anti, params=params))
    return Circuit(num_qubits=n, ops=ops)


def test_random_circuits_agree(engines):
    qk, ref = engines
    rng = np.random.default_rng(42)
    for _ in range(25):
        prog = build_program(_random_circuit(rng, 5, 18))
        a, _ = qk.statevector(prog.ops, 5)
        b, _ = ref.statevector(prog.ops, 5)
        assert np.allclose(a, b, atol=1e-8)


def test_modmul_and_qft_agree(engines):
    qk, ref = engines
    circuit = Circuit.model_validate(build_preset("shor", {"N": 15, "a": 7, "t": 6}))
    deferred = defer_measurements(build_program(circuit))
    a, _ = qk.statevector(deferred.ops, deferred.num_total)
    b, _ = ref.statevector(deferred.ops, deferred.num_total)
    assert np.allclose(a, b, atol=1e-8)


def test_noise_density_matrices_agree(engines):
    qk, ref = engines
    rng = np.random.default_rng(7)
    for model in ("depolarizing", "thermal"):
        prog = insert_noise(build_program(_random_circuit(rng, 3, 10)),
                            NoiseConfig(model=model, p1=0.03, p2=0.08, t1=20, t2=15, time_1q=0.4, time_2q=1.2))
        a, _ = qk.density_matrix(prog.ops, 3)
        b, _ = ref.density_matrix(prog.ops, 3)
        assert np.allclose(a, b, atol=1e-8)


def test_dynamic_teleportation_shots(engines):
    qk, _ = engines
    circuit = Circuit.model_validate(build_preset("teleportation", {"theta": math.pi, "phi": 0}))
    # Con θ = π el estado enviado es |1⟩: medir q2 al final debe dar siempre 1.
    circuit.num_clbits = 3
    circuit.ops.append(Circuit.model_validate({"ops": [measure(8, 2, 2)]}).ops[0])
    prog = build_program(circuit)
    sample = qk.sample(prog, 500, 3, 0.0, False, 10)
    assert all(key[0] == "1" for key in sample.counts)


def test_snapshots(engines):
    qk, ref = engines
    prog = build_program(Circuit.model_validate(build_preset("ghz", {"n": 3})))
    deferred = defer_measurements(prog)
    _, s1 = qk.statevector(deferred.ops, deferred.num_total, len(prog.steps), True)
    _, s2 = ref.statevector(deferred.ops, deferred.num_total, len(prog.steps), True)
    assert set(s1) == set(s2)
    for key in s1:
        assert np.allclose(s1[key], s2[key])


def test_export_qasm(engines):
    qk, _ = engines
    prog = build_program(Circuit.model_validate(build_preset("teleportation", {})))
    out = qk.to_qasm(prog)
    assert out["qasm3"] and "if" in out["qasm3"]


# --- El código generado por el editor es Qiskit válido y equivalente -------------------------

def _generated_statevector(code: str) -> np.ndarray:
    from qiskit.quantum_info import Statevector

    namespace: dict = {}
    exec(compile(code, "<coherencia>", "exec"), namespace)  # noqa: S102 - código generado por nosotros
    return np.asarray(Statevector(namespace["qc"]).data)


def _all_gates_circuit() -> Circuit:
    ops, col = [], 0
    for spec in GATES.values():
        if spec.kind != "matrix":
            continue
        n = spec.num_targets or 1
        params = [0.3 + 0.2 * i for i in range(len(spec.params))]
        ops.append(gate(col, spec.name, list(range(n)), params=params))
        ops.append(gate(col + 1, spec.name, list(range(1, n + 1)), controls=[0], params=params))
        ops.append(gate(col + 2, spec.name, list(range(2, n + 2)), controls=[0], anticontrols=[1], params=params))
        col += 3
    ops.append(gate(col, "qft", [0, 1, 2]))
    ops.append(gate(col + 1, "iqft", [1, 2, 3], controls=[0]))
    ops.append(gate(col + 2, "x", [3], controls=[0, 1, 2]))
    ops.append(gate(col + 3, "p", [3], controls=[0, 1, 2], params=["pi/5"]))
    head = [gate(0, "h", [q]) for q in range(4)]
    for op in ops:
        op["col"] += 1
    return Circuit.model_validate({"num_qubits": 4, "ops": head + ops})


def test_generated_code_runs_in_real_qiskit(engines, tmp_path):
    from app.services.qiskit_code import circuit_to_code
    from app.storage.subcircuits import SubcircuitStore

    _, ref = engines
    library = SubcircuitStore(tmp_path).mapping()
    circuits = [_all_gates_circuit(), Circuit.model_validate(build_preset("qft", {}))]
    shor = Circuit.model_validate(build_preset("shor", {"N": "15", "a": 7, "t": 4}))
    circuits.append(shor.model_copy(update={"ops": [op for op in shor.ops if op.kind != "measure"],
                                            "num_clbits": 0}))
    for sid, sub in library.items():
        if not sub.num_clbits:
            circuits.append(Circuit.model_validate({
                "num_qubits": sub.num_qubits + 1,
                "ops": [gate(0, "h", [q]) for q in range(sub.num_qubits + 1)]
                + [{"kind": "subcircuit", "subcircuit_id": sid, "col": 1, "targets": list(range(sub.num_qubits)),
                    "controls": [sub.num_qubits], "sub_params": {p: 0.4 for p in sub.params}}],
            }))
    for circuit in circuits:
        code = circuit_to_code(circuit, library).code
        prog = build_program(circuit, library, 20000)
        sv = ref.statevector(prog.ops, prog.num_qubits)
        expected = np.asarray(sv[0] if isinstance(sv, tuple) else sv)
        assert np.allclose(_generated_statevector(code), expected, atol=1e-8), circuit.name
