"""Editor de código Qiskit: generación, interpretación segura e ida y vuelta exacta."""

import numpy as np
import pytest

from app.algorithms import build_preset
from app.core.expressions import evaluate
from app.core.ir import build_program
from app.core.models import Circuit, Op
from app.services.qiskit_code import CodeError, CodeRejected, circuit_to_code, code_to_circuit, parse_for_api
from app.storage.subcircuits import SubcircuitStore

PREAMBLE = "from qiskit import QuantumCircuit\n"


@pytest.fixture()
def library(tmp_path):
    return SubcircuitStore(tmp_path).mapping()


def probabilities(run, circuit, library=None):
    res = run(circuit if isinstance(circuit, dict) else circuit.model_dump(), library=library)
    return {e["state"]: round(e["p"], 6) for e in res["histogram"]["entries"] if e["p"] > 1e-9}


def statevector(ref_engine, circuit, library):
    prog = build_program(circuit, library, 20000)
    sv = ref_engine.statevector(prog.ops, prog.num_qubits)
    return np.asarray(sv[0] if isinstance(sv, tuple) else sv)


PRESET_CASES = [
    ("bell", {}), ("ghz", {}), ("teleportation", {}), ("deutsch", {"oracle": "balanced_not"}), ("grover", {}),
    ("bv", {}), ("qft", {}), ("rqc", {}), ("shor", {"N": "15", "a": 7, "t": 6}),
]


@pytest.mark.parametrize("key,params", PRESET_CASES)
def test_round_trip_presets(key, params, run, library):
    circuit = Circuit.model_validate(build_preset(key, params))
    code = circuit_to_code(circuit, library).code
    parsed = code_to_circuit(code, circuit.name).circuit
    assert parsed.num_qubits == circuit.num_qubits and parsed.num_clbits == circuit.num_clbits
    assert probabilities(run, parsed, library) == probabilities(run, circuit, library)


def test_round_trip_library_with_controls_and_params(ref_engine, library):
    for sid, sub in library.items():
        if sub.num_clbits:
            continue
        n = sub.num_qubits
        circuit = Circuit(
            num_qubits=n + 1,
            ops=[Op(gate="h", col=0, targets=[q]) for q in range(n + 1)]
            + [Op(kind="subcircuit", subcircuit_id=sid, col=1, targets=list(range(n)), controls=[n],
                  sub_params={p: 0.37 for p in sub.params})],
        )
        code = circuit_to_code(circuit, library).code
        assert f"def {code.split('def ')[1].split('(')[0]}(" in code  # subcircuito como función
        parsed = code_to_circuit(code).circuit
        assert np.allclose(statevector(ref_engine, parsed, library), statevector(ref_engine, circuit, library))


def test_loops_and_expressions_become_python():
    circuit = Circuit(
        num_qubits=2,
        ops=[Op(gate="rz", col=0, targets=[0], params=["i*π/8"]), Op(gate="p", col=1, targets=[1], params=["2^i"])],
        loops=[{"col_start": 0, "col_end": 1, "iterations": 3, "var": "i"}],
    )
    code = circuit_to_code(circuit).code
    assert "for i in range(3):" in code
    assert "qc.rz(i*pi/8, 0)" in code and "qc.p(2**i, 1)" in code
    parsed = code_to_circuit(code).circuit
    angles = [evaluate(op.params[0]) for op in parsed.ops if op.gate == "rz"]
    assert angles == pytest.approx([0, np.pi / 8, np.pi / 4])
    assert [op.params[0] for op in parsed.ops if op.gate == "rz"][1:] == ["pi/8", "pi/4"]


def test_registers_keep_labels():
    circuit = Circuit(num_qubits=3, num_clbits=1, qubit_labels=["c0", "c1", "anc"], clbit_labels=["m"],
                      ops=[Op(gate="h", col=0, targets=[0])])
    code = circuit_to_code(circuit).code
    assert "QuantumRegister(2, 'c')" in code
    parsed = code_to_circuit(code).circuit
    assert parsed.qubit_labels == ["c0", "c1", "anc"] and parsed.clbit_labels == ["m"]


def test_ibm_style_program(run):
    code = PREAMBLE.replace("\n", ", QuantumRegister, ClassicalRegister, transpile\n") + """
from qiskit_aer import AerSimulator
from qiskit.visualization import plot_histogram
qr = QuantumRegister(2, 'q')
cr = ClassicalRegister(2, 'c')
qc = QuantumCircuit(qr, cr)
qc.h(qr[0])
qc.cx(qr[0], qr[1])
qc.measure(qr, cr)
sim = AerSimulator()
counts = sim.run(transpile(qc, sim), shots=1000).result().get_counts()
print(counts)
plot_histogram(counts)
"""
    parsed = code_to_circuit(code)
    assert probabilities(run, parsed.circuit) == {"00": 0.5, "11": 0.5}
    assert any("ignoraron" in w for w in parsed.warnings)


def test_functions_loops_and_to_gate(run):
    code = PREAMBLE + """
import numpy as np
def oracle(n, marked):
    o = QuantumCircuit(n)
    for i, bit in enumerate(reversed(marked)):
        if bit == "0":
            o.x(i)
    o.h(n - 1)
    o.mcx(list(range(n - 1)), n - 1)
    o.h(n - 1)
    for i, bit in enumerate(reversed(marked)):
        if bit == "0":
            o.x(i)
    return o

def diffuser(n):
    d = QuantumCircuit(n)
    d.h(range(n)); d.x(range(n))
    d.h(n - 1); d.mcx(list(range(n - 1)), n - 1); d.h(n - 1)
    d.x(range(n)); d.h(range(n))
    return d

qc = QuantumCircuit(3)
qc.h(range(3))
for _ in range(int(np.floor(np.pi / 4 * np.sqrt(8)))):
    qc.append(oracle(3, "101").to_gate(), range(3))
    qc.compose(diffuser(3), inplace=True)
"""
    probs = probabilities(run, code_to_circuit(code).circuit)
    assert max(probs, key=probs.get) == "101" and probs["101"] > 0.94


@pytest.mark.parametrize("snippet,expected", [
    ("qc = QuantumCircuit(3)\nqc.h([1, 2])\nfrom qiskit.circuit.library import QFTGate\nqc.append(QFTGate(3), [0, 1, 2])",
     {"000": 0.5, "100": 0.5}),
    ("from qiskit.circuit.library import QFT\nqc = QuantumCircuit(3)\nqc.x(0)\nqc.append(QFT(3, do_swaps=False), range(3))\n"
     "qc.append(QFT(3, do_swaps=False).inverse(), range(3))", {"001": 1.0}),
    ("qc = QuantumCircuit(2, 1)\nqc.h(0)\nqc.measure(0, 0)\nwith qc.if_test((0, 1)) as else_:\n    qc.x(1)\nwith else_:\n    qc.h(1)",
     {"00": 0.25, "10": 0.25, "11": 0.5}),
    ("from qiskit.circuit.library import RYGate\nimport numpy as np\nqc = QuantumCircuit(3)\nqc.x(0)\nqc.ch(0, 1)\n"
     "qc.append(RYGate(np.pi/3).control(2, ctrl_state='01'), [0, 1, 2])\nqc.append(UnitaryGate([[0, 1], [1, 0]]), [2])",
     {"001": 0.125, "101": 0.375, "111": 0.5}),
    ("qc = QuantumCircuit(3)\nqc.initialize('101')", {"101": 1.0}),
])
def test_qiskit_features(snippet, expected, run):
    code = PREAMBLE + "from qiskit.circuit.library import UnitaryGate\n" + snippet
    assert probabilities(run, code_to_circuit(code).circuit) == expected


def test_unitary_matching_named_gates():
    code = PREAMBLE + "import numpy as np\nfrom qiskit.circuit.library import UnitaryGate\nqc = QuantumCircuit(1)\n" \
        "qc.append(UnitaryGate([[1, 0], [0, np.exp(1j*np.pi/4)]]), [0])"
    assert code_to_circuit(code).circuit.ops[0].gate == "t"


@pytest.mark.parametrize("code,line,fragment", [
    ("qc = QuantumCircuit(2\nqc.h(0)", 1, "sintaxis"),
    (PREAMBLE + "qc = QuantumCircuit(2)\nqc.cx(0, 5)", 3, "no existe"),
    (PREAMBLE + "qc = QuantumCircuit(2)\nqc.foo(0)", 3, "no está disponible"),
    (PREAMBLE + "qc = QuantumCircuit(1)\nwhile True:\n    pass", 3, "demasiado"),
    ("import os\nos.system('ls')", 1, "No se puede importar"),
    ("x = ().__class__.__bases__", 1, "privados"),
    ("__import__('os')", 1, "no está definido"),
    ("open('/etc/passwd')", 1, "no está definido"),
    ("x = [0] * (10**9)", 1, "demasiado grande"),
    ("x = 1", None, "No se encontró ningún circuito"),
])
def test_errors_and_sandbox(code, line, fragment):
    with pytest.raises(CodeError) as info:
        code_to_circuit(code)
    assert info.value.line == line
    assert fragment in info.value.message


def test_parse_for_api_maps_semantic_errors_to_lines(settings):
    code = PREAMBLE + "qc = QuantumCircuit(4)\nqc.h(0)\nqc.append(modmul_gate(3, 9, 4), [0, 1, 2, 3])\n"
    code = "def modmul_gate(a, N, n):\n    pass\n" + code
    with pytest.raises(CodeRejected) as info:
        parse_for_api(code, "x", {}, settings)
    assert info.value.detail["errors"][0]["line"] == 6
