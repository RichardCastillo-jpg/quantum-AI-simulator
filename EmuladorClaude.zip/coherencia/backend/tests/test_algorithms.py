"""Pruebas de los algoritmos precargados, del servicio de simulación y de la biblioteca."""

import math

import pytest

from app.algorithms import PRESETS, AlgorithmError, build_preset
from app.core.ir import CircuitError
from app.core.models import SimRequest, SubcircuitIn, SubcircuitPatch
from app.services.simulate import simulate_steps
from app.storage.subcircuits import ConflictError, SubcircuitStore

from .conftest import gate


def test_every_preset_builds_and_runs(run):
    for preset in PRESETS:
        params = {p["key"]: p["default"] for p in preset["params"]}
        if preset["key"] == "rqc":
            params.update({"n": 6, "cycles": 4})
        circuit = build_preset(preset["key"], params)
        res = run(circuit)
        assert res["ok"], preset["key"]
        res = run(circuit, "shots", shots=128, seed=4)
        assert sum(res["shots"]["counts"].values()) == 128


def test_teleportation_fidelity(run):
    res = run(build_preset("teleportation", {"theta": 2.0, "phi": -1.2}))
    assert res["analysis"]["fidelity"] == pytest.approx(1.0)
    noisy = run(build_preset("teleportation", {"theta": 2.0, "phi": -1.2}),
                noise={"model": "depolarizing", "p1": 0.02, "p2": 0.05})
    assert 0.5 < noisy["analysis"]["fidelity"] < 0.999


@pytest.mark.parametrize("oracle", ["const0", "const1", "balanced_id", "balanced_not"])
def test_deutsch(run, oracle):
    res = run(build_preset("deutsch", {"oracle": oracle}))
    assert res["analysis"]["correct"]


def test_grover_matches_theory(run):
    res = run(build_preset("grover", {"n": 4, "marked": "0110"}))
    assert res["analysis"]["p_marked"] == pytest.approx(res["analysis"]["p_theory"])
    assert res["analysis"]["p_marked"] > 0.95


@pytest.mark.parametrize("big_n,a", [(15, 7), (15, 2), (21, 2), (35, 3)])
def test_shor_finds_factors(run, big_n, a):
    t = 2 * big_n.bit_length()
    if t + big_n.bit_length() > 18:
        t = 18 - big_n.bit_length()
    res = run(build_preset("shor", {"N": big_n, "a": a, "t": t}))
    analysis = res["analysis"]
    assert analysis["factors"], analysis["summary"]
    p, q = analysis["factors"][0], big_n // analysis["factors"][0]
    assert p * q == big_n and 1 < p < big_n
    assert analysis["success_probability"] > 0.25


def test_shor_validation():
    with pytest.raises(AlgorithmError):
        build_preset("shor", {"N": 17})
    with pytest.raises(AlgorithmError):
        build_preset("shor", {"N": 15, "a": 5})


def test_rqc_xeb(run):
    circuit = build_preset("rqc", {"n": 8, "cycles": 12, "seed": 11})
    ideal = run(circuit)
    assert 0.6 < ideal["analysis"]["ideal_xeb"] < 1.4
    noisy = run(circuit, noise={"model": "depolarizing", "p1": 0.01, "p2": 0.04})
    assert noisy["analysis"]["fidelity_estimate"] < 0.6
    sampled = run(circuit, "shots", shots=6000, seed=9)
    assert sampled["analysis"]["fidelity_estimate"] == pytest.approx(1.0, abs=0.2)


def test_rqc_2d_columns_do_not_overlap():
    circuit = build_preset("rqc", {"n": 9, "cycles": 4, "topology": "2d", "rows": 3})
    spans = {}
    for op in circuit["ops"]:
        qs = op["targets"] + op.get("controls", [])
        lo, hi = min(qs), max(qs)
        for other in spans.get(op["col"], []):
            assert hi < other[0] or lo > other[1]
        spans.setdefault(op["col"], []).append((lo, hi))


def test_implicit_measurement(run):
    res = run({"num_qubits": 2, "ops": [gate(0, "x", [1])]}, "shots", shots=50, seed=1)
    assert res["histogram"]["register"] == "qubits"
    assert res["shots"]["counts"] == {"10": 50}


def test_memory_per_shot(run):
    res = run({"num_qubits": 1, "num_clbits": 1, "ops": [gate(0, "h", [0]), {"kind": "measure", "col": 1,
                                                                             "targets": [0], "clbits": [0]}]},
              "shots", shots=64, seed=3, options={"memory": True})
    assert len(res["shots"]["memory"]) == 64
    assert set(res["shots"]["memory"]) <= {"0", "1"}


def test_steps_debugger(ref_engine, settings):
    circuit = build_preset("bell", {})
    req = SimRequest.model_validate({"circuit": circuit, "config": {}})
    out = simulate_steps(req, {}, ref_engine, settings)
    assert [s["index"] for s in out["steps"]] == [-1, 0, 1, 2]
    final = out["steps"][-2]
    assert final["purity"] == pytest.approx(1)
    assert final["bloch"][0]["r"] == pytest.approx(0, abs=1e-9)  # entrelazado: vector de Bloch nulo


def test_amplitudes_and_phases(run):
    res = run({"num_qubits": 1, "ops": [gate(0, "h", [0]), gate(1, "s", [0])]})
    amps = {a["state"]: a for a in res["state"]["amplitudes"]}
    assert amps["1"]["phase"] == pytest.approx(math.pi / 2)
    assert amps["0"]["re"] == pytest.approx(1 / math.sqrt(2))


# --- Biblioteca de subcircuitos ---------------------------------------------------------------
def test_store_seed_and_crud(tmp_path):
    store = SubcircuitStore(tmp_path)
    seeded = store.list()
    assert len(seeded) >= 5
    sub = store.create(SubcircuitIn(name="Mi bloque", num_qubits=2, ops=[gate(0, "h", [0]), gate(1, "x", [1], controls=[0])]))
    assert store.get(sub.id).name == "Mi bloque"
    renamed = store.update(sub.id, SubcircuitPatch(name="Bloque Bell"))
    assert renamed.name == "Bloque Bell"
    # Persistencia: una nueva instancia lee lo guardado y no vuelve a sembrar.
    again = SubcircuitStore(tmp_path)
    assert again.get(sub.id).name == "Bloque Bell"
    store.delete("par-de-bell")
    assert len(SubcircuitStore(tmp_path).list()) == len(seeded)


def test_store_rejects_cycles_and_protects_dependents(tmp_path):
    store = SubcircuitStore(tmp_path, seed=False)
    inner = store.create(SubcircuitIn(name="Interno", num_qubits=1, ops=[gate(0, "h", [0])]))
    outer = store.create(SubcircuitIn(name="Externo", num_qubits=1, ops=[
        {"kind": "subcircuit", "col": 0, "subcircuit_id": inner.id, "targets": [0]}]))
    with pytest.raises(CircuitError):
        store.update(inner.id, SubcircuitPatch(ops=[{"kind": "subcircuit", "col": 0, "subcircuit_id": outer.id,
                                                      "targets": [0]}]))
    with pytest.raises(ConflictError):
        store.delete(inner.id)
    with pytest.raises(CircuitError):
        store.update(inner.id, SubcircuitPatch(num_qubits=2, ops=[gate(0, "h", [1])]))


def test_subcircuit_edit_updates_instances(run, tmp_path):
    store = SubcircuitStore(tmp_path, seed=False)
    sub = store.create(SubcircuitIn(name="Giro", num_qubits=1, ops=[gate(0, "x", [0])]))
    circuit = {"num_qubits": 1, "ops": [{"kind": "subcircuit", "col": 0, "subcircuit_id": sub.id, "targets": [0]}]}
    before = run(circuit, library=store.mapping())
    assert before["dominant"]["state"] == "1"
    store.update(sub.id, SubcircuitPatch(ops=[gate(0, "id", [0])]))
    after = run(circuit, library=store.mapping())
    assert after["dominant"]["state"] == "0"
