"""Pruebas HTTP de la API (requieren FastAPI; se ejecutan en el contenedor)."""

import pytest

fastapi = pytest.importorskip("fastapi")
pytest.importorskip("httpx")

from fastapi.testclient import TestClient  # noqa: E402

from app.config import Settings  # noqa: E402
from app.main import create_app  # noqa: E402

from .conftest import gate  # noqa: E402


@pytest.fixture()
def client(tmp_path):
    app = create_app(Settings(data_dir=tmp_path, cors_origins=["http://localhost:4321"]))
    return TestClient(app)


def test_health_and_gates(client):
    health = client.get("/api/health").json()
    assert health["status"] == "ok"
    names = {g["name"] for g in client.get("/api/gates").json()}
    assert {"h", "x", "swap", "rz", "sx", "modmul", "qft"} <= names


def test_simulate_bell(client):
    circuit = {"num_qubits": 2, "ops": [gate(0, "h", [0]), gate(1, "x", [1], controls=[0])]}
    res = client.post("/api/simulate", json={"circuit": circuit, "config": {"mode": "statevector"}})
    assert res.status_code == 200
    probs = {e["state"]: e["p"] for e in res.json()["histogram"]["entries"]}
    assert probs["00"] == pytest.approx(0.5) and probs["11"] == pytest.approx(0.5)


def test_validation_error_shape(client):
    circuit = {"num_qubits": 1, "ops": [{**gate(0, "h", [3]), "id": "x1"}]}
    res = client.post("/api/simulate", json={"circuit": circuit})
    assert res.status_code == 422
    detail = res.json()["detail"]
    assert detail["errors"][0]["op_id"] == "x1"


def test_cors_preflight(client):
    res = client.options(
        "/api/simulate",
        headers={"Origin": "http://localhost:4321", "Access-Control-Request-Method": "POST"},
    )
    assert res.headers.get("access-control-allow-origin") == "http://localhost:4321"


def test_subcircuit_crud_and_reexecution(client):
    body = {"name": "Giro", "num_qubits": 1, "ops": [gate(0, "x", [0])]}
    created = client.post("/api/subcircuits", json=body)
    assert created.status_code == 201
    sid = created.json()["id"]
    circuit = {"num_qubits": 1, "ops": [{"kind": "subcircuit", "col": 0, "subcircuit_id": sid, "targets": [0]}]}
    first = client.post("/api/simulate", json={"circuit": circuit}).json()
    assert first["dominant"]["state"] == "1"
    client.put(f"/api/subcircuits/{sid}", json={"ops": [gate(0, "id", [0])], "name": "Quieto"})
    second = client.post("/api/simulate", json={"circuit": circuit}).json()
    assert second["dominant"]["state"] == "0"
    assert client.delete(f"/api/subcircuits/{sid}").status_code == 204
    assert client.get(f"/api/subcircuits/{sid}").status_code == 404


def test_algorithms_endpoint(client):
    presets = client.get("/api/algorithms").json()
    assert any(p["key"] == "shor" for p in presets)
    shor = client.post("/api/algorithms/shor", json={"N": 15, "a": 7, "t": 8}).json()
    res = client.post("/api/simulate", json={"circuit": shor, "config": {"mode": "shots", "shots": 512, "seed": 1}})
    assert res.json()["analysis"]["factors"] == [3, 5]
    bad = client.post("/api/algorithms/shor", json={"N": 17})
    assert bad.status_code == 422


def test_export(client):
    circuit = {"num_qubits": 2, "num_clbits": 2, "ops": [gate(0, "h", [0]), gate(1, "x", [1], controls=[0])]}
    res = client.post("/api/export", json={"circuit": circuit}).json()
    assert "qc.cx(0, 1)" in res["python"]


def test_qiskit_code_endpoints(client):
    circuit = {"num_qubits": 2, "ops": [gate(0, "h", [0]), gate(1, "x", [1], controls=[0])]}
    gen = client.post("/api/code/qiskit", json={"circuit": circuit}).json()
    assert "qc.cx(0, 1)" in gen["code"] and len(gen["line_map"]) == 2
    parsed = client.post("/api/code/parse", json={"code": gen["code"], "name": "Bell"})
    assert parsed.status_code == 200
    assert parsed.json()["circuit"]["num_qubits"] == 2
    bad = client.post("/api/code/parse", json={"code": "from qiskit import QuantumCircuit\nqc = QuantumCircuit(1)\nqc.h(4)"})
    assert bad.status_code == 422
    assert bad.json()["detail"]["errors"][0]["line"] == 3
