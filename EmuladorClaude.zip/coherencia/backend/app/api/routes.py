"""Rutas REST de la API (prefijo /api)."""

from __future__ import annotations

import logging
import platform
from typing import Any

import numpy as np
from fastapi import APIRouter, Body, HTTPException, Query, Request, Response

from ..algorithms import PRESETS, AlgorithmError, build_preset
from ..core.gates import catalog
from ..core.ir import CircuitError, build_program
from ..core.models import Circuit, CodeRequest, ExportRequest, SimRequest, Subcircuit, SubcircuitIn, SubcircuitPatch
from ..services.export import to_python
from ..services.qiskit_code import CodeRejected, generate_for_api, parse_for_api
from ..services.simulate import check_limits, simulate, simulate_steps
from ..storage.subcircuits import ConflictError, NotFoundError

router = APIRouter(prefix="/api")
log = logging.getLogger("coherencia.api")


def _state(request: Request):
    return request.app.state.store, request.app.state.engine, request.app.state.settings


def _circuit_error(exc: CircuitError) -> HTTPException:
    return HTTPException(status_code=422, detail=exc.to_dict())


def _engine_error(exc: Exception) -> HTTPException:
    log.exception("Fallo del motor de simulación")
    return HTTPException(
        status_code=500,
        detail={"message": f"El motor de simulación falló: {exc}", "errors": []},
    )


# --- Meta --------------------------------------------------------------------------------
@router.get("/health")
def health(request: Request) -> dict:
    store, engine, settings = _state(request)
    return {
        "status": "ok",
        "engine": engine.name,
        "engine_version": engine.version,
        "python": platform.python_version(),
        "numpy": np.__version__,
        "subcircuits": len(store.list()),
        "limits": {
            "max_qubits": settings.max_qubits,
            "max_density_qubits": settings.max_density_qubits,
            "max_step_qubits": settings.max_step_qubits,
            "max_steps": settings.max_steps,
            "max_shots": settings.max_shots,
            "max_memory_shots": settings.max_memory_shots,
            "max_ops": settings.max_ops,
        },
    }


@router.get("/gates")
def gates() -> list[dict]:
    return catalog()


# --- Simulación --------------------------------------------------------------------------
@router.post("/simulate")
def run_simulation(req: SimRequest, request: Request) -> dict:
    store, engine, settings = _state(request)
    try:
        return simulate(req, store.mapping(), engine, settings)
    except CircuitError as exc:
        raise _circuit_error(exc) from exc
    except Exception as exc:  # noqa: BLE001 - se informa al cliente con un mensaje legible
        raise _engine_error(exc) from exc


@router.post("/simulate/steps")
def run_steps(req: SimRequest, request: Request) -> dict:
    store, engine, settings = _state(request)
    try:
        return simulate_steps(req, store.mapping(), engine, settings)
    except CircuitError as exc:
        raise _circuit_error(exc) from exc
    except Exception as exc:  # noqa: BLE001
        raise _engine_error(exc) from exc


@router.post("/validate")
def validate(req: ExportRequest, request: Request) -> dict:
    store, _, settings = _state(request)
    try:
        check_limits(req.circuit, settings)
        prog = build_program(req.circuit, store.mapping(), settings.max_ops)
    except CircuitError as exc:
        return {"ok": False, **exc.to_dict()}
    return {"ok": True, "ops": len(prog.ops), "steps": len(prog.steps), "depth": prog.depth(), "warnings": prog.warnings}


@router.post("/export")
def export(req: ExportRequest, request: Request) -> dict:
    store, engine, settings = _state(request)
    try:
        check_limits(req.circuit, settings)
        prog = build_program(req.circuit, store.mapping(), settings.max_ops)
    except CircuitError as exc:
        raise _circuit_error(exc) from exc
    out: dict[str, Any] = {"python": to_python(prog, req.circuit.name), "qasm3": None, "qasm2": None, "errors": []}
    if hasattr(engine, "to_qasm"):
        out.update(engine.to_qasm(prog))
    else:
        out["errors"].append("La exportación OpenQASM requiere el motor Qiskit.")
    return out


# --- Editor de código Qiskit ----------------------------------------------------------------
@router.post("/code/qiskit")
def code_from_circuit(req: ExportRequest, request: Request) -> dict:
    """Código Qiskit editable que reproduce el circuito (con ciclos y subcircuitos como funciones)."""
    store, _, _ = _state(request)
    return generate_for_api(req.circuit, store.mapping())


@router.post("/code/parse")
def circuit_from_code(req: CodeRequest, request: Request) -> dict:
    """Interpreta código Qiskit (sin ejecutarlo: se recorre su árbol sintáctico) y devuelve el circuito."""
    store, _, settings = _state(request)
    try:
        return parse_for_api(req.code, req.name, store.mapping(), settings)
    except CodeRejected as exc:
        raise HTTPException(status_code=422, detail=exc.detail) from exc


# --- Subcircuitos ------------------------------------------------------------------------
@router.get("/subcircuits", response_model=list[Subcircuit])
def list_subcircuits(request: Request):
    store, _, _ = _state(request)
    return store.list()


@router.post("/subcircuits", response_model=Subcircuit, status_code=201)
def create_subcircuit(data: SubcircuitIn, request: Request):
    store, _, _ = _state(request)
    try:
        return store.create(data)
    except CircuitError as exc:
        raise _circuit_error(exc) from exc


@router.post("/subcircuits/validate")
def validate_subcircuit(request: Request, data: SubcircuitIn, sid: str | None = Query(None)) -> dict:
    """Valida un borrador de subcircuito con sus parámetros libres a 0 (para el editor)."""
    store, _, settings = _state(request)
    library = store.mapping()
    circuit = Circuit(name=data.name, num_qubits=data.num_qubits, num_clbits=data.num_clbits, ops=data.ops, loops=data.loops)
    try:
        prog = build_program(circuit, library, settings.max_ops, env={p: 0.0 for p in data.params}, root_id=sid)
    except CircuitError as exc:
        return {"ok": False, **exc.to_dict()}
    return {"ok": True, "ops": len(prog.ops), "steps": len(prog.steps), "depth": prog.depth(), "warnings": prog.warnings}


@router.get("/subcircuits/{sid}", response_model=Subcircuit)
def get_subcircuit(sid: str, request: Request):
    store, _, _ = _state(request)
    try:
        return store.get(sid)
    except NotFoundError as exc:
        raise HTTPException(status_code=404, detail={"message": f"No existe el subcircuito «{sid}»"}) from exc


@router.put("/subcircuits/{sid}", response_model=Subcircuit)
def update_subcircuit(sid: str, patch: SubcircuitPatch, request: Request):
    store, _, _ = _state(request)
    try:
        return store.update(sid, patch)
    except NotFoundError as exc:
        raise HTTPException(status_code=404, detail={"message": f"No existe el subcircuito «{sid}»"}) from exc
    except CircuitError as exc:
        raise _circuit_error(exc) from exc


@router.delete("/subcircuits/{sid}", status_code=204, response_class=Response)
def delete_subcircuit(sid: str, request: Request, force: bool = Query(False)) -> Response:
    store, _, _ = _state(request)
    try:
        store.delete(sid, force=force)
    except NotFoundError as exc:
        raise HTTPException(status_code=404, detail={"message": f"No existe el subcircuito «{sid}»"}) from exc
    except ConflictError as exc:
        raise HTTPException(status_code=409, detail={"message": exc.message, "dependents": exc.dependents}) from exc
    return Response(status_code=204)


@router.get("/subcircuits/{sid}/dependents")
def subcircuit_dependents(sid: str, request: Request) -> list[dict]:
    store, _, _ = _state(request)
    return [{"id": d.id, "name": d.name} for d in store.dependents(sid)]


# --- Algoritmos --------------------------------------------------------------------------
@router.get("/algorithms")
def list_algorithms() -> list[dict]:
    return PRESETS


@router.post("/algorithms/{key}")
def make_algorithm(key: str, request: Request, params: dict | None = Body(default=None)) -> dict:
    _, _, settings = _state(request)
    try:
        return build_preset(key, params or {}, settings.max_qubits)
    except AlgorithmError as exc:
        raise HTTPException(status_code=422, detail={"message": str(exc), "errors": [{"op_id": None, "message": str(exc)}]}) from exc


@router.get("/algorithms/{key}")
def make_algorithm_get(key: str, request: Request) -> dict:
    _, _, settings = _state(request)
    try:
        return build_preset(key, dict(request.query_params), settings.max_qubits)
    except AlgorithmError as exc:
        raise HTTPException(status_code=422, detail={"message": str(exc), "errors": [{"op_id": None, "message": str(exc)}]}) from exc
