"""Persistencia de subcircuitos en archivos JSON (un archivo por subcircuito).

El directorio se monta como volumen de Docker (``DATA_DIR``), de modo que la
biblioteca sobrevive a los reinicios de los contenedores. Las escrituras son
atómicas (archivo temporal + ``os.replace``) y están protegidas por un cerrojo.
"""

from __future__ import annotations

import json
import logging
import os
import re
import tempfile
import threading
import unicodedata
import uuid
from datetime import datetime, timezone
from pathlib import Path

from ..core.expressions import is_identifier
from ..core.ir import CircuitError, validate_subcircuit_definition
from ..core.models import Subcircuit, SubcircuitIn, SubcircuitPatch

log = logging.getLogger("coherencia.storage")


class NotFoundError(KeyError):
    pass


class ConflictError(Exception):
    def __init__(self, message: str, dependents: list[dict]):
        super().__init__(message)
        self.message = message
        self.dependents = dependents


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _slug(text: str) -> str:
    norm = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    norm = re.sub(r"[^a-zA-Z0-9]+", "-", norm).strip("-").lower()
    return norm[:32] or "subcircuito"


class SubcircuitStore:
    def __init__(self, data_dir: Path, seed: bool = True):
        self.dir = Path(data_dir) / "subcircuits"
        self.dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._items: dict[str, Subcircuit] = {}
        self._load()
        if seed:
            self._seed()

    # -- lectura ---------------------------------------------------------------------
    def _load(self) -> None:
        for path in sorted(self.dir.glob("*.json")):
            try:
                item = Subcircuit.model_validate(json.loads(path.read_text(encoding="utf-8")))
                self._items[item.id] = item
            except Exception as exc:  # archivo corrupto: se ignora y se registra
                log.warning("No se pudo leer %s: %s", path.name, exc)

    def list(self) -> list[Subcircuit]:
        with self._lock:
            return sorted(self._items.values(), key=lambda s: (s.name.lower(), s.id))

    def get(self, sid: str) -> Subcircuit:
        with self._lock:
            if sid not in self._items:
                raise NotFoundError(sid)
            return self._items[sid]

    def mapping(self) -> dict[str, Subcircuit]:
        with self._lock:
            return dict(self._items)

    def dependents(self, sid: str) -> list[Subcircuit]:
        with self._lock:
            return [
                s
                for s in self._items.values()
                if s.id != sid and any(op.kind == "subcircuit" and op.subcircuit_id == sid for op in s.ops)
            ]

    # -- escritura ----------------------------------------------------------------------
    def _write(self, item: Subcircuit) -> None:
        data = item.model_dump(mode="json")
        fd, tmp = tempfile.mkstemp(dir=self.dir, prefix=".tmp-", suffix=".json")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, self.dir / f"{item.id}.json")
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)

    @staticmethod
    def _check_params(params: list[str]) -> None:
        bad = [p for p in params if not is_identifier(p)]
        if bad:
            raise CircuitError(
                "Parámetros no válidos",
                [{"op_id": None, "message": f"«{p}» no es un nombre de parámetro válido"} for p in bad],
            )
        if len(set(params)) != len(params):
            raise CircuitError("Parámetros repetidos", [{"op_id": None, "message": "Hay parámetros repetidos"}])

    def create(self, data: SubcircuitIn, sid: str | None = None, system: bool = False) -> Subcircuit:
        with self._lock:
            self._check_params(data.params)
            new_id = sid or f"{_slug(data.name)}-{uuid.uuid4().hex[:6]}"
            now = _now()
            item = Subcircuit(**data.model_dump(), id=new_id, created_at=now, updated_at=now, system=system)
            validate_subcircuit_definition(item, self._items)
            self._items[item.id] = item
            self._write(item)
            return item

    def update(self, sid: str, patch: SubcircuitPatch) -> Subcircuit:
        with self._lock:
            current = self.get(sid)
            changes = {k: v for k, v in patch.model_dump(exclude_unset=True).items() if v is not None}
            merged = current.model_dump()
            merged.update(changes)
            merged["updated_at"] = _now()
            item = Subcircuit.model_validate(merged)
            self._check_params(item.params)
            library = dict(self._items)
            library[sid] = item
            validate_subcircuit_definition(item, library)
            # Los subcircuitos que lo usan deben seguir siendo válidos (p. ej. si cambia el número de cúbits).
            for dep in self.dependents(sid):
                try:
                    validate_subcircuit_definition(dep, library)
                except CircuitError as exc:
                    raise CircuitError(
                        f"El cambio rompe el subcircuito «{dep.name}», que usa este",
                        exc.errors,
                    ) from exc
            self._items[sid] = item
            self._write(item)
            return item

    def delete(self, sid: str, force: bool = False) -> None:
        with self._lock:
            self.get(sid)
            deps = self.dependents(sid)
            if deps and not force:
                raise ConflictError(
                    "Otros subcircuitos usan este; elimínalos o edítalos antes",
                    [{"id": d.id, "name": d.name} for d in deps],
                )
            self._items.pop(sid, None)
            path = self.dir / f"{sid}.json"
            if path.exists():
                path.unlink()

    # -- biblioteca inicial ---------------------------------------------------------------
    def _seed(self) -> None:
        marker = self.dir / ".seeded"
        if marker.exists() or self._items:
            return
        for sid, data in SEED_LIBRARY:
            try:
                self.create(SubcircuitIn.model_validate(data), sid=sid)
            except Exception as exc:  # pragma: no cover - las semillas se prueban
                log.warning("Semilla %s no válida: %s", sid, exc)
        marker.write_text(_now(), encoding="utf-8")


def _g(col, gate, targets, controls=(), params=(), anticontrols=()):
    return {
        "id": uuid.uuid4().hex[:8],
        "kind": "gate",
        "gate": gate,
        "col": col,
        "targets": list(targets),
        "controls": list(controls),
        "anticontrols": list(anticontrols),
        "params": list(params),
    }


SEED_LIBRARY: list[tuple[str, dict]] = [
    (
        "par-de-bell",
        {
            "name": "Par de Bell",
            "description": "Prepara (|00⟩+|11⟩)/√2 a partir de |00⟩: Hadamard y CNOT.",
            "num_qubits": 2,
            "ops": [_g(0, "h", [0]), _g(1, "x", [1], controls=[0])],
            "color": "aqua",
            "tags": ["entrelazamiento"],
        },
    ),
    (
        "sumador-completo",
        {
            "name": "Sumador completo",
            "description": "Suma reversible a + b + cin: deja la suma en q2 y el acarreo en q3 (q3 debe empezar en 0).",
            "num_qubits": 4,
            "ops": [
                _g(0, "x", [3], controls=[0, 1]),
                _g(1, "x", [1], controls=[0]),
                _g(2, "x", [3], controls=[1, 2]),
                _g(3, "x", [2], controls=[1]),
                _g(4, "x", [1], controls=[0]),
            ],
            "color": "amber",
            "tags": ["aritmética", "Toffoli"],
        },
    ),
    (
        "difusor-grover-3",
        {
            "name": "Difusor de Grover (3)",
            "description": "Inversión sobre la media 2|s⟩⟨s| − I para 3 cúbits.",
            "num_qubits": 3,
            "ops": [
                *[_g(0, "h", [q]) for q in range(3)],
                *[_g(1, "x", [q]) for q in range(3)],
                _g(2, "z", [2], controls=[0, 1]),
                *[_g(3, "x", [q]) for q in range(3)],
                *[_g(4, "h", [q]) for q in range(3)],
            ],
            "color": "violet",
            "tags": ["Grover"],
        },
    ),
    (
        "qft-3-manual",
        {
            "name": "QFT de 3 cúbits",
            "description": "Transformada de Fourier construida a mano con H, fases controladas y un SWAP.",
            "num_qubits": 3,
            "ops": [
                _g(0, "h", [2]),
                _g(1, "p", [2], controls=[1], params=["pi/2"]),
                _g(2, "p", [2], controls=[0], params=["pi/4"]),
                _g(3, "h", [1]),
                _g(4, "p", [1], controls=[0], params=["pi/2"]),
                _g(5, "h", [0]),
                _g(6, "swap", [0, 2]),
            ],
            "color": "blue",
            "tags": ["Fourier"],
        },
    ),
    (
        "capa-variacional",
        {
            "name": "Capa variacional",
            "description": "Rotaciones RY(θ) y RZ(φ) en dos cúbits seguidas de un CNOT. Parámetros θ y φ.",
            "num_qubits": 2,
            "params": ["theta", "phi"],
            "ops": [
                _g(0, "ry", [0], params=["theta"]),
                _g(0, "ry", [1], params=["theta"]),
                _g(1, "rz", [0], params=["phi"]),
                _g(1, "rz", [1], params=["phi"]),
                _g(2, "x", [1], controls=[0]),
            ],
            "color": "green",
            "tags": ["variacional", "parámetros"],
        },
    ),
]
