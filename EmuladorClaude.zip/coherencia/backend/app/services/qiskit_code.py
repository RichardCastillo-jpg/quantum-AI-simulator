"""Código Qiskit ⇄ circuito de Coherencia.

* :func:`circuit_to_code` genera código Python de Qiskit legible a partir del modelo de
  columnas. Conserva los ciclos ``for`` (como bucles de Python), las expresiones de los
  parámetros (``i*pi/8``) y los subcircuitos (como funciones que devuelven un
  ``QuantumCircuit``), y devuelve qué línea corresponde a cada operación.
* :func:`code_to_circuit` interpreta un subconjunto seguro de Python que construye circuitos
  con la API de Qiskit y devuelve el modelo de columnas. **No usa** ``eval`` ni ``exec`` ni
  importa nada del código del usuario: recorre el árbol sintáctico (``ast``) con un intérprete
  propio que solo conoce aritmética, listas, bucles, funciones definidas en el propio código y
  los objetos de Qiskit que tienen sentido en un circuito. Lo relativo a ejecutar o dibujar
  (``AerSimulator``, ``transpile``, ``print``, ``plot_histogram``…) se ignora, porque Coherencia
  ejecuta el circuito por su cuenta.
"""

from __future__ import annotations

import ast
import builtins
import cmath
import keyword
import math
import re
import unicodedata
from collections import defaultdict
from dataclasses import dataclass, field, replace
from fractions import Fraction
from collections.abc import Iterator
from typing import Any, Callable, Iterable, Mapping

import numpy as np

from ..core import expressions as ex
from ..core.gates import ALIAS_CONTROLS, GATES, gate_matrix, resolve_name
from ..core.models import Circuit, Condition, Loop, Op

MAX_CODE_LENGTH = 200_000
MAX_STEPS = 2_000_000
MAX_CALL_DEPTH = 60
MAX_SEQUENCE = 1_000_000
MAX_QUBITS_MODEL = 64
MAX_CLBITS_MODEL = 256


# =====================================================================================
#  Números y expresiones
# =====================================================================================

def nice_number(x: float) -> str:
    """Representación legible: múltiplos racionales de π (``3*pi/4``), enteros o decimales."""
    x = float(x)
    if x == 0:
        return "0"
    frac = Fraction(x / math.pi).limit_denominator(64)
    if frac != 0 and abs(float(frac) * math.pi - x) < 1e-10:
        p, q = frac.numerator, frac.denominator
        body = "pi" if abs(p) == 1 else f"{abs(p)}*pi"
        return ("-" if p < 0 else "") + body + (f"/{q}" if q != 1 else "")
    if x.is_integer() and abs(x) < 1e15:
        return str(int(x))
    return repr(round(x, 12))


_PY_FUNC = {"ln": "log"}
_MATH_NAMES = {"pi", "tau", "e", "sin", "cos", "tan", "asin", "acos", "atan", "atan2", "sqrt", "exp", "log",
               "log2", "log10", "floor", "ceil"}
_PREC = {"+": 1, "-": 1, "*": 2, "/": 2, "%": 2, "^": 4}


def _fmt_plain(v: float) -> str:
    v = float(v)
    if v.is_integer() and abs(v) < 1e15:
        return str(int(v))
    return repr(v)


class _ExprWriter:
    """Convierte una expresión de Coherencia (``2π/3``, ``i^2``) en Python (``2*pi/3``, ``i**2``)."""

    def __init__(self, names: Mapping[str, str], imports: set[str]):
        self.names = names
        self.imports = imports

    def write(self, value: float | str) -> str:
        if not isinstance(value, str):
            text = nice_number(float(value))
            if "pi" in text:
                self.imports.add("pi")
            return text
        try:
            node = ex.parse(value)
        except ex.ExpressionError:
            return value  # se deja tal cual; el intérprete informará del error si se edita
        return self._emit(node)[0]

    def _emit(self, node) -> tuple[str, int]:
        if isinstance(node, ex.Num):
            return _fmt_plain(node.value), 9
        if isinstance(node, ex.Var):
            name = {"π": "pi", "τ": "tau"}.get(node.name, node.name)
            if name in ("pi", "tau", "e") and node.name not in self.names:
                self.imports.add(name)
                return name, 9
            return self.names.get(node.name, name), 9
        if isinstance(node, ex.Unary):
            inner, p = self._emit(node.operand)
            if p < 3:
                inner = f"({inner})"
            return (inner if node.op == "+" else f"-{inner}"), 3
        if isinstance(node, ex.Binary):
            p = _PREC[node.op]
            left, lp = self._emit(node.left)
            right, rp = self._emit(node.right)
            if node.op == "^":
                if lp <= p:
                    left = f"({left})"
                if rp < 3:
                    right = f"({right})"
                return f"{left}**{right}", p
            if lp < p:
                left = f"({left})"
            if rp < p or (rp == p and node.op in "-/%"):
                right = f"({right})"
            sep = f" {node.op} " if p == 1 else node.op
            return f"{left}{sep}{right}", p
        if isinstance(node, ex.Call):
            fname = _PY_FUNC.get(node.name, node.name)
            if fname in _MATH_NAMES:
                self.imports.add(fname)
            args = ", ".join(self._emit(a)[0] for a in node.args)
            return f"{fname}({args})", 9
        return "0", 9  # pragma: no cover


def _complex_literal(z: complex) -> str:
    re_, im = round(z.real, 12) + 0.0, round(z.imag, 12) + 0.0
    if im == 0:
        return _fmt_plain(re_)
    if re_ == 0:
        return f"{_fmt_plain(im)}j"
    sign = "+" if im >= 0 else "-"
    return f"({_fmt_plain(re_)}{sign}{_fmt_plain(abs(im))}j)"


def _matrix_literal(mat: np.ndarray) -> str:
    rows = ["[" + ", ".join(_complex_literal(complex(z)) for z in row) + "]" for row in mat]
    return "[" + ", ".join(rows) + "]"


def _py_ident(text: str, taken: set[str], fallback: str) -> str:
    ascii_text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    base = re.sub(r"\W+", "_", ascii_text.lower()).strip("_")
    if not base or base[0].isdigit():
        base = f"{fallback}_{base}" if base else fallback
    if keyword.iskeyword(base):
        base += "_"
    name, k = base, 2
    while name in taken:
        name, k = f"{base}_{k}", k + 1
    taken.add(name)
    return name


# =====================================================================================
#  Circuito → código
# =====================================================================================

_GATE_CLASS = {
    "x": "XGate", "y": "YGate", "z": "ZGate", "h": "HGate", "s": "SGate", "sdg": "SdgGate", "t": "TGate",
    "tdg": "TdgGate", "sx": "SXGate", "sxdg": "SXdgGate", "id": "IGate", "p": "PhaseGate", "rx": "RXGate",
    "ry": "RYGate", "rz": "RZGate", "u": "UGate", "swap": "SwapGate", "iswap": "iSwapGate", "rxx": "RXXGate",
    "ryy": "RYYGate", "rzz": "RZZGate",
}
_ONE_CONTROL = {"x": "cx", "y": "cy", "z": "cz", "h": "ch", "s": "cs", "sdg": "csdg", "sx": "csx", "p": "cp",
                "rx": "crx", "ry": "cry", "rz": "crz", "swap": "cswap"}
_RESERVED = ({"qc", "sub", "pi", "tau", "e", "np", "QuantumCircuit", "QuantumRegister", "ClassicalRegister"}
             | _MATH_NAMES | {n for n in dir(builtins) if not n.startswith("_")})

MODMUL_HELPER = '''def modmul_gate(a, N, n):
    """|y⟩ → |a·y mod N⟩ para y < N (identidad en el resto). Núcleo de Shor."""
    u = np.zeros((2**n, 2**n))
    for y in range(2**n):
        u[(a * y) % N if y < N else y, y] = 1
    return UnitaryGate(u, label=f"x{a} mod {N}")'''


@dataclass
class GeneratedCode:
    code: str
    line_map: dict[str, int]
    warnings: list[str]


class _CodeGen:
    def __init__(self, library: Mapping[str, Any]):
        self.library = library
        self.math: set[str] = set()
        self.lib: set[str] = set()
        self.need_np = False
        self.need_modmul = False
        self.func_names: dict[str, str] = {}
        self.taken: set[str] = set(_RESERVED)
        self.func_order: list[str] = []
        self.warnings: list[str] = []
        self.registers = False

    # -- utilidades --------------------------------------------------------------------
    def _var_names(self, raw: Iterable[str]) -> dict[str, str]:
        out = {}
        for name in raw:
            if name.isidentifier() and not keyword.iskeyword(name) and name not in _RESERVED:
                out[name] = name
            else:
                out[name] = _py_ident(name, set(out.values()) | _RESERVED, "v")
        return out

    def _ctrl_suffix(self, controls: list[int], antis: list[int]) -> tuple[str, list[int]]:
        k = len(controls) + len(antis)
        qargs = list(controls) + list(antis)
        if not antis:
            return f".control({k})" if k > 1 else ".control()", qargs
        bits = ["1"] * len(controls) + ["0"] * len(antis)
        state = "".join(reversed(bits))
        return f".control({k}, ctrl_state='{state}')", qargs

    def _gate_object(self, name: str, params: list[str], op: Op, nt: int, writer: _ExprWriter) -> str:
        if name in ("qft", "iqft"):
            self.lib.add("QFTGate")
            return f"QFTGate({nt})" + (".inverse()" if name == "iqft" else "")
        if name == "modmul":
            self.need_modmul = self.need_np = True
            self.lib.add("UnitaryGate")
            return f"modmul_gate({params[0]}, {params[1]}, {nt})"
        if name == "unitary":
            self.lib.add("UnitaryGate")
            mat = np.array([[complex(e[0], e[1] if len(e) > 1 else 0.0) for e in row] for row in (op.matrix or [])])
            label = f", label={op.label!r}" if op.label else ""
            return f"UnitaryGate({_matrix_literal(mat)}{label})"
        if name in _GATE_CLASS:
            self.lib.add(_GATE_CLASS[name])
            return f"{_GATE_CLASS[name]}({', '.join(params)})"
        # √Y, √W, fSim: sin clase en Qiskit → matriz exacta.
        self.lib.add("UnitaryGate")
        try:
            values = tuple(ex.evaluate(p) for p in op.params)
            mat = gate_matrix(name, values)
        except Exception:  # noqa: BLE001 - parámetros simbólicos (dependen de un ciclo)
            self.warnings.append(f"{GATES[name].label} con parámetros simbólicos se exportó con valor 0.")
            mat = gate_matrix(name, tuple(0.0 for _ in GATES[name].params))
        return f"UnitaryGate({_matrix_literal(mat)}, label={GATES[name].label!r})"

    def _gate_lines(self, op: Op, cv: str, writer: _ExprWriter) -> list[str]:
        raw = (op.gate or "").strip().lower()
        targets, controls, antis = list(op.targets), list(op.controls), list(op.anticontrols)
        implied = ALIAS_CONTROLS.get(raw, 0)
        if implied and not controls and not antis and len(targets) == implied + 1:
            controls, targets = targets[:implied], targets[implied:]
        name = resolve_name(raw)
        if name not in GATES:
            return [f"# compuerta desconocida «{op.gate}» omitida"]
        spec = GATES[name]
        params = [writer.write(p) for p in op.params[: len(spec.params)]]
        while len(params) < len(spec.params):
            params.append("0")
        k = len(controls) + len(antis)
        t = ", ".join(map(str, targets))
        if name == "id":
            return [f"{cv}.id({t})"]  # la identidad controlada sigue siendo la identidad
        if k == 0 and name in _GATE_CLASS:
            return [f"{cv}.{name}({', '.join(params + [t])})"]
        if not antis and name in _GATE_CLASS:
            c = controls
            if k == 1 and name in _ONE_CONTROL:
                return [f"{cv}.{_ONE_CONTROL[name]}({', '.join(params + [str(c[0]), t])})"]
            if k == 1 and name == "u":
                return [f"{cv}.cu({', '.join(params)}, 0, {c[0]}, {t})"]
            if k == 2 and name == "x":
                return [f"{cv}.ccx({c[0]}, {c[1]}, {t})"]
            if k == 2 and name == "z":
                return [f"{cv}.ccz({c[0]}, {c[1]}, {t})"]
            if k >= 3 and name == "x":
                return [f"{cv}.mcx({c}, {t})"]
            if k >= 2 and name in ("p", "z", "s", "sdg", "t", "tdg"):
                lam = params[0] if name == "p" else {"z": "pi", "s": "pi/2", "sdg": "-pi/2", "t": "pi/4",
                                                       "tdg": "-pi/4"}[name]
                if "pi" in lam:
                    self.math.add("pi")
                return [f"{cv}.mcp({lam}, {c}, {t})"]
        obj = self._gate_object(name, params, op, len(targets), writer)
        if k == 0:
            return [f"{cv}.append({obj}, [{t}])"]
        suffix, qargs = self._ctrl_suffix(controls, antis)
        return [f"{cv}.append({obj}{suffix}, {qargs + targets})"]

    def _op_lines(self, op: Op, cv: str, writer: _ExprWriter, nc: int) -> list[str]:
        if op.kind == "gate":
            return self._gate_lines(op, cv, writer)
        if op.kind == "measure":
            q = op.targets[0] if op.targets else 0
            c = op.clbits[0] if op.clbits else q
            return [f"{cv}.measure({q}, {c})"]
        if op.kind == "reset":
            return [f"{cv}.reset({op.targets[0] if op.targets else 0})"]
        if op.kind == "barrier":
            return [f"{cv}.barrier({', '.join(map(str, op.targets))})"]
        if op.kind == "subcircuit":
            sub = self.library.get(op.subcircuit_id or "")
            if sub is None:
                return [f"# subcircuito «{op.subcircuit_id}» no encontrado"]
            fname = self._function_for(sub)
            args = ", ".join(writer.write(op.sub_params.get(p, 0.0)) for p in sub.params)
            call = f"{fname}({args})"
            controls, antis = list(op.controls), list(op.anticontrols)
            if controls or antis:
                suffix, qargs = self._ctrl_suffix(controls, antis)
                return [f"{cv}.append({call}.to_gate(){suffix}, {qargs + list(op.targets)})"]
            parts = [f"qubits={list(op.targets)}"]
            if sub.num_clbits:
                clbits = list(op.clbits) or list(range(sub.num_clbits))
                parts.append(f"clbits={clbits}")
            return [f"{cv}.compose({call}, {', '.join(parts)}, inplace=True)"]
        return []

    def _function_for(self, sub) -> str:
        if sub.id in self.func_names:
            return self.func_names[sub.id]
        name = _py_ident(sub.name or sub.id, self.taken, "bloque")
        self.func_names[sub.id] = name
        self.func_order.append(sub.id)
        return name

    # -- bloques con ciclos ----------------------------------------------------------------
    def emit_block(self, ops: list[Op], loops: list[Loop], cv: str, names: dict[str, str], depth: int,
                   out: list[str], line_map: dict[str, int] | None, nc: int) -> None:
        by_col: dict[int, list[Op]] = defaultdict(list)
        for op in ops:
            by_col[op.col].append(op)
        if not by_col and not loops:
            return
        hi = max([*by_col.keys(), *(lp.col_end for lp in loops)], default=-1)
        ordered = sorted(loops, key=lambda lp: (lp.col_start, -lp.col_end))
        self._emit_range(0, hi, ordered, by_col, cv, names, depth, out, line_map, nc)

    def _emit_range(self, lo, hi, loops, by_col, cv, names, depth, out, line_map, nc) -> None:
        pad = "    " * depth
        col = lo
        while col <= hi:
            outer = next((lp for lp in loops if lp.col_start == col and lp.col_end <= hi), None)
            if outer is not None:
                inner = [lp for lp in loops if lp is not outer and outer.col_start <= lp.col_start
                         and lp.col_end <= outer.col_end]
                local = dict(names)
                var = self._var_names([outer.var])[outer.var]
                local[outer.var] = var
                start, step, n = outer.start, outer.step, outer.iterations
                if float(start).is_integer() and float(step).is_integer() and step != 0:
                    s, st = int(start), int(step)
                    stop = s + n * st
                    rng = f"range({n})" if (s == 0 and st == 1) else (
                        f"range({s}, {stop})" if st == 1 else f"range({s}, {stop}, {st})")
                    out.append(f"{pad}for {var} in {rng}:")
                else:
                    k = f"_k{depth}"
                    out.append(f"{pad}for {k} in range({n}):")
                    out.append(f"{pad}    {var} = {_fmt_plain(start)} + {k}*{_fmt_plain(step)}")
                mark = len(out)
                self._emit_range(outer.col_start, outer.col_end, inner, by_col, cv, local, depth + 1, out,
                                 line_map, nc)
                if len(out) == mark:
                    out.append(f"{pad}    pass")
                col = outer.col_end + 1
                continue
            col_ops = sorted(by_col.get(col, []), key=lambda o: min([*o.targets, *o.controls, *o.anticontrols],
                                                                    default=0))
            writer = _ExprWriter(names, self.math)
            current: tuple | None = None
            for op in col_ops:
                cond = tuple((c.clbit, c.value) for c in (op.condition or []))
                lines = self._op_lines(op, cv, writer, nc)
                if cond:
                    if cond != current:
                        indent = pad
                        for cb, val in cond:
                            out.append(f"{indent}with {cv}.if_test(({cv}.clbits[{cb}], {val})):")
                            indent += "    "
                        current = cond
                    indent = pad + "    " * len(cond)
                else:
                    current = None
                    indent = pad
                if line_map is not None and lines:
                    line_map[op.id] = len(out)
                out.extend(indent + ln for ln in lines)
            col += 1

    # -- documento completo ----------------------------------------------------------------
    def generate(self, circuit: Circuit) -> GeneratedCode:
        body: list[str] = []
        line_map: dict[str, int] = {}
        name_kw = f", name={circuit.name!r}" if circuit.name else ""
        qregs = _registers(circuit.qubit_labels, circuit.num_qubits)
        cregs = _registers(circuit.clbit_labels, circuit.num_clbits) if circuit.num_clbits else []
        self.registers = bool(qregs or cregs)
        if self.registers:
            reg_vars: list[str] = []
            for kind, regs, default, total in (("QuantumRegister", qregs, "q", circuit.num_qubits),
                                               ("ClassicalRegister", cregs, "c", circuit.num_clbits)):
                if not total:
                    continue
                for rname, size in regs or [(default, total)]:
                    var = _py_ident(rname, self.taken, "r")
                    reg_vars.append(var)
                    body.append(f"{var} = {kind}({size}, {rname!r})")
            body.append(f"qc = QuantumCircuit({', '.join(reg_vars)}{name_kw})")
        else:
            qc_args = f"{circuit.num_qubits}, {circuit.num_clbits}" if circuit.num_clbits else f"{circuit.num_qubits}"
            body.append(f"qc = QuantumCircuit({qc_args}{name_kw})")
        init = (circuit.initial_state or "").strip()
        if init and "1" in init:
            body.append(f"qc.initialize('{init.zfill(circuit.num_qubits)[-circuit.num_qubits:]}')")
        loop_names = self._var_names([lp.var for lp in circuit.loops])
        self.emit_block(list(circuit.ops), list(circuit.loops), "qc", loop_names, 0, body, line_map,
                        circuit.num_clbits)

        # Subcircuitos (incluidos los anidados): una función por definición.
        funcs: list[str] = []
        done: set[str] = set()
        while len(done) < len(self.func_order):
            sid = next(s for s in self.func_order if s not in done)
            done.add(sid)
            sub = self.library[sid]
            pnames = self._var_names(sub.params)
            lnames = self._var_names([lp.var for lp in sub.loops])
            names = {**pnames, **lnames}
            fn = self.func_names[sid]
            lines = [f"def {fn}({', '.join(pnames[p] for p in sub.params)}):"]
            if sub.description:
                lines.append(f"    {_docstring(sub.description)}")
            sub_args = f"{sub.num_qubits}, {sub.num_clbits}" if sub.num_clbits else f"{sub.num_qubits}"
            lines.append(f"    sub = QuantumCircuit({sub_args}, name={sub.name!r})")
            mark = len(lines)
            self.emit_block(list(sub.ops), list(sub.loops), "sub", names, 1, lines, None, sub.num_clbits)
            if len(lines) == mark:
                lines.append("    pass")
            lines.append("    return sub")
            funcs.append("\n".join(lines))

        header = ["from qiskit import QuantumCircuit" + (", QuantumRegister, ClassicalRegister" if self.registers else "")]
        if self.lib:
            header.append(f"from qiskit.circuit.library import {', '.join(sorted(self.lib))}")
        if self.math:
            order = ["pi", "tau", "e"] + sorted(self.math - {"pi", "tau", "e"})
            header.append(f"from math import {', '.join(n for n in order if n in self.math)}")
        if self.need_np:
            header.append("import numpy as np")
        blocks = ["\n".join(header)]
        if self.need_modmul:
            blocks.append(MODMUL_HELPER)
        blocks.extend(funcs)
        prefix = "\n\n\n".join(blocks) + "\n\n\n"
        offset = prefix.count("\n") + 1
        footer = [
            "",
            "# Coherencia ejecuta el circuito automáticamente al editar este código.",
            "# Para ejecutarlo fuera de aquí (si el circuito no mide, añade qc.measure_all()):",
            "#   from qiskit_aer import AerSimulator",
            "#   print(AerSimulator().run(qc, shots=1024).result().get_counts())",
        ]
        code = prefix + "\n".join(body + footer) + "\n"
        return GeneratedCode(code=code, line_map={k: v + offset for k, v in line_map.items()},
                             warnings=list(dict.fromkeys(self.warnings)))


def _registers(labels: list[str] | None, n: int) -> list[tuple[str, int]] | None:
    """Agrupa etiquetas como c0…c7, w0…w3 en registros con nombre (para conservarlas en el código)."""
    if not labels or len(labels) != n:
        return None
    regs: list[tuple[str, int]] = []
    i = 0
    while i < n:
        m = re.fullmatch(r"(.*?\D)0", labels[i]) if labels[i] else None
        k = 0
        if m:
            name = m.group(1)
            while i + k < n and labels[i + k] == f"{name}{k}":
                k += 1
        if k >= 2:
            regs.append((name, k))
            i += k
        else:
            if not labels[i].strip():
                return None
            regs.append((labels[i], 1))
            i += 1
    return regs


def _docstring(text: str) -> str:
    text = " ".join(text.split()).replace('"""', "'''")
    return f'"""{text}"""'


def circuit_to_code(circuit: Circuit, library: Mapping[str, Any] | None = None) -> GeneratedCode:
    return _CodeGen(library or {}).generate(circuit)


# =====================================================================================
#  Código → circuito: intérprete seguro
# =====================================================================================

class CodeError(Exception):
    def __init__(self, message: str, line: int | None = None, col: int | None = None):
        super().__init__(message)
        self.message = message
        self.line = line
        self.col = col

    def to_dict(self) -> dict:
        where = f"Línea {self.line}: " if self.line else ""
        return {
            "message": where + self.message,
            "errors": [{"op_id": None, "line": self.line, "col": self.col, "message": self.message}],
        }


class _TooLong(CodeError):
    """Se superó el presupuesto de pasos: se informa en la línea del ciclo más interno."""


class _Ignored:
    """Valor «agujero negro» para lo que solo sirve para ejecutar o dibujar fuera de Coherencia."""

    _inst = None

    def __new__(cls):
        if cls._inst is None:
            cls._inst = super().__new__(cls)
        return cls._inst

    def __repr__(self) -> str:  # pragma: no cover
        return "<ignorado>"


IGN = _Ignored()


@dataclass(eq=False)
class Reg:
    kind: str  # "q" | "c"
    size: int
    name: str


@dataclass(frozen=True)
class Bit:
    kind: str
    reg: Reg | None
    index: int


@dataclass
class ROp:
    kind: str  # gate | measure | reset | barrier
    gate: str = ""
    targets: tuple[int, ...] = ()
    controls: tuple[int, ...] = ()
    anticontrols: tuple[int, ...] = ()
    params: tuple[float, ...] = ()
    clbits: tuple[int, ...] = ()
    condition: tuple[tuple[int, int], ...] = ()
    matrix: np.ndarray | None = None
    label: str | None = None
    line: int | None = None


class Circ:
    _counter = 0

    def __init__(self, name: str | None = None):
        Circ._counter += 1
        self.serial = Circ._counter
        self.name = name
        self.nq = 0
        self.nc = 0
        self.qregs: list[tuple[Reg, int]] = []
        self.cregs: list[tuple[Reg, int]] = []
        self.ops: list[ROp] = []
        self.initial: dict[int, int] = {}
        self.touched: set[int] = set()
        self.cond_stack: list[tuple[tuple[int, int], ...]] = []
        self.used_as_block = False

    def copy(self) -> "Circ":
        c = Circ(self.name)
        c.nq, c.nc = self.nq, self.nc
        c.qregs, c.cregs = list(self.qregs), list(self.cregs)
        c.ops = list(self.ops)
        c.initial = dict(self.initial)
        c.touched = set(self.touched)
        return c

    def add_register(self, reg: Reg) -> None:
        if reg.kind == "q":
            if any(r is reg for r, _ in self.qregs):
                raise CodeError(f"El registro «{reg.name}» ya está en el circuito")
            self.qregs.append((reg, self.nq))
            self.nq += reg.size
        else:
            if any(r is reg for r, _ in self.cregs):
                raise CodeError(f"El registro «{reg.name}» ya está en el circuito")
            self.cregs.append((reg, self.nc))
            self.nc += reg.size
        if self.nq > MAX_QUBITS_MODEL:
            raise CodeError(f"Demasiados cúbits (máximo {MAX_QUBITS_MODEL})")
        if self.nc > MAX_CLBITS_MODEL:
            raise CodeError(f"Demasiados bits clásicos (máximo {MAX_CLBITS_MODEL})")

    def current_condition(self) -> tuple[tuple[int, int], ...]:
        out: list[tuple[int, int]] = []
        for cond in self.cond_stack:
            out.extend(cond)
        return tuple(out)

    def emit(self, rop: ROp) -> None:
        cond = self.current_condition()
        if cond:
            rop = replace(rop, condition=tuple(rop.condition) + cond)
        for q in (*rop.targets, *rop.controls, *rop.anticontrols):
            self.touched.add(q)
        self.ops.append(rop)


@dataclass
class GateObj:
    base: str
    nt: int
    params: tuple[float, ...] = ()
    ctrl: tuple[bool, ...] = ()
    matrix: np.ndarray | None = None
    sub: Circ | None = None
    label: str | None = None


@dataclass
class _IfCtx:
    circ: Circ
    cond: tuple[tuple[int, int], ...]
    is_else: bool = False


class _Return(Exception):
    def __init__(self, value):
        self.value = value


class _Break(Exception):
    pass


class _Continue(Exception):
    pass


@dataclass
class UserFunc:
    node: ast.FunctionDef
    defaults: list
    kw_defaults: dict


@dataclass
class Module:
    name: str


@dataclass
class Bound:
    obj: Any
    name: str


@dataclass
class Builtin:
    name: str
    fn: Callable[..., Any]
    # Si recibe (interp, args, kwargs, node) en lugar de solo valores.
    raw: bool = False


# --- Biblioteca de funciones puras ------------------------------------------------------

def _num_arg(v, what="un número"):
    if isinstance(v, bool) or not isinstance(v, (int, float, complex)):
        raise CodeError(f"Se esperaba {what}, no {_type_name(v)}")
    return v


def _from_np(v):
    if isinstance(v, np.ndarray):
        if v.size > MAX_SEQUENCE:
            raise CodeError("Matriz demasiado grande")
        return v.tolist()
    if isinstance(v, np.generic):
        return v.item()
    return v


def _np_fn(fn):
    def call(*args, **kwargs):
        clean = []
        for a in args:
            if isinstance(a, (list, tuple)):
                clean.append(np.array(a))
            else:
                clean.append(_num_arg(a) if not isinstance(a, np.ndarray) else a)
        with np.errstate(all="ignore"):
            return _from_np(fn(*clean, **{k: v for k, v in kwargs.items() if k in ("dtype",)}))
    return call


def _math_fn(real_fn, complex_fn=None):
    def call(*args):
        vals = [_num_arg(a) for a in args]
        try:
            if any(isinstance(v, complex) for v in vals):
                if complex_fn is None:
                    raise CodeError("La función no admite números complejos")
                return complex_fn(*vals)
            return real_fn(*vals)
        except ValueError as exc:
            if complex_fn is not None:
                return complex_fn(*vals)
            raise CodeError(f"Valor fuera del dominio: {exc}") from exc
    return call


def _array(obj, dtype=None):
    def conv(x):
        if isinstance(x, (list, tuple)):
            return [conv(i) for i in x]
        _num_arg(x)
        return complex(x) if dtype is complex else x
    return conv(obj)


def _zeros(shape, dtype=None):
    dims = [shape] if isinstance(shape, int) else list(shape)
    total = 1
    for d in dims:
        if not isinstance(d, int) or d < 0:
            raise CodeError("Dimensión no válida")
        total *= d
    if total > MAX_SEQUENCE:
        raise CodeError("Matriz demasiado grande")
    return np.zeros(dims).tolist()


def _eye(n, dtype=None):
    if not isinstance(n, int) or n < 0 or n * n > MAX_SEQUENCE:
        raise CodeError("Dimensión no válida")
    return np.eye(n).tolist()


MATH_ATTRS: dict[str, Any] = {
    "pi": math.pi, "e": math.e, "tau": math.tau, "inf": math.inf,
    "sqrt": _math_fn(math.sqrt, cmath.sqrt), "sin": _math_fn(math.sin, cmath.sin), "cos": _math_fn(math.cos, cmath.cos),
    "tan": _math_fn(math.tan, cmath.tan), "asin": _math_fn(math.asin), "acos": _math_fn(math.acos),
    "atan": _math_fn(math.atan), "atan2": _math_fn(math.atan2), "exp": _math_fn(math.exp, cmath.exp),
    "log": _math_fn(math.log, cmath.log), "log2": _math_fn(math.log2), "log10": _math_fn(math.log10),
    "floor": _math_fn(math.floor), "ceil": _math_fn(math.ceil), "pow": _math_fn(math.pow),
    "radians": _math_fn(math.radians), "degrees": _math_fn(math.degrees), "gcd": _math_fn(math.gcd),
    "isclose": _math_fn(math.isclose), "fabs": _math_fn(math.fabs),
}

NUMPY_ATTRS: dict[str, Any] = {
    "pi": math.pi, "e": math.e, "inf": math.inf, "complex128": complex, "complex_": complex, "float64": float,
    "array": _array, "asarray": _array, "zeros": _zeros, "eye": _eye, "identity": _eye,
    **{name: _np_fn(getattr(np, name)) for name in (
        "sqrt", "sin", "cos", "tan", "arcsin", "arccos", "arctan", "arctan2", "exp", "log", "log2", "log10",
        "abs", "floor", "ceil", "round", "radians", "degrees", "conj", "conjugate", "real", "imag", "angle",
        "sign", "mod", "gcd", "sum", "transpose")},
}

QISKIT_GATE_CLASSES = {
    "HGate": ("h", 0, 1, 0), "XGate": ("x", 0, 1, 0), "YGate": ("y", 0, 1, 0), "ZGate": ("z", 0, 1, 0),
    "SGate": ("s", 0, 1, 0), "SdgGate": ("sdg", 0, 1, 0), "TGate": ("t", 0, 1, 0), "TdgGate": ("tdg", 0, 1, 0),
    "SXGate": ("sx", 0, 1, 0), "SXdgGate": ("sxdg", 0, 1, 0), "IGate": ("id", 0, 1, 0),
    "PhaseGate": ("p", 1, 1, 0), "U1Gate": ("p", 1, 1, 0), "RXGate": ("rx", 1, 1, 0), "RYGate": ("ry", 1, 1, 0),
    "RZGate": ("rz", 1, 1, 0), "UGate": ("u", 3, 1, 0), "U3Gate": ("u", 3, 1, 0),
    "SwapGate": ("swap", 0, 2, 0), "iSwapGate": ("iswap", 0, 2, 0), "RXXGate": ("rxx", 1, 2, 0),
    "RYYGate": ("ryy", 1, 2, 0), "RZZGate": ("rzz", 1, 2, 0),
    "CXGate": ("x", 0, 1, 1), "CYGate": ("y", 0, 1, 1), "CZGate": ("z", 0, 1, 1), "CHGate": ("h", 0, 1, 1),
    "CSGate": ("s", 0, 1, 1), "CSdgGate": ("sdg", 0, 1, 1), "CSXGate": ("sx", 0, 1, 1),
    "CPhaseGate": ("p", 1, 1, 1), "CRXGate": ("rx", 1, 1, 1), "CRYGate": ("ry", 1, 1, 1),
    "CRZGate": ("rz", 1, 1, 1), "CCXGate": ("x", 0, 1, 2), "CCZGate": ("z", 0, 1, 2),
    "CSwapGate": ("swap", 0, 2, 1),
}

# Métodos de QuantumCircuit que crean compuertas: (base, nº de parámetros, nº de controles, nº de objetivos)
GATE_METHODS: dict[str, tuple[str, int, int, int]] = {
    "x": ("x", 0, 0, 1), "y": ("y", 0, 0, 1), "z": ("z", 0, 0, 1), "h": ("h", 0, 0, 1), "s": ("s", 0, 0, 1),
    "sdg": ("sdg", 0, 0, 1), "t": ("t", 0, 0, 1), "tdg": ("tdg", 0, 0, 1), "sx": ("sx", 0, 0, 1),
    "sxdg": ("sxdg", 0, 0, 1), "id": ("id", 0, 0, 1), "i": ("id", 0, 0, 1), "p": ("p", 1, 0, 1),
    "u1": ("p", 1, 0, 1), "rx": ("rx", 1, 0, 1), "ry": ("ry", 1, 0, 1), "rz": ("rz", 1, 0, 1),
    "u": ("u", 3, 0, 1), "u3": ("u", 3, 0, 1), "swap": ("swap", 0, 0, 2), "iswap": ("iswap", 0, 0, 2),
    "rxx": ("rxx", 1, 0, 2), "ryy": ("ryy", 1, 0, 2), "rzz": ("rzz", 1, 0, 2),
    "cx": ("x", 0, 1, 1), "cnot": ("x", 0, 1, 1), "cy": ("y", 0, 1, 1), "cz": ("z", 0, 1, 1),
    "ch": ("h", 0, 1, 1), "cs": ("s", 0, 1, 1), "csdg": ("sdg", 0, 1, 1), "csx": ("sx", 0, 1, 1),
    "cp": ("p", 1, 1, 1), "cu1": ("p", 1, 1, 1), "crx": ("rx", 1, 1, 1), "cry": ("ry", 1, 1, 1),
    "crz": ("rz", 1, 1, 1), "ccx": ("x", 0, 2, 1), "toffoli": ("x", 0, 2, 1), "ccz": ("z", 0, 2, 1),
    "cswap": ("swap", 0, 1, 2), "fredkin": ("swap", 0, 1, 2),
}

IGNORED_CIRCUIT_METHODS = {"draw", "depth", "size", "width", "count_ops", "decompose", "num_nonlocal_gates",
                           "num_tensor_factors", "num_unitary_factors", "qasm", "save_statevector",
                           "save_density_matrix", "save_probabilities", "save_probabilities_dict"}

IGNORED_MODULES = {"qiskit_aer", "qiskit.providers", "qiskit.providers.aer", "qiskit.visualization",
                   "qiskit.primitives", "qiskit_ibm_runtime", "qiskit_ibm_provider", "qiskit.quantum_info",
                   "qiskit.transpiler", "qiskit.result", "qiskit.tools", "qiskit.tools.visualization",
                   "matplotlib", "matplotlib.pyplot", "IPython", "IPython.display", "qiskit.qasm2",
                   "qiskit.qasm3", "qiskit_aer.noise", "qiskit.compiler", "qiskit_aer.primitives"}
IGNORED_NAMES = {"transpile", "execute", "Aer", "BasicAer", "assemble", "print", "display", "plot_histogram",
                 "plot_bloch_multivector", "plot_state_city", "plot_state_qsphere"}


def _type_name(v) -> str:
    if isinstance(v, Circ):
        return "un QuantumCircuit"
    if isinstance(v, GateObj):
        return "una compuerta"
    if isinstance(v, Reg):
        return "un registro"
    if isinstance(v, Bit):
        return "un cúbit" if v.kind == "q" else "un bit clásico"
    return {bool: "un booleano", int: "un entero", float: "un número", complex: "un complejo", str: "un texto",
            list: "una lista", tuple: "una tupla", dict: "un diccionario", type(None): "None"}.get(
        type(v), type(v).__name__)


_SAFE_METHODS = {
    list: {"append", "extend", "insert", "pop", "index", "count", "reverse", "copy", "remove", "clear"},
    tuple: {"index", "count"},
    str: {"upper", "lower", "join", "zfill", "replace", "split", "strip", "startswith", "endswith", "count",
          "rjust", "ljust", "find"},
    dict: {"get", "items", "keys", "values", "copy"},
    int: {"bit_length"},
    complex: {"conjugate"},
    float: {"is_integer"},
}


def _guard_size(v):
    if isinstance(v, (list, tuple, str)) and len(v) > MAX_SEQUENCE:
        raise CodeError("Secuencia demasiado grande")
    if isinstance(v, int) and not isinstance(v, bool) and v.bit_length() > 4096:
        raise CodeError("Número entero demasiado grande")
    return v


def _builtin_range(*args):
    for a in args:
        if not isinstance(a, int) or isinstance(a, bool):
            raise CodeError("range() necesita números enteros")
    r = range(*args)
    if len(r) > MAX_SEQUENCE:
        raise CodeError("range() demasiado grande")
    return r


BUILTINS: dict[str, Any] = {
    "range": _builtin_range, "len": len, "list": list, "tuple": tuple, "int": int, "float": float,
    "complex": complex, "abs": abs, "min": min, "max": max, "sum": sum, "round": round, "enumerate": enumerate,
    "zip": zip, "reversed": reversed, "sorted": sorted, "str": str, "bool": bool, "pow": pow, "divmod": divmod,
    "bin": bin, "any": any, "all": all, "dict": dict, "format": format,
    "True": True, "False": False, "None": None,
}


class Interpreter:
    def __init__(self):
        self.globals: dict[str, Any] = {"__name__": "__coherencia__"}
        self.steps = 0
        self.depth = 0
        self.ignored_lines: list[int] = []
        self.warnings: list[str] = []
        self.circuits: list[Circ] = []
        self.line = 0

    # -- utilidades ---------------------------------------------------------------------
    def tick(self, node) -> None:
        self.steps += 1
        if self.steps > MAX_STEPS:
            raise _TooLong("El programa tarda demasiado (¿un ciclo infinito?)")

    def fail(self, msg: str, node=None):
        raise CodeError(msg, getattr(node, "lineno", None) or self.line or None, getattr(node, "col_offset", None))

    # -- módulos ---------------------------------------------------------------------------
    def module_attrs(self, name: str) -> dict[str, Any] | None:
        if name in ("math", "cmath"):
            return MATH_ATTRS
        if name == "numpy":
            return NUMPY_ATTRS
        if name in ("qiskit", "qiskit.circuit"):
            return {
                "QuantumCircuit": Builtin("QuantumCircuit", self.new_circuit, raw=True),
                "QuantumRegister": Builtin("QuantumRegister", lambda *a, **k: self.new_register("q", *a, **k)),
                "ClassicalRegister": Builtin("ClassicalRegister", lambda *a, **k: self.new_register("c", *a, **k)),
                "Parameter": Builtin("Parameter", self.no_parameters),
                "ParameterVector": Builtin("ParameterVector", self.no_parameters),
                "transpile": IGN, "execute": IGN, "Aer": IGN, "BasicAer": IGN,
            }
        if name in ("qiskit.circuit.library", "qiskit.extensions", "qiskit.circuit.library.standard_gates"):
            attrs: dict[str, Any] = {cls: Builtin(cls, self._gate_class(cls)) for cls in QISKIT_GATE_CLASSES}
            attrs.update({
                "UnitaryGate": Builtin("UnitaryGate", self.unitary_gate),
                "QFTGate": Builtin("QFTGate", self.qft_gate),
                "QFT": Builtin("QFT", self.qft_circuit),
                "MCXGate": Builtin("MCXGate", self.mcx_gate),
                "MCPhaseGate": Builtin("MCPhaseGate", self.mcp_gate),
            })
            return attrs
        return None

    def import_module(self, name: str, node) -> Module:
        if name in IGNORED_MODULES or any(name.startswith(m + ".") for m in IGNORED_MODULES):
            return Module(name)
        if self.module_attrs(name) is None and name not in ("qiskit", "qiskit.circuit"):
            self.fail(f"No se puede importar «{name}» en Coherencia (se admiten qiskit, math y numpy)", node)
        return Module(name)

    def module_get(self, mod: Module, attr: str, node):
        if mod.name in IGNORED_MODULES or any(mod.name.startswith(m + ".") for m in IGNORED_MODULES):
            return IGN
        sub = f"{mod.name}.{attr}"
        if sub in IGNORED_MODULES or self.module_attrs(sub) is not None:
            return Module(sub)
        attrs = self.module_attrs(mod.name) or {}
        if attr in attrs:
            return attrs[attr]
        self.fail(f"«{mod.name}.{attr}» no está disponible en Coherencia", node)

    # -- constructores de Qiskit ------------------------------------------------------------
    def no_parameters(self, *args, **kwargs):
        raise CodeError("Los parámetros simbólicos (Parameter) aún no se admiten: usa números o variables de Python")

    def new_register(self, kind: str, size=None, name=None, bits=None):
        if not isinstance(size, int) or isinstance(size, bool) or size < 0:
            raise CodeError("El tamaño del registro debe ser un entero")
        limit = MAX_QUBITS_MODEL if kind == "q" else MAX_CLBITS_MODEL
        if size > limit:
            raise CodeError(f"Registro demasiado grande (máximo {limit})")
        return Reg(kind, size, str(name) if name is not None else ("q" if kind == "q" else "c"))

    def new_circuit(self, args, kwargs, node):
        circ = Circ(kwargs.get("name"))
        ints = [a for a in args if isinstance(a, int) and not isinstance(a, bool)]
        if ints:
            if len(ints) != len(args) or len(ints) > 2:
                self.fail("Usa QuantumCircuit(n) o QuantumCircuit(n, m), o bien registros", node)
            circ.add_register(Reg("q", ints[0], "q"))
            if len(ints) == 2:
                circ.add_register(Reg("c", ints[1], "c"))
        else:
            for a in args:
                if isinstance(a, Reg):
                    circ.add_register(a)
                elif isinstance(a, list) and all(isinstance(r, Reg) for r in a):
                    for r in a:
                        circ.add_register(r)
                else:
                    self.fail(f"QuantumCircuit no acepta {_type_name(a)}", node)
        self.circuits.append(circ)
        return circ

    def _gate_class(self, cls: str):
        base, np_, nt, nctrl = QISKIT_GATE_CLASSES[cls]

        def make(*args, **kwargs):
            params = [a for a in args if not isinstance(a, str)][:np_]
            for key in ("theta", "phi", "lam", "lambda"):
                if key in kwargs:
                    params.append(kwargs[key])
            if len(params) != np_:
                raise CodeError(f"{cls} necesita {np_} parámetro(s)")
            g = GateObj(base, nt, tuple(_real(p) for p in params), label=kwargs.get("label"))
            if nctrl:
                g = _control(g, nctrl, kwargs.get("ctrl_state"))
            return g
        return make

    def unitary_gate(self, data, label=None, **_):
        mat = _to_matrix(data)
        n = int(round(math.log2(mat.shape[0]))) if mat.shape[0] > 0 else 0
        if mat.shape[0] != mat.shape[1] or (1 << n) != mat.shape[0] or n < 1:
            raise CodeError("UnitaryGate necesita una matriz cuadrada de 2ⁿ×2ⁿ")
        if n > 4:
            raise CodeError("Coherencia admite matrices personalizadas de hasta 4 cúbits")
        if not np.allclose(mat.conj().T @ mat, np.eye(mat.shape[0]), atol=1e-6):
            raise CodeError("La matriz no es unitaria (U†U ≠ I)")
        return GateObj("unitary", n, matrix=mat, label=label)

    def qft_gate(self, num_qubits=None, **kwargs):
        if not isinstance(num_qubits, int) or num_qubits < 1:
            raise CodeError("QFTGate necesita el número de cúbits")
        return GateObj("qft", num_qubits)

    def qft_circuit(self, num_qubits=None, approximation_degree=0, do_swaps=True, inverse=False,
                    insert_barriers=False, name=None):
        if not isinstance(num_qubits, int) or num_qubits < 1:
            raise CodeError("QFT necesita el número de cúbits")
        if approximation_degree:
            raise CodeError("La QFT aproximada (approximation_degree) no se admite")
        circ = Circ(name or ("IQFT" if inverse else "QFT"))
        circ.add_register(Reg("q", num_qubits, "q"))
        ts = tuple(range(num_qubits))
        swaps = [ROp("gate", "swap", (ts[q], ts[num_qubits - q - 1])) for q in range(num_qubits // 2)]
        if inverse:
            if not do_swaps:
                circ.ops.extend(swaps)  # QFT⁻¹ sin intercambios = QFT⁻¹ · SWAPs
            circ.ops.append(ROp("gate", "iqft", ts))
        else:
            circ.ops.append(ROp("gate", "qft", ts))
            if not do_swaps:
                circ.ops.extend(swaps)  # QFT sin intercambios = SWAPs · QFT
        return circ

    def mcx_gate(self, num_ctrl_qubits=None, label=None, ctrl_state=None):
        if not isinstance(num_ctrl_qubits, int) or num_ctrl_qubits < 1:
            raise CodeError("MCXGate necesita el número de controles")
        return _control(GateObj("x", 1), num_ctrl_qubits, ctrl_state)

    def mcp_gate(self, lam=None, num_ctrl_qubits=None, label=None, ctrl_state=None):
        if not isinstance(num_ctrl_qubits, int) or num_ctrl_qubits < 1:
            raise CodeError("MCPhaseGate necesita el número de controles")
        return _control(GateObj("p", 1, (_real(lam),)), num_ctrl_qubits, ctrl_state)

    def modmul_builtin(self, a=None, N=None, n=None):
        vals = []
        for v in (a, N, n):
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not float(v).is_integer():
                raise CodeError("modmul_gate(a, N, n) necesita enteros")
            vals.append(int(v))
        a, N, n = vals
        if not 1 <= n <= 10:
            raise CodeError("modmul_gate admite entre 1 y 10 cúbits")
        return GateObj("modmul", n, (float(a), float(N)), label=f"×{a} mod {N}")

    # -- ejecución -------------------------------------------------------------------------
    def run(self, code: str) -> None:
        if len(code) > MAX_CODE_LENGTH:
            raise CodeError("El código es demasiado largo")
        try:
            tree = ast.parse(code, mode="exec")
        except SyntaxError as exc:
            raise CodeError(_syntax_message(exc), exc.lineno, (exc.offset or 1) - 1) from None
        try:
            self.exec_block(tree.body, self.globals)
        except CodeError as exc:
            if exc.line is None:
                exc.line = self.line or None
            raise

    def exec_block(self, body: list[ast.stmt], env: dict) -> None:
        for stmt in body:
            self.exec_stmt(stmt, env)

    def exec_stmt(self, node: ast.stmt, env: dict) -> None:
        self.tick(node)
        self.line = node.lineno
        try:
            self._exec_stmt(node, env)
        except _TooLong as exc:
            if exc.line is None and isinstance(node, (ast.For, ast.While)):
                exc.line = node.lineno
            raise
        except CodeError as exc:
            if exc.line is None:
                exc.line = node.lineno
            raise
        except (_Return, _Break, _Continue):
            raise
        except RecursionError:
            raise CodeError("Demasiada recursión", node.lineno) from None
        except ZeroDivisionError:
            raise CodeError("División entre cero", node.lineno) from None
        except IndexError:
            raise CodeError("Índice fuera de rango", node.lineno) from None
        except KeyError as exc:
            raise CodeError(f"Clave inexistente: {exc}", node.lineno) from None
        except (TypeError, ValueError, OverflowError, AttributeError) as exc:
            raise CodeError(f"Operación no válida: {exc}", node.lineno) from None

    def _exec_stmt(self, node: ast.stmt, env: dict) -> None:
        if isinstance(node, ast.Expr):
            if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                return  # docstring
            value = self.eval(node.value, env)
            if value is IGN:
                self.ignored_lines.append(node.lineno)
            return
        if isinstance(node, ast.Assign):
            value = self.eval(node.value, env)
            if value is IGN:
                self.ignored_lines.append(node.lineno)
            for target in node.targets:
                self.assign(target, value, env)
            return
        if isinstance(node, ast.AnnAssign):
            if node.value is not None:
                self.assign(node.target, self.eval(node.value, env), env)
            return
        if isinstance(node, ast.AugAssign):
            current = self.eval(_load(node.target), env)
            value = self.binop(node.op, current, self.eval(node.value, env), node)
            self.assign(node.target, value, env)
            return
        if isinstance(node, ast.Import):
            for alias in node.names:
                mod = self.import_module(alias.name, node)
                if alias.asname:
                    env[alias.asname] = mod
                else:
                    top = alias.name.split(".")[0]
                    env[top] = Module(top) if top != alias.name else mod
            return
        if isinstance(node, ast.ImportFrom):
            modname = node.module or ""
            mod = self.import_module(modname, node)
            for alias in node.names:
                if alias.name == "*":
                    attrs = self.module_attrs(modname) or {}
                    env.update(attrs)
                    continue
                env[alias.asname or alias.name] = self.module_get(mod, alias.name, node)
            return
        if isinstance(node, ast.For):
            iterable = self.eval(node.iter, env)
            items = self.iterate(iterable, node)
            broke = False
            for item in items:
                self.tick(node)
                self.assign(node.target, item, env)
                try:
                    self.exec_block(node.body, env)
                except _Break:
                    broke = True
                    break
                except _Continue:
                    continue
            if not broke and node.orelse:
                self.exec_block(node.orelse, env)
            return
        if isinstance(node, ast.While):
            while self.truth(self.eval(node.test, env)):
                self.tick(node)
                try:
                    self.exec_block(node.body, env)
                except _Break:
                    break
                except _Continue:
                    continue
            return
        if isinstance(node, ast.If):
            test = self.eval(node.test, env)
            if test is IGN:
                return
            self.exec_block(node.body if self.truth(test) else node.orelse, env)
            return
        if isinstance(node, ast.With):
            self.exec_with(node, env)
            return
        if isinstance(node, ast.FunctionDef):
            if node.name == "modmul_gate":
                env["modmul_gate"] = Builtin("modmul_gate", self.modmul_builtin)
                return
            if node.decorator_list:
                self.fail("Los decoradores no se admiten", node)
            args = node.args
            if args.vararg or args.kwarg or args.posonlyargs:
                self.fail("Solo se admiten funciones con argumentos simples", node)
            defaults = [self.eval(d, env) for d in args.defaults]
            kw_defaults = {a.arg: self.eval(d, env) for a, d in zip(args.kwonlyargs, args.kw_defaults) if d}
            env[node.name] = UserFunc(node, defaults, kw_defaults)
            return
        if isinstance(node, ast.Return):
            raise _Return(self.eval(node.value, env) if node.value is not None else None)
        if isinstance(node, ast.Pass):
            return
        if isinstance(node, ast.Break):
            raise _Break()
        if isinstance(node, ast.Continue):
            raise _Continue()
        if isinstance(node, ast.Assert):
            if not self.truth(self.eval(node.test, env)):
                self.fail("La afirmación (assert) no se cumple", node)
            return
        if isinstance(node, ast.Delete):
            return
        self.fail(f"La instrucción «{type(node).__name__}» no se admite en Coherencia", node)

    def exec_with(self, node: ast.With, env: dict) -> None:
        if len(node.items) != 1:
            self.fail("Usa un solo bloque with a la vez", node)
        item = node.items[0]
        ctx = self.eval(item.context_expr, env)
        if not isinstance(ctx, _IfCtx):
            self.fail("Solo se admite with qc.if_test(...)", node)
        if item.optional_vars is not None:
            if ctx.is_else:
                self.fail("Un bloque else no tiene otro else", node)
            self.assign(item.optional_vars, _IfCtx(ctx.circ, ctx.cond, is_else=True), env)
        cond = ctx.cond
        if ctx.is_else:
            if len(cond) != 1:
                self.fail("El bloque else solo se admite con condiciones de un único bit", node)
            cond = ((cond[0][0], 1 - cond[0][1]),)
        ctx.circ.cond_stack.append(cond)
        try:
            self.exec_block(node.body, env)
        finally:
            ctx.circ.cond_stack.pop()

    # -- asignación ------------------------------------------------------------------------
    def assign(self, target, value, env: dict) -> None:
        if isinstance(target, ast.Name):
            env[target.id] = value
            return
        if isinstance(target, (ast.Tuple, ast.List)):
            items = list(self.iterate(value, target))
            if len(items) != len(target.elts):
                self.fail(f"Se esperaban {len(target.elts)} valores y hay {len(items)}", target)
            for t, v in zip(target.elts, items):
                self.assign(t, v, env)
            return
        if isinstance(target, ast.Subscript):
            obj = self.eval(target.value, env)
            key = self.eval(target.slice, env)
            if isinstance(obj, (list, dict)):
                obj[key] = value
                return
            self.fail("Solo se puede asignar por índice en listas y diccionarios", target)
        if isinstance(target, ast.Attribute):
            obj = self.eval(target.value, env)
            if isinstance(obj, Circ) and target.attr == "name":
                obj.name = str(value)
                return
            if isinstance(obj, GateObj) and target.attr in ("label", "name"):
                obj.label = str(value)
                return
            self.fail(f"No se puede asignar el atributo «{target.attr}»", target)
        self.fail("Destino de asignación no admitido", target)

    # -- evaluación ------------------------------------------------------------------------
    def lookup(self, name: str, env: dict, node):
        if name in env:
            return env[name]
        if name in self.globals:
            return self.globals[name]
        if name in IGNORED_NAMES:
            return IGN
        if name in BUILTINS:
            return BUILTINS[name]
        self.fail(f"«{name}» no está definido", node)

    def truth(self, v) -> bool:
        if isinstance(v, (Circ, GateObj, Reg)):
            return True
        return bool(v)

    def iterate(self, value, node):
        if isinstance(value, Reg):
            return [Bit(value.kind, value, i) for i in range(value.size)]
        if isinstance(value, (list, tuple, range, str, dict)):
            return list(value)
        if isinstance(value, Iterator) and type(value).__module__ == "builtins":
            items = []
            for item in value:
                items.append(item)
                if len(items) > MAX_SEQUENCE:
                    self.fail("Secuencia demasiado grande", node)
            return items
        self.fail(f"No se puede recorrer {_type_name(value)}", node)

    def eval(self, node, env: dict):
        self.tick(node)
        method = getattr(self, f"_e_{type(node).__name__}", None)
        if method is None:
            self.fail(f"La expresión «{type(node).__name__}» no se admite", node)
        return _guard_size(method(node, env))

    def _e_Constant(self, node, env):
        if isinstance(node.value, bytes):
            self.fail("Los bytes no se admiten", node)
        return node.value

    def _e_Name(self, node, env):
        return self.lookup(node.id, env, node)

    def _e_List(self, node, env):
        return self._elements(node.elts, env)

    def _e_Tuple(self, node, env):
        return tuple(self._elements(node.elts, env))

    def _e_Set(self, node, env):
        return self._elements(node.elts, env)

    def _elements(self, elts, env):
        out = []
        for e in elts:
            if isinstance(e, ast.Starred):
                out.extend(self.iterate(self.eval(e.value, env), e))
            else:
                out.append(self.eval(e, env))
        return out

    def _e_Dict(self, node, env):
        return {self.eval(k, env): self.eval(v, env) for k, v in zip(node.keys, node.values) if k is not None}

    def _e_JoinedStr(self, node, env):
        parts = []
        for v in node.values:
            if isinstance(v, ast.Constant):
                parts.append(str(v.value))
            elif isinstance(v, ast.FormattedValue):
                val = self.eval(v.value, env)
                spec = self.eval(v.format_spec, env) if v.format_spec is not None else ""
                if not isinstance(val, (int, float, complex, str, bool, type(None))):
                    val = str(val)
                parts.append(format(val, spec))
        return "".join(parts)

    def _e_BinOp(self, node, env):
        return self.binop(node.op, self.eval(node.left, env), self.eval(node.right, env), node)

    def binop(self, op, a, b, node):
        if a is IGN or b is IGN:
            return IGN
        if isinstance(op, ast.Pow) and isinstance(a, int) and isinstance(b, int) and abs(a) > 1 and b > 4096:
            self.fail("Potencia demasiado grande", node)
        if isinstance(op, ast.Mult):
            for seq, k in ((a, b), (b, a)):
                if isinstance(seq, (list, tuple, str)) and isinstance(k, int) and len(seq) * max(k, 0) > MAX_SEQUENCE:
                    self.fail("Secuencia demasiado grande", node)
        if isinstance(op, ast.LShift) and isinstance(b, int) and b > 4096:
            self.fail("Desplazamiento demasiado grande", node)
        for v in (a, b):
            if isinstance(v, (Circ, GateObj, Reg, Bit, Module, UserFunc, Builtin, Bound)):
                self.fail(f"No se puede operar con {_type_name(v)}", node)
        ops = {ast.Add: lambda: a + b, ast.Sub: lambda: a - b, ast.Mult: lambda: a * b, ast.Div: lambda: a / b,
               ast.FloorDiv: lambda: a // b, ast.Mod: lambda: a % b, ast.Pow: lambda: a ** b,
               ast.BitAnd: lambda: a & b, ast.BitOr: lambda: a | b, ast.BitXor: lambda: a ^ b,
               ast.LShift: lambda: a << b, ast.RShift: lambda: a >> b}
        fn = ops.get(type(op))
        if fn is None:
            self.fail("Operador no admitido", node)
        if isinstance(op, ast.Mod) and isinstance(a, str):
            self.fail("El formato con % no se admite; usa f-strings", node)
        return fn()

    def _e_UnaryOp(self, node, env):
        v = self.eval(node.operand, env)
        if v is IGN:
            return IGN
        if isinstance(node.op, ast.Not):
            return not self.truth(v)
        if isinstance(v, (Circ, GateObj, Reg, Bit)):
            self.fail(f"No se puede operar con {_type_name(v)}", node)
        if isinstance(node.op, ast.USub):
            return -v
        if isinstance(node.op, ast.UAdd):
            return +v
        if isinstance(node.op, ast.Invert):
            return ~v
        self.fail("Operador no admitido", node)

    def _e_BoolOp(self, node, env):
        if isinstance(node.op, ast.And):
            value = True
            for v in node.values:
                value = self.eval(v, env)
                if not self.truth(value):
                    return value
            return value
        value = False
        for v in node.values:
            value = self.eval(v, env)
            if self.truth(value):
                return value
        return value

    def _e_Compare(self, node, env):
        left = self.eval(node.left, env)
        for op, comp in zip(node.ops, node.comparators):
            right = self.eval(comp, env)
            if left is IGN or right is IGN:
                return IGN
            if isinstance(op, ast.Eq):
                ok = left == right
            elif isinstance(op, ast.NotEq):
                ok = left != right
            elif isinstance(op, ast.Lt):
                ok = left < right
            elif isinstance(op, ast.LtE):
                ok = left <= right
            elif isinstance(op, ast.Gt):
                ok = left > right
            elif isinstance(op, ast.GtE):
                ok = left >= right
            elif isinstance(op, ast.In):
                ok = left in right
            elif isinstance(op, ast.NotIn):
                ok = left not in right
            elif isinstance(op, ast.Is):
                ok = left is right
            elif isinstance(op, ast.IsNot):
                ok = left is not right
            else:
                self.fail("Comparación no admitida", node)
            if not ok:
                return False
            left = right
        return True

    def _e_IfExp(self, node, env):
        return self.eval(node.body if self.truth(self.eval(node.test, env)) else node.orelse, env)

    def _e_Subscript(self, node, env):
        obj = self.eval(node.value, env)
        key = self.eval(node.slice, env)
        if obj is IGN:
            return IGN
        if isinstance(obj, Reg):
            if isinstance(key, slice):
                return [Bit(obj.kind, obj, i) for i in range(obj.size)[key]]
            if not isinstance(key, int):
                self.fail("El índice de un registro debe ser entero", node)
            idx = key + obj.size if key < 0 else key
            if not 0 <= idx < obj.size:
                self.fail(f"El registro «{obj.name}» tiene {obj.size} elementos (índice {key})", node)
            return Bit(obj.kind, obj, idx)
        if isinstance(obj, (list, tuple, str, range, dict)):
            if isinstance(obj, dict):
                return obj[key]
            if isinstance(key, tuple):
                # Indexado al estilo numpy: m[i, j]
                val = obj
                for k in key:
                    val = val[k]
                return val
            return obj[key]
        self.fail(f"No se puede indexar {_type_name(obj)}", node)

    def _e_Slice(self, node, env):
        def ev(n):
            return self.eval(n, env) if n is not None else None
        return slice(ev(node.lower), ev(node.upper), ev(node.step))

    def _e_Attribute(self, node, env):
        obj = self.eval(node.value, env)
        return self.get_attr(obj, node.attr, node)

    def get_attr(self, obj, attr: str, node):
        if attr.startswith("_"):
            self.fail("No se puede acceder a atributos privados", node)
        if obj is IGN:
            return IGN
        if isinstance(obj, Module):
            return self.module_get(obj, attr, node)
        if isinstance(obj, Circ):
            if attr == "num_qubits":
                return obj.nq
            if attr == "num_clbits":
                return obj.nc
            if attr == "qubits":
                return [Bit("q", None, i) for i in range(obj.nq)]
            if attr == "clbits":
                return [Bit("c", None, i) for i in range(obj.nc)]
            if attr == "name":
                return obj.name or "circuit"
            if attr == "qregs":
                return [r for r, _ in obj.qregs]
            if attr == "cregs":
                return [r for r, _ in obj.cregs]
            if attr in IGNORED_CIRCUIT_METHODS:
                return Builtin(attr, lambda *a, **k: IGN)
            return Bound(obj, attr)
        if isinstance(obj, GateObj):
            if attr in ("control", "inverse", "power", "to_matrix", "repeat"):
                return Bound(obj, attr)
            if attr in ("num_qubits",):
                return len(obj.ctrl) + obj.nt
            if attr in ("params",):
                return list(obj.params)
            if attr in ("label", "name"):
                return obj.label or obj.base
            self.fail(f"Las compuertas no tienen «{attr}» en Coherencia", node)
        if isinstance(obj, Reg):
            if attr == "size":
                return obj.size
            if attr == "name":
                return obj.name
            self.fail(f"Los registros no tienen «{attr}»", node)
        if isinstance(obj, (int, float, complex)) and not isinstance(obj, bool) and attr in ("real", "imag"):
            return getattr(obj, attr)
        for typ, names in _SAFE_METHODS.items():
            if isinstance(obj, typ) and attr in names:
                return getattr(obj, attr)
        self.fail(f"{_type_name(obj).capitalize()} no tiene «{attr}» (o no está permitido)", node)

    def _e_Call(self, node, env):
        func = self.eval(node.func, env)
        args = []
        for a in node.args:
            if isinstance(a, ast.Starred):
                args.extend(self.iterate(self.eval(a.value, env), a))
            else:
                args.append(self.eval(a, env))
        kwargs = {}
        for kw in node.keywords:
            if kw.arg is None:
                extra = self.eval(kw.value, env)
                if not isinstance(extra, dict):
                    self.fail("** necesita un diccionario", node)
                kwargs.update(extra)
            else:
                kwargs[kw.arg] = self.eval(kw.value, env)
        return self.call(func, args, kwargs, node)

    def call(self, func, args, kwargs, node):
        if func is IGN:
            return IGN
        if isinstance(func, Builtin):
            if func.raw:
                return func.fn(args, kwargs, node)
            try:
                return func.fn(*args, **kwargs)
            except CodeError as exc:
                if exc.line is None:
                    exc.line = node.lineno
                raise
        if isinstance(func, Bound):
            if isinstance(func.obj, Circ):
                return self.circuit_method(func.obj, func.name, args, kwargs, node)
            return self.gate_method(func.obj, func.name, args, kwargs, node)
        if isinstance(func, UserFunc):
            return self.call_user(func, args, kwargs, node)
        if callable(func) and (func in BUILTINS.values() or func in MATH_ATTRS.values()
                               or func in NUMPY_ATTRS.values() or getattr(func, "__self__", None) is not None):
            if func in (sorted, min, max) and "key" in kwargs:
                self.fail("El argumento key= no se admite", node)
            for a in args:
                if isinstance(a, (UserFunc, Builtin, Bound)):
                    self.fail("No se pueden pasar funciones como argumento", node)
            args = [self.iterate(a, node) if isinstance(a, Reg) else a for a in args]
            try:
                return func(*args, **kwargs)
            except CodeError as exc:
                if exc.line is None:
                    exc.line = node.lineno
                raise
        self.fail(f"{_type_name(func).capitalize()} no se puede llamar", node)

    def call_user(self, fn: UserFunc, args, kwargs, node):
        self.depth += 1
        if self.depth > MAX_CALL_DEPTH:
            self.fail("Demasiadas llamadas anidadas", node)
        try:
            spec = fn.node.args
            names = [a.arg for a in spec.args]
            if len(args) > len(names):
                self.fail(f"{fn.node.name}() recibe como mucho {len(names)} argumentos", node)
            local: dict[str, Any] = {}
            first_default = len(names) - len(fn.defaults)
            for i, name in enumerate(names):
                if i < len(args):
                    local[name] = args[i]
                elif name in kwargs:
                    local[name] = kwargs.pop(name)
                elif i >= first_default:
                    local[name] = fn.defaults[i - first_default]
                else:
                    self.fail(f"Falta el argumento «{name}» de {fn.node.name}()", node)
            for a in spec.kwonlyargs:
                if a.arg in kwargs:
                    local[a.arg] = kwargs.pop(a.arg)
                elif a.arg in fn.kw_defaults:
                    local[a.arg] = fn.kw_defaults[a.arg]
                else:
                    self.fail(f"Falta el argumento «{a.arg}» de {fn.node.name}()", node)
            if kwargs:
                self.fail(f"{fn.node.name}() no tiene el argumento «{next(iter(kwargs))}»", node)
            scope = _Scope(local, self.globals)
            try:
                self.exec_block(fn.node.body, scope)
            except _Return as ret:
                return ret.value
            return None
        finally:
            self.depth -= 1

    def _e_ListComp(self, node, env):
        out: list = []
        self._comprehension(node.generators, 0, _Scope({}, env), lambda sc: out.append(self.eval(node.elt, sc)))
        return out

    _e_GeneratorExp = _e_ListComp
    _e_SetComp = _e_ListComp

    def _e_DictComp(self, node, env):
        out: dict = {}

        def add(sc):
            out[self.eval(node.key, sc)] = self.eval(node.value, sc)
        self._comprehension(node.generators, 0, _Scope({}, env), add)
        return out

    def _comprehension(self, gens, i, scope, emit):
        if i == len(gens):
            emit(scope)
            return
        gen = gens[i]
        for item in self.iterate(self.eval(gen.iter, scope), gen):
            self.tick(gen)
            self.assign(gen.target, item, scope)
            if all(self.truth(self.eval(cond, scope)) for cond in gen.ifs):
                self._comprehension(gens, i + 1, scope, emit)

    def _e_Lambda(self, node, env):
        self.fail("Las funciones lambda no se admiten; usa def", node)

    # -- cúbits y bits -----------------------------------------------------------------------
    def qubits_of(self, circ: Circ, value, node, kind: str = "q") -> list[int]:
        size = circ.nq if kind == "q" else circ.nc
        what = "cúbit" if kind == "q" else "bit clásico"
        if isinstance(value, bool):
            self.fail(f"Se esperaba un {what}", node)
        if isinstance(value, int):
            idx = value + size if value < 0 else value
            if not 0 <= idx < size:
                self.fail(f"El {what} {value} no existe (el circuito tiene {size})", node)
            return [idx]
        if isinstance(value, Bit):
            if value.kind != kind:
                self.fail(f"Se esperaba un {what} y se recibió {_type_name(value)}", node)
            if value.reg is None:
                if not 0 <= value.index < size:
                    self.fail(f"El {what} {value.index} no existe", node)
                return [value.index]
            regs = circ.qregs if kind == "q" else circ.cregs
            for reg, off in regs:
                if reg is value.reg:
                    return [off + value.index]
            self.fail(f"El registro «{value.reg.name}» no pertenece a este circuito", node)
        if isinstance(value, Reg):
            if value.kind != kind:
                self.fail(f"Se esperaba un registro de {what}s", node)
            return [q for i in range(value.size) for q in self.qubits_of(circ, Bit(kind, value, i), node, kind)]
        if isinstance(value, (list, tuple, range)):
            out: list[int] = []
            for v in value:
                out.extend(self.qubits_of(circ, v, node, kind))
            return out
        self.fail(f"Se esperaba un {what} y se recibió {_type_name(value)}", node)

    # -- métodos de QuantumCircuit ---------------------------------------------------------
    def circuit_method(self, circ: Circ, name: str, args, kwargs, node):
        line = node.lineno
        if name in GATE_METHODS:
            base, nparams, nctrl, nt = GATE_METHODS[name]
            args = list(args)
            params = args[:nparams]
            qargs = args[nparams:]
            names = ("theta", "phi", "lam", "lambda")
            for key in names:
                if key in kwargs and len(params) < nparams:
                    params.append(kwargs.pop(key))
            for key in ("control_qubit", "qubit", "target_qubit", "qubit1", "qubit2", "control_qubit1",
                        "control_qubit2"):
                if key in kwargs:
                    qargs.append(kwargs.pop(key))
            if len(params) != nparams or len(qargs) != nctrl + nt:
                self.fail(f"qc.{name}() necesita {nparams} parámetro(s) y {nctrl + nt} cúbit(s)", node)
            g = GateObj(base, nt, tuple(self.real(p, node) for p in params))
            if nctrl:
                g = _control(g, nctrl, kwargs.get("ctrl_state"))
            self.broadcast(circ, g, qargs, node, line)
            return circ
        if name == "cu":
            if len(args) != 6:
                self.fail("qc.cu(θ, φ, λ, γ, control, objetivo) necesita 6 argumentos", node)
            theta, phi, lam, gamma = (self.real(v, node) for v in args[:4])
            if abs(gamma) > 1e-12:
                if kwargs.get("ctrl_state") not in (None, 1, "1"):
                    self.fail("cu con γ ≠ 0 y ctrl_state no se admite", node)
                self.broadcast(circ, GateObj("p", 1, (gamma,)), [args[4]], node, line)
            self.broadcast(circ, _control(GateObj("u", 1, (theta, phi, lam)), 1, kwargs.get("ctrl_state")),
                           args[4:6], node, line)
            return circ
        if name == "mcx":
            if len(args) < 2:
                self.fail("qc.mcx(controles, objetivo) necesita dos argumentos", node)
            ctrls = self.qubits_of(circ, args[0], node)
            g = _control(GateObj("x", 1), len(ctrls), kwargs.get("ctrl_state"))
            self.apply_gate(circ, g, ctrls + self.qubits_of(circ, args[1], node), node, line)
            return circ
        if name == "mcp":
            if len(args) < 3:
                self.fail("qc.mcp(λ, controles, objetivo) necesita tres argumentos", node)
            ctrls = self.qubits_of(circ, args[1], node)
            g = _control(GateObj("p", 1, (self.real(args[0], node),)), len(ctrls), kwargs.get("ctrl_state"))
            self.apply_gate(circ, g, ctrls + self.qubits_of(circ, args[2], node), node, line)
            return circ
        if name in ("mcrx", "mcry", "mcrz"):
            if len(args) < 3:
                self.fail(f"qc.{name}(θ, controles, objetivo) necesita tres argumentos", node)
            ctrls = self.qubits_of(circ, args[1], node)
            g = _control(GateObj(name[2:], 1, (self.real(args[0], node),)), len(ctrls), None)
            self.apply_gate(circ, g, ctrls + self.qubits_of(circ, args[2], node), node, line)
            return circ
        if name == "unitary":
            if len(args) < 2:
                self.fail("qc.unitary(matriz, cúbits) necesita dos argumentos", node)
            g = self.unitary_gate(args[0], label=kwargs.get("label"))
            self.apply_gate(circ, g, self.qubits_of(circ, args[1], node), node, line)
            return circ
        if name == "measure":
            if len(args) != 2:
                self.fail("qc.measure(cúbit, bit) necesita dos argumentos", node)
            qs = self.qubits_of(circ, args[0], node)
            cs = self.qubits_of(circ, args[1], node, "c")
            if len(qs) != len(cs):
                self.fail(f"measure: {len(qs)} cúbit(s) y {len(cs)} bit(s) no coinciden", node)
            for q, c in zip(qs, cs):
                circ.emit(ROp("measure", targets=(q,), clbits=(c,), line=line))
            return circ
        if name == "measure_all":
            add_bits = kwargs.get("add_bits", True)
            if add_bits:
                start = circ.nc
                circ.add_register(Reg("c", circ.nq, "meas"))
                self.warnings.append(f"measure_all() añadió {circ.nq} bits clásicos (registro «meas»).")
            else:
                start = 0
                if circ.nc < circ.nq:
                    self.fail("measure_all(add_bits=False) necesita tantos bits clásicos como cúbits", node)
            circ.emit(ROp("barrier", targets=tuple(range(circ.nq)), line=line))
            for q in range(circ.nq):
                circ.emit(ROp("measure", targets=(q,), clbits=(start + q,), line=line))
            return None
        if name == "reset":
            for q in self.qubits_of(circ, list(args), node):
                circ.emit(ROp("reset", targets=(q,), line=line))
            return circ
        if name == "barrier":
            qs = self.qubits_of(circ, list(args), node) if args else list(range(circ.nq))
            circ.emit(ROp("barrier", targets=tuple(dict.fromkeys(qs)), line=line))
            return circ
        if name in ("append", "compose"):
            return self.append_or_compose(circ, name, args, kwargs, node)
        if name == "initialize" or name == "prepare_state":
            return self.initialize(circ, args, kwargs, node)
        if name == "if_test":
            if len(args) != 1:
                self.fail("if_test necesita una condición (bit, valor)", node)
            return _IfCtx(circ, self.condition(circ, args[0], node))
        if name == "add_register":
            for reg in args:
                if not isinstance(reg, Reg):
                    self.fail("add_register necesita registros", node)
                circ.add_register(reg)
            return None
        if name == "copy":
            c = circ.copy()
            if args:
                c.name = str(args[0])
            self.circuits.append(c)
            return c
        if name == "inverse":
            c = Circ(f"{circ.name or 'circuito'}_dg")
            c.nq, c.nc, c.qregs, c.cregs = circ.nq, circ.nc, list(circ.qregs), list(circ.cregs)
            c.ops = [_invert(op, node) for op in reversed(circ.ops)]
            self.circuits.append(c)
            return c
        if name in ("to_gate", "to_instruction"):
            if name == "to_gate" and any(op.kind in ("measure", "reset") for op in circ.ops):
                self.fail("to_gate() no admite mediciones ni reinicios; usa to_instruction()", node)
            circ.used_as_block = True
            return GateObj("circuit", circ.nq, sub=circ, label=kwargs.get("label") or circ.name)
        if name == "repeat":
            reps = args[0] if args else None
            if not isinstance(reps, int) or reps < 0:
                self.fail("repeat(n) necesita un entero", node)
            c = circ.copy()
            c.ops = list(circ.ops) * reps
            if len(c.ops) > MAX_SEQUENCE:
                self.fail("Circuito demasiado grande", node)
            self.circuits.append(c)
            return c
        if name in ("assign_parameters", "bind_parameters"):
            self.no_parameters()
        if name in ("c_if",):
            self.fail("c_if ya no existe en Qiskit 2: usa with qc.if_test((bit, valor)):", node)
        self.fail(f"qc.{name}() no está disponible en Coherencia", node)

    def real(self, v, node) -> float:
        if v is IGN:
            self.fail("Este valor viene de una instrucción que Coherencia ignora", node)
        try:
            return _real(v)
        except CodeError as exc:
            exc.line = exc.line or node.lineno
            raise

    def broadcast(self, circ: Circ, g: GateObj, qargs, node, line) -> None:
        lists = [self.qubits_of(circ, q, node) for q in qargs]
        n = max((len(lst) for lst in lists), default=0)
        for lst in lists:
            if len(lst) not in (1, n):
                self.fail("Las listas de cúbits tienen longitudes distintas", node)
        for i in range(n):
            self.apply_gate(circ, g, [lst[0] if len(lst) == 1 else lst[i] for lst in lists], node, line)

    def apply_gate(self, circ: Circ, g: GateObj, qidx: list[int], node, line, clbits: list[int] | None = None) -> None:
        need = len(g.ctrl) + g.nt
        if len(qidx) != need:
            self.fail(f"La compuerta necesita {need} cúbit(s) y recibió {len(qidx)}", node)
        if len(set(qidx)) != len(qidx):
            self.fail("Un cúbit aparece repetido en la misma compuerta", node)
        k = len(g.ctrl)
        ctrls = tuple(q for q, pol in zip(qidx[:k], g.ctrl) if pol)
        antis = tuple(q for q, pol in zip(qidx[:k], g.ctrl) if not pol)
        targets = tuple(qidx[k:])
        if g.base == "circuit":
            assert g.sub is not None
            self.inline(circ, g.sub, list(targets), clbits, ctrls, antis, node, line)
            return
        if g.base == "modmul":
            a, big_n = int(g.params[0]), int(g.params[1])
            if (1 << g.nt) < big_n:
                self.fail(f"modmul_gate: N = {big_n} no cabe en {g.nt} cúbits", node)
            if math.gcd(a, big_n) != 1:
                self.fail(f"modmul_gate: a = {a} no es coprimo con N = {big_n}", node)
        circ.emit(ROp("gate", g.base, targets, ctrls, antis, g.params, matrix=g.matrix, label=g.label, line=line))

    def inline(self, circ: Circ, sub: Circ, qubits: list[int], clbits: list[int] | None, ctrls, antis, node,
               line) -> None:
        sub.used_as_block = True
        if sub.initial and any(sub.initial.values()):
            self.fail("Un subcircuito con initialize() no se puede insertar; usa compuertas X", node)
        if len(qubits) != sub.nq:
            self.fail(f"El subcircuito tiene {sub.nq} cúbit(s) y se asignaron {len(qubits)}", node)
        if clbits is None:
            if sub.nc and any(op.kind == "measure" or op.condition for op in sub.ops):
                if circ.nc < sub.nc:
                    self.fail("El subcircuito usa bits clásicos: indica clbits=[…]", node)
                clbits = list(range(sub.nc))
            else:
                clbits = list(range(sub.nc))
        if len(clbits) != sub.nc:
            self.fail(f"El subcircuito tiene {sub.nc} bit(s) clásicos y se asignaron {len(clbits)}", node)
        for op in sub.ops:
            if (ctrls or antis) and op.kind in ("measure", "reset"):
                self.fail("Un subcircuito controlado no puede contener mediciones ni reinicios", node)
            if (ctrls or antis) and op.kind == "barrier":
                continue
            mapped = replace(
                op,
                targets=tuple(qubits[q] for q in op.targets),
                controls=tuple(qubits[q] for q in op.controls) + (tuple(ctrls) if op.kind == "gate" else ()),
                anticontrols=tuple(qubits[q] for q in op.anticontrols) + (tuple(antis) if op.kind == "gate" else ()),
                clbits=tuple(clbits[c] for c in op.clbits),
                condition=tuple((clbits[c], v) for c, v in op.condition),
                line=line,
            )
            circ.emit(mapped)

    def append_or_compose(self, circ: Circ, name: str, args, kwargs, node):
        if not args:
            self.fail(f"qc.{name}() necesita qué añadir", node)
        other = args[0]
        if other is IGN:
            self.fail("No se puede añadir algo que Coherencia ignora", node)
        if name == "append":
            qargs = args[1] if len(args) > 1 else kwargs.get("qargs")
            cargs = args[2] if len(args) > 2 else kwargs.get("cargs")
        else:
            qargs = args[1] if len(args) > 1 else kwargs.get("qubits")
            cargs = args[2] if len(args) > 2 else kwargs.get("clbits")
            if kwargs.get("front"):
                self.fail("compose(front=True) no se admite", node)
        target = circ
        if name == "compose" and not kwargs.get("inplace", False):
            target = circ.copy()
            self.circuits.append(target)
        if isinstance(other, Circ):
            g = GateObj("circuit", other.nq, sub=other)
        elif isinstance(other, GateObj):
            g = other
        else:
            self.fail(f"No se puede añadir {_type_name(other)} al circuito", node)
        if qargs is None:
            if name == "compose" and g.base == "circuit" and g.sub is not None and g.sub.nq <= target.nq:
                qidx = list(range(g.sub.nq))
            else:
                self.fail(f"qc.{name}() necesita la lista de cúbits", node)
        else:
            qidx = self.qubits_of(target, qargs, node)
        cidx = self.qubits_of(target, cargs, node, "c") if cargs is not None else None
        self.apply_gate(target, g, qidx, node, node.lineno, clbits=cidx)
        if name == "compose" and kwargs.get("inplace", False):
            return None
        return target

    def initialize(self, circ: Circ, args, kwargs, node):
        if not args:
            self.fail("initialize necesita un estado", node)
        state = args[0]
        qubits = self.qubits_of(circ, args[1], node) if len(args) > 1 else (
            self.qubits_of(circ, kwargs["qubits"], node) if "qubits" in kwargs else list(range(circ.nq)))
        n = len(qubits)
        if isinstance(state, str):
            if len(state) != n or any(ch not in "01" for ch in state):
                self.fail("initialize con texto solo admite '0' y '1', uno por cúbit", node)
            bits = [int(ch) for ch in reversed(state)]
        elif isinstance(state, int) and not isinstance(state, bool):
            if not 0 <= state < (1 << n):
                self.fail("Estado de la base fuera de rango", node)
            bits = [(state >> i) & 1 for i in range(n)]
        elif isinstance(state, (list, tuple)):
            amps = np.array([complex(_num_arg(a)) for a in state])
            if len(amps) != (1 << n):
                self.fail(f"initialize necesita {1 << n} amplitudes", node)
            nz = np.flatnonzero(np.abs(amps) > 1e-9)
            if len(nz) != 1 or abs(abs(amps[nz[0]]) - 1) > 1e-6:
                self.fail("Coherencia solo admite initialize con estados de la base computacional", node)
            bits = [(int(nz[0]) >> i) & 1 for i in range(n)]
        else:
            self.fail("Estado inicial no reconocido", node)
        for q, b in zip(qubits, bits):
            if q in circ.touched:
                self.fail("initialize solo se admite al principio, antes de cualquier operación sobre esos cúbits",
                          node)
            circ.initial[q] = b
        return circ

    def condition(self, circ: Circ, cond, node) -> tuple[tuple[int, int], ...]:
        if not isinstance(cond, tuple) or len(cond) != 2:
            self.fail("La condición debe ser (bit, valor) o (registro, valor)", node)
        what, value = cond
        if isinstance(value, bool):
            value = int(value)
        if not isinstance(value, int):
            self.fail("El valor de la condición debe ser un entero", node)
        if isinstance(what, Reg):
            bits = self.qubits_of(circ, what, node, "c")
            if not 0 <= value < (1 << len(bits)):
                self.fail("Valor fuera del rango del registro", node)
            return tuple((c, (value >> i) & 1) for i, c in enumerate(bits))
        bits = self.qubits_of(circ, what, node, "c")
        if len(bits) != 1 or value not in (0, 1):
            self.fail("Una condición sobre un bit debe valer 0 o 1", node)
        return ((bits[0], value),)

    # -- métodos de compuertas -----------------------------------------------------------------
    def gate_method(self, g: GateObj, name: str, args, kwargs, node):
        if name == "control":
            n = args[0] if args else kwargs.get("num_ctrl_qubits", 1)
            if not isinstance(n, int) or n < 1:
                self.fail("control() necesita un número de controles positivo", node)
            state = args[2] if len(args) > 2 else kwargs.get("ctrl_state")
            return _control(g, n, state)
        if name == "inverse":
            return _invert_gate(g, node)
        if name in ("power", "repeat"):
            k = args[0] if args else None
            if not isinstance(k, int) or k < 1 or k > 64:
                self.fail(f"{name}() solo admite enteros entre 1 y 64", node)
            sub = Circ(g.label)
            sub.add_register(Reg("q", len(g.ctrl) + g.nt, "q"))
            for _ in range(k):
                self.apply_gate(sub, g, list(range(sub.nq)), node, node.lineno)
            return GateObj("circuit", sub.nq, sub=sub, label=g.label)
        if name == "to_matrix":
            return IGN
        self.fail(f"Las compuertas no tienen {name}()", node)


class _Scope(dict):
    """Ámbito local que lee del ámbito exterior cuando no encuentra un nombre."""

    def __init__(self, local: dict, parent: dict):
        super().__init__(local)
        self.parent = parent

    def __missing__(self, key):
        return self.parent[key]

    def __contains__(self, key) -> bool:  # type: ignore[override]
        return dict.__contains__(self, key) or key in self.parent


def _load(target):
    if isinstance(target, ast.Name):
        return ast.copy_location(ast.Name(id=target.id, ctx=ast.Load()), target)
    if isinstance(target, ast.Subscript):
        return ast.copy_location(ast.Subscript(value=target.value, slice=target.slice, ctx=ast.Load()), target)
    if isinstance(target, ast.Attribute):
        return ast.copy_location(ast.Attribute(value=target.value, attr=target.attr, ctx=ast.Load()), target)
    raise CodeError("Asignación compuesta no admitida", getattr(target, "lineno", None))


def _real(v) -> float:
    if isinstance(v, bool) or not isinstance(v, (int, float, complex)):
        raise CodeError(f"Se esperaba un número y se recibió {_type_name(v)}")
    if isinstance(v, complex):
        if abs(v.imag) > 1e-12:
            raise CodeError("Los ángulos deben ser números reales")
        v = v.real
    v = float(v)
    if not math.isfinite(v):
        raise CodeError("El parámetro no es un número finito")
    return v


def _to_matrix(data) -> np.ndarray:
    if isinstance(data, GateObj) or isinstance(data, Circ):
        raise CodeError("UnitaryGate necesita una matriz (lista de listas)")
    try:
        mat = np.array(data, dtype=complex)
    except (TypeError, ValueError):
        raise CodeError("No se pudo leer la matriz") from None
    if mat.ndim != 2:
        raise CodeError("La matriz debe ser bidimensional")
    if not np.all(np.isfinite(mat)):
        raise CodeError("La matriz contiene valores no finitos")
    return mat


def _control(g: GateObj, n: int, ctrl_state) -> GateObj:
    if ctrl_state is None:
        pols = [True] * n
    elif isinstance(ctrl_state, str):
        if len(ctrl_state) != n or any(ch not in "01" for ch in ctrl_state):
            raise CodeError("ctrl_state debe tener un 0 o un 1 por control")
        pols = [ch == "1" for ch in reversed(ctrl_state)]
    elif isinstance(ctrl_state, int) and not isinstance(ctrl_state, bool):
        if not 0 <= ctrl_state < (1 << n):
            raise CodeError("ctrl_state fuera de rango")
        pols = [bool((ctrl_state >> i) & 1) for i in range(n)]
    else:
        raise CodeError("ctrl_state debe ser un texto como '01' o un entero")
    return replace(g, ctrl=tuple(pols) + tuple(g.ctrl))


_SELF_INVERSE = {"x", "y", "z", "h", "id", "swap"}
_PAIRS = {"s": "sdg", "sdg": "s", "t": "tdg", "tdg": "t", "sx": "sxdg", "sxdg": "sx", "qft": "iqft", "iqft": "qft"}
_NEGATE = {"p", "rx", "ry", "rz", "rxx", "ryy", "rzz"}


def _invert_base(base: str, params: tuple[float, ...], matrix, label, node=None):
    if base in _SELF_INVERSE:
        return base, params, matrix, label
    if base in _PAIRS:
        return _PAIRS[base], params, matrix, label
    if base in _NEGATE:
        return base, tuple(-p for p in params), matrix, label
    if base == "u":
        theta, phi, lam = params
        return "u", (-theta, -lam, -phi), matrix, label
    if base == "modmul":
        a, big_n = int(params[0]), int(params[1])
        try:
            inv = pow(a, -1, big_n)
        except ValueError:
            raise CodeError(f"{a} no tiene inverso módulo {big_n}", getattr(node, "lineno", None)) from None
        return "modmul", (float(inv), float(big_n)), matrix, f"×{inv} mod {big_n}"
    if base == "unitary":
        return "unitary", params, matrix.conj().T, (label + "†") if label else "U†"
    if base in GATES:
        mat = gate_matrix(base, params).conj().T
        return "unitary", (), mat, f"{GATES[base].label}†"
    raise CodeError(f"No se puede invertir «{base}»", getattr(node, "lineno", None))


def _invert(op: ROp, node) -> ROp:
    if op.kind in ("measure", "reset"):
        raise CodeError("No se puede invertir un circuito con mediciones o reinicios", getattr(node, "lineno", None))
    if op.kind == "barrier":
        return op
    base, params, matrix, label = _invert_base(op.gate, op.params, op.matrix, op.label, node)
    return replace(op, gate=base, params=params, matrix=matrix, label=label)


def _invert_gate(g: GateObj, node) -> GateObj:
    if g.base == "circuit":
        assert g.sub is not None
        sub = g.sub.copy()
        sub.ops = [_invert(op, node) for op in reversed(g.sub.ops)]
        return replace(g, sub=sub, label=f"{g.label or 'bloque'}†")
    base, params, matrix, label = _invert_base(g.base, g.params, g.matrix, g.label, node)
    return replace(g, base=base, params=params, matrix=matrix, label=label)


def _syntax_message(exc: SyntaxError) -> str:
    msg = exc.msg or "sintaxis no válida"
    translations = {
        "invalid syntax": "sintaxis no válida",
        "unexpected indent": "sangría inesperada",
        "expected an indented block": "falta un bloque con sangría",
        "unindent does not match any outer indentation level": "la sangría no coincide con ningún nivel anterior",
        "unterminated string literal": "texto sin cerrar",
        "was never closed": "no se cerró",
        "unmatched": "no tiene pareja",
        "expected ':'": "falta «:»",
        "invalid decimal literal": "número no válido",
    }
    for en, es in translations.items():
        if en in msg:
            msg = msg.replace(en, es)
            break
    return f"Error de sintaxis: {msg}"


# =====================================================================================
#  Resultado del intérprete → modelo de columnas
# =====================================================================================

@dataclass
class ParsedCircuit:
    circuit: Circuit
    warnings: list[str]
    op_lines: dict[str, int] = field(default_factory=dict)


_CONST_GATES: list[tuple[str, int, np.ndarray]] = []


def _constant_gates() -> list[tuple[str, int, np.ndarray]]:
    if not _CONST_GATES:
        for name, spec in GATES.items():
            if spec.kind == "matrix" and not spec.params and spec.num_targets and spec.matrix is not None:
                _CONST_GATES.append((name, spec.num_targets, spec.matrix()))
    return _CONST_GATES


def _match_constant(mat: np.ndarray) -> str | None:
    n = int(round(math.log2(mat.shape[0])))
    for name, nt, ref in _constant_gates():
        if nt == n and ref.shape == mat.shape and np.allclose(ref, mat, atol=1e-9):
            return name
    return None


def _param_value(x: float) -> float | str:
    text = nice_number(x)
    return text if "pi" in text else float(x)


def _layout(ops: list[ROp], nq: int) -> list[int]:
    """Asigna columnas lo antes posible, sin cruzar líneas verticales de compuertas multicúbit."""
    qfree = [0] * nq
    c_write: dict[int, int] = {}
    c_read: dict[int, int] = {}
    cols = []
    for op in ops:
        qs = [*op.targets, *op.controls, *op.anticontrols]
        if op.kind == "barrier":
            span = list(qs) if qs else list(range(nq))
        elif len(qs) > 1:
            span = list(range(min(qs), max(qs) + 1))
        else:
            span = qs
        col = max((qfree[q] for q in span), default=0)
        reads = [c for c, _ in op.condition]
        for c in reads:
            col = max(col, c_write.get(c, -1) + 1)
        for c in op.clbits:
            col = max(col, c_write.get(c, -1) + 1, c_read.get(c, -1) + 1)
        for q in span:
            qfree[q] = col + 1
        for c in reads:
            c_read[c] = max(c_read.get(c, -1), col)
        for c in op.clbits:
            c_write[c] = col
        cols.append(col)
    return cols


def _to_model(circ: Circ, default_name: str, max_ops: int) -> tuple[Circuit, dict[str, int]]:
    if circ.nq < 1:
        raise CodeError("El circuito no tiene cúbits")
    if len(circ.ops) > max_ops:
        raise CodeError(f"El circuito tiene {len(circ.ops)} operaciones y el límite es {max_ops}")
    cols = _layout(circ.ops, circ.nq)
    ops: list[Op] = []
    op_lines: dict[str, int] = {}
    for rop, col in zip(circ.ops, cols):
        kw: dict[str, Any] = {"col": col, "targets": list(rop.targets)}
        if rop.condition:
            kw["condition"] = [Condition(clbit=c, value=v) for c, v in rop.condition]
        if rop.kind == "gate":
            gate, matrix = rop.gate, rop.matrix
            if gate == "unitary" and matrix is not None:
                named = _match_constant(matrix)
                if named:
                    gate, matrix = named, None
            kw.update(kind="gate", gate=gate, controls=list(rop.controls), anticontrols=list(rop.anticontrols))
            if gate == "modmul":
                kw["params"] = [int(rop.params[0]), int(rop.params[1])]
            elif gate != "unitary":
                kw["params"] = [_param_value(p) for p in rop.params]
            if matrix is not None:
                kw["matrix"] = [[[float(z.real), float(z.imag)] for z in row] for row in matrix]
                kw["label"] = (rop.label or "U")[:40]
        elif rop.kind == "measure":
            kw.update(kind="measure", clbits=list(rop.clbits))
        elif rop.kind == "reset":
            kw.update(kind="reset")
        else:
            kw.update(kind="barrier", targets=[] if len(rop.targets) == circ.nq else list(rop.targets))
        op = Op(**kw)
        ops.append(op)
        if rop.line:
            op_lines[op.id] = rop.line

    def labels(regs: list[tuple[Reg, int]], default: str) -> list[str] | None:
        if not regs or (len(regs) == 1 and regs[0][0].name == default):
            return None
        out: list[str] = []
        for reg, _ in regs:
            out.extend(f"{reg.name}{i}" if reg.size > 1 else reg.name for i in range(reg.size))
        return [s[:24] for s in out]

    initial = "".join(str(circ.initial.get(q, 0)) for q in reversed(range(circ.nq)))
    model = Circuit(
        name=(circ.name or default_name or "Circuito")[:120],
        num_qubits=circ.nq,
        num_clbits=circ.nc,
        initial_state=initial,
        qubit_labels=labels(circ.qregs, "q"),
        clbit_labels=labels(circ.cregs, "c"),
        ops=ops,
        loops=[],
        meta={"source": "qiskit-code"},
    )
    return model, op_lines


def code_to_circuit(code: str, default_name: str = "Circuito", max_ops: int = 20000) -> ParsedCircuit:
    interp = Interpreter()
    interp.run(code)
    named = {name: v for name, v in interp.globals.items() if isinstance(v, Circ)}
    main: Circ | None = None
    for preferred in ("qc", "circuit", "circ", "circuito", "qcirc"):
        if isinstance(named.get(preferred), Circ):
            main = named[preferred]
            break
    if main is None:
        candidates = [c for c in named.values() if not c.used_as_block]
        if candidates:
            main = max(candidates, key=lambda c: c.serial)
        elif named:
            main = max(named.values(), key=lambda c: c.serial)
    if main is None:
        raise CodeError("No se encontró ningún circuito: crea uno con qc = QuantumCircuit(n)")
    model, op_lines = _to_model(main, default_name, max_ops)
    warnings = list(dict.fromkeys(interp.warnings))
    if interp.ignored_lines:
        lines = sorted(set(interp.ignored_lines))
        shown = ", ".join(map(str, lines[:6])) + ("…" if len(lines) > 6 else "")
        warnings.append(f"Se ignoraron las líneas {shown} (ejecución o visualización): Coherencia ejecuta el "
                        "circuito automáticamente.")
    return ParsedCircuit(model, warnings, op_lines)


class CodeRejected(Exception):
    """Error listo para la API (422) con el formato habitual {message, errors[{line, …}]}."""

    def __init__(self, detail: dict):
        super().__init__(detail.get("message", ""))
        self.detail = detail


def parse_for_api(code: str, name: str | None, library: Mapping[str, Any], settings) -> dict:
    """Interpreta el código y lo valida con el mismo constructor de IR que usa la simulación."""
    from ..core.ir import CircuitError, build_program  # import local: evita ciclos

    try:
        parsed = code_to_circuit(code, name or "Circuito", settings.max_ops)
    except CodeError as exc:
        raise CodeRejected(exc.to_dict()) from exc
    warnings = list(parsed.warnings)
    try:
        prog = build_program(parsed.circuit, library, settings.max_ops)
        warnings.extend(prog.warnings)
    except CircuitError as exc:
        detail = exc.to_dict()
        for item in detail.get("errors", []):
            item["line"] = parsed.op_lines.get(item.get("op_id") or "")
            item["op_id"] = None
        first = next((e for e in detail.get("errors", []) if e.get("line")), None)
        if first:
            detail["message"] = f"Línea {first['line']}: {first['message']}"
        raise CodeRejected(detail) from exc
    if parsed.circuit.num_qubits > settings.max_qubits:
        warnings.append(
            f"El circuito tiene {parsed.circuit.num_qubits} cúbits y el servidor simula hasta {settings.max_qubits}."
        )
    return {"circuit": parsed.circuit.model_dump(), "warnings": warnings, "op_lines": parsed.op_lines}


def generate_for_api(circuit: Circuit, library: Mapping[str, Any]) -> dict:
    gen = circuit_to_code(circuit, library)
    return {"code": gen.code, "line_map": gen.line_map, "warnings": gen.warnings}
