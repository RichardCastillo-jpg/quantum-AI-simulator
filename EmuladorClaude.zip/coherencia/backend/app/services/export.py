"""Exportación del circuito expandido a código Python de Qiskit (y OpenQASM con el motor Qiskit)."""

from __future__ import annotations

import math

import numpy as np

from ..core.ir import Prim, Program


def _num(x: float) -> str:
    for k in (1, 2, 3, 4, 6, 8, 16, 32, 64):
        for sign in (1, -1):
            if abs(x - sign * math.pi / k) < 1e-12:
                s = "-" if sign < 0 else ""
                return f"{s}np.pi" if k == 1 else f"{s}np.pi/{k}"
    return repr(round(float(x), 12))


def _matrix_literal(mat: np.ndarray) -> str:
    rows = []
    for row in mat:
        cells = []
        for z in row:
            z = complex(z)
            if abs(z.imag) < 1e-15:
                cells.append(repr(round(z.real, 12)))
            else:
                cells.append(f"complex({round(z.real, 12)!r}, {round(z.imag, 12)!r})")
        rows.append("[" + ", ".join(cells) + "]")
    return "np.array([" + ", ".join(rows) + "], dtype=complex)"


_SIMPLE = {"x", "y", "z", "h", "s", "sdg", "t", "tdg", "sx", "sxdg", "id", "swap", "iswap"}
_PHASE = {"z": "np.pi", "s": "np.pi/2", "sdg": "-np.pi/2", "t": "np.pi/4", "tdg": "-np.pi/4"}


def _gate_lines(p: Prim) -> list[str]:
    ctrls = list(p.controls) + list(p.anticontrols)
    k = len(ctrls)
    t = list(p.qubits)
    name = p.name
    pre = [f"qc.x({q})" for q in p.anticontrols]
    params = [_num(v) for v in p.params]
    line: str | None = None
    if name == "modmul":
        a, big_n = int(round(p.params[0])), int(round(p.params[1]))
        line = f"qc.append(modmul_gate({a}, {big_n}, {len(t)}, {k}), {ctrls + t})"
    elif name in ("unitary", "sy", "sw", "fsim"):
        mat = p.base_matrix()
        line = f"qc.append(controlled(UnitaryGate({_matrix_literal(mat)}, label={p.label or name!r}), {k}), {ctrls + t})"
    elif k == 0:
        if name in _SIMPLE:
            line = f"qc.{name}({', '.join(map(str, t))})"
        elif name in ("p", "rx", "ry", "rz", "rxx", "ryy", "rzz"):
            line = f"qc.{name}({params[0]}, {', '.join(map(str, t))})"
        elif name == "u":
            line = f"qc.u({', '.join(params)}, {t[0]})"
    else:
        if name == "x":
            line = f"qc.cx({ctrls[0]}, {t[0]})" if k == 1 else (
                f"qc.ccx({ctrls[0]}, {ctrls[1]}, {t[0]})" if k == 2 else f"qc.mcx({ctrls}, {t[0]})")
        elif name in _PHASE or name == "p":
            lam = _PHASE.get(name, params[0] if params else "0")
            line = (f"qc.cz({ctrls[0]}, {t[0]})" if (name == "z" and k == 1) else
                    f"qc.cp({lam}, {ctrls[0]}, {t[0]})" if k == 1 else f"qc.mcp({lam}, {ctrls}, {t[0]})")
        elif k == 1 and name in ("y", "h", "sx"):
            line = f"qc.c{name}({ctrls[0]}, {t[0]})"
        elif k == 1 and name in ("rx", "ry", "rz"):
            line = f"qc.c{name}({params[0]}, {ctrls[0]}, {t[0]})"
        elif k == 1 and name == "swap":
            line = f"qc.cswap({ctrls[0]}, {t[0]}, {t[1]})"
        elif name == "id":
            line = None
        else:
            mat = p.base_matrix()
            line = f"qc.append(controlled(UnitaryGate({_matrix_literal(mat)}, label={name!r}), {k}), {ctrls + t})"
    body = [line] if line else []
    post = [f"qc.x({q})" for q in p.anticontrols]
    return pre + body + post


def _plain_lines(p: Prim) -> list[str]:
    if p.kind == "gate":
        return _gate_lines(p)
    if p.kind == "measure":
        return [f"qc.measure({p.qubits[0]}, {p.clbit})"]
    if p.kind == "reset":
        return [f"qc.reset({p.qubits[0]})"]
    if p.kind == "barrier":
        return [f"qc.barrier({', '.join(map(str, p.qubits))})"]
    return []


HEADER = '''"""Circuito exportado desde Coherencia.

Requiere: pip install qiskit qiskit-aer
"""
import numpy as np
from qiskit import QuantumCircuit
from qiskit.circuit.library import UnitaryGate
from qiskit_aer import AerSimulator


def controlled(gate, k):
    """Versión controlada exacta (controles en los bits bajos)."""
    if k == 0:
        return gate
    u = gate.to_matrix()
    dim = u.shape[0]
    full = np.eye(dim << k, dtype=complex)
    idx = (np.arange(dim) << k) | ((1 << k) - 1)
    full[np.ix_(idx, idx)] = u
    return UnitaryGate(full, label=f"c{k}-{gate.label or gate.name}")


def modmul_gate(a, N, n, k=0):
    """|y⟩ → |a·y mod N⟩ para y < N (identidad en el resto), con k controles."""
    dim = 1 << n
    u = np.zeros((dim, dim), dtype=complex)
    for y in range(dim):
        u[(a * y) % N if y < N else y, y] = 1
    return controlled(UnitaryGate(u, label=f"x{a} mod {N}"), k)

'''


def to_python(prog: Program, name: str, shots: int = 1024) -> str:
    n, m = prog.num_qubits, prog.num_clbits
    lines = [HEADER, f"# {name}", f"qc = QuantumCircuit({n}, {m})" if m else f"qc = QuantumCircuit({n})"]
    ops = [p for p in prog.ops if p.kind != "channel"]
    i = 0
    while i < len(ops):
        p = ops[i]
        if p.condition:
            indent = ""
            for c, v in p.condition:
                lines.append(f"{indent}with qc.if_test((qc.clbits[{c}], {v})):")
                indent += "    "
            j = i
            while j < len(ops) and ops[j].condition == p.condition:
                for ln in _plain_lines(ops[j]):
                    lines.append(indent + ln)
                j += 1
            i = j
            continue
        lines.extend(_plain_lines(p))
        i += 1
    if not prog.has_measurements:
        lines.append("qc.measure_all()")
    lines += [
        "",
        "if __name__ == '__main__':",
        "    sim = AerSimulator()",
        f"    counts = sim.run(qc, shots={shots}).result().get_counts()",
        "    print(qc.draw(output='text'))",
        "    print(counts)",
        "",
    ]
    return "\n".join(lines)
