"""Principio de medición diferida.

Convierte un programa con mediciones a mitad de circuito, reinicios y control
clásico en un programa *sin* mediciones sobre un sistema ampliado con cúbits
auxiliares, exactamente equivalente en estadística:

* ``measure q → c`` (no final)  →  CNOT(q → a): el auxiliar ``a`` guarda una copia
  del resultado en la base computacional; al trazarlo, ``q`` queda decoherido
  exactamente como tras una medición proyectiva.
* ``reset q``                   →  SWAP(q, a) con ``a`` en |0⟩.
* ``if c == v: U``              →  U controlada por el auxiliar que guarda ``c``
  (anticontrol si v = 0).
* error de lectura a mitad de circuito → canal de inversión de bit sobre ``a``.

Las mediciones finales se eliminan y se registran como fuentes de los bits
clásicos, de modo que la distribución clásica exacta se obtiene marginalizando
|ψ|² (o la diagonal de ρ).
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace

from .ir import CircuitError, Prim, Program, StepInfo
from .noise import bitflip_kraus, controlled_kraus


@dataclass
class DeferredProgram:
    num_qubits: int  # cúbits del circuito original
    num_total: int  # cúbits + auxiliares
    num_clbits: int
    ops: list[Prim]
    clbit_sources: list[tuple[str, int] | None]  # por bit clásico: ("anc"|"q", índice) o None (=0)
    terminal_readout: list[bool]  # bits cuya distribución final debe pasar por el error de lectura
    ancillas: list[dict] = field(default_factory=list)
    steps: list[StepInfo] = field(default_factory=list)

    @property
    def num_ancillas(self) -> int:
        return self.num_total - self.num_qubits

    @property
    def has_channels(self) -> bool:
        return any(p.kind == "channel" for p in self.ops)

    @property
    def only_measure_ancillas(self) -> bool:
        return all(a["kind"] == "measure" for a in self.ancillas)


class UnsupportedExact(CircuitError):
    pass


def _terminal_flags(ops: list[Prim]) -> list[bool]:
    terminal = [False] * len(ops)
    used_q: set[int] = set()
    read_c: set[int] = set()
    for i in range(len(ops) - 1, -1, -1):
        p = ops[i]
        if p.kind == "barrier":
            continue
        if p.kind == "measure":
            q, c = p.qubits[0], p.clbit
            if q not in used_q and c not in read_c and not p.condition:
                terminal[i] = True
            used_q.add(q)
            read_c.discard(c)
            read_c.update(cc for cc, _ in p.condition)
        else:
            used_q.update(p.all_qubits)
            read_c.update(cc for cc, _ in p.condition)
    return terminal


def defer_measurements(prog: Program, readout: float = 0.0) -> DeferredProgram:
    n, m = prog.num_qubits, prog.num_clbits
    terminal = _terminal_flags(prog.ops)
    total = n
    out: list[Prim] = []
    sources: list[tuple[str, int] | None] = [None] * m
    term_ro = [False] * m
    ancillas: list[dict] = []

    for i, p in enumerate(prog.ops):
        if p.kind == "barrier":
            continue
        if p.kind in ("measure", "reset") and p.condition:
            raise UnsupportedExact(
                "Operación no soportada en modo exacto",
                [{"op_id": p.source, "message": "Mediciones o reinicios condicionados: usa el modo Shots"}],
            )
        if p.kind == "measure":
            q, c = p.qubits[0], p.clbit
            if terminal[i]:
                sources[c] = ("q", q)
                term_ro[c] = readout > 0
            else:
                a = total
                total += 1
                out.append(Prim("gate", "x", qubits=(a,), controls=(q,), step=p.step, source=p.source, noiseless=True,
                                label="copia de medición"))
                if readout > 0:
                    out.append(Prim("channel", "kraus", qubits=(a,), kraus=bitflip_kraus(readout), step=p.step,
                                    source=p.source, label="lectura"))
                sources[c] = ("anc", a)
                term_ro[c] = False
                ancillas.append({"kind": "measure", "qubit": q, "clbit": c, "ancilla": a, "step": p.step})
            continue
        if p.kind == "reset":
            q = p.qubits[0]
            a = total
            total += 1
            out.append(Prim("gate", "swap", qubits=(q, a), step=p.step, source=p.source, noiseless=True, label="reinicio"))
            ancillas.append({"kind": "reset", "qubit": q, "ancilla": a, "step": p.step})
            continue

        # Compuertas y canales: las condiciones clásicas pasan a ser controles cuánticos.
        extra_c: list[int] = []
        extra_a: list[int] = []
        never = False
        for c, v in p.condition:
            src = sources[c]
            if src is None:  # bit nunca escrito: vale 0
                if v == 1:
                    never = True
                    break
                continue
            kind, idx = src
            if kind != "anc":  # pragma: no cover - una medición final no puede leerse después
                raise UnsupportedExact("Condición sobre una medición final", [{"op_id": p.source, "message": "Condición inválida"}])
            target = extra_c if v == 1 else extra_a
            if idx not in target:
                target.append(idx)
        if never or set(extra_c) & set(extra_a):
            continue
        if p.kind == "gate":
            out.append(replace(p, controls=p.controls + tuple(extra_c), anticontrols=p.anticontrols + tuple(extra_a),
                               condition=()))
        elif p.kind == "channel":
            if extra_c or extra_a:
                kraus = controlled_kraus(p.kraus, len(extra_c), len(extra_a))
                out.append(replace(p, qubits=tuple(extra_c) + tuple(extra_a) + p.qubits, kraus=kraus, condition=()))
            else:
                out.append(replace(p, condition=()))
    return DeferredProgram(n, total, m, out, sources, term_ro, ancillas, list(prog.steps))
