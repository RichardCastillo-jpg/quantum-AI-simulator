"""Catálogo de compuertas con matrices exactas.

Convenciones (idénticas a Qiskit):

* Orden *little-endian*: para una compuerta aplicada sobre ``qargs = [a, b, …]``
  el índice de la matriz es ``b_a + 2·b_b + …`` (``qargs[0]`` es el bit menos
  significativo).
* Las matrices reproducen exactamente las de ``qiskit.circuit.library``
  (incluida la fase global), de modo que las versiones controladas son exactas.

Los controles no forman parte del catálogo: cualquier compuerta unitaria puede
recibir controles (``|1⟩``) y anticontroles (``|0⟩``). CNOT = X con un control,
Toffoli = X con dos controles, CZ = Z con un control, etc.
"""

from __future__ import annotations

import cmath
import math
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Callable

import numpy as np

SQRT1_2 = 1 / math.sqrt(2)


@dataclass(frozen=True)
class GateSpec:
    name: str
    label: str
    category: str
    num_targets: int | None  # None = número variable de cúbits objetivo
    params: tuple[str, ...] = ()
    description: str = ""
    matrix: Callable[..., np.ndarray] | None = None
    # "macro": se expande en compuertas primitivas (QFT); "special": matriz construida aparte.
    kind: str = "matrix"
    min_targets: int = 1
    max_targets: int = 8
    aliases: tuple[str, ...] = field(default_factory=tuple)


def _m(rows) -> np.ndarray:
    return np.array(rows, dtype=complex)


def _rx(theta: float) -> np.ndarray:
    c, s = math.cos(theta / 2), math.sin(theta / 2)
    return _m([[c, -1j * s], [-1j * s, c]])


def _ry(theta: float) -> np.ndarray:
    c, s = math.cos(theta / 2), math.sin(theta / 2)
    return _m([[c, -s], [s, c]])


def _rz(theta: float) -> np.ndarray:
    return _m([[cmath.exp(-0.5j * theta), 0], [0, cmath.exp(0.5j * theta)]])


def _p(lam: float) -> np.ndarray:
    return _m([[1, 0], [0, cmath.exp(1j * lam)]])


def _u(theta: float, phi: float, lam: float) -> np.ndarray:
    c, s = math.cos(theta / 2), math.sin(theta / 2)
    return _m(
        [
            [c, -cmath.exp(1j * lam) * s],
            [cmath.exp(1j * phi) * s, cmath.exp(1j * (phi + lam)) * c],
        ]
    )


def _rxx(theta: float) -> np.ndarray:
    c, s = math.cos(theta / 2), math.sin(theta / 2)
    return _m(
        [
            [c, 0, 0, -1j * s],
            [0, c, -1j * s, 0],
            [0, -1j * s, c, 0],
            [-1j * s, 0, 0, c],
        ]
    )


def _ryy(theta: float) -> np.ndarray:
    c, s = math.cos(theta / 2), math.sin(theta / 2)
    return _m(
        [
            [c, 0, 0, 1j * s],
            [0, c, -1j * s, 0],
            [0, -1j * s, c, 0],
            [1j * s, 0, 0, c],
        ]
    )


def _rzz(theta: float) -> np.ndarray:
    a, b = cmath.exp(-0.5j * theta), cmath.exp(0.5j * theta)
    return np.diag([a, b, b, a]).astype(complex)


def _fsim(theta: float, phi: float) -> np.ndarray:
    c, s = math.cos(theta), math.sin(theta)
    return _m(
        [
            [1, 0, 0, 0],
            [0, c, -1j * s, 0],
            [0, -1j * s, c, 0],
            [0, 0, 0, cmath.exp(-1j * phi)],
        ]
    )


_I = _m([[1, 0], [0, 1]])
_X = _m([[0, 1], [1, 0]])
_Y = _m([[0, -1j], [1j, 0]])
_Z = _m([[1, 0], [0, -1]])
_H = _m([[SQRT1_2, SQRT1_2], [SQRT1_2, -SQRT1_2]])
_S = _m([[1, 0], [0, 1j]])
_SDG = _m([[1, 0], [0, -1j]])
_T = _m([[1, 0], [0, cmath.exp(0.25j * math.pi)]])
_TDG = _m([[1, 0], [0, cmath.exp(-0.25j * math.pi)]])
_SX = 0.5 * _m([[1 + 1j, 1 - 1j], [1 - 1j, 1 + 1j]])
_SXDG = 0.5 * _m([[1 - 1j, 1 + 1j], [1 + 1j, 1 - 1j]])
# Raíces principales: √P = ((1+i)/2)·I + ((1−i)/2)·P para P de Pauli (P² = I).
_SY = 0.5 * _m([[1 + 1j, -1 - 1j], [1 + 1j, 1 + 1j]])
_SW = _m([[(1 + 1j) / 2, -1j * SQRT1_2], [SQRT1_2, (1 + 1j) / 2]])
_SWAP = _m([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
_ISWAP = _m([[1, 0, 0, 0], [0, 0, 1j, 0], [0, 1j, 0, 0], [0, 0, 0, 1]])


def _const(mat: np.ndarray) -> Callable[..., np.ndarray]:
    def build(*_args) -> np.ndarray:
        return mat.copy()

    return build


GATES: dict[str, GateSpec] = {}


def _register(spec: GateSpec) -> None:
    GATES[spec.name] = spec


# --- Una sola compuerta -------------------------------------------------------
_register(GateSpec("id", "I", "pauli", 1, (), "Identidad: no modifica el estado (útil como espera con ruido).", _const(_I)))
_register(GateSpec("x", "X", "pauli", 1, (), "NOT cuántico: |0⟩↔|1⟩. Rotación de π en torno a X.", _const(_X)))
_register(GateSpec("y", "Y", "pauli", 1, (), "Rotación de π en torno a Y: inversión de bit y de fase.", _const(_Y)))
_register(GateSpec("z", "Z", "pauli", 1, (), "Inversión de fase: añade π a |1⟩.", _const(_Z)))
_register(GateSpec("h", "H", "clifford", 1, (), "Hadamard: |0⟩→(|0⟩+|1⟩)/√2, crea superposición.", _const(_H)))
_register(GateSpec("s", "S", "phase", 1, (), "Fase π/2 sobre |1⟩ (raíz cuadrada de Z).", _const(_S)))
_register(GateSpec("sdg", "S†", "phase", 1, (), "Inversa de S: fase −π/2 sobre |1⟩.", _const(_SDG)))
_register(GateSpec("t", "T", "phase", 1, (), "Fase π/4 sobre |1⟩ (raíz cuarta de Z).", _const(_T)))
_register(GateSpec("tdg", "T†", "phase", 1, (), "Inversa de T: fase −π/4 sobre |1⟩.", _const(_TDG)))
_register(GateSpec("sx", "√X", "clifford", 1, (), "Raíz cuadrada de NOT: media rotación en torno a X.", _const(_SX)))
_register(GateSpec("sxdg", "√X†", "clifford", 1, (), "Inversa de √X.", _const(_SXDG)))
_register(GateSpec("sy", "√Y", "rotation", 1, (), "Raíz cuadrada de Y (conjunto nativo de circuitos aleatorios).", _const(_SY)))
_register(GateSpec("sw", "√W", "rotation", 1, (), "Raíz de W=(X+Y)/√2 (conjunto nativo de circuitos aleatorios).", _const(_SW)))
_register(GateSpec("p", "P", "phase", 1, ("φ",), "Fase arbitraria φ sobre |1⟩.", _p))
_register(GateSpec("rx", "RX", "rotation", 1, ("θ",), "Rotación de ángulo θ en torno al eje X.", _rx))
_register(GateSpec("ry", "RY", "rotation", 1, ("θ",), "Rotación de ángulo θ en torno al eje Y.", _ry))
_register(GateSpec("rz", "RZ", "rotation", 1, ("θ",), "Rotación de ángulo θ en torno al eje Z.", _rz))
_register(GateSpec("u", "U", "rotation", 1, ("θ", "φ", "λ"), "Compuerta general de un cúbit U(θ, φ, λ).", _u))

# --- Dos cúbits ---------------------------------------------------------------
_register(GateSpec("swap", "SWAP", "multi", 2, (), "Intercambia los estados de dos cúbits.", _const(_SWAP)))
_register(GateSpec("iswap", "iSWAP", "multi", 2, (), "Intercambio con fase i en |01⟩ y |10⟩.", _const(_ISWAP)))
_register(GateSpec("rxx", "RXX", "multi", 2, ("θ",), "Interacción de Ising exp(−iθ X⊗X/2).", _rxx))
_register(GateSpec("ryy", "RYY", "multi", 2, ("θ",), "Interacción de Ising exp(−iθ Y⊗Y/2).", _ryy))
_register(GateSpec("rzz", "RZZ", "multi", 2, ("θ",), "Interacción de Ising exp(−iθ Z⊗Z/2).", _rzz))
_register(GateSpec("fsim", "fSim", "multi", 2, ("θ", "φ"), "Compuerta fermiónica fSim(θ, φ) de los procesadores de Google.", _fsim))

# --- Bloques de tamaño variable -----------------------------------------------
_register(GateSpec("qft", "QFT", "block", None, (), "Transformada cuántica de Fourier sobre los cúbits objetivo.", kind="macro", min_targets=1, max_targets=24))
_register(GateSpec("iqft", "QFT†", "block", None, (), "Transformada cuántica de Fourier inversa.", kind="macro", min_targets=1, max_targets=24))
_register(GateSpec("modmul", "×a mod N", "block", None, ("a", "N"), "Multiplicación modular |y⟩→|a·y mod N⟩ (para y < N). Núcleo del algoritmo de Shor.", kind="special", min_targets=2, max_targets=10))
_register(GateSpec("unitary", "U", "block", None, (), "Compuerta unitaria definida por su matriz.", kind="special", min_targets=1, max_targets=4))

ALIASES = {"cnot": "x", "cx": "x", "ccx": "x", "toffoli": "x", "cz": "z", "i": "id", "phase": "p", "not": "x"}

# Número de controles implícitos que implican los alias de la interfaz.
ALIAS_CONTROLS = {"cnot": 1, "cx": 1, "ccx": 2, "toffoli": 2, "cz": 1}


def resolve_name(name: str) -> str:
    key = name.strip().lower()
    return ALIASES.get(key, key)


def gate_matrix(name: str, params: tuple[float, ...] = ()) -> np.ndarray:
    spec = GATES[name]
    if spec.matrix is None:
        raise KeyError(f"La compuerta {name} no tiene una matriz fija")
    return spec.matrix(*params)


@lru_cache(maxsize=256)
def modmul_matrix(a: int, N: int, n: int) -> np.ndarray:
    """Permutación |y⟩ → |a·y mod N⟩ para y < N; identidad para y ≥ N."""
    dim = 1 << n
    mat = np.zeros((dim, dim), dtype=complex)
    for y in range(dim):
        target = (a * y) % N if y < N else y
        mat[target, y] = 1.0
    mat.setflags(write=False)
    return mat


def controlled_matrix(u: np.ndarray, num_controls: int) -> np.ndarray:
    """Matriz de U controlada por ``num_controls`` cúbits (bits bajos), todos en |1⟩."""
    if num_controls == 0:
        return np.array(u, dtype=complex)
    dim_t = u.shape[0]
    k = num_controls
    full = np.eye(dim_t << k, dtype=complex)
    cmask = (1 << k) - 1
    idx = (np.arange(dim_t) << k) | cmask
    full[np.ix_(idx, idx)] = u
    return full


def is_unitary(mat: np.ndarray, atol: float = 1e-8) -> bool:
    if mat.ndim != 2 or mat.shape[0] != mat.shape[1]:
        return False
    return bool(np.allclose(mat.conj().T @ mat, np.eye(mat.shape[0]), atol=atol))


def catalog() -> list[dict]:
    """Descripción serializable del catálogo (para /api/gates y la documentación)."""
    items = []
    for spec in GATES.values():
        entry = {
            "name": spec.name,
            "label": spec.label,
            "category": spec.category,
            "num_targets": spec.num_targets,
            "min_targets": spec.min_targets if spec.num_targets is None else spec.num_targets,
            "max_targets": spec.max_targets if spec.num_targets is None else spec.num_targets,
            "params": list(spec.params),
            "description": spec.description,
            "kind": spec.kind,
        }
        if spec.matrix is not None and not spec.params:
            mat = spec.matrix()
            entry["matrix"] = [[[float(z.real), float(z.imag)] for z in row] for row in mat]
        items.append(entry)
    return items
