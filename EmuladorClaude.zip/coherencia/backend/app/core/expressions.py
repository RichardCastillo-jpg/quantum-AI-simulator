"""Evaluador seguro de expresiones matemáticas para parámetros de compuertas.

No usa ``eval``. Gramática (descenso recursivo):

    expr   := term (('+' | '-') term)*
    term   := unary (('*' | '/' | '%') unary)*
    unary  := ('+' | '-') unary | power
    power  := atom (('^' | '**') unary)?          # asociativa a la derecha
    atom   := number | ident | ident '(' args ')' | '(' expr ')'

Admite multiplicación implícita entre un número y un identificador o paréntesis
(``2pi``, ``3(pi/4)``), constantes ``pi``/``π``/``tau``/``e`` y variables
(por ejemplo, el índice ``i`` de un ciclo for o los parámetros de un subcircuito).
El frontend contiene un espejo exacto de este módulo (``src/lib/expr.ts``).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable, Mapping

MAX_LENGTH = 240
MAX_DEPTH = 48

CONSTANTS: dict[str, float] = {
    "pi": math.pi,
    "π": math.pi,
    "tau": math.tau,
    "τ": math.tau,
    "e": math.e,
}


def _round(x: float) -> float:
    return float(round(x))


FUNCTIONS: dict[str, tuple[int, Callable[..., float]]] = {
    "sin": (1, math.sin),
    "cos": (1, math.cos),
    "tan": (1, math.tan),
    "asin": (1, math.asin),
    "acos": (1, math.acos),
    "atan": (1, math.atan),
    "atan2": (2, math.atan2),
    "sqrt": (1, math.sqrt),
    "exp": (1, math.exp),
    "log": (1, math.log),
    "ln": (1, math.log),
    "log2": (1, math.log2),
    "log10": (1, math.log10),
    "abs": (1, abs),
    "floor": (1, math.floor),
    "ceil": (1, math.ceil),
    "round": (1, _round),
    "min": (2, min),
    "max": (2, max),
}


class ExpressionError(ValueError):
    """Error de sintaxis o de evaluación en una expresión."""


@dataclass(frozen=True)
class Token:
    kind: str  # num | id | op | lp | rp | comma | end
    value: str
    pos: int


def _is_ident_start(ch: str) -> bool:
    return ch == "_" or ch.isalpha()


def _is_ident_char(ch: str) -> bool:
    return ch == "_" or ch.isalnum()


def tokenize(src: str) -> list[Token]:
    tokens: list[Token] = []
    i, n = 0, len(src)
    while i < n:
        ch = src[i]
        if ch.isspace():
            i += 1
            continue
        if ch.isdigit() or (ch == "." and i + 1 < n and src[i + 1].isdigit()):
            j = i
            while j < n and (src[j].isdigit() or src[j] == "."):
                j += 1
            if j < n and src[j] in "eE":
                k = j + 1
                if k < n and src[k] in "+-":
                    k += 1
                if k < n and src[k].isdigit():
                    j = k
                    while j < n and src[j].isdigit():
                        j += 1
            text = src[i:j]
            if text.count(".") > 1:
                raise ExpressionError(f"Número mal formado «{text}» en la posición {i + 1}")
            tokens.append(Token("num", text, i))
            i = j
            continue
        if _is_ident_start(ch):
            j = i + 1
            while j < n and _is_ident_char(src[j]):
                j += 1
            tokens.append(Token("id", src[i:j], i))
            i = j
            continue
        if ch == "*" and i + 1 < n and src[i + 1] == "*":
            tokens.append(Token("op", "^", i))
            i += 2
            continue
        if ch in "+-*/%^":
            tokens.append(Token("op", ch, i))
            i += 1
            continue
        if ch == "·" or ch == "×":
            tokens.append(Token("op", "*", i))
            i += 1
            continue
        if ch == "(":
            tokens.append(Token("lp", ch, i))
            i += 1
            continue
        if ch == ")":
            tokens.append(Token("rp", ch, i))
            i += 1
            continue
        if ch == ",":
            tokens.append(Token("comma", ch, i))
            i += 1
            continue
        raise ExpressionError(f"Carácter no válido «{ch}» en la posición {i + 1}")
    tokens.append(Token("end", "", n))
    return _insert_implicit_mult(tokens)


def _insert_implicit_mult(tokens: list[Token]) -> list[Token]:
    out: list[Token] = []
    for idx, tok in enumerate(tokens):
        if idx > 0:
            prev = tokens[idx - 1]
            # 2pi, 2(…), )( , )x  → multiplicación implícita
            if (prev.kind == "num" and tok.kind in ("id", "lp")) or (
                prev.kind == "rp" and tok.kind in ("id", "num", "lp")
            ):
                out.append(Token("op", "*", tok.pos))
        out.append(tok)
    return out


# --- AST ---------------------------------------------------------------------


@dataclass(frozen=True)
class Num:
    value: float


@dataclass(frozen=True)
class Var:
    name: str
    pos: int


@dataclass(frozen=True)
class Unary:
    op: str
    operand: object


@dataclass(frozen=True)
class Binary:
    op: str
    left: object
    right: object


@dataclass(frozen=True)
class Call:
    name: str
    args: tuple
    pos: int


class _Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.i = 0
        self.depth = 0

    def peek(self) -> Token:
        return self.tokens[self.i]

    def take(self) -> Token:
        tok = self.tokens[self.i]
        self.i += 1
        return tok

    def _enter(self) -> None:
        self.depth += 1
        if self.depth > MAX_DEPTH:
            raise ExpressionError("Expresión demasiado anidada")

    def parse(self):
        node = self.expr()
        tok = self.peek()
        if tok.kind != "end":
            raise ExpressionError(f"Símbolo inesperado «{tok.value}» en la posición {tok.pos + 1}")
        return node

    def expr(self):
        self._enter()
        node = self.term()
        while self.peek().kind == "op" and self.peek().value in "+-":
            op = self.take().value
            node = Binary(op, node, self.term())
        self.depth -= 1
        return node

    def term(self):
        node = self.unary()
        while self.peek().kind == "op" and self.peek().value in "*/%":
            op = self.take().value
            node = Binary(op, node, self.unary())
        return node

    def unary(self):
        tok = self.peek()
        if tok.kind == "op" and tok.value in "+-":
            self.take()
            self._enter()
            node = Unary(tok.value, self.unary())
            self.depth -= 1
            return node
        return self.power()

    def power(self):
        base = self.atom()
        if self.peek().kind == "op" and self.peek().value == "^":
            self.take()
            self._enter()
            exponent = self.unary()
            self.depth -= 1
            return Binary("^", base, exponent)
        return base

    def atom(self):
        tok = self.take()
        if tok.kind == "num":
            try:
                return Num(float(tok.value))
            except ValueError as exc:  # pragma: no cover - protegido por el tokenizador
                raise ExpressionError(f"Número no válido «{tok.value}»") from exc
        if tok.kind == "id":
            if self.peek().kind == "lp":
                self.take()
                args = []
                if self.peek().kind != "rp":
                    args.append(self.expr())
                    while self.peek().kind == "comma":
                        self.take()
                        args.append(self.expr())
                closing = self.take()
                if closing.kind != "rp":
                    raise ExpressionError(f"Falta «)» tras los argumentos de {tok.value}")
                return Call(tok.value, tuple(args), tok.pos)
            return Var(tok.value, tok.pos)
        if tok.kind == "lp":
            node = self.expr()
            closing = self.take()
            if closing.kind != "rp":
                raise ExpressionError(f"Falta «)» (abierto en la posición {tok.pos + 1})")
            return node
        if tok.kind == "end":
            raise ExpressionError("La expresión está incompleta")
        raise ExpressionError(f"Símbolo inesperado «{tok.value}» en la posición {tok.pos + 1}")


def parse(src: str):
    if not isinstance(src, str):
        raise ExpressionError("La expresión debe ser texto")
    if len(src) > MAX_LENGTH:
        raise ExpressionError(f"La expresión supera {MAX_LENGTH} caracteres")
    if not src.strip():
        raise ExpressionError("La expresión está vacía")
    return _Parser(tokenize(src)).parse()


def _eval(node, env: Mapping[str, float]) -> float:
    if isinstance(node, Num):
        return node.value
    if isinstance(node, Var):
        if node.name in env:
            return float(env[node.name])
        if node.name in CONSTANTS:
            return CONSTANTS[node.name]
        raise ExpressionError(f"Variable desconocida «{node.name}»")
    if isinstance(node, Unary):
        val = _eval(node.operand, env)
        return -val if node.op == "-" else val
    if isinstance(node, Binary):
        a = _eval(node.left, env)
        b = _eval(node.right, env)
        if node.op == "+":
            return a + b
        if node.op == "-":
            return a - b
        if node.op == "*":
            return a * b
        if node.op == "/":
            if b == 0:
                raise ExpressionError("División entre cero")
            return a / b
        if node.op == "%":
            if b == 0:
                raise ExpressionError("Módulo entre cero")
            return math.fmod(a, b)
        if node.op == "^":
            try:
                result = a**b
            except (OverflowError, ZeroDivisionError) as exc:
                raise ExpressionError("Potencia fuera de rango") from exc
            if isinstance(result, complex):
                raise ExpressionError("La potencia produce un número complejo")
            return float(result)
    if isinstance(node, Call):
        spec = FUNCTIONS.get(node.name)
        if spec is None:
            raise ExpressionError(f"Función desconocida «{node.name}»")
        arity, fn = spec
        if len(node.args) != arity:
            raise ExpressionError(f"{node.name} espera {arity} argumento(s)")
        values = [_eval(arg, env) for arg in node.args]
        try:
            return float(fn(*values))
        except (ValueError, OverflowError) as exc:
            raise ExpressionError(f"Valor fuera del dominio de {node.name}") from exc
    raise ExpressionError("Expresión no válida")  # pragma: no cover


def evaluate(value: float | int | str, env: Mapping[str, float] | None = None) -> float:
    """Evalúa un número o una expresión y devuelve un ``float`` finito."""
    if isinstance(value, bool):
        raise ExpressionError("Se esperaba un número")
    if isinstance(value, (int, float)):
        result = float(value)
    else:
        result = _eval(parse(value), env or {})
    if not math.isfinite(result):
        raise ExpressionError("El resultado no es un número finito")
    return result


def free_variables(src: str) -> set[str]:
    """Identificadores usados como variables (no constantes ni funciones)."""
    found: set[str] = set()

    def walk(node) -> None:
        if isinstance(node, Var):
            if node.name not in CONSTANTS:
                found.add(node.name)
        elif isinstance(node, Unary):
            walk(node.operand)
        elif isinstance(node, Binary):
            walk(node.left)
            walk(node.right)
        elif isinstance(node, Call):
            for arg in node.args:
                walk(arg)

    walk(parse(src))
    return found


def is_identifier(name: str) -> bool:
    return (
        bool(name)
        and len(name) <= 24
        and _is_ident_start(name[0])
        and all(_is_ident_char(c) for c in name)
        and name not in CONSTANTS
        and name not in FUNCTIONS
    )
