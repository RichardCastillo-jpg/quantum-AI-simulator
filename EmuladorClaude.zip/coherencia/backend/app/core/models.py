"""Esquemas JSON (Pydantic v2) compartidos por la API y el frontend.

El circuito se describe por columnas (pasos de tiempo). Cada operación tiene una
columna ``col`` y unos cúbits; los ciclos ``for`` repiten un rango de columnas.
"""

from __future__ import annotations

import uuid
from typing import Any, Literal, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator

ParamValue = Union[float, str]


def _new_id() -> str:
    return uuid.uuid4().hex[:10]


class Condition(BaseModel):
    """Control clásico: la operación se ejecuta solo si ``c[clbit] == value``."""

    model_config = ConfigDict(extra="ignore")
    clbit: int = Field(ge=0, le=255)
    value: int = Field(default=1, ge=0, le=1)


class Op(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str = Field(default_factory=_new_id, max_length=64)
    kind: Literal["gate", "measure", "reset", "barrier", "subcircuit"] = "gate"
    gate: str | None = Field(default=None, max_length=32)
    col: int = Field(default=0, ge=0, le=100_000)
    targets: list[int] = Field(default_factory=list, max_length=64)
    controls: list[int] = Field(default_factory=list, max_length=32)
    anticontrols: list[int] = Field(default_factory=list, max_length=32)
    params: list[ParamValue] = Field(default_factory=list, max_length=8)
    clbits: list[int] = Field(default_factory=list, max_length=64)
    condition: list[Condition] | None = None
    subcircuit_id: str | None = Field(default=None, max_length=80)
    sub_params: dict[str, ParamValue] = Field(default_factory=dict)
    # Matriz para compuertas personalizadas: matrix[fila][columna] = [re, im]
    matrix: list[list[list[float]]] | None = None
    label: str | None = Field(default=None, max_length=40)


class Loop(BaseModel):
    """Ciclo for: repite las columnas [col_start, col_end] ``iterations`` veces.

    La variable ``var`` toma los valores ``start + k·step`` (k = 0 … iterations−1)
    y puede usarse en los parámetros de las compuertas del rango.
    """

    model_config = ConfigDict(extra="ignore")

    id: str = Field(default_factory=_new_id, max_length=64)
    col_start: int = Field(ge=0, le=100_000)
    col_end: int = Field(ge=0, le=100_000)
    iterations: int = Field(default=2, ge=1, le=10_000)
    var: str = Field(default="i", max_length=24)
    start: float = 0.0
    step: float = 1.0
    label: str | None = Field(default=None, max_length=40)


class Circuit(BaseModel):
    model_config = ConfigDict(extra="ignore")

    version: int = 1
    name: str = Field(default="Circuito", max_length=120)
    num_qubits: int = Field(default=2, ge=1, le=64)
    num_clbits: int = Field(default=0, ge=0, le=256)
    # Cadena de bits en el orden de Qiskit: el carácter más a la derecha es q0.
    initial_state: str = Field(default="", max_length=64)
    qubit_labels: list[str] | None = None
    clbit_labels: list[str] | None = None
    ops: list[Op] = Field(default_factory=list, max_length=20_000)
    loops: list[Loop] = Field(default_factory=list, max_length=500)
    meta: dict[str, Any] = Field(default_factory=dict)

    @field_validator("initial_state")
    @classmethod
    def _bits(cls, value: str) -> str:
        value = value.strip()
        if value and any(ch not in "01" for ch in value):
            raise ValueError("El estado inicial solo puede contener 0 y 1")
        return value


class NoiseConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")

    model: Literal["none", "depolarizing", "thermal"] = "none"
    # Despolarizante: probabilidad por compuerta de 1 y 2 cúbits.
    p1: float = Field(default=0.005, ge=0.0, le=1.0)
    p2: float = Field(default=0.02, ge=0.0, le=1.0)
    # Relajación térmica (microsegundos).
    t1: float = Field(default=50.0, gt=0.0, le=1e7)
    t2: float = Field(default=70.0, gt=0.0, le=1e7)
    time_1q: float = Field(default=0.05, ge=0.0, le=1e5)
    time_2q: float = Field(default=0.30, ge=0.0, le=1e5)
    # Error de lectura simétrico (ambos modelos).
    readout: float = Field(default=0.0, ge=0.0, le=0.5)


class SimConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")

    mode: Literal["statevector", "shots"] = "statevector"
    shots: int = Field(default=1024, ge=1, le=1_000_000)
    seed: int | None = Field(default=None, ge=0, le=2**31 - 1)
    noise: NoiseConfig = Field(default_factory=NoiseConfig)


class SimOptions(BaseModel):
    model_config = ConfigDict(extra="ignore")

    memory: bool = False  # devolver el resultado de cada disparo (para animaciones)
    include_state: bool = True  # en modo shots, calcular también el estado exacto
    max_amplitudes: int = Field(default=256, ge=1, le=4096)
    max_probabilities: int = Field(default=64, ge=1, le=4096)


class SimRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    circuit: Circuit
    config: SimConfig = Field(default_factory=SimConfig)
    options: SimOptions = Field(default_factory=SimOptions)


class SubcircuitIn(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str = Field(min_length=1, max_length=60)
    description: str = Field(default="", max_length=600)
    num_qubits: int = Field(ge=1, le=24)
    num_clbits: int = Field(default=0, ge=0, le=64)
    params: list[str] = Field(default_factory=list, max_length=8)
    ops: list[Op] = Field(default_factory=list, max_length=5000)
    loops: list[Loop] = Field(default_factory=list, max_length=200)
    color: str | None = Field(default=None, max_length=24)
    tags: list[str] = Field(default_factory=list, max_length=12)


class SubcircuitPatch(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str | None = Field(default=None, min_length=1, max_length=60)
    description: str | None = Field(default=None, max_length=600)
    num_qubits: int | None = Field(default=None, ge=1, le=24)
    num_clbits: int | None = Field(default=None, ge=0, le=64)
    params: list[str] | None = None
    ops: list[Op] | None = None
    loops: list[Loop] | None = None
    color: str | None = None
    tags: list[str] | None = None


class Subcircuit(SubcircuitIn):
    id: str
    created_at: str
    updated_at: str
    system: bool = False


class ExportRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    circuit: Circuit


class CodeRequest(BaseModel):
    """Código Python de Qiskit que se traduce al modelo de circuito."""

    model_config = ConfigDict(extra="ignore")

    code: str = Field(max_length=200_000)
    name: str | None = Field(default=None, max_length=120)
