"""Cálculo de magnitudes observables a partir de un vector de estado o de una matriz densidad."""

from __future__ import annotations

import math
from typing import Sequence

import numpy as np

EPS = 1e-12


def bitstr(index: int, n: int) -> str:
    return format(index, f"0{n}b") if n > 0 else ""


def _entropy(r: float) -> float:
    lp, lm = (1 + r) / 2, (1 - r) / 2
    s = 0.0
    for lam in (lp, lm):
        if lam > EPS:
            s -= lam * math.log2(lam)
    return max(0.0, s)


def _bloch_entry(q: int, x: float, y: float, z: float) -> dict:
    r = min(1.0, math.sqrt(x * x + y * y + z * z))
    return {
        "qubit": q,
        "x": float(x),
        "y": float(y),
        "z": float(z),
        "r": r,
        "purity": (1 + r * r) / 2,
        "entropy": _entropy(r),
        "p1": float((1 - z) / 2),
        "theta": float(math.acos(max(-1.0, min(1.0, z / r)))) if r > 1e-9 else 0.0,
        "phi": float(math.atan2(y, x)) if math.hypot(x, y) > 1e-9 else 0.0,
    }


def bloch_pure(psi: np.ndarray, n_total: int, qubits: Sequence[int]) -> list[dict]:
    out = []
    for k in qubits:
        r = psi.reshape(1 << (n_total - k - 1), 2, 1 << k)
        a = r[:, 0, :]
        b = r[:, 1, :]
        za = float(np.vdot(a, a).real)
        zb = float(np.vdot(b, b).real)
        xy = complex(np.vdot(a, b))
        out.append(_bloch_entry(k, 2 * xy.real, 2 * xy.imag, za - zb))
    return out


def reduced_qubit_density(rho: np.ndarray, n_total: int, k: int) -> np.ndarray:
    big_a = 1 << (n_total - k - 1)
    big_b = 1 << k
    t = rho.reshape(big_a, 2, big_b, big_a, 2, big_b)
    return np.einsum("aibajb->ij", t)


def bloch_density(rho: np.ndarray, n_total: int, qubits: Sequence[int]) -> list[dict]:
    out = []
    for k in qubits:
        r = reduced_qubit_density(rho, n_total, k)
        x = 2 * r[0, 1].real
        y = -2 * r[0, 1].imag
        z = (r[0, 0] - r[1, 1]).real
        out.append(_bloch_entry(k, float(x), float(y), float(z)))
    return out


def bloch_basis(bits: str) -> list[dict]:
    """Vectores de Bloch del estado inicial (cadena en orden de Qiskit)."""
    n = len(bits)
    out = []
    for q in range(n):
        bit = bits[n - 1 - q]
        out.append(_bloch_entry(q, 0.0, 0.0, -1.0 if bit == "1" else 1.0))
    return out


def marginal_low(probs: np.ndarray, n_total: int, n_keep: int) -> np.ndarray:
    """Marginal sobre los ``n_keep`` cúbits de menor índice (descarta los auxiliares)."""
    if n_total == n_keep:
        return probs
    return probs.reshape(1 << (n_total - n_keep), 1 << n_keep).sum(axis=0)


def classical_distribution(
    probs: np.ndarray,
    n_total: int,
    sources: Sequence[tuple[str, int] | None],
    terminal_readout: Sequence[bool],
    readout: float,
) -> np.ndarray | None:
    m = len(sources)
    if m == 0 or m > 24:
        return None
    positions = sorted({src[1] for src in sources if src is not None})
    if positions:
        t = probs.reshape([2] * n_total)
        keep_axes = {n_total - 1 - pos for pos in positions}
        sum_axes = tuple(ax for ax in range(n_total) if ax not in keep_axes)
        marg = t.sum(axis=sum_axes) if sum_axes else t
        marg = np.asarray(marg).reshape(-1)
    else:
        marg = np.array([1.0])
    rank = {pos: i for i, pos in enumerate(positions)}
    js = np.arange(marg.size, dtype=np.int64)
    values = np.zeros(marg.size, dtype=np.int64)
    for c, src in enumerate(sources):
        if src is not None:
            values |= ((js >> rank[src[1]]) & 1) << c
    dist = np.bincount(values, weights=marg, minlength=1 << m).astype(float)
    if readout > 0:
        idx = np.arange(dist.size, dtype=np.int64)
        for c, flag in enumerate(terminal_readout):
            if flag:
                dist = (1 - readout) * dist + readout * dist[idx ^ (1 << c)]
    total = dist.sum()
    if total > 0:
        dist = dist / total
    return dist


def probability_entries(probs: np.ndarray, n: int, limit: int) -> tuple[list[dict], float, bool]:
    """Entradas del histograma. Para n ≤ 6 se devuelven todos los estados (incluidos los nulos)."""
    size = probs.size
    if n <= 6 and size <= limit:
        return [{"state": bitstr(i, n), "p": float(max(probs[i], 0.0))} for i in range(size)], 0.0, False
    nonzero = np.flatnonzero(probs > EPS)
    if nonzero.size > limit:
        part = np.argpartition(-probs[nonzero], limit - 1)[:limit]
        chosen = nonzero[part]
    else:
        chosen = nonzero
    chosen = sorted(chosen.tolist(), key=lambda i: (-probs[i], i))
    shown = float(sum(probs[i] for i in chosen))
    entries = [{"state": bitstr(i, n), "p": float(probs[i])} for i in chosen]
    return entries, max(0.0, float(probs.sum()) - shown), nonzero.size > len(chosen)


def amplitude_entries(psi: np.ndarray, n: int, limit: int) -> tuple[list[dict], bool]:
    probs = np.abs(psi) ** 2
    if n <= 4:
        idx = list(range(psi.size))
        truncated = False
    else:
        nonzero = np.flatnonzero(probs > EPS)
        if nonzero.size > limit:
            part = np.argpartition(-probs[nonzero], limit - 1)[:limit]
            idx = sorted(nonzero[part].tolist(), key=lambda i: (-probs[i], i))
            truncated = True
        else:
            idx = sorted(nonzero.tolist(), key=lambda i: (-probs[i], i)) if nonzero.size > 64 else nonzero.tolist()
            truncated = False
    out = []
    for i in idx:
        z = complex(psi[i])
        out.append(
            {
                "state": bitstr(i, n),
                "re": z.real,
                "im": z.imag,
                "p": float(probs[i]),
                "phase": float(math.atan2(z.imag, z.real)) if abs(z) > 1e-9 else 0.0,
            }
        )
    return out, truncated


def purity_pure_reduced(psi: np.ndarray, n: int, n_total: int) -> float:
    anc = n_total - n
    if anc == 0:
        return 1.0
    mat = psi.reshape(1 << anc, 1 << n)
    if anc <= n:
        g = mat @ mat.conj().T
    else:
        g = mat.T @ mat.conj()
    return float(np.sum(np.abs(g) ** 2).real)


def reduce_density(rho: np.ndarray, n: int, n_total: int) -> np.ndarray:
    anc = n_total - n
    if anc == 0:
        return rho
    t = rho.reshape(1 << anc, 1 << n, 1 << anc, 1 << n)
    return np.einsum("aiaj->ij", t)


def dominant_branch_state(psi: np.ndarray, n: int, n_total: int) -> np.ndarray:
    """Para un estado reducido puro, devuelve el vector de los cúbits originales."""
    anc = n_total - n
    if anc == 0:
        return psi
    mat = psi.reshape(1 << anc, 1 << n)
    norms = np.sum(np.abs(mat) ** 2, axis=1)
    r = int(np.argmax(norms))
    vec = mat[r]
    return vec / math.sqrt(norms[r])


def branch_entries(psi: np.ndarray, n: int, n_total: int, ancillas: list[dict], limit_branches: int, limit_amps: int) -> list[dict]:
    anc = n_total - n
    if anc == 0:
        return []
    mat = psi.reshape(1 << anc, 1 << n)
    norms = np.sum(np.abs(mat) ** 2, axis=1)
    order = [int(r) for r in np.argsort(-norms) if norms[r] > 1e-10][:limit_branches]
    out = []
    for r in order:
        bits = []
        for info in ancillas:
            bit = (r >> (info["ancilla"] - n)) & 1
            if info["kind"] == "measure":
                bits.append({"clbit": info["clbit"], "qubit": info["qubit"], "value": int(bit), "step": info["step"]})
        vec = mat[r] / math.sqrt(norms[r])
        amps, truncated = amplitude_entries(vec, n, limit_amps)
        label = " ".join(f"c{b['clbit']}={b['value']}" for b in bits)
        out.append({"label": label, "probability": float(norms[r]), "record": bits, "amplitudes": amps, "truncated": truncated})
    return out


def counts_to_probabilities(counts: dict[str, int], m: int) -> np.ndarray | None:
    if m > 24:
        return None
    dist = np.zeros(1 << m)
    total = sum(counts.values())
    if total == 0:
        return dist
    for key, val in counts.items():
        dist[int(key, 2)] += val
    return dist / total
