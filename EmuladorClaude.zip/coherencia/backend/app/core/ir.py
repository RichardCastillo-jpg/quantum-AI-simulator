"""Traducción del circuito JSON a una representación intermedia (IR) plana.

La IR es una lista de operaciones primitivas (:class:`Prim`) sobre índices de
cúbits y bits clásicos globales. Durante la construcción se:

* validan índices, aridades, parámetros y conflictos por columna;
* evalúan las expresiones de los parámetros (con variables de ciclos y de
  subcircuitos);
* desenrollan los ciclos ``for`` (anidados);
* expanden los subcircuitos (recursivos, con detección de ciclos), propagando
  controles, anticontroles y condiciones clásicas;
* expanden los bloques macro (QFT, QFT†) a compuertas primitivas.

Ambos motores (Qiskit Aer y el de referencia NumPy) consumen exactamente la
misma IR, lo que permite validarlos entre sí.
"""

from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field, replace
from typing import Iterable, Mapping, Protocol, Sequence

import numpy as np

from .expressions import ExpressionError, evaluate, is_identifier
from .gates import ALIAS_CONTROLS, GATES, gate_matrix, is_unitary, modmul_matrix, resolve_name
from .models import Circuit, Loop, Op

MAX_SUBCIRCUIT_DEPTH = 16


class CircuitError(Exception):
    """Error de validación con detalle por operación (``op_id``)."""

    def __init__(self, message: str, errors: list[dict] | None = None):
        super().__init__(message)
        self.message = message
        self.errors = errors or []

    def to_dict(self) -> dict:
        return {"message": self.message, "errors": self.errors}


@dataclass
class Prim:
    kind: str  # gate | measure | reset | barrier | channel
    name: str = ""
    qubits: tuple[int, ...] = ()
    controls: tuple[int, ...] = ()
    anticontrols: tuple[int, ...] = ()
    params: tuple[float, ...] = ()
    matrix: np.ndarray | None = None
    clbit: int | None = None
    kraus: tuple[np.ndarray, ...] | None = None
    condition: tuple[tuple[int, int], ...] = ()
    step: int = 0
    source: str | None = None
    label: str | None = None
    noiseless: bool = False

    @property
    def all_qubits(self) -> tuple[int, ...]:
        return self.controls + self.anticontrols + self.qubits

    def base_matrix(self) -> np.ndarray:
        if self.matrix is not None:
            return self.matrix
        return gate_matrix(self.name, self.params)


@dataclass
class StepInfo:
    index: int
    col: int
    label: str
    ops: list[str] = field(default_factory=list)


@dataclass
class Program:
    num_qubits: int
    num_clbits: int
    ops: list[Prim]
    steps: list[StepInfo]
    warnings: list[str] = field(default_factory=list)

    @property
    def gate_count(self) -> int:
        return sum(1 for p in self.ops if p.kind == "gate" and not p.noiseless)

    @property
    def has_measurements(self) -> bool:
        return any(p.kind == "measure" for p in self.ops)

    @property
    def is_dynamic(self) -> bool:
        """True si hay medición/reinicio a mitad de circuito o control clásico."""
        seen_measure_q: set[int] = set()
        for p in self.ops:
            if p.condition or p.kind == "reset":
                return True
            if p.kind == "measure":
                seen_measure_q.add(p.qubits[0])
            elif p.kind in ("gate", "channel") and seen_measure_q.intersection(p.all_qubits):
                return True
        return False

    @property
    def has_channels(self) -> bool:
        return any(p.kind == "channel" for p in self.ops)

    def depth(self) -> int:
        level = [0] * self.num_qubits
        clevel = [0] * max(self.num_clbits, 1)
        best = 0
        for p in self.ops:
            if p.kind in ("barrier", "channel") or p.noiseless:
                continue
            qs = [q for q in p.all_qubits if q < self.num_qubits]
            cs = [c for c, _ in p.condition]
            if p.clbit is not None:
                cs.append(p.clbit)
            d = max([level[q] for q in qs] + [clevel[c] for c in cs] + [0]) + 1
            for q in qs:
                level[q] = d
            for c in cs:
                clevel[c] = d
            best = max(best, d)
        return best

    def count_ops(self) -> dict[str, int]:
        counts: dict[str, int] = defaultdict(int)
        for p in self.ops:
            if p.noiseless or p.kind == "channel":
                continue
            if p.kind == "gate":
                k = len(p.controls) + len(p.anticontrols)
                key = p.name if k == 0 else f"c{k}-{p.name}" if k > 1 else f"c-{p.name}"
                counts[key] += 1
            else:
                counts[p.kind] += 1
        return dict(counts)


class SubcircuitLike(Protocol):
    id: str
    name: str
    num_qubits: int
    num_clbits: int
    params: list[str]
    ops: list[Op]
    loops: list[Loop]


@dataclass(frozen=True)
class Frame:
    qmap: tuple[int, ...]
    cmap: tuple[int, ...]
    controls: tuple[int, ...] = ()
    anticontrols: tuple[int, ...] = ()
    condition: tuple[tuple[int, int], ...] = ()
    stack: tuple[str, ...] = ()
    report_id: str | None = None  # operación de nivel superior a la que se atribuyen errores
    context: str = ""
    top: bool = True

    @property
    def nq(self) -> int:
        return len(self.qmap)

    @property
    def nc(self) -> int:
        return len(self.cmap)


def _fmt_env(env: Mapping[str, float]) -> str:
    parts = []
    for key, val in env.items():
        parts.append(f"{key}={int(val) if float(val).is_integer() else round(val, 4)}")
    return ", ".join(parts)


class ProgramBuilder:
    def __init__(self, library: Mapping[str, SubcircuitLike] | None = None, max_ops: int = 20000):
        self.library = library or {}
        self.max_ops = max_ops
        self.errors: list[dict] = []
        self.warnings: list[str] = []
        self.ops: list[Prim] = []
        self.steps: list[StepInfo] = []
        self._current_step = -1

    # -- utilidades -----------------------------------------------------------
    def _error(self, frame: Frame, op: Op | None, message: str) -> None:
        op_id = frame.report_id or (op.id if op is not None else None)
        prefix = f"{frame.context}: " if frame.context else ""
        self.errors.append({"op_id": op_id, "message": prefix + message})

    def _push(self, prim: Prim) -> None:
        prim.step = self._current_step
        self.ops.append(prim)
        if len(self.ops) > self.max_ops:
            raise CircuitError(
                f"El circuito expandido supera el límite de {self.max_ops} operaciones "
                "(revisa las iteraciones de los ciclos for)."
            )

    # -- entrada ---------------------------------------------------------------
    def build(self, circuit: Circuit, env: Mapping[str, float] | None = None, root_id: str | None = None) -> Program:
        n, m = circuit.num_qubits, circuit.num_clbits
        init = circuit.initial_state or ""
        if init and len(init) != n:
            self.errors.append(
                {"op_id": None, "message": f"El estado inicial «{init}» debe tener {n} bits (uno por cúbit)."}
            )
        else:
            # Orden de Qiskit: el carácter de la derecha corresponde a q0.
            for q, bit in enumerate(reversed(init)):
                if bit == "1":
                    self.ops.append(Prim("gate", "x", qubits=(q,), step=-1, noiseless=True, label="prep"))
        frame = Frame(qmap=tuple(range(n)), cmap=tuple(range(m)), stack=(root_id,) if root_id else ())
        self._expand_block(circuit.ops, circuit.loops, frame, dict(env or {}))
        if self.errors:
            raise CircuitError("El circuito contiene errores", self.errors)
        return Program(n, m, self.ops, self.steps, self.warnings)

    # -- bloques y ciclos -------------------------------------------------------
    def _expand_block(self, ops: Sequence[Op], loops: Sequence[Loop], frame: Frame, env: dict[str, float]) -> None:
        by_col: dict[int, list[Op]] = defaultdict(list)
        for op in ops:
            by_col[op.col].append(op)
        for col_ops in by_col.values():
            col_ops.sort(key=lambda o: (min(self._local_qubits(o, frame) or [frame.nq]), o.id))
        self._check_columns(by_col, frame)
        valid_loops = self._check_loops(loops, frame)
        last = max([*by_col.keys(), *[lp.col_end for lp in valid_loops], -1])
        if last < 0:
            return
        self._walk(0, last, by_col, valid_loops, frame, env)

    def _walk(self, lo: int, hi: int, by_col, loops: list[Loop], frame: Frame, env: dict[str, float]) -> None:
        # Ciclos de primer nivel dentro de [lo, hi] (los ya ordenados por inicio y extensión).
        top: list[Loop] = []
        for lp in loops:
            if lp.col_start < lo or lp.col_end > hi:
                continue
            if any(o.col_start <= lp.col_start and lp.col_end <= o.col_end for o in top):
                continue
            top.append(lp)
        starts = {lp.col_start: lp for lp in top}
        c = lo
        while c <= hi:
            lp = starts.get(c)
            if lp is not None:
                inner = [o for o in loops if o is not lp and lp.col_start <= o.col_start and o.col_end <= lp.col_end]
                for k in range(lp.iterations):
                    sub_env = dict(env)
                    sub_env[lp.var] = lp.start + k * lp.step
                    self._walk(lp.col_start, lp.col_end, by_col, inner, frame, sub_env)
                c = lp.col_end + 1
                continue
            col_ops = by_col.get(c)
            if col_ops:
                if frame.top:
                    label = f"Columna {c}"
                    if env:
                        label += f" ({_fmt_env(env)})"
                    self._current_step += 1
                    self.steps.append(StepInfo(self._current_step, c, label, [o.id for o in col_ops]))
                for op in col_ops:
                    self._emit(op, frame, env)
            c += 1

    def _check_loops(self, loops: Sequence[Loop], frame: Frame) -> list[Loop]:
        valid: list[Loop] = []
        for lp in loops:
            if lp.col_end < lp.col_start:
                self._error(frame, None, f"El ciclo «{lp.label or lp.var}» termina antes de empezar")
                continue
            if not is_identifier(lp.var):
                self._error(frame, None, f"«{lp.var}» no es un nombre de variable válido para un ciclo")
                continue
            valid.append(lp)
        valid.sort(key=lambda lp: (lp.col_start, -lp.col_end))
        for i, a in enumerate(valid):
            for b in valid[i + 1 :]:
                overlap = a.col_start <= b.col_end and b.col_start <= a.col_end
                nested = (a.col_start <= b.col_start and b.col_end <= a.col_end) or (
                    b.col_start <= a.col_start and a.col_end <= b.col_end
                )
                if overlap and not nested:
                    self._error(
                        frame,
                        None,
                        f"Los ciclos de las columnas {a.col_start}–{a.col_end} y {b.col_start}–{b.col_end} "
                        "se solapan sin estar anidados",
                    )
        return valid

    def _local_qubits(self, op: Op, frame: Frame) -> list[int]:
        qs = list(op.targets) + list(op.controls) + list(op.anticontrols)
        if op.kind == "barrier" and not qs:
            qs = list(range(frame.nq))
        return qs

    def _check_columns(self, by_col, frame: Frame) -> None:
        for col, col_ops in by_col.items():
            used_q: dict[int, str] = {}
            written_c: dict[int, str] = {}
            read_c: dict[int, str] = {}
            for op in col_ops:
                if op.kind == "barrier":
                    continue
                for q in self._local_qubits(op, frame):
                    if q in used_q and used_q[q] != op.id:
                        self._error(frame, op, f"La columna {col} tiene dos operaciones sobre q{q}")
                    used_q[q] = op.id
                writes = list(op.clbits) if op.kind in ("measure", "subcircuit") else []
                reads = [cond.clbit for cond in (op.condition or [])]
                for c in writes:
                    if c in written_c or c in read_c:
                        self._error(frame, op, f"La columna {col} escribe y usa el bit clásico c{c} a la vez")
                    written_c[c] = op.id
                for c in reads:
                    if c in written_c:
                        self._error(frame, op, f"La columna {col} lee c{c} mientras otra operación lo escribe")
                    read_c[c] = op.id

    # -- operaciones -------------------------------------------------------------
    def _map_qubits(self, frame: Frame, op: Op, qs: Iterable[int], what: str) -> tuple[int, ...] | None:
        out = []
        for q in qs:
            if not isinstance(q, int) or q < 0 or q >= frame.nq:
                self._error(frame, op, f"El cúbit {what} q{q} no existe (hay {frame.nq})")
                return None
            out.append(frame.qmap[q])
        return tuple(out)

    def _map_condition(self, frame: Frame, op: Op) -> tuple[tuple[int, int], ...] | None:
        conds = list(frame.condition)
        for cond in op.condition or []:
            if cond.clbit >= frame.nc:
                self._error(frame, op, f"La condición usa c{cond.clbit}, pero solo hay {frame.nc} bits clásicos")
                return None
            conds.append((frame.cmap[cond.clbit], cond.value))
        return tuple(conds)

    def _eval_params(self, frame: Frame, op: Op, names: Sequence[str], env: Mapping[str, float]) -> tuple[float, ...] | None:
        values = list(op.params)
        if len(values) != len(names):
            if len(values) < len(names):
                self._error(frame, op, f"Faltan parámetros: se esperaban {len(names)} ({', '.join(names)})")
            else:
                self._error(frame, op, f"Sobran parámetros: se esperaban {len(names)}")
            return None
        out = []
        for name, raw in zip(names, values):
            try:
                out.append(evaluate(raw, env))
            except ExpressionError as exc:
                self._error(frame, op, f"Parámetro {name} = «{raw}»: {exc}")
                return None
        return tuple(out)

    def _emit(self, op: Op, frame: Frame, env: dict[str, float]) -> None:
        kind = op.kind
        targets = list(op.targets)
        controls = list(op.controls)
        anticontrols = list(op.anticontrols)

        if kind == "gate":
            if not op.gate:
                self._error(frame, op, "Falta el nombre de la compuerta")
                return
            raw_name = op.gate.strip().lower()
            implied = ALIAS_CONTROLS.get(raw_name, 0)
            if implied and not controls and not anticontrols and len(targets) == implied + 1:
                controls, targets = targets[:implied], targets[implied:]
            name = resolve_name(raw_name)
            spec = GATES.get(name)
            if spec is None:
                self._error(frame, op, f"Compuerta desconocida «{op.gate}»")
                return
        elif kind in ("measure", "reset"):
            if len(targets) != 1:
                self._error(frame, op, "La medición y el reinicio actúan sobre exactamente un cúbit")
                return
            if controls or anticontrols:
                self._error(frame, op, "Una medición o un reinicio no pueden tener controles cuánticos")
                return
        all_local = targets + controls + anticontrols
        if len(set(all_local)) != len(all_local):
            self._error(frame, op, "Un cúbit aparece repetido entre objetivos y controles")
            return
        t = self._map_qubits(frame, op, targets, "objetivo")
        c = self._map_qubits(frame, op, controls, "de control")
        a = self._map_qubits(frame, op, anticontrols, "de anticontrol")
        if t is None or c is None or a is None:
            return
        cond = self._map_condition(frame, op)
        if cond is None:
            return
        ctrl = frame.controls + c
        anti = frame.anticontrols + a

        if kind == "barrier":
            if frame.controls or frame.anticontrols:
                return
            qubits = t if t else tuple(frame.qmap)
            self._push(Prim("barrier", "barrier", qubits=qubits, source=op.id, condition=()))
            return

        if kind in ("measure", "reset"):
            if frame.controls or frame.anticontrols:
                self._error(frame, op, "Un subcircuito controlado no puede contener mediciones ni reinicios")
                return
            if kind == "reset":
                self._push(Prim("reset", "reset", qubits=t, condition=cond, source=op.id))
                return
            clbits = list(op.clbits)
            if not clbits:
                local_q = targets[0]
                if local_q < frame.nc:
                    clbits = [local_q]
                else:
                    self._error(frame, op, "La medición necesita un bit clásico (añade registros clásicos)")
                    return
            if len(clbits) != 1 or clbits[0] < 0 or clbits[0] >= frame.nc:
                self._error(frame, op, f"El bit clásico c{clbits[0] if clbits else '?'} no existe (hay {frame.nc})")
                return
            self._push(Prim("measure", "measure", qubits=t, clbit=frame.cmap[clbits[0]], condition=cond, source=op.id))
            return

        if kind == "subcircuit":
            self._emit_subcircuit(op, frame, env, t, ctrl, anti, cond)
            return

        # --- compuertas -------------------------------------------------------
        spec = GATES[name]
        if spec.num_targets is not None and len(t) != spec.num_targets:
            self._error(frame, op, f"{spec.label} necesita {spec.num_targets} cúbit(s) objetivo, recibió {len(t)}")
            return
        if spec.num_targets is None and not (spec.min_targets <= len(t) <= spec.max_targets):
            self._error(
                frame, op, f"{spec.label} admite entre {spec.min_targets} y {spec.max_targets} cúbits objetivo"
            )
            return
        params = self._eval_params(frame, op, spec.params, env) if spec.name != "unitary" else ()
        if params is None:
            return
        label = op.label or spec.label

        if spec.kind == "macro":
            self._emit_qft(t, inverse=(spec.name == "iqft"), ctrl=ctrl, anti=anti, cond=cond, source=op.id)
            return
        if spec.name == "modmul":
            mat = self._modmul(frame, op, params, len(t))
            if mat is None:
                return
            av, nv = int(round(params[0])), int(round(params[1]))
            self._push(
                Prim("gate", "modmul", qubits=t, controls=ctrl, anticontrols=anti, params=params, matrix=mat,
                     condition=cond, source=op.id, label=f"×{av} mod {nv}")
            )
            return
        if spec.name == "unitary":
            mat = self._custom_matrix(frame, op, len(t))
            if mat is None:
                return
            self._push(
                Prim("gate", "unitary", qubits=t, controls=ctrl, anticontrols=anti, matrix=mat, condition=cond,
                     source=op.id, label=op.label or "U")
            )
            return
        self._push(
            Prim("gate", spec.name, qubits=t, controls=ctrl, anticontrols=anti, params=params, condition=cond,
                 source=op.id, label=label)
        )

    def _emit_qft(self, ts: tuple[int, ...], inverse: bool, ctrl, anti, cond, source: str) -> None:
        n = len(ts)
        seq: list[tuple[str, tuple[int, ...], tuple[int, ...], tuple[float, ...]]] = []
        if not inverse:
            for j in reversed(range(n)):
                seq.append(("h", (ts[j],), (), ()))
                for k in reversed(range(j)):
                    seq.append(("p", (ts[j],), (ts[k],), (math.pi / 2 ** (j - k),)))
            for q in range(n // 2):
                seq.append(("swap", (ts[q], ts[n - q - 1]), (), ()))
        else:
            for q in range(n // 2):
                seq.append(("swap", (ts[q], ts[n - q - 1]), (), ()))
            for j in range(n):
                for k in range(j):
                    seq.append(("p", (ts[j],), (ts[k],), (-math.pi / 2 ** (j - k),)))
                seq.append(("h", (ts[j],), (), ()))
        for name, qs, extra_c, params in seq:
            self._push(
                Prim("gate", name, qubits=qs, controls=tuple(ctrl) + extra_c, anticontrols=tuple(anti), params=params,
                     condition=cond, source=source, label=None)
            )

    def _modmul(self, frame: Frame, op: Op, params: tuple[float, ...], n: int) -> np.ndarray | None:
        a_raw, n_raw = params
        if abs(a_raw - round(a_raw)) > 1e-9 or abs(n_raw - round(n_raw)) > 1e-9:
            self._error(frame, op, "a y N deben ser enteros")
            return None
        a, big_n = int(round(a_raw)), int(round(n_raw))
        if big_n < 2:
            self._error(frame, op, "N debe ser al menos 2")
            return None
        if (1 << n) < big_n:
            self._error(frame, op, f"N = {big_n} necesita al menos {math.ceil(math.log2(big_n))} cúbits objetivo")
            return None
        if math.gcd(a, big_n) != 1:
            self._error(frame, op, f"a = {a} no es coprimo con N = {big_n}: la operación no sería reversible")
            return None
        return modmul_matrix(a % big_n, big_n, n)

    def _custom_matrix(self, frame: Frame, op: Op, n: int) -> np.ndarray | None:
        if op.matrix is None:
            self._error(frame, op, "La compuerta personalizada necesita una matriz")
            return None
        dim = 1 << n
        try:
            mat = np.array([[complex(e[0], e[1] if len(e) > 1 else 0.0) for e in row] for row in op.matrix], dtype=complex)
        except (TypeError, IndexError, ValueError):
            self._error(frame, op, "Formato de matriz no válido: se espera [fila][columna] = [re, im]")
            return None
        if mat.shape != (dim, dim):
            self._error(frame, op, f"La matriz debe ser {dim}×{dim} para {n} cúbit(s)")
            return None
        if not np.all(np.isfinite(mat)):
            self._error(frame, op, "La matriz contiene valores no finitos")
            return None
        if not is_unitary(mat, atol=1e-6):
            self._error(frame, op, "La matriz no es unitaria (U†U ≠ I)")
            return None
        return mat

    def _emit_subcircuit(self, op: Op, frame: Frame, env, t, ctrl, anti, cond) -> None:
        sid = op.subcircuit_id
        if not sid or sid not in self.library:
            self._error(frame, op, f"El subcircuito «{sid}» no existe en la biblioteca")
            return
        sub = self.library[sid]
        if sid in frame.stack:
            self._error(frame, op, f"El subcircuito «{sub.name}» se contiene a sí mismo (recursión)")
            return
        if len(frame.stack) >= MAX_SUBCIRCUIT_DEPTH:
            self._error(frame, op, "Demasiados niveles de subcircuitos anidados")
            return
        if len(t) != sub.num_qubits:
            self._error(
                frame,
                op,
                f"«{sub.name}» necesita {sub.num_qubits} cúbit(s) y la instancia asigna {len(t)}",
            )
            return
        clbits = list(op.clbits)
        if sub.num_clbits and not clbits:
            clbits = list(range(sub.num_clbits))
        if len(clbits) != sub.num_clbits:
            self._error(frame, op, f"«{sub.name}» necesita {sub.num_clbits} bit(s) clásicos")
            return
        if any(cb < 0 or cb >= frame.nc for cb in clbits):
            self._error(frame, op, f"«{sub.name}» usa bits clásicos inexistentes (hay {frame.nc})")
            return
        if len(set(clbits)) != len(clbits):
            self._error(frame, op, "Bits clásicos repetidos en la asignación del subcircuito")
            return
        if (ctrl or anti) and sub.num_clbits:
            self._error(frame, op, "Un subcircuito con mediciones no puede llevar controles cuánticos")
            return
        sub_env: dict[str, float] = {}
        for pname in sub.params:
            raw = op.sub_params.get(pname, 0.0)
            try:
                sub_env[pname] = evaluate(raw, env)
            except ExpressionError as exc:
                self._error(frame, op, f"Parámetro {pname} = «{raw}»: {exc}")
                return
            if pname not in op.sub_params:
                self.warnings.append(f"«{sub.name}»: el parámetro {pname} no tiene valor; se usa 0.")
        inner = Frame(
            qmap=t,
            cmap=tuple(frame.cmap[cb] for cb in clbits),
            controls=tuple(ctrl),
            anticontrols=tuple(anti),
            condition=cond,
            stack=frame.stack + (sid,),
            report_id=frame.report_id or op.id,
            context=(f"{frame.context} › " if frame.context else "") + f"en «{sub.name}»",
            top=False,
        )
        self._expand_block(sub.ops, sub.loops, inner, sub_env)


def build_program(circuit: Circuit, library: Mapping[str, SubcircuitLike] | None = None, max_ops: int = 20000,
                  env: Mapping[str, float] | None = None, root_id: str | None = None) -> Program:
    return ProgramBuilder(library, max_ops).build(circuit, env, root_id)


def validate_subcircuit_definition(sub: SubcircuitLike, library: Mapping[str, SubcircuitLike]) -> None:
    """Comprueba que un subcircuito se expande sin errores (incluida la recursión)."""
    probe = Circuit(
        name=sub.name,
        num_qubits=sub.num_qubits,
        num_clbits=sub.num_clbits,
        ops=[
            Op(
                id="__probe__",
                kind="subcircuit",
                col=0,
                subcircuit_id=sub.id,
                targets=list(range(sub.num_qubits)),
                clbits=list(range(sub.num_clbits)),
                sub_params={p: 0.0 for p in sub.params},
            )
        ],
    )
    lib = dict(library)
    lib[sub.id] = sub
    build_program(probe, lib)


def strip_terminal_measurements(prog: Program) -> Program:
    """Copia del programa sin las mediciones finales (para vistas de estado)."""
    keep = list(prog.ops)
    used_q: set[int] = set()
    read_c: set[int] = set()
    out_rev: list[Prim] = []
    for p in reversed(keep):
        if p.kind == "measure" and p.qubits[0] not in used_q and p.clbit not in read_c and not p.condition:
            used_q.add(p.qubits[0])
            continue
        if p.kind == "measure":
            used_q.add(p.qubits[0])
            read_c.discard(p.clbit)
        else:
            used_q.update(p.all_qubits)
            read_c.update(c for c, _ in p.condition)
        out_rev.append(p)
    return replace(prog, ops=list(reversed(out_rev)))
