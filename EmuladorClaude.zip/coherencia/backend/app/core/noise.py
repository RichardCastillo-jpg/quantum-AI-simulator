"""Modelos de ruido como canales de Kraus explícitos.

El ruido se inserta en la IR como operaciones ``channel`` justo después de cada
compuerta lógica, de modo que los dos motores aplican exactamente los mismos
canales en los mismos puntos:

* **Despolarizante**: E(ρ) = (1−λ)ρ + λ·I/2ⁿ con λ = p1 (1 cúbit) o p2 (2 cúbits).
  Para compuertas de 3 o más cúbits se aplica un canal de 1 cúbit con λ = p2 sobre
  cada cúbit implicado.
* **Relajación térmica** (T1, T2, tiempo de compuerta t): amortiguamiento de
  amplitud γ = 1 − e^{−t/T1} compuesto con desfase puro, de forma que la
  coherencia decae como e^{−t/T2} (requiere T2 ≤ 2·T1). Las compuertas de 2 o más
  cúbits usan el tiempo ``time_2q`` en cada cúbit.
* **Lectura**: inversión simétrica del bit medido con probabilidad ``readout``.
"""

from __future__ import annotations

import itertools
import math
from dataclasses import replace
from functools import lru_cache

import numpy as np

from .ir import CircuitError, Prim, Program
from .models import NoiseConfig

_I = np.eye(2, dtype=complex)
_X = np.array([[0, 1], [1, 0]], dtype=complex)
_Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
_Z = np.array([[1, 0], [0, -1]], dtype=complex)
_PAULIS = (_I, _X, _Y, _Z)


@lru_cache(maxsize=64)
def depolarizing_kraus(lam: float, num_qubits: int = 1) -> tuple[np.ndarray, ...]:
    if num_qubits not in (1, 2):
        raise ValueError("Solo se construyen canales despolarizantes de 1 o 2 cúbits")
    dim4 = 4**num_qubits
    max_lam = dim4 / (dim4 - 1)
    lam = min(max(lam, 0.0), max_lam)
    w_id = 1 - lam * (dim4 - 1) / dim4
    w_p = lam / dim4
    ops = []
    for combo in itertools.product(range(4), repeat=num_qubits):
        mat = np.array([[1.0]], dtype=complex)
        # combo[0] corresponde al primer cúbit (bit menos significativo).
        for idx in reversed(combo):
            mat = np.kron(mat, _PAULIS[idx])
        weight = w_id if all(i == 0 for i in combo) else w_p
        if weight > 0:
            ops.append(math.sqrt(weight) * mat)
    return tuple(ops)


@lru_cache(maxsize=64)
def thermal_kraus(t1: float, t2: float, time: float) -> tuple[np.ndarray, ...]:
    if time <= 0:
        return (_I.copy(),)
    if t2 > 2 * t1 + 1e-12:
        raise ValueError("T2 debe ser menor o igual que 2·T1")
    gamma = 1 - math.exp(-time / t1)
    lam_phi = math.exp(-time * (1 / t2 - 1 / (2 * t1)))
    lam_phi = min(max(lam_phi, 0.0), 1.0)
    a0 = np.array([[1, 0], [0, math.sqrt(1 - gamma)]], dtype=complex)
    a1 = np.array([[0, math.sqrt(gamma)], [0, 0]], dtype=complex)
    d0 = math.sqrt((1 + lam_phi) / 2) * _I
    d1 = math.sqrt((1 - lam_phi) / 2) * _Z
    ops = []
    for d in (d0, d1):
        for a in (a0, a1):
            k = d @ a
            if np.linalg.norm(k) > 1e-12:
                ops.append(k)
    return tuple(ops)


@lru_cache(maxsize=64)
def bitflip_kraus(p: float) -> tuple[np.ndarray, ...]:
    p = min(max(p, 0.0), 1.0)
    ops = []
    if p < 1:
        ops.append(math.sqrt(1 - p) * _I)
    if p > 0:
        ops.append(math.sqrt(p) * _X)
    return tuple(ops)


def controlled_kraus(kraus: tuple[np.ndarray, ...], num_controls: int, num_anticontrols: int) -> tuple[np.ndarray, ...]:
    """Kraus del canal aplicado solo cuando los controles están en |1⟩ y los anticontroles en |0⟩.

    Los cúbits de control ocupan los bits bajos: primero los controles, después
    los anticontroles y por último los objetivos del canal.
    K'_i = P_⊥ ⊗ I/√m + P ⊗ K_i, que es CPTP y actúa como E en la rama activa.
    """
    c = num_controls + num_anticontrols
    if c == 0:
        return kraus
    dim_c = 1 << c
    match_index = (1 << num_controls) - 1  # controles = 1, anticontroles = 0
    proj = np.zeros(dim_c)
    proj[match_index] = 1.0
    p_match = np.diag(proj).astype(complex)
    p_other = np.diag(1.0 - proj).astype(complex)
    dim_t = kraus[0].shape[0]
    m = len(kraus)
    eye_t = np.eye(dim_t, dtype=complex) / math.sqrt(m)
    return tuple(np.kron(k, p_match) + np.kron(eye_t, p_other) for k in kraus)


def validate_noise(cfg: NoiseConfig) -> None:
    if cfg.model == "thermal" and cfg.t2 > 2 * cfg.t1 + 1e-12:
        raise CircuitError(
            "Parámetros de ruido no válidos",
            [{"op_id": None, "message": f"T2 = {cfg.t2} µs no puede superar 2·T1 = {2 * cfg.t1} µs"}],
        )


def _channels_for(prim: Prim, cfg: NoiseConfig) -> list[Prim]:
    qubits = prim.all_qubits
    k = len(qubits)
    out: list[Prim] = []

    def add(kraus, qs):
        if len(kraus) == 1 and np.allclose(kraus[0], np.eye(kraus[0].shape[0])):
            return
        out.append(Prim("channel", "kraus", qubits=tuple(qs), kraus=kraus, condition=prim.condition, step=prim.step,
                        source=prim.source, label=cfg.model))

    if cfg.model == "depolarizing":
        if k == 1 and cfg.p1 > 0:
            add(depolarizing_kraus(cfg.p1, 1), qubits)
        elif k == 2 and cfg.p2 > 0:
            add(depolarizing_kraus(cfg.p2, 2), qubits)
        elif k >= 3 and cfg.p2 > 0:
            kr = depolarizing_kraus(cfg.p2, 1)
            for q in qubits:
                add(kr, (q,))
    elif cfg.model == "thermal":
        time = cfg.time_1q if k == 1 else cfg.time_2q
        if time > 0:
            kr = thermal_kraus(cfg.t1, cfg.t2, time)
            for q in qubits:
                add(kr, (q,))
    return out


def insert_noise(prog: Program, cfg: NoiseConfig) -> Program:
    """Devuelve una copia del programa con canales de ruido tras cada compuerta."""
    if cfg.model == "none":
        return prog
    validate_noise(cfg)
    ops: list[Prim] = []
    for prim in prog.ops:
        ops.append(prim)
        if prim.kind == "gate" and not prim.noiseless:
            ops.extend(_channels_for(prim, cfg))
    return replace(prog, ops=ops)
