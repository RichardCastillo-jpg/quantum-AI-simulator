"""Utilidades compartidas por los generadores de algoritmos."""

from __future__ import annotations

import uuid
from typing import Any

import numpy as np


class AlgorithmError(ValueError):
    """Parámetros no válidos para un algoritmo precargado."""


def _id(prefix: str = "op") -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


class CircuitBuilder:
    def __init__(self, num_qubits: int, num_clbits: int = 0, name: str = "Circuito"):
        self.num_qubits = num_qubits
        self.num_clbits = num_clbits
        self.name = name
        self.ops: list[dict] = []
        self.loops: list[dict] = []

    def gate(self, col: int, gate: str, targets, controls=(), params=(), anticontrols=(), condition=None, label=None) -> dict:
        op = {
            "id": _id(),
            "kind": "gate",
            "gate": gate,
            "col": col,
            "targets": list(targets),
            "controls": list(controls),
            "anticontrols": list(anticontrols),
            "params": list(params),
        }
        if condition:
            op["condition"] = [{"clbit": c, "value": v} for c, v in condition]
        if label:
            op["label"] = label
        self.ops.append(op)
        return op

    def measure(self, col: int, qubit: int, clbit: int) -> dict:
        op = {"id": _id(), "kind": "measure", "col": col, "targets": [qubit], "clbits": [clbit]}
        self.ops.append(op)
        return op

    def barrier(self, col: int, qubits=()) -> dict:
        op = {"id": _id(), "kind": "barrier", "col": col, "targets": list(qubits)}
        self.ops.append(op)
        return op

    def loop(self, col_start: int, col_end: int, iterations: int, var: str = "i", label: str | None = None) -> dict:
        lp = {"id": _id("loop"), "col_start": col_start, "col_end": col_end, "iterations": iterations, "var": var,
              "start": 0, "step": 1}
        if label:
            lp["label"] = label
        self.loops.append(lp)
        return lp

    def build(self, meta: dict[str, Any], initial_state: str = "", clbit_labels=None, qubit_labels=None,
              description: str = "") -> dict:
        circuit = {
            "version": 1,
            "name": self.name,
            "num_qubits": self.num_qubits,
            "num_clbits": self.num_clbits,
            "initial_state": initial_state,
            "ops": self.ops,
            "loops": self.loops,
            "meta": {**meta, "description": description},
        }
        if clbit_labels:
            circuit["clbit_labels"] = clbit_labels
        if qubit_labels:
            circuit["qubit_labels"] = qubit_labels
        return circuit


def register_distribution(context: dict) -> tuple[np.ndarray | None, str]:
    """Distribución sobre los bits clásicos: conteos (modo shots) o exacta (modo statevector)."""
    shots = context.get("shots")
    if shots is not None and shots.get("register") == "clbits":
        width = shots["width"]
        if width > 24:
            return None, "conteos"
        dist = np.zeros(1 << width)
        total = sum(shots["counts"].values()) or 1
        for key, val in shots["counts"].items():
            dist[int(key, 2)] += val / total
        return dist, "conteos"
    view = context.get("view")
    if view is not None and view.classical is not None:
        return view.classical, "exacta"
    return None, "no disponible"


def int_param(params: dict, key: str, default: int, lo: int, hi: int) -> int:
    raw = params.get(key, default)
    try:
        value = int(float(raw))
    except (TypeError, ValueError) as exc:
        raise AlgorithmError(f"«{key}» debe ser un entero") from exc
    if not (lo <= value <= hi):
        raise AlgorithmError(f"«{key}» debe estar entre {lo} y {hi}")
    return value


def float_param(params: dict, key: str, default: float) -> float:
    raw = params.get(key, default)
    try:
        return float(raw)
    except (TypeError, ValueError) as exc:
        raise AlgorithmError(f"«{key}» debe ser un número") from exc
