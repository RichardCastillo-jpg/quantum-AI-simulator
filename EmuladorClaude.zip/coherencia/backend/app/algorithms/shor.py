"""Algoritmo de Shor: estimación de fase del operador U|y⟩ = |a·y mod N⟩ y post-procesado clásico.

Registro de conteo: q0 … q(t−1). Registro de trabajo: q(t) … q(t+n−1), inicializado en |1⟩.
Para cada cúbit de conteo j se aplica U^(2^j) = multiplicación por a^(2^j) mod N
controlada por q_j; después la QFT inversa y la medición del registro de conteo.
Cada resultado y aproxima s/r ≈ y/2^t; las fracciones continuas recuperan el
periodo r y, si r es par y a^(r/2) ≢ −1 (mod N), los factores mcd(a^(r/2) ± 1, N).
"""

from __future__ import annotations

import math
from fractions import Fraction

from .common import AlgorithmError, CircuitBuilder, int_param, register_distribution


def _is_prime(n: int) -> bool:
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    r = int(math.isqrt(n))
    return all(n % d for d in range(3, r + 1, 2))


def _is_prime_power(n: int) -> bool:
    for b in range(2, int(math.log2(n)) + 2):
        root = round(n ** (1 / b))
        for cand in (root - 1, root, root + 1):
            if cand > 1 and cand**b == n:
                return True
    return False


def classical_order(a: int, n: int) -> int:
    r, x = 1, a % n
    while x != 1:
        x = (x * a) % n
        r += 1
        if r > n:
            return 0
    return r


def build_shor(params: dict, max_qubits: int = 22) -> dict:
    big_n = int_param(params, "N", 15, 15, 255)
    if big_n % 2 == 0:
        raise AlgorithmError("N debe ser impar (si es par, 2 ya es un factor)")
    if _is_prime(big_n):
        raise AlgorithmError(f"N = {big_n} es primo: no hay factores que encontrar")
    if _is_prime_power(big_n):
        raise AlgorithmError(f"N = {big_n} es potencia de un primo: se factoriza clásicamente")
    a = int_param(params, "a", 7 if big_n == 15 else 2, 2, big_n - 1)
    g = math.gcd(a, big_n)
    if g != 1:
        raise AlgorithmError(f"mcd({a}, {big_n}) = {g}: ya es un factor; elige un a coprimo con N")
    n = big_n.bit_length()
    t = int_param(params, "t", 2 * n, 2, 2 * n + 2)
    if t + n > max_qubits:
        raise AlgorithmError(
            f"Se necesitan {t + n} cúbits ({t} de conteo + {n} de trabajo) y el servidor admite {max_qubits}; "
            "reduce t o N"
        )
    b = CircuitBuilder(t + n, t, f"Shor · N = {big_n}, a = {a}")
    work = list(range(t, t + n))
    for j in range(t):
        b.gate(0, "h", [j])
    b.gate(0, "x", [work[0]], label="|1⟩")
    for j in range(t):
        mult = pow(a, 2**j, big_n)
        b.gate(1 + j, "modmul", work, controls=[j], params=[mult, big_n], label=f"×{mult}")
    b.gate(1 + t, "iqft", list(range(t)))
    for j in range(t):
        b.measure(2 + t, j, j)
    labels = [f"c{j}" for j in range(t)] + [f"w{k}" for k in range(n)]
    return b.build(
        {"algorithm": "shor", "N": big_n, "a": a, "t": t, "n": n},
        qubit_labels=labels,
        description=(
            f"Estimación de fase de U|y⟩ = |{a}·y mod {big_n}⟩ con {t} cúbits de conteo y {n} de trabajo. "
            "Los resultados y/2^t ≈ s/r se convierten en el periodo r mediante fracciones continuas."
        ),
    )


def _convergents(y: int, t: int, n: int) -> list[str]:
    frac = Fraction(y, 2**t)
    out = []
    a0 = frac
    terms = []
    x = a0
    for _ in range(12):
        ip = x.numerator // x.denominator
        terms.append(ip)
        rem = x - ip
        if rem == 0:
            break
        x = 1 / rem
    h_prev, h = 1, terms[0]
    k_prev, k = 0, 1
    out.append(f"{h}/{k}")
    for term in terms[1:]:
        h_prev, h = h, term * h + h_prev
        k_prev, k = k, term * k + k_prev
        if k > n:
            break
        out.append(f"{h}/{k}")
    return out


def analyze_shor(ctx: dict) -> dict | None:
    meta = ctx["circuit"].meta
    big_n, a, t = int(meta["N"]), int(meta["a"]), int(meta["t"])
    dist, source = register_distribution(ctx)
    if dist is None:
        return None
    true_r = classical_order(a, big_n)
    rows = []
    success = 0.0
    factors_found: set[int] = set()
    for y in range(dist.size):
        p = float(dist[y])
        if p <= 1e-9:
            continue
        frac = Fraction(y, 2**t).limit_denominator(big_n)
        r = frac.denominator
        r_found = 0
        # y = 0 no aporta información de fase. Si s y r tenían factores comunes, la fracción
        # reducida da un divisor de r: se prueban unos pocos múltiplos pequeños (práctica estándar).
        if y != 0:
            for mult in range(1, 5):
                cand = r * mult
                if cand <= big_n and pow(a, cand, big_n) == 1:
                    r_found = cand
                    break
        factors = None
        if r_found and r_found % 2 == 0:
            half = pow(a, r_found // 2, big_n)
            if half != big_n - 1:
                f1, f2 = math.gcd(half - 1, big_n), math.gcd(half + 1, big_n)
                nontrivial = sorted({f for f in (f1, f2) if 1 < f < big_n})
                if nontrivial:
                    factors = nontrivial
                    success += p
                    factors_found.update(nontrivial)
        rows.append(
            {
                "y": y,
                "bits": format(y, f"0{t}b"),
                "p": p,
                "phase": y / 2**t,
                "fraction": f"{frac.numerator}/{frac.denominator}",
                "r": r_found or None,
                "factors": factors,
                "convergents": _convergents(y, t, big_n),
            }
        )
    rows.sort(key=lambda row: -row["p"])
    pair = sorted(factors_found)
    summary = (
        f"{big_n} = {pair[0]} × {big_n // pair[0]}" if pair else "Ningún resultado dio un factor no trivial"
    )
    return {
        "kind": "shor",
        "title": "Algoritmo de Shor",
        "N": big_n,
        "a": a,
        "t": t,
        "true_order": true_r,
        "success_probability": success,
        "factors": pair,
        "rows": rows[:24],
        "source": source,
        "peaks_expected": true_r,
        "summary": f"{summary} · orden real de {a} mod {big_n}: r = {true_r} · "
        f"probabilidad de éxito por ejecución: {success:.3f}",
    }
