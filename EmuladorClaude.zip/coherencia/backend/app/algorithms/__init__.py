"""Registro de algoritmos precargados y de sus análisis."""

from __future__ import annotations

from typing import Callable

from .basic import (
    analyze_bv,
    analyze_deutsch,
    analyze_grover,
    analyze_qft,
    analyze_teleportation,
    build_bell,
    build_bv,
    build_deutsch,
    build_ghz,
    build_grover,
    build_qft,
    build_teleportation,
)
from .common import AlgorithmError
from .rqc import analyze_rqc, build_rqc
from .shor import analyze_shor, build_shor

PRESETS: list[dict] = [
    {
        "key": "teleportation",
        "name": "Teleportación cuántica",
        "summary": "Envía el estado de q0 a q2 con un par de Bell, dos bits clásicos y correcciones dinámicas.",
        "tags": ["3 cúbits", "control clásico", "dinámico"],
        "params": [
            {"key": "theta", "label": "θ del estado a enviar", "type": "number", "default": 1.1, "min": 0, "max": 3.1416, "step": 0.01},
            {"key": "phi", "label": "φ del estado a enviar", "type": "number", "default": 0.7, "min": -3.1416, "max": 3.1416, "step": 0.01},
        ],
    },
    {
        "key": "deutsch",
        "name": "Algoritmo de Deutsch",
        "summary": "Decide con una sola consulta si una función de un bit es constante o balanceada.",
        "tags": ["2 cúbits", "oráculo"],
        "params": [
            {"key": "oracle", "label": "Oráculo", "type": "select", "default": "balanced_id",
             "options": [
                 {"value": "const0", "label": "Constante f(x)=0"},
                 {"value": "const1", "label": "Constante f(x)=1"},
                 {"value": "balanced_id", "label": "Balanceada f(x)=x"},
                 {"value": "balanced_not", "label": "Balanceada f(x)=¬x"},
             ]},
        ],
    },
    {
        "key": "shor",
        "name": "Algoritmo de Shor",
        "summary": "Factoriza N encontrando el periodo de aˣ mod N con estimación de fase y QFT inversa.",
        "tags": ["multiplicación modular", "QFT†", "fracciones continuas"],
        "params": [
            {"key": "N", "label": "N (impar compuesto)", "type": "select", "default": "15",
             "options": [{"value": str(v), "label": str(v)} for v in (15, 21, 33, 35, 39, 51, 55, 57)]},
            {"key": "a", "label": "Base a (coprima con N)", "type": "integer", "default": 7, "min": 2, "max": 254},
            {"key": "t", "label": "Cúbits de conteo t", "type": "integer", "default": 8, "min": 2, "max": 14},
        ],
    },
    {
        "key": "rqc",
        "name": "Circuito cuántico aleatorio",
        "summary": "Muestreo de circuitos aleatorios con √X, √Y, √W y entrelazadores; XEB y Porter–Thomas.",
        "tags": ["ventaja cuántica", "XEB", "ruido"],
        "params": [
            {"key": "n", "label": "Cúbits", "type": "integer", "default": 8, "min": 2, "max": 20},
            {"key": "cycles", "label": "Ciclos", "type": "integer", "default": 10, "min": 1, "max": 40},
            {"key": "seed", "label": "Semilla", "type": "integer", "default": 7, "min": 0, "max": 99999},
            {"key": "topology", "label": "Topología", "type": "select", "default": "1d",
             "options": [{"value": "1d", "label": "Cadena 1D"}, {"value": "2d", "label": "Rejilla 2D"}]},
            {"key": "rows", "label": "Filas (2D)", "type": "integer", "default": 2, "min": 1, "max": 10},
            {"key": "entangler", "label": "Entrelazador", "type": "select", "default": "cz",
             "options": [{"value": "cz", "label": "CZ"}, {"value": "iswap", "label": "iSWAP"},
                         {"value": "fsim", "label": "fSim(π/2, π/6)"}]},
        ],
    },
    {
        "key": "grover",
        "name": "Búsqueda de Grover",
        "summary": "Amplifica la amplitud de un estado marcado; las iteraciones forman un ciclo for.",
        "tags": ["ciclo for", "multicontrol"],
        "params": [
            {"key": "n", "label": "Cúbits", "type": "integer", "default": 3, "min": 2, "max": 8},
            {"key": "marked", "label": "Estado marcado", "type": "bits", "default": "101"},
        ],
    },
    {
        "key": "bv",
        "name": "Bernstein–Vazirani",
        "summary": "Recupera una cadena secreta de n bits con una única consulta al oráculo.",
        "tags": ["oráculo", "n+1 cúbits"],
        "params": [{"key": "secret", "label": "Cadena secreta", "type": "bits", "default": "1011"}],
    },
    {
        "key": "qft",
        "name": "Transformada cuántica de Fourier",
        "summary": "Aplica la QFT a un estado de la base y deja ver las fases que codifica.",
        "tags": ["fases", "bloque QFT"],
        "params": [
            {"key": "n", "label": "Cúbits", "type": "integer", "default": 3, "min": 1, "max": 8},
            {"key": "x", "label": "Entero de entrada x", "type": "integer", "default": 5, "min": 0, "max": 255},
        ],
    },
    {
        "key": "bell",
        "name": "Estado de Bell",
        "summary": "El ejemplo mínimo de entrelazamiento: H seguido de CNOT.",
        "tags": ["2 cúbits", "entrelazamiento"],
        "params": [],
    },
    {
        "key": "ghz",
        "name": "Estado GHZ",
        "summary": "Entrelazamiento de n cúbits con una cadena de CNOT.",
        "tags": ["n cúbits"],
        "params": [{"key": "n", "label": "Cúbits", "type": "integer", "default": 4, "min": 2, "max": 16}],
    },
]

_BUILDERS: dict[str, Callable[..., dict]] = {
    "teleportation": build_teleportation,
    "deutsch": build_deutsch,
    "grover": build_grover,
    "bv": build_bv,
    "qft": build_qft,
    "bell": build_bell,
    "ghz": build_ghz,
}

_ANALYZERS: dict[str, Callable[[dict], dict | None]] = {
    "teleportation": analyze_teleportation,
    "deutsch": analyze_deutsch,
    "grover": analyze_grover,
    "bv": analyze_bv,
    "qft": analyze_qft,
    "shor": analyze_shor,
    "rqc": analyze_rqc,
}


def build_preset(key: str, params: dict, max_qubits: int = 22) -> dict:
    if key == "shor":
        return build_shor(params, max_qubits)
    if key == "rqc":
        return build_rqc(params, max_qubits)
    builder = _BUILDERS.get(key)
    if builder is None:
        raise AlgorithmError(f"Algoritmo desconocido «{key}»")
    return builder(params)


def analyze_algorithm(name: str, ctx: dict) -> dict | None:
    fn = _ANALYZERS.get(name)
    return fn(ctx) if fn else None


__all__ = ["PRESETS", "AlgorithmError", "build_preset", "analyze_algorithm"]
