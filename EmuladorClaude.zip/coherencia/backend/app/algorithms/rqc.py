"""Circuitos cuánticos aleatorios (RQC) al estilo de los experimentos de ventaja cuántica.

Cada ciclo aplica una compuerta aleatoria de {√X, √Y, √W} a cada cúbit (sin repetir
la del ciclo anterior en el mismo cúbit) y una capa de entrelazadores (CZ, iSWAP o
fSim(π/2, π/6)) según un patrón 1D alternado o el patrón ABCDCDAB de una rejilla 2D.

El análisis compara las muestras con la distribución ideal mediante la
*entropía cruzada lineal* (XEB):  F = 2ⁿ·⟨p_ideal(x)⟩_muestras − 1, que vale ≈ 1
para un muestreador perfecto (estadística de Porter–Thomas) y ≈ 0 para ruido puro.
"""

from __future__ import annotations

import math
import random

import numpy as np

from ..core.deferred import defer_measurements
from .common import AlgorithmError, CircuitBuilder, int_param, register_distribution

SINGLE = ("sx", "sy", "sw")


def _pack_columns(pairs: list[tuple[int, int]]) -> list[list[tuple[int, int]]]:
    """Reparte pares en sub-columnas de modo que sus intervalos verticales no se crucen."""
    columns: list[list[tuple[int, int]]] = []
    spans: list[list[tuple[int, int]]] = []
    for a, b in sorted(pairs, key=lambda p: (min(p), max(p))):
        lo, hi = min(a, b), max(a, b)
        for col, used in zip(columns, spans):
            if all(hi < u_lo or lo > u_hi for u_lo, u_hi in used):
                col.append((a, b))
                used.append((lo, hi))
                break
        else:
            columns.append([(a, b)])
            spans.append([(lo, hi)])
    return columns


def _patterns_2d(rows: int, cols: int) -> list[list[tuple[int, int]]]:
    def q(r: int, c: int) -> int:
        return r * cols + c

    a = [(q(r, c), q(r, c + 1)) for r in range(rows) for c in range(0, cols - 1, 2)]
    b = [(q(r, c), q(r, c + 1)) for r in range(rows) for c in range(1, cols - 1, 2)]
    c_ = [(q(r, c), q(r + 1, c)) for r in range(0, rows - 1, 2) for c in range(cols)]
    d = [(q(r, c), q(r + 1, c)) for r in range(1, rows - 1, 2) for c in range(cols)]
    seq = [a, b, c_, d, c_, d, a, b]  # ABCDCDAB
    return [p for p in seq if p] or [a]


def build_rqc(params: dict, max_qubits: int = 22) -> dict:
    n = int_param(params, "n", 6, 2, max_qubits)
    cycles = int_param(params, "cycles", 8, 1, 40)
    seed = int_param(params, "seed", 7, 0, 2**31 - 1)
    topology = str(params.get("topology", "1d"))
    entangler = str(params.get("entangler", "cz"))
    if entangler not in ("cz", "iswap", "fsim"):
        raise AlgorithmError("El entrelazador debe ser cz, iswap o fsim")
    rows = cols = 0
    if topology == "2d":
        rows = int_param(params, "rows", max(1, int(math.isqrt(n))), 1, n)
        if n % rows:
            raise AlgorithmError(f"Con rejilla 2D, n = {n} debe ser múltiplo del número de filas ({rows})")
        cols = n // rows
        patterns = _patterns_2d(rows, cols)
    elif topology == "1d":
        even = [(q, q + 1) for q in range(0, n - 1, 2)]
        odd = [(q, q + 1) for q in range(1, n - 1, 2)]
        patterns = [p for p in (even, odd) if p]
    else:
        raise AlgorithmError("La topología debe ser 1d o 2d")

    rng = random.Random(seed)
    b = CircuitBuilder(n, n, f"Circuito aleatorio · {n} cúbits · {cycles} ciclos")
    last = [None] * n
    col = 0

    def single_layer(c: int) -> None:
        for q in range(n):
            choices = [g for g in SINGLE if g != last[q]]
            g = rng.choice(choices)
            last[q] = g
            b.gate(c, g, [q])

    for k in range(cycles):
        single_layer(col)
        col += 1
        pairs = patterns[k % len(patterns)]
        for sub in _pack_columns(pairs):
            for qa, qb in sub:
                if entangler == "cz":
                    b.gate(col, "z", [qb], controls=[qa])
                elif entangler == "iswap":
                    b.gate(col, "iswap", [qa, qb])
                else:
                    b.gate(col, "fsim", [qa, qb], params=["pi/2", "pi/6"])
            col += 1
    single_layer(col)
    col += 1
    for q in range(n):
        b.measure(col, q, q)
    return b.build(
        {"algorithm": "rqc", "n": n, "cycles": cycles, "seed": seed, "topology": topology, "entangler": entangler,
         "rows": rows, "cols": cols},
        description=(
            "Circuito aleatorio con compuertas {√X, √Y, √W} y entrelazadores en patrón de ladrillo. Su distribución "
            "de salida sigue la ley de Porter–Thomas; la XEB lineal mide cuán bien se muestrea."
        ),
    )


def analyze_rqc(ctx: dict) -> dict | None:
    circuit = ctx["circuit"]
    n = circuit.num_qubits
    if n > 20:
        return {"kind": "rqc", "title": "Circuito aleatorio", "summary": "El análisis XEB se limita a 20 cúbits."}
    engine = ctx["engine"]
    prog = ctx["program"]
    deferred = defer_measurements(prog, 0.0)  # programa ideal: las mediciones finales se descartan
    psi, _ = engine.statevector(deferred.ops, deferred.num_total)
    p_ideal = np.abs(psi) ** 2
    if deferred.num_total > n:
        p_ideal = p_ideal.reshape(-1, 1 << n).sum(axis=0)
    dim = 1 << n
    ideal_xeb = float(dim * np.sum(p_ideal**2) - 1)

    # Distribución observada sobre los bits clásicos (c_k ← q_k).
    dist, source = register_distribution(ctx)
    sampled_xeb = None
    if dist is not None and dist.size == dim:
        sampled_xeb = float(dim * np.sum(dist * p_ideal) - 1)
    elif ctx.get("view") is not None:
        dist = ctx["view"].probs
        source = "exacta (cúbits)"
        sampled_xeb = float(dim * np.sum(dist * p_ideal) - 1)

    # Histograma de Porter–Thomas de x = 2ⁿ·p_ideal.
    x = dim * p_ideal
    edges = np.linspace(0, 6, 25)
    hist, _ = np.histogram(np.clip(x, 0, 6 - 1e-9), bins=edges)
    width = edges[1] - edges[0]
    bins = []
    for i in range(len(hist)):
        mid = (edges[i] + edges[i + 1]) / 2
        bins.append({"x0": float(edges[i]), "x1": float(edges[i + 1]), "density": float(hist[i] / (dim * width)),
                     "porter_thomas": float(math.exp(-mid))})
    fidelity = None
    if sampled_xeb is not None and ideal_xeb > 1e-9:
        fidelity = max(-1.0, min(1.5, sampled_xeb / ideal_xeb))
    shots = ctx.get("shots")
    stderr = None
    if shots is not None:
        # Desviación estándar de la media de 2ⁿ·p_ideal sobre las muestras.
        stderr = float(math.sqrt(max(np.sum(p_ideal * (dim * p_ideal) ** 2) - (ideal_xeb + 1) ** 2, 0)) /
                       math.sqrt(max(shots["shots"], 1)))
    return {
        "kind": "rqc",
        "title": "Circuito aleatorio (XEB)",
        "ideal_xeb": ideal_xeb,
        "sampled_xeb": sampled_xeb,
        "fidelity_estimate": fidelity,
        "xeb_stderr": stderr,
        "source": source,
        "porter_thomas": bins,
        "summary": (
            f"XEB lineal {sampled_xeb:.3f} (ideal {ideal_xeb:.3f})" if sampled_xeb is not None else
            f"XEB ideal {ideal_xeb:.3f}"
        ),
    }
