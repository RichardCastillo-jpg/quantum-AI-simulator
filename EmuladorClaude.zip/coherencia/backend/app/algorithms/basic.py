"""Algoritmos didácticos: Bell, GHZ, teleportación, Deutsch, Grover, Bernstein–Vazirani y QFT."""

from __future__ import annotations

import math

import numpy as np

from .common import AlgorithmError, CircuitBuilder, float_param, int_param, register_distribution


# --- Bell y GHZ -----------------------------------------------------------------------
def build_bell(params: dict) -> dict:
    b = CircuitBuilder(2, 2, "Estado de Bell |Φ⁺⟩")
    b.gate(0, "h", [0])
    b.gate(1, "x", [1], controls=[0])
    b.measure(2, 0, 0)
    b.measure(2, 1, 1)
    return b.build(
        {"algorithm": "bell"},
        description="Hadamard + CNOT producen (|00⟩+|11⟩)/√2: los dos cúbits quedan perfectamente correlacionados.",
    )


def build_ghz(params: dict) -> dict:
    n = int_param(params, "n", 3, 2, 16)
    b = CircuitBuilder(n, n, f"Estado GHZ de {n} cúbits")
    b.gate(0, "h", [0])
    for q in range(1, n):
        b.gate(q, "x", [q], controls=[q - 1])
    for q in range(n):
        b.measure(n, q, q)
    return b.build({"algorithm": "ghz", "n": n},
                   description="Generaliza el estado de Bell: (|0…0⟩+|1…1⟩)/√2 con una cadena de CNOT.")


# --- Teleportación -----------------------------------------------------------------------
def build_teleportation(params: dict) -> dict:
    theta = float_param(params, "theta", 1.1)
    phi = float_param(params, "phi", 0.7)
    b = CircuitBuilder(3, 2, "Teleportación cuántica")
    b.gate(0, "u", [0], params=[round(theta, 6), round(phi, 6), 0], label="ψ")
    b.gate(1, "h", [1])
    b.gate(2, "x", [2], controls=[1])
    b.gate(3, "x", [1], controls=[0])
    b.gate(4, "h", [0])
    b.measure(5, 0, 0)
    b.measure(5, 1, 1)
    b.gate(6, "x", [2], condition=[(1, 1)])
    b.gate(7, "z", [2], condition=[(0, 1)])
    return b.build(
        {"algorithm": "teleportation", "theta": theta, "phi": phi},
        clbit_labels=["m0", "m1"],
        description=(
            "q0 se prepara en |ψ⟩ = U(θ, φ)|0⟩. Un par de Bell entre q1 y q2, una medición de Bell sobre q0 y q1 y "
            "dos correcciones clásicas en tiempo real (X si m1 = 1, Z si m0 = 1) trasladan |ψ⟩ a q2."
        ),
    )


def analyze_teleportation(ctx: dict) -> dict | None:
    meta = ctx["circuit"].meta
    view = ctx.get("view")
    theta, phi = float(meta.get("theta", 0.0)), float(meta.get("phi", 0.0))
    expected = (math.sin(theta) * math.cos(phi), math.sin(theta) * math.sin(phi), math.cos(theta))
    out = {"kind": "teleportation", "title": "Teleportación", "expected_bloch": expected}
    if view is not None and len(view.bloch) >= 3:
        b = view.bloch[2]
        fidelity = (1 + expected[0] * b["x"] + expected[1] * b["y"] + expected[2] * b["z"]) / 2
        out["received_bloch"] = (b["x"], b["y"], b["z"])
        out["fidelity"] = max(0.0, min(1.0, fidelity))
        out["summary"] = (
            f"Fidelidad entre el estado enviado y el recibido en q2: {out['fidelity']:.4f}"
        )
    dist, source = register_distribution(ctx)
    if dist is not None and dist.size >= 4:
        out["bell_outcomes"] = [{"state": format(i, "02b"), "p": float(dist[i])} for i in range(4)]
        out["bell_source"] = source
    return out


# --- Deutsch ------------------------------------------------------------------------------
DEUTSCH_ORACLES = {
    "const0": ("Constante f(x) = 0", "constante"),
    "const1": ("Constante f(x) = 1", "constante"),
    "balanced_id": ("Balanceada f(x) = x", "balanceada"),
    "balanced_not": ("Balanceada f(x) = ¬x", "balanceada"),
}


def build_deutsch(params: dict) -> dict:
    oracle = str(params.get("oracle", "balanced_id"))
    if oracle not in DEUTSCH_ORACLES:
        raise AlgorithmError(f"Oráculo desconocido «{oracle}»")
    b = CircuitBuilder(2, 1, f"Algoritmo de Deutsch · {DEUTSCH_ORACLES[oracle][0]}")
    b.gate(0, "x", [1])
    b.gate(1, "h", [0])
    b.gate(1, "h", [1])
    col = 2
    if oracle == "const0":
        b.gate(col, "id", [1], label="U_f")
        col += 1
    elif oracle == "const1":
        b.gate(col, "x", [1], label="U_f")
        col += 1
    elif oracle == "balanced_id":
        b.gate(col, "x", [1], controls=[0])
        col += 1
    else:
        b.gate(col, "x", [1], controls=[0])
        b.gate(col + 1, "x", [1])
        col += 2
    b.gate(col, "h", [0])
    b.measure(col + 1, 0, 0)
    return b.build(
        {"algorithm": "deutsch", "oracle": oracle},
        qubit_labels=["x", "y"],
        description=(
            "Con una sola evaluación del oráculo U_f|x⟩|y⟩ = |x⟩|y⊕f(x)⟩ se decide si f es constante "
            "(se mide 0) o balanceada (se mide 1)."
        ),
    )


def analyze_deutsch(ctx: dict) -> dict | None:
    meta = ctx["circuit"].meta
    oracle = meta.get("oracle", "balanced_id")
    dist, source = register_distribution(ctx)
    if dist is None:
        return None
    p1 = float(dist[1]) if dist.size > 1 else 0.0
    verdict = "balanceada" if p1 > 0.5 else "constante"
    expected = DEUTSCH_ORACLES.get(oracle, ("", ""))[1]
    return {
        "kind": "deutsch",
        "title": "Algoritmo de Deutsch",
        "p_one": p1,
        "verdict": verdict,
        "expected": expected,
        "correct": verdict == expected,
        "source": source,
        "summary": f"Se mide 1 con probabilidad {p1:.3f}: f es {verdict} (oráculo real: {expected}).",
    }


# --- Grover ------------------------------------------------------------------------------
def build_grover(params: dict) -> dict:
    n = int_param(params, "n", 3, 2, 8)
    marked = str(params.get("marked", "1" * n))
    if len(marked) != n or any(ch not in "01" for ch in marked):
        raise AlgorithmError(f"El estado marcado debe tener {n} bits")
    optimal = max(1, int(math.floor(math.pi / 4 * math.sqrt(2**n))))
    iterations = int_param(params, "iterations", optimal, 1, 64)
    b = CircuitBuilder(n, n, f"Búsqueda de Grover · |{marked}⟩")
    for q in range(n):
        b.gate(0, "h", [q])
    # Oráculo de fase: invierte el signo de |marked⟩ con un único Z multicontrolado.
    bits = {q: marked[n - 1 - q] for q in range(n)}
    ones = [q for q in range(n) if bits[q] == "1"]
    col = 1
    start = col
    if ones:
        target = ones[-1]
        controls = [q for q in ones if q != target]
        anti = [q for q in range(n) if bits[q] == "0"]
        b.gate(col, "z", [target], controls=controls, anticontrols=anti, label="oráculo")
        col += 1
    else:
        b.gate(col, "x", [n - 1])
        b.gate(col + 1, "z", [n - 1], anticontrols=list(range(n - 1)), label="oráculo")
        b.gate(col + 2, "x", [n - 1])
        col += 3
    # Difusor: H X (MCZ) X H.
    for q in range(n):
        b.gate(col, "h", [q])
        b.gate(col + 1, "x", [q])
    b.gate(col + 2, "z", [n - 1], controls=list(range(n - 1)))
    for q in range(n):
        b.gate(col + 3, "x", [q])
        b.gate(col + 4, "h", [q])
    end = col + 4
    if iterations > 1:
        b.loop(start, end, iterations, var="k", label="iteración de Grover")
    for q in range(n):
        b.measure(end + 1, q, q)
    return b.build(
        {"algorithm": "grover", "marked": marked, "iterations": iterations, "optimal": optimal},
        description=(
            f"Amplificación de amplitud: {iterations} iteración(es) de oráculo + difusor (ciclo for) concentran "
            f"la probabilidad en |{marked}⟩. Óptimo ≈ π/4·√(2ⁿ) = {optimal}."
        ),
    )


def analyze_grover(ctx: dict) -> dict | None:
    meta = ctx["circuit"].meta
    marked = meta.get("marked")
    n = ctx["circuit"].num_qubits
    k = int(meta.get("iterations", 1))
    dist, source = register_distribution(ctx)
    if dist is None or marked is None:
        return None
    p = float(dist[int(marked, 2)])
    theta = math.asin(1 / math.sqrt(2**n))
    theory = math.sin((2 * k + 1) * theta) ** 2
    return {
        "kind": "grover",
        "title": "Búsqueda de Grover",
        "marked": marked,
        "p_marked": p,
        "p_theory": theory,
        "iterations": k,
        "source": source,
        "summary": f"P(|{marked}⟩) = {p:.4f} · teoría sin²((2k+1)θ) = {theory:.4f}",
    }


# --- Bernstein–Vazirani ------------------------------------------------------------------
def build_bv(params: dict) -> dict:
    secret = str(params.get("secret", "1011"))
    if not secret or len(secret) > 12 or any(ch not in "01" for ch in secret):
        raise AlgorithmError("La cadena secreta debe tener entre 1 y 12 bits")
    n = len(secret)
    b = CircuitBuilder(n + 1, n, f"Bernstein–Vazirani · s = {secret}")
    anc = n
    b.gate(0, "x", [anc])
    for q in range(n + 1):
        b.gate(1, "h", [q])
    col = 2
    for q in range(n):
        if secret[n - 1 - q] == "1":
            b.gate(col, "x", [anc], controls=[q])
            col += 1
    if col == 2:
        b.gate(col, "id", [anc])
        col += 1
    for q in range(n):
        b.gate(col, "h", [q])
    for q in range(n):
        b.measure(col + 1, q, q)
    return b.build({"algorithm": "bv", "secret": secret},
                   description="Una sola consulta al oráculo f(x) = s·x (mod 2) revela la cadena secreta s completa.")


def analyze_bv(ctx: dict) -> dict | None:
    secret = ctx["circuit"].meta.get("secret")
    dist, source = register_distribution(ctx)
    if dist is None or secret is None:
        return None
    best = int(np.argmax(dist))
    found = format(best, f"0{len(secret)}b")
    return {"kind": "bv", "title": "Bernstein–Vazirani", "secret": secret, "found": found,
            "p": float(dist[best]), "correct": found == secret, "source": source,
            "summary": f"Cadena recuperada {found} con probabilidad {float(dist[best]):.3f}"}


# --- QFT -----------------------------------------------------------------------------------
def build_qft(params: dict) -> dict:
    n = int_param(params, "n", 3, 1, 10)
    x = int_param(params, "x", 5 % (2**n), 0, 2**n - 1)
    b = CircuitBuilder(n, 0, f"QFT de |{x}⟩ con {n} cúbits")
    b.gate(0, "qft", list(range(n)))
    return b.build(
        {"algorithm": "qft", "n": n, "x": x},
        initial_state=format(x, f"0{n}b"),
        description=(
            "La transformada cuántica de Fourier lleva |x⟩ a una superposición uniforme cuyas fases crecen como "
            "2π·x·y/2ⁿ: mira el color (fase) de cada amplitud."
        ),
    )


def analyze_qft(ctx: dict) -> dict | None:
    meta = ctx["circuit"].meta
    view = ctx.get("view")
    if view is None or view.psi is None:
        return None
    n, x = int(meta["n"]), int(meta["x"])
    dim = 2**n
    psi = view.psi
    expected = np.exp(2j * np.pi * x * np.arange(dim) / dim) / math.sqrt(dim)
    overlap = abs(np.vdot(expected, psi)) ** 2
    return {"kind": "qft", "title": "Transformada de Fourier", "fidelity_with_dft": float(overlap),
            "phase_step": 2 * math.pi * x / dim,
            "summary": f"Fidelidad con la DFT teórica: {overlap:.6f} · paso de fase 2π·{x}/{dim}"}
