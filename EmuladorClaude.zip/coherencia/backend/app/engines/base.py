"""Interfaz común de los motores de simulación."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

import numpy as np

from ..core.ir import Prim, Program


@dataclass
class SampleResult:
    counts: dict[str, int]
    memory: list[str] | None = None
    method: str = "statevector"
    info: dict = field(default_factory=dict)


class Engine(Protocol):
    name: str
    version: str

    def statevector(self, ops: list[Prim], n_total: int, num_steps: int = 0, snapshots: bool = False
                    ) -> tuple[np.ndarray, dict[int, np.ndarray]]:
        """Simula un programa unitario (sin mediciones). Devuelve ψ y, opcionalmente,
        instantáneas tras cada paso (clave −1 = estado inicial)."""

    def density_matrix(self, ops: list[Prim], n_total: int, num_steps: int = 0, snapshots: bool = False
                       ) -> tuple[np.ndarray, dict[int, np.ndarray]]:
        """Igual que ``statevector`` pero admite canales de Kraus (estado mixto exacto)."""

    def sample(self, prog: Program, shots: int, seed: int | None, readout: float, memory: bool,
               max_density_qubits: int) -> SampleResult:
        """Ejecuta el circuito dinámico con mediciones reales y devuelve los conteos."""


def snapshot_points(ops: list[Prim], num_steps: int) -> list[tuple[int, list[int]]]:
    """Para cada posición de la lista de operaciones, los pasos que terminan justo antes.

    Devuelve una lista de (índice_de_operación, [pasos a guardar antes de ella]); el índice
    ``len(ops)`` representa el final del programa. El paso −1 es el estado inicial.
    """
    points: list[tuple[int, list[int]]] = []
    next_snap = -1
    for i, p in enumerate(ops):
        if p.step < 0:
            continue
        pending = []
        while next_snap < p.step:
            pending.append(next_snap)
            next_snap += 1
        if pending:
            points.append((i, pending))
    pending = []
    while next_snap < num_steps:
        pending.append(next_snap)
        next_snap += 1
    if pending:
        points.append((len(ops), pending))
    return points
