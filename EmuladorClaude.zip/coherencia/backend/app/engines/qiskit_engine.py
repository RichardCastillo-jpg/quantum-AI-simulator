"""Motor principal: traduce la IR a ``QuantumCircuit`` de Qiskit y ejecuta en Qiskit Aer.

Decisiones de traducción:

* Las compuertas con equivalente nativo en Aer se emiten como tales (``cx``,
  ``ccx``, ``mcx``, ``cp``, ``mcphase``, ``cswap``…); el resto se emite como
  ``UnitaryGate`` con la matriz exacta (incluida la versión controlada), así el
  circuito nunca necesita transpilarse y la semántica es idéntica a la del motor
  de referencia.
* Los anticontroles (control sobre |0⟩) se implementan rodeando el control con X.
* El control clásico se traduce a bloques ``if_test`` anidados (circuitos dinámicos).
* El ruido llega como instrucciones ``kraus`` explícitas; el error de lectura se
  modela con ``ReadoutError`` de Aer para que afecte también al control clásico.
"""

from __future__ import annotations

import math

import numpy as np

from ..core.gates import controlled_matrix
from ..core.ir import Prim, Program
from .base import SampleResult, snapshot_points

try:  # pragma: no cover - depende del entorno
    import qiskit
    from qiskit import QuantumCircuit
    from qiskit.circuit.library import (
        CCXGate,
        CPhaseGate,
        CSwapGate,
        CSXGate,
        CXGate,
        CYGate,
        CZGate,
        HGate,
        IGate,
        MCPhaseGate,
        MCXGate,
        PhaseGate,
        RXGate,
        RXXGate,
        RYGate,
        RYYGate,
        RZGate,
        RZZGate,
        SdgGate,
        SGate,
        SwapGate,
        SXdgGate,
        SXGate,
        TdgGate,
        TGate,
        UGate,
        UnitaryGate,
        XGate,
        YGate,
        ZGate,
    )
    from qiskit.quantum_info import Kraus
    import qiskit_aer
    from qiskit_aer import AerSimulator
    from qiskit_aer.noise import NoiseModel, ReadoutError

    QISKIT_AVAILABLE = True
    QISKIT_IMPORT_ERROR = None
except Exception as exc:  # pragma: no cover
    QISKIT_AVAILABLE = False
    QISKIT_IMPORT_ERROR = repr(exc)


_PHASES = {"z": math.pi, "s": math.pi / 2, "sdg": -math.pi / 2, "t": math.pi / 4, "tdg": -math.pi / 4}


def _single_native(name: str, params: tuple[float, ...]):
    table = {
        "id": lambda: IGate(),
        "x": lambda: XGate(),
        "y": lambda: YGate(),
        "z": lambda: ZGate(),
        "h": lambda: HGate(),
        "s": lambda: SGate(),
        "sdg": lambda: SdgGate(),
        "t": lambda: TGate(),
        "tdg": lambda: TdgGate(),
        "sx": lambda: SXGate(),
        "sxdg": lambda: SXdgGate(),
        "p": lambda: PhaseGate(params[0]),
        "rx": lambda: RXGate(params[0]),
        "ry": lambda: RYGate(params[0]),
        "rz": lambda: RZGate(params[0]),
        "u": lambda: UGate(*params),
        "swap": lambda: SwapGate(),
        "rxx": lambda: RXXGate(params[0]),
        "ryy": lambda: RYYGate(params[0]),
        "rzz": lambda: RZZGate(params[0]),
    }
    maker = table.get(name)
    return maker() if maker else None


class QiskitEngine:
    name = "Qiskit Aer"

    def __init__(self) -> None:
        if not QISKIT_AVAILABLE:
            raise RuntimeError(f"Qiskit/Qiskit Aer no están disponibles: {QISKIT_IMPORT_ERROR}")
        self.version = f"qiskit {qiskit.__version__} · qiskit-aer {qiskit_aer.__version__}"

    # -- traducción -------------------------------------------------------------------
    def _gate(self, p: Prim, ctrls: list[int], force: bool = False):
        k = len(ctrls)
        name = p.name
        targets = list(p.qubits)
        label = p.label if p.label and p.label not in ("prep",) else None
        if not force:
            if name == "id":
                return (IGate(), targets) if k == 0 else (None, [])
            if name == "x":
                if k == 0:
                    return XGate(), targets
                if k == 1:
                    return CXGate(), ctrls + targets
                if k == 2:
                    return CCXGate(), ctrls + targets
                return MCXGate(k), ctrls + targets
            if name in _PHASES or name == "p":
                lam = _PHASES.get(name, p.params[0] if p.params else 0.0)
                if k == 0:
                    return _single_native(name, p.params), targets
                if k == 1:
                    return (CZGate() if name == "z" else CPhaseGate(lam)), ctrls + targets
                return MCPhaseGate(lam, k), ctrls + targets
            if k == 1 and name == "y":
                return CYGate(), ctrls + targets
            if k == 1 and name == "sx":
                return CSXGate(), ctrls + targets
            if k == 1 and name == "swap":
                return CSwapGate(), ctrls + targets
            if k == 0:
                native = _single_native(name, p.params)
                if native is not None:
                    return native, targets
        mat = controlled_matrix(p.base_matrix(), k)
        return UnitaryGate(mat, label=label or name), ctrls + targets

    def _append_gate(self, qc, p: Prim, force: bool = False) -> None:
        anti = list(p.anticontrols)
        for q in anti:
            qc.x(q)
        gate, qargs = self._gate(p, list(p.controls) + anti, force)
        if gate is not None:
            qc.append(gate, qargs)
        for q in anti:
            qc.x(q)

    def _append_plain(self, qc, p: Prim, force: bool = False) -> None:
        if p.kind == "gate":
            self._append_gate(qc, p, force)
        elif p.kind == "measure":
            qc.measure(p.qubits[0], p.clbit)
        elif p.kind == "reset":
            qc.reset(p.qubits[0])
        elif p.kind == "barrier":
            qc.barrier(*p.qubits)
        elif p.kind == "channel":
            qc.append(Kraus([np.asarray(k) for k in p.kraus]).to_instruction(), list(p.qubits))
        else:  # pragma: no cover
            raise ValueError(f"Operación desconocida {p.kind}")

    def _emit_conditional(self, qc, cond, group: list[Prim], force: bool = False) -> None:
        if not cond:
            for p in group:
                self._append_plain(qc, p, force)
            return
        (clbit, value), rest = cond[0], cond[1:]
        with qc.if_test((qc.clbits[clbit], value)):
            self._emit_conditional(qc, rest, group, force)

    def build_circuit(self, ops: list[Prim], n_total: int, n_clbits: int, saves: dict[int, list[int]] | None = None,
                      save_kind: str = "statevector", final_label: str | None = None, force_unitary: bool = False):
        qc = QuantumCircuit(n_total, n_clbits) if n_clbits else QuantumCircuit(n_total)
        saves = saves or {}

        def save(labels: list[int]) -> None:
            for s in labels:
                lbl = f"step_{s}" if s >= 0 else "step_init"
                if save_kind == "density":
                    qc.save_density_matrix(label=lbl)
                else:
                    qc.save_statevector(label=lbl)

        i = 0
        while i < len(ops):
            if i in saves:
                save(saves[i])
            p = ops[i]
            if p.condition:
                group = [p]
                cond_bits = {c for c, _ in p.condition}
                written = {p.clbit} if p.kind == "measure" else set()
                j = i + 1
                while (
                    j < len(ops)
                    and j not in saves
                    and ops[j].condition == p.condition
                    and not (written & cond_bits)
                ):
                    if ops[j].kind == "measure":
                        written.add(ops[j].clbit)
                    group.append(ops[j])
                    j += 1
                self._emit_conditional(qc, list(p.condition), group, force_unitary)
                i = j
                continue
            self._append_plain(qc, p, force_unitary)
            i += 1
        if len(ops) in saves:
            save(saves[len(ops)])
        if final_label:
            if save_kind == "density":
                qc.save_density_matrix(label=final_label)
            else:
                qc.save_statevector(label=final_label)
        return qc

    # -- ejecución --------------------------------------------------------------------
    def _run(self, qc, **kwargs):
        method = kwargs.pop("method")
        noise_model = kwargs.pop("noise_model", None)
        sim = AerSimulator(method=method, noise_model=noise_model) if noise_model is not None else AerSimulator(method=method)
        result = sim.run(qc, **kwargs).result()
        if not result.success:  # pragma: no cover
            raise RuntimeError(getattr(result, "status", "La simulación de Aer no terminó correctamente"))
        return result

    def _run_with_fallback(self, build, **kwargs):
        try:
            return self._run(build(False), **dict(kwargs))
        except Exception:
            # Red de seguridad: emitir todas las compuertas como matrices unitarias densas.
            return self._run(build(True), **dict(kwargs))

    @staticmethod
    def _as_array(obj) -> np.ndarray:
        return np.asarray(getattr(obj, "data", obj), dtype=complex)

    def statevector(self, ops: list[Prim], n_total: int, num_steps: int = 0, snapshots: bool = False):
        saves = dict(snapshot_points(ops, num_steps)) if snapshots else None
        result = self._run_with_fallback(
            lambda force: self.build_circuit(ops, n_total, 0, saves, "statevector", "final", force),
            method="statevector",
            shots=1,
        )
        data = result.data(0)
        psi = self._as_array(data["final"]).reshape(-1)
        snaps: dict[int, np.ndarray] = {}
        if saves:
            for labels in saves.values():
                for s in labels:
                    key = f"step_{s}" if s >= 0 else "step_init"
                    snaps[s] = self._as_array(data[key]).reshape(-1)
        return psi, snaps

    def density_matrix(self, ops: list[Prim], n_total: int, num_steps: int = 0, snapshots: bool = False):
        saves = dict(snapshot_points(ops, num_steps)) if snapshots else None
        result = self._run_with_fallback(
            lambda force: self.build_circuit(ops, n_total, 0, saves, "density", "final", force),
            method="density_matrix",
            shots=1,
        )
        data = result.data(0)
        dim = 1 << n_total
        rho = self._as_array(data["final"]).reshape(dim, dim)
        snaps: dict[int, np.ndarray] = {}
        if saves:
            for labels in saves.values():
                for s in labels:
                    key = f"step_{s}" if s >= 0 else "step_init"
                    snaps[s] = self._as_array(data[key]).reshape(dim, dim)
        return rho, snaps

    def sample(self, prog: Program, shots: int, seed: int | None, readout: float, memory: bool,
               max_density_qubits: int) -> SampleResult:
        noise_model = None
        if readout > 0:
            noise_model = NoiseModel()
            noise_model.add_all_qubit_readout_error(ReadoutError([[1 - readout, readout], [readout, 1 - readout]]))
        if prog.has_channels and not prog.is_dynamic and prog.num_qubits <= max_density_qubits:
            method = "density_matrix"
        else:
            method = "statevector"
        kwargs = {"method": method, "shots": shots, "memory": memory}
        if seed is not None:
            kwargs["seed_simulator"] = seed
        if noise_model is not None:
            kwargs["noise_model"] = noise_model
        result = self._run_with_fallback(
            lambda force: self.build_circuit(prog.ops, prog.num_qubits, prog.num_clbits, force_unitary=force), **kwargs
        )
        raw = result.get_counts(0)
        counts = {key.replace(" ", ""): int(val) for key, val in raw.items()}
        mem = [s.replace(" ", "") for s in result.get_memory(0)] if memory else None
        return SampleResult(counts, mem, method)

    # -- exportación ------------------------------------------------------------------
    def to_qasm(self, prog: Program) -> dict:
        ops = [p for p in prog.ops if p.kind != "channel"]
        qc = self.build_circuit(ops, prog.num_qubits, prog.num_clbits)
        out: dict[str, str | None] = {"qasm3": None, "qasm2": None, "errors": []}
        try:
            from qiskit import qasm3

            out["qasm3"] = qasm3.dumps(qc)
        except Exception as exc:  # pragma: no cover - depende de la versión
            out["errors"].append(f"OpenQASM 3: {exc}")
        try:
            from qiskit import qasm2

            out["qasm2"] = qasm2.dumps(qc)
        except Exception as exc:  # pragma: no cover
            out["errors"].append(f"OpenQASM 2: {exc}")
        return out
