"""Selección del motor de simulación."""

from __future__ import annotations

import logging
from functools import lru_cache

from .reference import ReferenceEngine

log = logging.getLogger("coherencia.engines")


@lru_cache(maxsize=4)
def get_engine(preferred: str = "qiskit"):
    """Devuelve el motor pedido. Qiskit Aer es el predeterminado; si no puede
    importarse se usa el motor de referencia y se deja constancia en el log."""
    if preferred == "reference":
        return ReferenceEngine()
    try:
        from .qiskit_engine import QiskitEngine

        return QiskitEngine()
    except Exception as exc:  # pragma: no cover - depende del entorno
        log.warning("Qiskit Aer no disponible (%s); se usa el motor de referencia NumPy.", exc)
        return ReferenceEngine()
