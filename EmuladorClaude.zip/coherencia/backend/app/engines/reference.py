"""Motor de referencia en NumPy.

Implementación independiente y deliberadamente directa de la evolución de
estados (vector de estado, matriz densidad y trayectorias con medición). Sirve
para validar el motor de Qiskit Aer en las pruebas y como alternativa ligera
(``QSIM_ENGINE=reference``) cuando Qiskit no está disponible.
"""

from __future__ import annotations

import numpy as np

from ..core.analysis import bitstr, classical_distribution
from ..core.deferred import defer_measurements
from ..core.ir import Prim, Program
from .base import SampleResult, snapshot_points


def apply_matrix(psi: np.ndarray, n: int, u: np.ndarray, targets, controls=(), anticontrols=()) -> np.ndarray:
    """Aplica ``u`` (little-endian sobre ``targets``) con controles a un vector de 2ⁿ amplitudes."""
    targets = list(targets)
    k = len(targets)
    tensor = psi.reshape([2] * n)
    index: list = [slice(None)] * n
    fixed = set()
    for q in controls:
        index[n - 1 - q] = 1
        fixed.add(q)
    for q in anticontrols:
        index[n - 1 - q] = 0
        fixed.add(q)
    sub = tensor[tuple(index)]
    remaining = [q for q in range(n - 1, -1, -1) if q not in fixed]  # orden de ejes de ``sub``
    axis_of = {q: i for i, q in enumerate(remaining)}
    m = len(remaining)
    target_axes = [axis_of[q] for q in reversed(targets)]
    rest = [a for a in range(m) if a not in target_axes]
    perm = rest + target_axes
    moved = np.transpose(sub, perm).reshape(-1, 1 << k)
    moved = moved @ u.T
    moved = moved.reshape([2] * m)
    result = np.transpose(moved, np.argsort(perm))
    out = tensor.copy() if not tensor.flags.writeable else tensor
    out[tuple(index)] = result
    return out.reshape(-1)


def _apply_to_density(rho_vec: np.ndarray, n: int, u: np.ndarray, targets, controls=(), anticontrols=()) -> np.ndarray:
    # ρ vectorizado (fila·2ⁿ + columna): los cúbits n…2n−1 son la fila, 0…n−1 la columna.
    shift = lambda qs: [q + n for q in qs]  # noqa: E731
    v = apply_matrix(rho_vec, 2 * n, u, shift(targets), shift(controls), shift(anticontrols))
    v = apply_matrix(v, 2 * n, u.conj(), list(targets), list(controls), list(anticontrols))
    return v


class ReferenceEngine:
    name = "Referencia NumPy"

    def __init__(self) -> None:
        self.version = np.__version__

    # -- estados exactos ---------------------------------------------------------
    def statevector(self, ops: list[Prim], n_total: int, num_steps: int = 0, snapshots: bool = False):
        psi = np.zeros(1 << n_total, dtype=complex)
        psi[0] = 1.0
        snaps: dict[int, np.ndarray] = {}
        points = dict(snapshot_points(ops, num_steps)) if snapshots else {}
        for i, p in enumerate(ops):
            for s in points.get(i, []):
                snaps[s] = psi.copy()
            if p.kind == "gate":
                psi = apply_matrix(psi, n_total, p.base_matrix(), p.qubits, p.controls, p.anticontrols)
            elif p.kind == "barrier":
                continue
            else:
                raise ValueError(f"Operación «{p.kind}» no admitida en una simulación unitaria")
        for s in points.get(len(ops), []):
            snaps[s] = psi.copy()
        return psi, snaps

    def density_matrix(self, ops: list[Prim], n_total: int, num_steps: int = 0, snapshots: bool = False):
        dim = 1 << n_total
        rho = np.zeros(dim * dim, dtype=complex)
        rho[0] = 1.0
        snaps: dict[int, np.ndarray] = {}
        points = dict(snapshot_points(ops, num_steps)) if snapshots else {}
        for i, p in enumerate(ops):
            for s in points.get(i, []):
                snaps[s] = rho.reshape(dim, dim).copy()
            if p.kind == "gate":
                rho = _apply_to_density(rho, n_total, p.base_matrix(), p.qubits, p.controls, p.anticontrols)
            elif p.kind == "channel":
                acc = np.zeros_like(rho)
                for k in p.kraus:
                    acc += _apply_to_density(rho.copy(), n_total, k, p.qubits)
                rho = acc
            elif p.kind == "barrier":
                continue
            else:
                raise ValueError(f"Operación «{p.kind}» no admitida en una simulación exacta")
        for s in points.get(len(ops), []):
            snaps[s] = rho.reshape(dim, dim).copy()
        return rho.reshape(dim, dim), snaps

    # -- muestreo -------------------------------------------------------------------
    def sample(self, prog: Program, shots: int, seed: int | None, readout: float, memory: bool,
               max_density_qubits: int) -> SampleResult:
        rng = np.random.default_rng(seed)
        m = prog.num_clbits
        if not prog.is_dynamic:
            deferred = defer_measurements(prog, readout)
            if deferred.has_channels:
                if deferred.num_total <= max_density_qubits:
                    rho, _ = self.density_matrix(deferred.ops, deferred.num_total)
                    probs = np.clip(np.real(np.diag(rho)), 0, None)
                    method = "density_matrix"
                else:
                    return self._trajectories(prog, shots, rng, readout, memory)
            else:
                psi, _ = self.statevector(deferred.ops, deferred.num_total)
                probs = np.abs(psi) ** 2
                method = "statevector"
            dist = classical_distribution(probs, deferred.num_total, deferred.clbit_sources, deferred.terminal_readout,
                                          readout)
            if dist is None:
                return self._trajectories(prog, shots, rng, readout, memory)
            dist = dist / dist.sum()
            outcomes = rng.choice(dist.size, size=shots, p=dist)
            counts: dict[str, int] = {}
            values, freq = np.unique(outcomes, return_counts=True)
            for v, f in zip(values, freq):
                counts[bitstr(int(v), m)] = int(f)
            mem = [bitstr(int(v), m) for v in outcomes] if memory else None
            return SampleResult(counts, mem, method)
        return self._trajectories(prog, shots, rng, readout, memory)

    def _trajectories(self, prog: Program, shots: int, rng, readout: float, memory: bool) -> SampleResult:
        n, m = prog.num_qubits, prog.num_clbits
        counts: dict[str, int] = {}
        mem: list[str] = []
        for _ in range(shots):
            psi = np.zeros(1 << n, dtype=complex)
            psi[0] = 1.0
            bits = [0] * m
            for p in prog.ops:
                if p.condition and any(bits[c] != v for c, v in p.condition):
                    continue
                if p.kind == "gate":
                    psi = apply_matrix(psi, n, p.base_matrix(), p.qubits, p.controls, p.anticontrols)
                elif p.kind == "channel":
                    psi = self._sample_kraus(psi, n, p, rng)
                elif p.kind in ("measure", "reset"):
                    q = p.qubits[0]
                    r = psi.reshape(1 << (n - q - 1), 2, 1 << q)
                    p1 = float(np.sum(np.abs(r[:, 1, :]) ** 2))
                    outcome = 1 if rng.random() < p1 else 0
                    if outcome == 1:
                        r[:, 0, :] = 0
                        norm = np.sqrt(p1)
                    else:
                        r[:, 1, :] = 0
                        norm = np.sqrt(max(1 - p1, 1e-300))
                    psi = r.reshape(-1) / norm
                    if p.kind == "measure":
                        recorded = outcome ^ (1 if readout > 0 and rng.random() < readout else 0)
                        bits[p.clbit] = recorded
                    elif outcome == 1:
                        psi = apply_matrix(psi, n, np.array([[0, 1], [1, 0]], dtype=complex), (q,))
            key = "".join(str(bits[c]) for c in range(m - 1, -1, -1))
            counts[key] = counts.get(key, 0) + 1
            if memory:
                mem.append(key)
        return SampleResult(counts, mem if memory else None, "trayectorias")

    @staticmethod
    def _sample_kraus(psi: np.ndarray, n: int, p: Prim, rng) -> np.ndarray:
        candidates = []
        weights = []
        for k in p.kraus:
            v = apply_matrix(psi.copy(), n, k, p.qubits)
            w = float(np.vdot(v, v).real)
            candidates.append(v)
            weights.append(w)
        total = sum(weights)
        r = rng.random() * total
        acc = 0.0
        for v, w in zip(candidates, weights):
            acc += w
            if r <= acc and w > 0:
                return v / np.sqrt(w)
        v, w = candidates[-1], weights[-1]
        return v / np.sqrt(max(w, 1e-300))
