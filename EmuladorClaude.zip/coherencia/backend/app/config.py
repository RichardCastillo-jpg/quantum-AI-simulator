"""Configuración del servicio a partir de variables de entorno.

Todas las variables son opcionales; los valores por defecto están pensados para
un portátil normal. Ver README.md para la lista completa.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _list(name: str, default: str) -> list[str]:
    raw = os.environ.get(name, default)
    return [item.strip() for item in raw.split(",") if item.strip()]


@dataclass(frozen=True)
class Settings:
    # Motor de simulación: "qiskit" (Qiskit Aer, por defecto) o "reference" (NumPy).
    engine: str = field(default_factory=lambda: os.environ.get("QSIM_ENGINE", "qiskit").lower())
    data_dir: Path = field(default_factory=lambda: Path(os.environ.get("DATA_DIR", "./data")))
    cors_origins: list[str] = field(
        default_factory=lambda: _list(
            "CORS_ORIGINS",
            "http://localhost:4321,http://127.0.0.1:4321,http://localhost:3000",
        )
    )
    # Límites de cómputo (protegen al servidor de peticiones desproporcionadas).
    max_qubits: int = field(default_factory=lambda: _int("QSIM_MAX_QUBITS", 22))
    max_density_qubits: int = field(default_factory=lambda: _int("QSIM_MAX_DENSITY_QUBITS", 10))
    max_step_qubits: int = field(default_factory=lambda: _int("QSIM_MAX_STEP_QUBITS", 12))
    max_steps: int = field(default_factory=lambda: _int("QSIM_MAX_STEPS", 400))
    max_ops: int = field(default_factory=lambda: _int("QSIM_MAX_OPS", 20000))
    max_shots: int = field(default_factory=lambda: _int("QSIM_MAX_SHOTS", 100000))
    max_memory_shots: int = field(default_factory=lambda: _int("QSIM_MAX_MEMORY_SHOTS", 10000))
    max_clbits: int = field(default_factory=lambda: _int("QSIM_MAX_CLBITS", 64))
    seed_library: bool = field(default_factory=lambda: os.environ.get("QSIM_SEED_LIBRARY", "1") != "0")


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def override_settings(settings: Settings) -> None:
    """Usado por las pruebas para inyectar una configuración aislada."""
    global _settings
    _settings = settings
