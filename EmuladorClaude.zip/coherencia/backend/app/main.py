"""Punto de entrada de la API de Coherencia (FastAPI + Qiskit Aer)."""

from __future__ import annotations

import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from .api.routes import router
from .config import Settings, get_settings
from .engines import get_engine
from .storage.subcircuits import SubcircuitStore

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()
    app = FastAPI(
        title="Coherencia · API de simulación cuántica",
        version="1.0.0",
        description=(
            "Valida circuitos JSON (con subcircuitos, ciclos for, parámetros y ruido), los traduce a "
            "QuantumCircuit de Qiskit y los ejecuta en Qiskit Aer."
        ),
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=False,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["*"],
        max_age=600,
    )
    app.add_middleware(GZipMiddleware, minimum_size=2048)
    app.state.settings = settings
    app.state.store = SubcircuitStore(settings.data_dir, seed=settings.seed_library)
    app.state.engine = get_engine(settings.engine)
    logging.getLogger("coherencia").info("Motor: %s (%s)", app.state.engine.name, app.state.engine.version)
    app.include_router(router)

    @app.get("/")
    def root() -> dict:
        return {"service": "coherencia-api", "docs": "/docs", "health": "/api/health"}

    return app


app = create_app()
