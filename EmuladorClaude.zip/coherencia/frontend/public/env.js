// Configuración por defecto (desarrollo). En el contenedor, server.mjs sirve /env.js con
// el valor de PUBLIC_API_URL; vacío significa «mismo origen» (/api, reenviado al backend).
window.__COHERENCIA__ = window.__COHERENCIA__ || { apiUrl: '' };
