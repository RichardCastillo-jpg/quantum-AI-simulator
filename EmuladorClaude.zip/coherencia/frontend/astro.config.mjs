// @ts-check
import { defineConfig } from 'astro/config';

// En desarrollo (`npm run dev`) Vite reenvía /api al backend; en producción lo hace server.mjs.
export default defineConfig({
  output: 'static',
  server: { port: 4321, host: true },
  markdown: {
    shikiConfig: { theme: 'github-dark-dimmed' },
  },
  vite: {
    server: {
      proxy: {
        '/api': {
          target: process.env.API_PROXY_TARGET || 'http://localhost:8000',
          changeOrigin: true,
        },
      },
    },
  },
});
