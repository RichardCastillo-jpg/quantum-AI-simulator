// Galería de algoritmos: vista previa del circuito, ejecución en la propia página y
// traspaso al simulador.

import { api } from '../lib/api';
import { clear, h } from '../lib/dom';
import { fmtProb, ket } from '../lib/format';
import type { Circuit, Preset, SimConfig, SubcircuitDef } from '../lib/types';
import { toast } from './common';
import { presetForm } from './presets';
import { renderAnalysis } from './simulator/analysis';
import { DEFAULT_CONFIG } from './simulator/controller';
import { CircuitEditor } from './simulator/editor';
import { phaseLegend, renderHistogram } from './simulator/histogram';
import { localModel } from './simulator/modals';

const SHOTS_FIRST = new Set(['shor', 'rqc', 'teleportation', 'deutsch', 'bv', 'grover']);

function configFor(key: string): SimConfig {
  const cfg: SimConfig = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  cfg.mode = SHOTS_FIRST.has(key) ? 'shots' : 'statevector';
  cfg.shots = key === 'rqc' ? 4000 : 1024;
  cfg.seed = 7;
  return cfg;
}

function card(preset: Preset, library: () => SubcircuitDef[]): HTMLElement {
  let circuit: Circuit | null = null;
  let editor: CircuitEditor | null = null;
  let ran = false;
  const previewHost = h('div', { class: 'modal-editor' });
  const desc = h('p', { class: 'desc' });
  const runArea = h('div', { class: 'algo-run' });
  const status = h('p', { class: 'hint' });
  const openBtn = h('button', { class: 'btn', type: 'button', disabled: true }, 'Abrir en el simulador') as HTMLButtonElement;

  const run = async () => {
    if (!circuit) return;
    status.textContent = 'Ejecutando…';
    try {
      const cfg = configFor(preset.key);
      const res = await api.simulate(circuit, cfg, { include_state: true, max_probabilities: 32 });
      clear(runArea);
      const hist = h('div', { class: 'hist' });
      const colorByPhase = res.mode === 'statevector' && !!res.state?.amplitudes;
      const top = h('div', { class: 'card-head' },
        h('h3', null, res.mode === 'shots' ? `${res.shots?.shots} disparos` : 'Estado exacto'),
        h('div', { class: 'grow' }), colorByPhase ? phaseLegend() : null);
      runArea.append(top, hist);
      if (res.histogram) {
        renderHistogram(hist, res.histogram.entries, {
          colorByPhase, shots: res.histogram.shots, other: res.histogram.other, truncated: res.histogram.truncated,
          registerLabel: res.histogram.register === 'clbits' ? 'bits clásicos' : 'cúbits',
        });
      }
      if (res.dominant) {
        runArea.append(h('p', { class: 'summary-line' }, 'Resultado más probable ', h('strong', { class: 'math' }, ket(res.dominant.state)),
          ` con probabilidad ${fmtProb(res.dominant.p)}`));
      }
      const analysis = renderAnalysis(res.analysis);
      if (analysis) runArea.append(analysis);
      status.textContent = `${res.engine} · ${res.elapsed_ms.toFixed(1)} ms`;
      ran = true;
    } catch (e) {
      status.textContent = e instanceof Error ? e.message : String(e);
    }
  };

  const load = async (params: Record<string, unknown>, execute: boolean) => {
    try {
      circuit = await api.algorithm(preset.key, params);
      desc.textContent = String(circuit.meta?.description ?? '');
      editor?.destroy();
      clear(previewHost);
      const { model } = localModel(circuit, library, true);
      editor = new CircuitEditor(previewHost, model);
      openBtn.disabled = false;
      if (execute) await run();
    } catch (e) {
      status.textContent = e instanceof Error ? e.message : String(e);
      toast(status.textContent, { kind: 'error' });
    }
  };

  openBtn.addEventListener('click', () => {
    if (!circuit) return;
    sessionStorage.setItem('coherencia.handoff', JSON.stringify({ circuit, config: configFor(preset.key) }));
    location.href = '/simulador';
  });

  const defaults = Object.fromEntries(preset.params.map((p) => [p.key, p.default]));
  const form = presetForm(preset, (params) => load(params, true), 'Aplicar y ejecutar');
  const el = h('article', { class: 'algo-card', id: preset.key },
    h('div', null,
      h('h2', null, preset.name),
      h('p', { class: 'summary' }, preset.summary),
      h('div', { class: 'tags' }, ...preset.tags.map((t) => h('span', { class: 'chip' }, t))),
      form,
      h('div', { class: 'card-actions' }, openBtn),
      status),
    h('div', { class: 'algo-preview' }, desc, previewHost, runArea),
  );
  // Carga diferida: solo cuando la tarjeta entra en pantalla.
  const io = new IntersectionObserver((entries) => {
    if (entries.some((e) => e.isIntersecting) && !ran && !circuit) {
      io.disconnect();
      load(defaults, true);
    }
  }, { rootMargin: '200px' });
  io.observe(el);
  return el;
}

export async function mountAlgorithms(root: HTMLElement): Promise<void> {
  let library: SubcircuitDef[] = [];
  try {
    library = await api.subcircuits();
  } catch {
    /* la galería funciona sin biblioteca */
  }
  try {
    const presets = await api.algorithms();
    const list = h('div', { class: 'algo-list' });
    for (const p of presets) list.appendChild(card(p, () => library));
    root.appendChild(list);
  } catch (e) {
    root.appendChild(h('p', { class: 'message bad' }, e instanceof Error ? e.message : String(e)));
  }
}
