// Gráfico de barras 3D en canvas 2D, sin dependencias: proyección con perspectiva suave,
// orden de pintor, sombreado por cara y suelo semitransparente (las barras negativas cuelgan
// por debajo, como en los «city plots» de matrices densidad de los artículos).
//
// Interacción: arrastrar gira; Mayús+arrastrar (o botón derecho) desplaza; Ctrl+rueda, pellizco
// o los botones acercan; doble clic restablece; flechas, + y − desde el teclado. Al pasar sobre
// una barra se muestra su valor. Se puede exportar a PNG con fondo blanco para un artículo.

import { prefersReducedMotion } from '../lib/dom';
import { hideTooltip, showTooltip } from './common';

export type RGB = [number, number, number];

export interface Bar3 {
  row: number;
  col: number;
  value: number;
  rgb: RGB;
  key: string;
  tip: () => Node | string;
}

export interface Bars3Data {
  rows: number;
  cols: number;
  bars: Bar3[];
  rowLabels: string[];
  colLabels: string[];
  rowTitle: string;
  colTitle: string;
  zTitle: string;
  zMin: number;
  zMax: number;
  ticks: number[];
  fmtTick: (v: number) => string;
  ariaLabel: string;
  title?: string;
}

export interface Camera {
  yaw: number;
  pitch: number;
  zoom: number;
  panX: number;
  panY: number;
}

interface Theme {
  bg: string | null;
  floor: string;
  grid: string;
  wall: string;
  ink: string;
  ink2: string;
  outline: string;
  hover: string;
  mono: string;
  ui: string;
}

const DEG = Math.PI / 180;
export const DEFAULT_CAMERA: Camera = { yaw: -38 * DEG, pitch: 30 * DEG, zoom: 1, panX: 0, panY: 0 };

const cssVar = (name: string, fallback: string) =>
  (typeof document !== 'undefined' && getComputedStyle(document.documentElement).getPropertyValue(name).trim()) || fallback;

function screenTheme(): Theme {
  return {
    bg: null,
    floor: 'rgba(109, 141, 179, 0.07)',
    grid: 'rgba(109, 141, 179, 0.28)',
    wall: 'rgba(109, 141, 179, 0.16)',
    ink: cssVar('--ink-2', '#a8b6c7'),
    ink2: cssVar('--ink-3', '#75859a'),
    outline: 'rgba(5, 9, 14, 0.45)',
    hover: cssVar('--accent-2', '#ffd07a'),
    mono: cssVar('--font-mono', 'monospace'),
    ui: cssVar('--font-ui', 'sans-serif'),
  };
}

const PAPER: Theme = {
  bg: '#ffffff',
  floor: 'rgba(40, 52, 70, 0.05)',
  grid: 'rgba(40, 52, 70, 0.30)',
  wall: 'rgba(40, 52, 70, 0.14)',
  ink: '#1d2633',
  ink2: '#4b5868',
  outline: 'rgba(0, 0, 0, 0.35)',
  hover: '#000',
  mono: 'ui-monospace, Menlo, Consolas, monospace',
  ui: 'Helvetica, Arial, sans-serif',
};

interface Projected { X: number; Y: number; d: number }
interface Face { pts: Projected[]; fill: string; bar: number; depth: number }

/** Lado de un polígono convexo/simple: prueba de punto dentro (regla par-impar). */
function inside(px: number, py: number, pts: Projected[]): boolean {
  let ok = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const a = pts[i], b = pts[j];
    if ((a.Y > py) !== (b.Y > py) && px < ((b.X - a.X) * (py - a.Y)) / (b.Y - a.Y + 1e-12) + a.X) ok = !ok;
  }
  return ok;
}

export class Bars3D {
  readonly canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private data: Bars3Data | null = null;
  private shown: number[] = []; // valores dibujados (para animar)
  private from: number[] = [];
  private animStart = 0;
  private animating = false;
  private cam: Camera = { ...DEFAULT_CAMERA };
  private faces: Face[] = [];
  private cells: { pts: Projected[]; row: number; col: number }[] = [];
  private hoverBar = -1;
  private raf = 0;
  private drag: { mode: 'rotate' | 'pan'; x: number; y: number } | null = null;
  private pointers = new Map<number, { x: number; y: number }>();
  private pinch = 0;
  private resizeObs: ResizeObserver;
  private width = 600;
  private height = 360;
  onCameraChange?: (cam: Camera) => void;

  constructor(private host: HTMLElement, height = 360) {
    this.height = height;
    this.canvas = document.createElement('canvas');
    this.canvas.className = 'bars3d-canvas';
    this.canvas.tabIndex = 0;
    this.canvas.setAttribute('role', 'img');
    this.ctx = this.canvas.getContext('2d')!;
    host.append(this.canvas);
    this.resizeObs = new ResizeObserver(() => this.resize());
    this.resizeObs.observe(host);
    this.bind();
    this.resize();
  }

  destroy(): void {
    cancelAnimationFrame(this.raf);
    this.resizeObs.disconnect();
    hideTooltip();
    this.canvas.remove();
  }

  get camera(): Camera {
    return { ...this.cam };
  }

  setCamera(cam: Partial<Camera>): void {
    this.cam = { ...this.cam, ...cam };
    this.cam.pitch = Math.max(4 * DEG, Math.min(89 * DEG, this.cam.pitch));
    this.cam.zoom = Math.max(0.45, Math.min(4, this.cam.zoom));
    this.request();
  }

  resetView(): void {
    this.cam = { ...DEFAULT_CAMERA };
    this.onCameraChange?.(this.camera);
    this.request();
  }

  zoomBy(f: number): void {
    this.setCamera({ zoom: this.cam.zoom * f });
    this.onCameraChange?.(this.camera);
  }

  set(data: Bars3Data): void {
    const prev = this.data;
    const sameShape = prev && prev.rows === data.rows && prev.cols === data.cols && prev.bars.length === data.bars.length
      && prev.bars.every((b, i) => b.key === data.bars[i].key);
    const target = data.bars.map((b) => b.value);
    this.from = sameShape ? [...this.shown] : target.map(() => 0);
    this.data = data;
    this.canvas.setAttribute('aria-label', data.ariaLabel);
    if (prefersReducedMotion()) {
      this.shown = target;
      this.animating = false;
    } else {
      this.shown = [...this.from];
      this.animStart = performance.now();
      this.animating = true;
    }
    this.hoverBar = -1;
    this.request();
  }

  /** PNG con fondo blanco y tipografía oscura, listo para un documento. */
  toPNG(scale = 2): string {
    const off = document.createElement('canvas');
    const w = Math.max(900, this.width), hgt = Math.round(w * 0.62);
    off.width = w * scale;
    off.height = hgt * scale;
    const ctx = off.getContext('2d')!;
    ctx.scale(scale, scale);
    const values = this.data ? this.data.bars.map((b) => b.value) : [];
    this.draw(ctx, w, hgt, PAPER, values, false, true);
    return off.toDataURL('image/png');
  }

  // ------------------------------------------------------------------ interacción
  private bind(): void {
    const c = this.canvas;
    c.addEventListener('contextmenu', (ev) => ev.preventDefault());
    c.addEventListener('pointerdown', (ev) => {
      c.setPointerCapture(ev.pointerId);
      this.pointers.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
      if (this.pointers.size === 2) {
        const [a, b] = [...this.pointers.values()];
        this.pinch = Math.hypot(a.x - b.x, a.y - b.y);
        this.drag = null;
        return;
      }
      this.drag = { mode: ev.shiftKey || ev.button === 2 ? 'pan' : 'rotate', x: ev.clientX, y: ev.clientY };
      hideTooltip();
      c.classList.add('dragging');
    });
    c.addEventListener('pointermove', (ev) => {
      if (this.pointers.has(ev.pointerId)) this.pointers.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
      if (this.pointers.size === 2 && this.pinch) {
        const [a, b] = [...this.pointers.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        this.setCamera({ zoom: this.cam.zoom * (d / this.pinch) });
        this.pinch = d;
        this.onCameraChange?.(this.camera);
        return;
      }
      if (this.drag) {
        const dx = ev.clientX - this.drag.x, dy = ev.clientY - this.drag.y;
        this.drag.x = ev.clientX;
        this.drag.y = ev.clientY;
        if (this.drag.mode === 'rotate') this.setCamera({ yaw: this.cam.yaw - dx * 0.008, pitch: this.cam.pitch + dy * 0.006 });
        else this.setCamera({ panX: this.cam.panX + dx, panY: this.cam.panY + dy });
        this.onCameraChange?.(this.camera);
        return;
      }
      this.hover(ev);
    });
    const end = (ev: PointerEvent) => {
      this.pointers.delete(ev.pointerId);
      if (this.pointers.size < 2) this.pinch = 0;
      if (!this.pointers.size) {
        this.drag = null;
        c.classList.remove('dragging');
      }
    };
    c.addEventListener('pointerup', end);
    c.addEventListener('pointercancel', end);
    c.addEventListener('pointerleave', () => {
      if (!this.drag) {
        this.hoverBar = -1;
        hideTooltip();
        this.request();
      }
    });
    c.addEventListener('dblclick', () => this.resetView());
    c.addEventListener('wheel', (ev) => {
      if (!(ev.ctrlKey || ev.metaKey)) return; // sin modificador la página se desplaza con normalidad
      ev.preventDefault();
      this.zoomBy(Math.exp(-ev.deltaY * 0.0015));
    }, { passive: false });
    c.addEventListener('keydown', (ev) => {
      const step = 8 * DEG;
      const map: Record<string, () => void> = {
        ArrowLeft: () => this.setCamera({ yaw: this.cam.yaw + step }),
        ArrowRight: () => this.setCamera({ yaw: this.cam.yaw - step }),
        ArrowUp: () => this.setCamera({ pitch: this.cam.pitch + step }),
        ArrowDown: () => this.setCamera({ pitch: this.cam.pitch - step }),
        '+': () => this.zoomBy(1.15),
        '=': () => this.zoomBy(1.15),
        '-': () => this.zoomBy(1 / 1.15),
        '0': () => this.resetView(),
      };
      const fn = map[ev.key];
      if (fn) {
        ev.preventDefault();
        fn();
        this.onCameraChange?.(this.camera);
      }
    });
  }

  private hover(ev: PointerEvent): void {
    if (!this.data) return;
    const rect = this.canvas.getBoundingClientRect();
    const x = ev.clientX - rect.left, y = ev.clientY - rect.top;
    let found = -1;
    for (let i = this.faces.length - 1; i >= 0; i--) {
      if (inside(x, y, this.faces[i].pts)) {
        found = this.faces[i].bar;
        break;
      }
    }
    let cellTip: Node | string | null = null;
    if (found < 0) {
      const cell = this.cells.find((c) => inside(x, y, c.pts));
      if (cell) {
        const idx = this.data.bars.findIndex((b) => b.row === cell.row && b.col === cell.col);
        if (idx >= 0) found = idx;
      }
    }
    if (found !== this.hoverBar) {
      this.hoverBar = found;
      this.request();
    }
    if (found >= 0) {
      cellTip = this.data.bars[found].tip();
      showTooltip(ev.clientX, ev.clientY, cellTip);
    } else {
      hideTooltip();
    }
  }

  // ------------------------------------------------------------------ dibujo
  private resize(): void {
    const w = Math.max(260, Math.floor(this.host.clientWidth || 600));
    const narrow = w < 420;
    this.width = w;
    const hgt = narrow ? Math.round(w * 0.9) : this.height;
    const dpr = Math.min(2.5, window.devicePixelRatio || 1);
    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(hgt * dpr);
    this.canvas.style.width = `${w}px`;
    this.canvas.style.height = `${hgt}px`;
    this.request();
  }

  private request(): void {
    if (this.raf) return;
    this.raf = requestAnimationFrame((t) => {
      this.raf = 0;
      this.frame(t);
    });
  }

  private frame(now: number): void {
    if (!this.data) return;
    const target = this.data.bars.map((b) => b.value);
    if (this.animating) {
      const t = Math.min(1, (now - this.animStart) / 480);
      const e = 1 - Math.pow(1 - t, 3);
      this.shown = target.map((v, i) => this.from[i] + (v - this.from[i]) * e);
      if (t >= 1) this.animating = false;
      else this.request();
    } else {
      this.shown = target;
    }
    const dpr = this.canvas.width / parseFloat(this.canvas.style.width || `${this.width}`);
    const ctx = this.ctx;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    const w = this.canvas.width / dpr, hgt = this.canvas.height / dpr;
    const { faces, cells } = this.draw(ctx, w, hgt, screenTheme(), this.shown, true, false);
    this.faces = faces;
    this.cells = cells;
  }

  private draw(ctx: CanvasRenderingContext2D, W: number, Hc: number, theme: Theme, values: number[],
    interactive: boolean, withTitle: boolean): { faces: Face[]; cells: { pts: Projected[]; row: number; col: number }[] } {
    const data = this.data!;
    const cam = interactive ? this.cam : { ...this.cam, panX: 0, panY: 0, zoom: Math.min(this.cam.zoom, 1.4) };
    const { rows, cols } = data;
    if (theme.bg) {
      ctx.fillStyle = theme.bg;
      ctx.fillRect(0, 0, W, Hc);
    }
    // Escala del mundo: la cuadrícula mide cols × rows y la barra más alta ~0,6 del lado mayor.
    const side = Math.max(cols, rows);
    const zAbs = Math.max(Math.abs(data.zMin), Math.abs(data.zMax), 1e-12);
    const H = Math.max(2.2, Math.min(9, side * 0.62));
    const zs = H / zAbs;
    const zLo = data.zMin * zs, zHi = data.zMax * zs;
    const cx = cols / 2, cy = rows / 2, cz = (zLo + zHi) / 2;
    const R = 0.5 * Math.hypot(cols, rows, zHi - zLo);
    const D = R * 6;
    const margin = 0.35; // los rótulos se colocan en píxeles fuera del suelo (ver padX/padY)
    // Encuadre: caja que ocupan la escena y sus rótulos vista con la orientación por defecto (en pantalla,
    // para que girar no cambie el tamaño) o con la orientación actual (al exportar, encuadre exacto).
    const unitBounds = (yaw: number, pitch: number) => {
      const c1 = Math.cos(yaw), s1 = Math.sin(yaw), c2 = Math.cos(pitch), s2 = Math.sin(pitch);
      let minU = Infinity, maxU = -Infinity, minV = Infinity, maxV = -Infinity;
      const xs = [-margin, cols + margin], ys = [-margin, rows + margin], zz = [Math.min(zLo, 0), zHi];
      for (const x of xs) for (const y of ys) for (const z of zz) {
        const px = x - cx, py = y - cy, pz = z - cz;
        const x1 = px * c1 - py * s1, y1 = px * s1 + py * c1;
        const f = D / (D - (-y1 * c2 + pz * s2));
        const u = f * x1, v = f * (y1 * s2 + pz * c2);
        minU = Math.min(minU, u); maxU = Math.max(maxU, u); minV = Math.min(minV, v); maxV = Math.max(maxV, v);
      }
      return { minU, maxU, minV, maxV };
    };
    const fit = interactive ? unitBounds(DEFAULT_CAMERA.yaw, DEFAULT_CAMERA.pitch) : unitBounds(cam.yaw, cam.pitch);
    const top = withTitle ? 44 : 0;
    const usableH = Hc - top;
    const padX = W < 440 ? 40 : 70, padTop = 26, padBottom = W < 440 ? 38 : 46;
    const scale = Math.max(4, Math.min((W - 2 * padX) / (fit.maxU - fit.minU),
      (usableH - padTop - padBottom) / (fit.maxV - fit.minV))) * cam.zoom;
    const ca = Math.cos(cam.yaw), sa = Math.sin(cam.yaw), ce = Math.cos(cam.pitch), se = Math.sin(cam.pitch);
    const ox = W / 2 + cam.panX - scale * ((fit.maxU + fit.minU) / 2);
    const oy = top + padTop + (usableH - padTop - padBottom) / 2 + cam.panY + scale * ((fit.maxV + fit.minV) / 2);
    const proj = (x: number, y: number, z: number): Projected => {
      const px = x - cx, py = y - cy, pz = z - cz;
      const x1 = px * ca - py * sa, y1 = px * sa + py * ca;
      const d = -y1 * ce + pz * se;
      const up = y1 * se + pz * ce;
      const f = D / (D - d);
      return { X: ox + scale * f * x1, Y: oy - scale * f * up, d };
    };
    const rot = (nx: number, ny: number, nz: number) => ({ x: nx * ca - ny * sa, y: nx * sa + ny * ca, z: nz });
    const facing = (n: { x: number; y: number; z: number }) => -n.y * ce + n.z * se;
    const L = { x: -0.45, y: -0.55, z: 0.8 };
    const Ln = Math.hypot(L.x, L.y, L.z);
    // Luz fija respecto a la cámara (arriba a la izquierda, hacia el observador, que está en −y).
    const shade = (n: { x: number; y: number; z: number }) =>
      0.52 + 0.48 * Math.max(0, (n.x * L.x + n.y * L.y + n.z * L.z) / Ln);

    // --- Suelo, paredes y ejes -----------------------------------------------------------------
    const corners = [proj(0, 0, 0), proj(cols, 0, 0), proj(cols, rows, 0), proj(0, rows, 0)];
    const cellPolys: { pts: Projected[]; row: number; col: number }[] = [];
    // Esquina más lejana: de ella salen las dos paredes del fondo.
    let far = 0;
    corners.forEach((c, i) => { if (c.d < corners[far].d) far = i; });
    const cornerXY: [number, number][] = [[0, 0], [cols, 0], [cols, rows], [0, rows]];
    const [fx, fy] = cornerXY[far];
    const wallX: [number, number] = fx === 0 ? [0, cols] : [cols, 0];
    const wallY: [number, number] = fy === 0 ? [0, rows] : [rows, 0];

    const line = (a: Projected, b: Projected, color: string, width = 1) => {
      ctx.strokeStyle = color;
      ctx.lineWidth = width;
      ctx.beginPath();
      ctx.moveTo(a.X, a.Y);
      ctx.lineTo(b.X, b.Y);
      ctx.stroke();
    };
    const poly = (pts: Projected[], fill: string | null, stroke: string | null, lw = 1) => {
      ctx.beginPath();
      pts.forEach((p, i) => (i ? ctx.lineTo(p.X, p.Y) : ctx.moveTo(p.X, p.Y)));
      ctx.closePath();
      if (fill) {
        ctx.fillStyle = fill;
        ctx.fill();
      }
      if (stroke) {
        ctx.strokeStyle = stroke;
        ctx.lineWidth = lw;
        ctx.stroke();
      }
    };

    // Paredes del fondo con líneas de escala.
    const wallPts = (axis: 'x' | 'y') => axis === 'x'
      ? [proj(wallX[0], fy, zLo), proj(wallX[1], fy, zLo), proj(wallX[1], fy, zHi), proj(wallX[0], fy, zHi)]
      : [proj(fx, wallY[0], zLo), proj(fx, wallY[1], zLo), proj(fx, wallY[1], zHi), proj(fx, wallY[0], zHi)];
    poly(wallPts('x'), theme.floor, null);
    poly(wallPts('y'), theme.floor, null);
    for (const t of data.ticks) {
      const z = t * zs;
      line(proj(wallX[0], fy, z), proj(wallX[1], fy, z), t === 0 ? theme.grid : theme.wall);
      line(proj(fx, wallY[0], z), proj(fx, wallY[1], z), t === 0 ? theme.grid : theme.wall);
    }
    line(proj(fx, fy, zLo), proj(fx, fy, zHi), theme.grid);

    // Rótulos del eje vertical, en la arista del fondo que queda más a la izquierda.
    const ends = [proj(wallX[1], fy, 0), proj(fx, wallY[1], 0)];
    const labelAtX = ends[0].X < ends[1].X ? 'x' : 'y';
    ctx.font = `11px ${theme.mono}`;
    ctx.fillStyle = theme.ink2;
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'right';
    for (const t of data.ticks) {
      const p = labelAtX === 'x' ? proj(wallX[1], fy, t * zs) : proj(fx, wallY[1], t * zs);
      ctx.fillText(data.fmtTick(t), p.X - 7, p.Y);
    }
    const zTop = labelAtX === 'x' ? proj(wallX[1], fy, zHi) : proj(fx, wallY[1], zHi);
    ctx.font = `600 12px ${theme.ui}`;
    ctx.fillStyle = theme.ink;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';
    ctx.fillText(data.zTitle, zTop.X - 10, zTop.Y - 8);

    const bw = side >= 16 ? 0.72 : 0.64;
    const gap = (1 - bw) / 2;
    const n = data.bars.length;

    // Barras negativas: quedan por debajo del suelo (se dibujan antes que él).
    const order = data.bars.map((b, i) => i);
    const centerDepth = (i: number) => proj(data.bars[i].col + 0.5, data.bars[i].row + 0.5, 0).d;
    order.sort((a, b) => centerDepth(a) - centerDepth(b));
    const faces: Face[] = [];
    const drawBar = (i: number) => {
      const b = data.bars[i];
      const v = values[i] ?? 0;
      if (Math.abs(v) * zs < 1e-3) return;
      const x0 = b.col + gap, x1 = b.col + 1 - gap, y0 = b.row + gap, y1 = b.row + 1 - gap;
      const z0 = Math.min(0, v * zs), z1 = Math.max(0, v * zs);
      const sides: [number, number, number, [number, number, number][]][] = [
        [0, 0, 1, [[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]]],
        [0, 0, -1, [[x0, y0, z0], [x0, y1, z0], [x1, y1, z0], [x1, y0, z0]]],
        [0, -1, 0, [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]]],
        [0, 1, 0, [[x1, y1, z0], [x0, y1, z0], [x0, y1, z1], [x1, y1, z1]]],
        [-1, 0, 0, [[x0, y1, z0], [x0, y0, z0], [x0, y0, z1], [x0, y1, z1]]],
        [1, 0, 0, [[x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [x1, y0, z1]]],
      ];
      const hovered = interactive && i === this.hoverBar;
      for (const [nx, ny, nz, pts3] of sides) {
        const nr = rot(nx, ny, nz);
        if (facing(nr) <= 1e-6) continue;
        const k = shade(nr) * (nz > 0 ? 1.08 : 1);
        const [r, g, bl] = b.rgb;
        const fill = `rgb(${Math.min(255, Math.round(r * k))} ${Math.min(255, Math.round(g * k))} ${Math.min(255, Math.round(bl * k))})`;
        const pts = pts3.map(([x, y, z]) => proj(x, y, z));
        poly(pts, fill, hovered ? theme.hover : theme.outline, hovered ? 1.6 : 0.6);
        faces.push({ pts, fill, bar: i, depth: 0 });
      }
    };
    for (const i of order) if ((values[i] ?? 0) < 0) drawBar(i);

    // Suelo con cuadrícula (semitransparente para dejar ver lo que cuelga).
    poly(corners, theme.floor, theme.grid);
    ctx.lineWidth = 1;
    for (let c = 1; c < cols; c++) line(proj(c, 0, 0), proj(c, rows, 0), theme.wall);
    for (let r = 1; r < rows; r++) line(proj(0, r, 0), proj(cols, r, 0), theme.wall);
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
      cellPolys.push({ row: r, col: c, pts: [proj(c, r, 0), proj(c + 1, r, 0), proj(c + 1, r + 1, 0), proj(c, r + 1, 0)] });
    }
    if (interactive && this.hoverBar >= 0 && this.hoverBar < n) {
      const b = data.bars[this.hoverBar];
      poly([proj(b.col, b.row, 0), proj(b.col + 1, b.row, 0), proj(b.col + 1, b.row + 1, 0), proj(b.col, b.row + 1, 0)],
        'rgba(255, 208, 122, 0.12)', null);
    }

    // Rótulos de filas y columnas en las aristas más cercanas al observador, desplazados en pantalla
    // perpendicularmente a la arista y hacia fuera del suelo; el título va más allá del rótulo más ancho.
    const nearY = proj(cx, 0, 0).d > proj(cx, rows, 0).d ? 0 : rows; // arista para las columnas
    const nearX = proj(0, cy, 0).d > proj(cols, cy, 0).d ? 0 : cols; // arista para las filas
    const center = proj(cx, cy, 0);
    const labelEdge = (count: number, labels: string[], title: string, at: (t: number) => Projected) => {
      const a = at(0), b = at(count);
      const len = Math.hypot(b.X - a.X, b.Y - a.Y) || 1;
      let nx = -(b.Y - a.Y) / len, ny = (b.X - a.X) / len;
      const mid = at(count / 2);
      if (nx * (mid.X - center.X) + ny * (mid.Y - center.Y) < 0) {
        nx = -nx;
        ny = -ny;
      }
      ctx.font = `11px ${theme.mono}`;
      const widest = Math.max(0, ...labels.map((l) => ctx.measureText(l).width));
      const spacing = len / Math.max(count, 1);
      const step = Math.max(1, Math.ceil((Math.abs(nx) > 0.6 ? 14 : widest + 8) / Math.max(spacing, 1)));
      ctx.fillStyle = theme.ink2;
      ctx.textBaseline = 'middle';
      ctx.textAlign = Math.abs(nx) < 0.35 ? 'center' : nx < 0 ? 'right' : 'left';
      for (let k = 0; k < count; k += step) {
        const p = at(k + 0.5);
        ctx.fillText(labels[k] ?? '', p.X + nx * 9, p.Y + ny * 9);
      }
      if (!title) return;
      const extent = Math.abs(nx) * widest + Math.abs(ny) * 12;
      ctx.font = `600 12px ${theme.ui}`;
      const half = Math.abs(nx) * (ctx.measureText(title).width / 2) + Math.abs(ny) * 7;
      const t = { X: mid.X + nx * (extent + 16 + half), Y: mid.Y + ny * (extent + 16 + half) };
      ctx.fillStyle = theme.ink;
      ctx.textAlign = 'center';
      ctx.fillText(title, t.X, t.Y);
    };
    labelEdge(cols, data.colLabels, data.colTitle, (t) => proj(t, nearY, 0));
    if (rows > 1 || data.rowTitle) labelEdge(rows, data.rowLabels, data.rowTitle, (t) => proj(nearX, t, 0));

    // Barras positivas, de la más lejana a la más cercana.
    for (const i of order) if ((values[i] ?? 0) >= 0) drawBar(i);

    if (withTitle && data.title) {
      ctx.font = `600 16px ${theme.ui}`;
      ctx.fillStyle = theme.ink;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText(data.title, 18, 14);
    }
    return { faces, cells: cellPolys };
  }
}
