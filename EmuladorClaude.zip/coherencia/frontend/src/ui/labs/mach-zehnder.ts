// Laboratorio: interferómetro de Mach–Zehnder con fotones individuales.
// Todas las probabilidades y amplitudes las calcula el emulador (API /simulate y /simulate/steps).

import { api } from '../../lib/api';
import { AutoRunner } from '../../lib/autorun';
import { clear, h } from '../../lib/dom';
import { fmtAngle, fmtProb } from '../../lib/format';
import type { Circuit, SimConfig, SimResult, StepsResult } from '../../lib/types';
import { toast } from '../common';
import { DEFAULT_CONFIG } from '../simulator/controller';
import { OpticalBench, renderCurve } from './bench';

const C_D0 = '#4dc8e6';
const C_D1 = '#e9a6d2';
const C_ABS = '#f0705f';

export interface MZOptions {
  bs2: boolean;
  block: boolean;
  phi: number;
}

export function mzCircuit(o: MZOptions): Circuit {
  const ops: Circuit['ops'] = [
    { id: 'bs1', kind: 'gate', gate: 'h', col: 0, targets: [0], label: 'BS₁' },
    { id: 'phase', kind: 'gate', gate: 'p', col: 1, targets: [0], params: [Number(o.phi.toFixed(6))], label: 'φ' },
  ];
  if (o.block) ops.push({ id: 'block', kind: 'measure', col: 2, targets: [0], clbits: [1] });
  if (o.bs2) ops.push({ id: 'bs2', kind: 'gate', gate: 'h', col: 3, targets: [0], label: 'BS₂' });
  ops.push({ id: 'detect', kind: 'measure', col: 4, targets: [0], clbits: [0] });
  return {
    version: 1, name: 'Interferómetro de Mach–Zehnder', num_qubits: 1, num_clbits: 2, initial_state: '0',
    qubit_labels: ['fotón'], clbit_labels: ['D', 'abs'], ops, loops: [], meta: { lab: 'mach-zehnder' },
  };
}

function cfg(mode: SimConfig['mode'], shots = 1): SimConfig {
  return { ...JSON.parse(JSON.stringify(DEFAULT_CONFIG)), mode, shots, seed: null };
}

export function outcomeProbs(res: SimResult): { d0: number; d1: number; abs: number } {
  // Bits clásicos (c1 c0): c1 = absorbido, c0 = detector.
  const p: Record<string, number> = {};
  for (const e of res.classical?.entries ?? []) p[e.state] = e.p;
  const abs = (p['10'] ?? 0) + (p['11'] ?? 0);
  return { d0: p['00'] ?? 0, d1: p['01'] ?? 0, abs };
}

export function mountMachZehnder(root: HTMLElement): void {
  const state: MZOptions = { bs2: true, block: false, phi: 0 };
  const counts = { d0: 0, d1: 0, abs: 0 };
  let exact: { d0: number; d1: number; abs: number } | null = null;

  const benchHost = h('div', { class: 'bench-card' });
  const bench = new OpticalBench(benchHost, 'Interferómetro de Mach–Zehnder: fuente, dos divisores de haz, dos espejos, desfasador y detectores');

  // ------------------------------------------------------------ controles
  const phiValue = h('span', { class: 'phi-value' }, 'φ = 0');
  const phiSlider = h('input', { type: 'range', min: '0', max: String(2 * Math.PI), step: '0.01', value: '0', 'aria-label': 'Fase φ del desfasador' }) as HTMLInputElement;
  const toggle = (label: string, checked: boolean, onchange: (v: boolean) => void) => {
    const input = h('input', { type: 'checkbox', role: 'switch', checked, 'aria-label': label }) as HTMLInputElement;
    input.addEventListener('change', () => onchange(input.checked));
    return h('label', { class: 'toggle-row' }, h('span', null, label), h('span', { class: 'switch' }, input, h('i')));
  };
  const nInput = h('input', { class: 'field mono', type: 'number', min: '1', max: '5000', value: '200', 'aria-label': 'Número de fotones de la ráfaga' }) as HTMLInputElement;
  const fireOne = h('button', { class: 'btn btn-primary', type: 'button' }, 'Disparar un fotón') as HTMLButtonElement;
  const fireMany = h('button', { class: 'btn', type: 'button' }, 'Ráfaga') as HTMLButtonElement;
  const reset = h('button', { class: 'btn btn-ghost', type: 'button' }, 'Reiniciar contadores');
  const equiv = h('div', { class: 'equiv', 'aria-label': 'Circuito equivalente' });
  const openSim = h('button', { class: 'btn btn-sm', type: 'button' }, 'Abrir este circuito en el simulador');

  const side = h('div', { class: 'lab-side' },
    h('div', { class: 'card' },
      h('h3', null, 'Desfasador'),
      h('div', { class: 'phi-row' }, phiValue, h('span', { class: 'mono soft', id: 'phi-rad' })),
      phiSlider,
      h('p', { class: 'hint' }, 'Mueve la fase y observa cómo la interferencia pasa de constructiva a destructiva. Los círculos del banco muestran cada amplitud compleja: la longitud es el módulo y el ángulo y el color, la fase.'),
    ),
    h('div', { class: 'card' },
      h('h3', null, 'Configuración'),
      toggle('Segundo divisor de haz (BS₂)', true, (v) => { state.bs2 = v; update(); }),
      toggle('Bloquear el brazo B', false, (v) => { state.block = v; update(); }),
    ),
    h('div', { class: 'card' },
      h('h3', null, 'Fotones'),
      h('div', { class: 'fire-row' }, fireOne),
      h('div', { class: 'fire-row', style: { marginTop: '8px' } }, h('label', { class: 'mini-field', style: { width: '110px' } }, h('span', { class: 'label' }, 'Ráfaga de N'), nInput), h('div', { style: { alignSelf: 'end' } }, fireMany)),
      h('div', { class: 'fire-row', style: { marginTop: '8px' } }, reset),
    ),
  );

  // ------------------------------------------------------------ resultados
  const curveHost = h('div');
  const tableHost = h('div');
  const errorBox = h('p', { class: 'message bad lab-error', hidden: true });
  const results = h('div', { class: 'lab-results' },
    h('div', { class: 'card' },
      h('h3', null, 'Probabilidad de detección frente a φ'),
      h('div', { class: 'legend' },
        h('span', null, h('i', { style: { background: C_D0 } }), 'P(D₀) teoría'),
        h('span', null, h('i', { style: { background: C_D1 } }), 'P(D₁) teoría'),
        h('span', null, h('i', { class: 'dot', style: { background: 'var(--ink)' } }), 'valor del emulador')),
      curveHost,
      h('p', { class: 'hint' }, 'Sin obstáculos y con BS₂: P(D₀) = cos²(φ/2), P(D₁) = sin²(φ/2). Sin BS₂ o con un brazo bloqueado desaparece la interferencia.'),
    ),
    h('div', { class: 'card' }, h('h3', null, 'Detecciones acumuladas'), tableHost,
      h('h3', { style: { marginTop: '14px' } }, 'Circuito equivalente'), equiv,
      h('div', { style: { marginTop: '10px' } }, openSim)),
  );

  root.append(errorBox, h('div', { class: 'lab-grid' }, benchHost, side), results);

  // ------------------------------------------------------------ emulador reactivo
  const runner = new AutoRunner<MZOptions, { res: SimResult; steps: StepsResult }>({
    run: async (o, signal) => {
      const circuit = mzCircuit(o);
      const [res, steps] = await Promise.all([
        api.simulate(circuit, cfg('statevector'), { include_state: true }, signal),
        api.steps(circuit, cfg('statevector'), signal),
      ]);
      return { res, steps };
    },
    onResult: ({ res, steps }, o) => {
      errorBox.hidden = true;
      exact = outcomeProbs(res);
      const ampAt = (col: number) => steps.steps.find((s) => s.col === col)?.amplitudes ?? null;
      const afterBs1 = ampAt(0);
      const afterPhase = ampAt(1);
      const last = steps.steps[steps.steps.length - 1]?.amplitudes ?? null;
      const pick = (amps: typeof afterBs1, state: string) => {
        const a = amps?.find((x) => x.state === state);
        return a ? { re: a.re, im: a.im } : null;
      };
      bench.setAmplitudes({
        armA: pick(afterBs1, '0'),
        armB: pick(afterPhase, '1'),
        d0: o.block ? null : pick(last, '0'),
        d1: o.block ? null : pick(last, '1'),
      });
      bench.setIntensities({ armA: 0.5, armB: 0.5, armBAfter: o.block ? 0 : 0.5, d0: exact.d0, d1: exact.d1 });
      renderAll();
    },
    onError: (err) => {
      errorBox.hidden = false;
      errorBox.textContent = err instanceof Error ? err.message : String(err);
    },
    debounceMs: 60,
    throttleMs: 90,
  });

  const theory = (phi: number): [number, number] => {
    if (state.block) return [0.25, 0.25];
    if (!state.bs2) return [0.5, 0.5];
    return [Math.cos(phi / 2) ** 2, Math.sin(phi / 2) ** 2];
  };

  function renderAll(): void {
    renderCurve(curveHost, { theory, phi: state.phi, emulator: exact ? [exact.d0, exact.d1] : null, colors: [C_D0, C_D1] });
    const total = counts.d0 + counts.d1 + counts.abs;
    const row = (label: string, color: string, n: number, p: number | undefined) =>
      h('tr', null,
        h('td', null, h('span', { class: 'key', style: { background: color } }), label),
        h('td', null, String(n)),
        h('td', null, total ? fmtProb(n / total) : '—'),
        h('td', null, p === undefined ? '—' : fmtProb(p)));
    clear(tableHost);
    tableHost.append(
      h('table', { class: 'count-table' },
        h('thead', null, h('tr', null, h('th', null, 'Resultado'), h('th', null, 'Cuentas'), h('th', null, 'Frecuencia'), h('th', null, 'Emulador'))),
        h('tbody', null,
          row('D₀', C_D0, counts.d0, exact?.d0),
          row('D₁', C_D1, counts.d1, exact?.d1),
          state.block ? row('Absorbido en B', C_ABS, counts.abs, exact?.abs) : null)),
      h('p', { class: 'hint' }, total ? `${total} fotones emitidos.` : 'Dispara fotones para acumular estadística.'),
    );
    const parts = ['|0⟩', 'H (BS₁)', `P(${fmtAngle(state.phi)})`];
    if (state.block) parts.push('medir → abs');
    if (state.bs2) parts.push('H (BS₂)');
    parts.push('medir → D');
    equiv.textContent = parts.join('  ─  ');
    bench.setCount('d0', counts.d0);
    bench.setCount('d1', counts.d1);
  }

  function update(continuous = false): void {
    phiValue.textContent = `φ = ${fmtAngle(state.phi)}`;
    root.querySelector('#phi-rad')!.textContent = `${state.phi.toFixed(2)} rad`;
    bench.setState({ bs2: state.bs2, obstacle: state.block ? 'absorber' : 'none', showPhase: true, phaseLabel: `φ = ${fmtAngle(state.phi)}` });
    renderAll();
    runner.schedule({ ...state }, { continuous });
  }

  phiSlider.addEventListener('input', () => {
    state.phi = Number(phiSlider.value);
    update(true);
  });

  let busy = false;
  const fire = async (n: number) => {
    if (busy) return;
    busy = true;
    fireOne.disabled = fireMany.disabled = true;
    try {
      const res = await api.simulate(mzCircuit(state), cfg('shots', n), { memory: true, include_state: false });
      const memory = res.shots?.memory ?? [];
      const animated = Math.min(memory.length, n === 1 ? 1 : 24);
      const tasks: Promise<void>[] = [];
      memory.forEach((bits, i) => {
        const outcome = bits[0] === '1' ? 'absorbed' : bits[1] === '1' ? 'd1' : 'd0';
        const count = () => {
          counts[outcome === 'absorbed' ? 'abs' : outcome]++;
          renderAll();
        };
        if (i < animated) {
          tasks.push(new Promise((resolve) => setTimeout(() => {
            bench.firePhoton(outcome, { measuring: state.block, bs2: state.bs2, duration: n === 1 ? 1500 : 900 }).then(() => { count(); resolve(); });
          }, i * 110)));
        } else {
          tasks.push(Promise.all(tasks.slice(0, animated)).then(count));
        }
      });
      await Promise.all(tasks);
    } catch (e) {
      toast(e instanceof Error ? e.message : String(e), { kind: 'error' });
    } finally {
      busy = false;
      fireOne.disabled = fireMany.disabled = false;
    }
  };
  fireOne.addEventListener('click', () => fire(1));
  fireMany.addEventListener('click', () => fire(Math.max(1, Math.min(5000, Math.round(Number(nInput.value) || 100)))));
  reset.addEventListener('click', () => {
    counts.d0 = counts.d1 = counts.abs = 0;
    renderAll();
  });
  openSim.addEventListener('click', () => {
    sessionStorage.setItem('coherencia.handoff', JSON.stringify({ circuit: mzCircuit(state), config: cfg('statevector') }));
    location.href = '/simulador';
  });
  new ResizeObserver(() => renderAll()).observe(curveHost);
  update();
}
