// Laboratorio: medida libre de interacción (bombas de Elitzur–Vaidman).
// La bomba activa es un detector de camino en el brazo B: se modela como una medición
// a mitad de circuito (el emulador la resuelve con control dinámico o medición diferida).

import { api } from '../../lib/api';
import { clear, h } from '../../lib/dom';
import { fmtPercent } from '../../lib/format';
import type { Circuit, SimConfig } from '../../lib/types';
import { toast } from '../common';
import { DEFAULT_CONFIG } from '../simulator/controller';
import { OpticalBench } from './bench';
import { outcomeProbs } from './mach-zehnder';

type Scenario = 'live' | 'dud' | 'hidden';
type Outcome = 'boom' | 'd0' | 'd1';

function evCircuit(live: boolean): Circuit {
  const ops: Circuit['ops'] = [{ id: 'bs1', kind: 'gate', gate: 'h', col: 0, targets: [0], label: 'BS₁' }];
  if (live) ops.push({ id: 'bomb', kind: 'measure', col: 1, targets: [0], clbits: [1] });
  else ops.push({ id: 'dud', kind: 'gate', gate: 'id', col: 1, targets: [0], label: 'bomba' });
  ops.push({ id: 'bs2', kind: 'gate', gate: 'h', col: 2, targets: [0], label: 'BS₂' });
  ops.push({ id: 'detect', kind: 'measure', col: 3, targets: [0], clbits: [0] });
  return {
    version: 1, name: live ? 'Elitzur–Vaidman · bomba activa' : 'Elitzur–Vaidman · bomba defectuosa', num_qubits: 1, num_clbits: 2,
    initial_state: '0', qubit_labels: ['fotón'], clbit_labels: ['D', 'bomba'], ops, loops: [], meta: { lab: 'elitzur-vaidman' },
  };
}

function cfg(mode: SimConfig['mode'], shots = 1): SimConfig {
  return { ...JSON.parse(JSON.stringify(DEFAULT_CONFIG)), mode, shots, seed: null };
}

const COLORS: Record<Outcome, string> = { boom: '#f0705f', d0: '#4dc8e6', d1: '#62d6a2' };
const LABELS: Record<Outcome, string> = { boom: 'Explosión', d0: 'D₀ · inconcluso', d1: 'D₁ · sin interacción' };

export function mountElitzurVaidman(root: HTMLElement): void {
  let scenario: Scenario = 'live';
  let hiddenLive = Math.random() < 0.5;
  let hiddenAlive = true;
  let hiddenRevealed = false;
  const counts: Record<Outcome, number> = { boom: 0, d0: 0, d1: 0 };
  const score = { tested: 0, certified: 0, exploded: 0, correct: 0, wrong: 0 };
  let theory: Record<Outcome, number> | null = null;

  const isLive = () => (scenario === 'hidden' ? hiddenLive : scenario === 'live');

  const benchHost = h('div', { class: 'bench-card' });
  const bench = new OpticalBench(benchHost, 'Prueba de bombas de Elitzur–Vaidman: interferómetro con una bomba en el brazo B');

  const seg = h('div', { class: 'seg full', role: 'group', 'aria-label': 'Escenario' });
  const scenarios: [Scenario, string][] = [['live', 'Activa'], ['dud', 'Defectuosa'], ['hidden', 'A ciegas']];
  const message = h('p', { class: 'message', 'aria-live': 'polite' });
  const fireOne = h('button', { class: 'btn btn-primary', type: 'button' }, 'Enviar un fotón') as HTMLButtonElement;
  const fireMany = h('button', { class: 'btn', type: 'button' }, 'Enviar 200 fotones') as HTMLButtonElement;
  const resetBtn = h('button', { class: 'btn btn-ghost', type: 'button' }, 'Reiniciar estadística');
  const hiddenBox = h('div', { class: 'card' });
  const barsHost = h('div', { class: 'bars' });
  const statsHost = h('div');

  const side = h('div', { class: 'lab-side' },
    h('div', { class: 'card' }, h('h3', null, 'Escenario'), seg,
      h('p', { class: 'hint' }, 'El interferómetro está ajustado con φ = 0: sin obstáculos todos los fotones llegan a D₀. Una bomba activa actúa como detector en el brazo B.')),
    h('div', { class: 'card' }, h('h3', null, 'Fotones'), h('div', { class: 'fire-row' }, fireOne, fireMany), h('div', { class: 'fire-row', style: { marginTop: '8px' } }, resetBtn)),
    hiddenBox,
    message,
  );
  const results = h('div', { class: 'lab-results' },
    h('div', { class: 'card' }, h('h3', null, 'Frecuencias frente a la predicción del emulador'), barsHost,
      h('p', { class: 'hint' }, 'La marca vertical es la probabilidad exacta que calcula el emulador; la barra, la frecuencia observada.')),
    h('div', { class: 'card' }, h('h3', null, 'Registro'), statsHost),
  );
  root.append(h('div', { class: 'lab-grid' }, benchHost, side), results);

  async function refreshTheory(): Promise<void> {
    if (scenario === 'hidden') {
      theory = null;
      render();
      return;
    }
    try {
      const res = await api.simulate(evCircuit(isLive()), cfg('statevector'), { include_state: false });
      const p = outcomeProbs(res);
      theory = { boom: p.abs, d0: p.d0, d1: p.d1 };
    } catch (e) {
      theory = null;
      toast(e instanceof Error ? e.message : String(e), { kind: 'error' });
    }
    render();
  }

  function setMessage(text: string, tone: 'good' | 'bad' | 'neutral' | '' = ''): void {
    message.className = `message ${tone}`;
    message.textContent = text;
  }

  function render(): void {
    seg.replaceChildren(...scenarios.map(([v, label]) => h('button', { 'aria-pressed': v === scenario ? 'true' : 'false', type: 'button', onclick: () => {
      scenario = v;
      counts.boom = counts.d0 = counts.d1 = 0;
      if (v === 'hidden') newBomb();
      bench.setState({ obstacle: v === 'hidden' ? 'bomb-live' : v === 'live' ? 'bomb-live' : 'bomb-dud' });
      setMessage(v === 'hidden'
        ? 'Una bomba desconocida está en el brazo B. Envía fotones y decide si está activa sin hacerla explotar.'
        : v === 'live' ? 'Bomba activa: en la mitad de los casos absorbe el fotón y explota.'
          : 'Bomba defectuosa: es transparente y el interferómetro funciona como si no estuviera.');
      refreshTheory();
    } }, label)));
    const total = counts.boom + counts.d0 + counts.d1;
    clear(barsHost);
    for (const k of ['boom', 'd0', 'd1'] as Outcome[]) {
      const freq = total ? counts[k] / total : 0;
      barsHost.appendChild(h('div', { class: 'bar-row' },
        h('span', null, LABELS[k]),
        h('div', { class: 'bar-track' },
          h('div', { class: 'bar-fill', style: { width: `${freq * 100}%`, background: COLORS[k] } }),
          theory ? h('div', { class: 'bar-theory', style: { left: `calc(${theory[k] * 100}% - 1px)` }, title: `Emulador: ${fmtPercent(theory[k])}` }) : null),
        h('span', { class: 'mono soft' }, total ? fmtPercent(freq) : '—')));
    }
    clear(statsHost);
    statsHost.append(
      h('table', { class: 'count-table' },
        h('thead', null, h('tr', null, h('th', null, 'Resultado'), h('th', null, 'Cuentas'), h('th', null, 'Emulador'))),
        h('tbody', null,
          h('tr', null, h('td', null, 'Intentos'), h('td', null, String(total)), h('td', null, '')),
          ...(['boom', 'd0', 'd1'] as Outcome[]).map((k) => h('tr', null,
            h('td', null, h('span', { class: 'key', style: { background: COLORS[k] } }), LABELS[k]),
            h('td', null, String(counts[k])),
            h('td', null, theory ? fmtPercent(theory[k]) : 'oculto'))))),
    );
    bench.setCount('d0', counts.d0);
    bench.setCount('d1', counts.d1);
    if (theory) bench.setIntensities({ armA: 0.5, armB: 0.5, armBAfter: isLive() ? 0 : 0.5, d0: theory.d0, d1: theory.d1 });
    else bench.setIntensities({ armA: 0.5, armB: 0.5, armBAfter: 0.25, d0: 0.35, d1: 0.15 });
    renderHidden();
  }

  function newBomb(): void {
    hiddenLive = Math.random() < 0.5;
    hiddenAlive = true;
    hiddenRevealed = false;
    score.tested++;
    bench.setState({ obstacle: 'bomb-live' });
  }

  function renderHidden(): void {
    hiddenBox.hidden = scenario !== 'hidden';
    if (scenario !== 'hidden') return;
    clear(hiddenBox);
    const declare = (live: boolean) => () => {
      if (hiddenRevealed) return;
      hiddenRevealed = true;
      const ok = live === hiddenLive;
      if (ok) score.correct++;
      else score.wrong++;
      bench.setState({ obstacle: hiddenLive ? 'bomb-live' : 'bomb-dud' });
      setMessage(`${ok ? 'Correcto' : 'Incorrecto'}: la bomba era ${hiddenLive ? 'activa' : 'defectuosa'}.`, ok ? 'good' : 'bad');
      render();
    };
    hiddenBox.append(
      h('h3', null, 'Prueba oculta'),
      h('div', { class: 'score' },
        h('span', null, h('strong', null, String(score.tested)), ' bombas'),
        h('span', null, h('strong', null, String(score.certified)), ' certificadas intactas'),
        h('span', null, h('strong', null, String(score.exploded)), ' explotadas'),
        h('span', null, h('strong', null, `${score.correct}/${score.correct + score.wrong}`), ' aciertos')),
      h('div', { class: 'fire-row', style: { marginTop: '10px' } },
        h('button', { class: 'btn btn-sm', type: 'button', disabled: hiddenRevealed, onclick: declare(true) }, 'Declarar activa'),
        h('button', { class: 'btn btn-sm', type: 'button', disabled: hiddenRevealed, onclick: declare(false) }, 'Declarar defectuosa'),
        h('button', { class: 'btn btn-sm', type: 'button', onclick: () => {
          newBomb();
          setMessage('Nueva bomba colocada. ¿Activa o defectuosa?', 'neutral');
          render();
        } }, 'Nueva bomba')),
    );
  }

  let busy = false;
  async function fire(n: number): Promise<void> {
    if (busy) return;
    if (scenario === 'hidden' && !hiddenAlive) {
      setMessage('La bomba ya explotó. Coloca una nueva para seguir.', 'bad');
      return;
    }
    if (scenario === 'hidden' && n > 1) n = 1; // en la prueba oculta cada fotón cuenta
    busy = true;
    fireOne.disabled = fireMany.disabled = true;
    try {
      const live = isLive();
      const res = await api.simulate(evCircuit(live), cfg('shots', n), { memory: true, include_state: false });
      const memory = res.shots?.memory ?? [];
      const animated = Math.min(memory.length, n === 1 ? 1 : 20);
      let last = 'd0' as Outcome;
      const tasks: Promise<void>[] = [];
      memory.forEach((bits, i) => {
        const outcome: Outcome = bits[0] === '1' ? 'boom' : bits[1] === '1' ? 'd1' : 'd0';
        last = outcome;
        const count = () => {
          counts[outcome]++;
          render();
        };
        if (i < animated) {
          tasks.push(new Promise((resolve) => setTimeout(() => {
            bench.firePhoton(outcome === 'boom' ? 'absorbed' : outcome, { measuring: live, bs2: true, duration: n === 1 ? 1600 : 900 })
              .then(() => { count(); resolve(); });
          }, i * 120)));
        } else tasks.push(Promise.all(tasks.slice(0, animated)).then(count));
      });
      await Promise.all(tasks);
      if (n === 1) {
        if (last === 'boom') {
          if (scenario === 'hidden') {
            hiddenAlive = false;
            hiddenRevealed = true;
            score.exploded++;
          }
          setMessage('¡Bum! El fotón tomó el brazo B y la bomba lo absorbió: estaba activa, pero ya no existe.', 'bad');
        } else if (last === 'd1') {
          if (scenario === 'hidden' && !hiddenRevealed) {
            score.certified++;
            hiddenRevealed = true;
            bench.setState({ obstacle: 'bomb-live' });
          }
          setMessage('Clic en D₁: sin obstáculo D₁ nunca se activa, así que la bomba está activa… y el fotón no la tocó.', 'good');
        } else {
          setMessage('Clic en D₀: inconcluso, ocurre tanto con bombas activas como defectuosas. Prueba con otro fotón.', 'neutral');
        }
      }
      render();
    } catch (e) {
      toast(e instanceof Error ? e.message : String(e), { kind: 'error' });
    } finally {
      busy = false;
      fireOne.disabled = fireMany.disabled = false;
    }
  }

  fireOne.addEventListener('click', () => fire(1));
  fireMany.addEventListener('click', () => fire(200));
  resetBtn.addEventListener('click', () => {
    counts.boom = counts.d0 = counts.d1 = 0;
    render();
  });

  // Estado inicial: φ = 0, bomba activa en el brazo B; el emulador da las amplitudes tras BS₁.
  bench.setState({ obstacle: 'bomb-live', showPhase: false, bs2: true });
  bench.setIntensities({ armA: 0.5, armB: 0.5, armBAfter: 0, d0: 0.25, d1: 0.25 });
  api.steps(evCircuit(true), cfg('statevector')).then((steps) => {
    const first = steps.steps.find((s) => s.col === 0)?.amplitudes ?? [];
    const pick = (state: string) => {
      const a = first.find((x) => x.state === state);
      return a ? { re: a.re, im: a.im } : null;
    };
    bench.setAmplitudes({ armA: pick('0'), armB: pick('1'), d0: null, d1: null });
  }).catch(() => undefined);
  setMessage('Bomba activa: en la mitad de los casos absorbe el fotón y explota.');
  refreshTheory();
}
