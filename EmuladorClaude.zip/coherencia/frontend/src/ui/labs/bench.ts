// Banco óptico compartido por los laboratorios de Mach–Zehnder y Elitzur–Vaidman.
// Dibuja el interferómetro en SVG, los fasores de amplitud y anima fotones individuales.

import { prefersReducedMotion } from '../../lib/dom';
import { phaseColor } from '../../lib/phase';

const NS = 'http://www.w3.org/2000/svg';
type Pt = [number, number];

export const GEO = {
  source: [70, 370] as Pt,
  bs1: [200, 370] as Pt,
  m1: [200, 140] as Pt,
  m2: [620, 370] as Pt,
  bs2: [620, 140] as Pt,
  d0: [760, 140] as Pt,
  d1: [620, 34] as Pt,
  phase: [340, 370] as Pt,
  block: [480, 370] as Pt,
};

export type ObstacleKind = 'none' | 'absorber' | 'bomb-live' | 'bomb-dud';

export interface BenchState {
  bs2: boolean;
  obstacle: ObstacleKind;
  showPhase: boolean;
  phaseLabel: string;
}

export interface Amplitudes {
  armA?: { re: number; im: number } | null;
  armB?: { re: number; im: number } | null;
  d0?: { re: number; im: number } | null;
  d1?: { re: number; im: number } | null;
}

function el<K extends string>(tag: K, attrs: Record<string, string | number>, parent?: Element): SVGElement {
  const e = document.createElementNS(NS, tag) as SVGElement;
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, String(v));
  parent?.appendChild(e);
  return e;
}

function lerp(a: Pt, b: Pt, t: number): Pt {
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
}

function along(path: Pt[], t: number): Pt {
  const lens = path.slice(1).map((p, i) => Math.hypot(p[0] - path[i][0], p[1] - path[i][1]));
  const total = lens.reduce((s, x) => s + x, 0);
  let d = Math.max(0, Math.min(1, t)) * total;
  for (let i = 0; i < lens.length; i++) {
    if (d <= lens[i] || i === lens.length - 1) return lerp(path[i], path[i + 1], lens[i] ? d / lens[i] : 0);
    d -= lens[i];
  }
  return path[path.length - 1];
}

export class OpticalBench {
  readonly svg: SVGSVGElement;
  private beams: Record<string, SVGElement[]> = {};
  private phasors: Record<string, { g: SVGElement; arrow: SVGElement; label: SVGElement }> = {};
  private detectors: Record<'d0' | 'd1', { box: SVGElement; led: SVGElement; count: SVGElement }>;
  private bs2: SVGElement;
  private obstacle: SVGElement;
  private boom: SVGElement;
  private phaseGroup: SVGElement;
  private phaseText: SVGElement;
  private photonLayer: SVGElement;
  private state: BenchState = { bs2: true, obstacle: 'none', showPhase: true, phaseLabel: 'φ' };

  constructor(container: HTMLElement, title: string) {
    const svg = document.createElementNS(NS, 'svg') as SVGSVGElement;
    svg.setAttribute('viewBox', '0 0 840 430');
    svg.setAttribute('class', 'bench');
    svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', title);
    this.svg = svg;
    container.appendChild(svg);
    const defs = el('defs', {}, svg);
    const pat = el('pattern', { id: 'bench-holes', width: 30, height: 30, patternUnits: 'userSpaceOnUse' }, defs);
    el('circle', { cx: 15, cy: 15, r: 1.6, class: 'table-holes' }, pat);
    el('rect', { x: 0, y: 0, width: 840, height: 430, fill: 'url(#bench-holes)' }, svg);

    // Haces (núcleo + halo), con el brazo B partido por el obstáculo.
    const beamLayer = el('g', {}, svg);
    const segs: Record<string, Pt[]> = {
      in: [GEO.source, GEO.bs1],
      armA: [GEO.bs1, GEO.m1, GEO.bs2],
      armB1: [GEO.bs1, GEO.block],
      armB2: [GEO.block, GEO.m2, GEO.bs2],
      d0: [GEO.bs2, GEO.d0],
      d1: [GEO.bs2, GEO.d1],
    };
    for (const [key, pts] of Object.entries(segs)) {
      const d = `M ${pts.map((p) => p.join(' ')).join(' L ')}`;
      const glow = el('path', { d, class: 'beam beam-glow', 'stroke-width': 9 }, beamLayer);
      const core = el('path', { d, class: 'beam beam-core', 'stroke-width': 2.2 }, beamLayer);
      this.beams[key] = [glow, core];
    }

    // Fuente.
    el('rect', { x: 14, y: 350, width: 64, height: 40, rx: 7, class: 'source-box' }, svg);
    el('circle', { cx: 68, cy: 370, r: 4, fill: '#ff6b6b' }, svg);
    el('text', { x: 46, y: 408, class: 'label-small', 'text-anchor': 'middle' }, svg).textContent = 'fuente';

    // Divisores de haz.
    const bs = (p: Pt, cls: string) => {
      const g = el('g', { class: cls }, svg);
      el('rect', { x: p[0] - 19, y: p[1] - 19, width: 38, height: 38, rx: 3, class: 'optic-bs' }, g);
      el('line', { x1: p[0] - 19, y1: p[1] + 19, x2: p[0] + 19, y2: p[1] - 19, class: 'optic-bs-face' }, g);
      return g;
    };
    bs(GEO.bs1, 'bs1');
    this.bs2 = bs(GEO.bs2, 'bs2');
    el('text', { x: GEO.bs1[0] - 34, y: GEO.bs1[1] + 36, class: 'label' }, svg).textContent = 'BS₁';
    el('text', { x: GEO.bs2[0] + 26, y: GEO.bs2[1] + 36, class: 'label' }, svg).textContent = 'BS₂';

    // Espejos.
    const mirror = (p: Pt, label: string, lx: number, ly: number) => {
      el('line', { x1: p[0] - 17, y1: p[1] + 17, x2: p[0] + 17, y2: p[1] - 17, class: 'mirror-back' }, svg);
      el('line', { x1: p[0] - 15, y1: p[1] + 15, x2: p[0] + 15, y2: p[1] - 15, class: 'optic-mirror' }, svg);
      el('text', { x: lx, y: ly, class: 'label' }, svg).textContent = label;
    };
    mirror(GEO.m1, 'M₁', GEO.m1[0] - 44, GEO.m1[1] - 8);
    mirror(GEO.m2, 'M₂', GEO.m2[0] + 22, GEO.m2[1] + 30);

    // Desfasador.
    this.phaseGroup = el('g', {}, svg);
    el('rect', { x: GEO.phase[0] - 13, y: GEO.phase[1] - 26, width: 26, height: 52, rx: 4, class: 'phase-slab' }, this.phaseGroup);
    this.phaseText = el('text', { x: GEO.phase[0], y: GEO.phase[1] + 46, class: 'label-math', 'text-anchor': 'middle' }, this.phaseGroup);
    this.phaseText.textContent = 'φ';

    // Obstáculo (absorbente o bomba).
    this.obstacle = el('g', {}, svg);
    this.boom = el('circle', { cx: GEO.block[0], cy: GEO.block[1], r: 10, class: 'boom' }, svg);

    // Detectores.
    const det = (p: Pt, key: 'd0' | 'd1', label: string, horizontal: boolean) => {
      const g = el('g', {}, svg);
      const box = horizontal
        ? el('rect', { x: p[0] - 4, y: p[1] - 24, width: 52, height: 48, rx: 8, class: 'detector' }, g)
        : el('rect', { x: p[0] - 26, y: p[1] - 26, width: 52, height: 30, rx: 8, class: 'detector' }, g);
      const led = horizontal
        ? el('circle', { cx: p[0] + 22, cy: p[1], r: 9, class: 'det-led' }, g)
        : el('circle', { cx: p[0], cy: p[1] - 11, r: 8, class: 'det-led' }, g);
      el('text', horizontal ? { x: p[0] + 22, y: p[1] + 44, class: 'label', 'text-anchor': 'middle' } : { x: p[0] + 42, y: p[1] - 6, class: 'label' }, g).textContent = label;
      const count = el('text', horizontal ? { x: p[0] + 22, y: p[1] - 34, class: 'counter', 'text-anchor': 'middle' } : { x: p[0] - 42, y: p[1] - 4, class: 'counter', 'text-anchor': 'end' }, g);
      count.textContent = '0';
      return { box, led, count };
    };
    this.detectors = { d0: det(GEO.d0, 'd0', 'D₀', true), d1: det(GEO.d1, 'd1', 'D₁', false) };

    // Etiquetas de brazos.
    el('text', { x: 410, y: 128, class: 'label', 'text-anchor': 'middle' }, svg).textContent = 'brazo A · |0⟩';
    // Entre el obstáculo y M₂, para no chocar con la etiqueta del desfasador.
    el('text', { x: 552, y: 412, class: 'label', 'text-anchor': 'middle' }, svg).textContent = 'brazo B · |1⟩';

    // Fasores.
    const phasor = (key: string, p: Pt, label: string) => {
      const g = el('g', { transform: `translate(${p[0]} ${p[1]})` }, svg);
      el('circle', { r: 24, class: 'phasor-ring' }, g);
      el('line', { x1: -24, y1: 0, x2: 24, y2: 0, class: 'phasor-axis' }, g);
      el('line', { x1: 0, y1: -24, x2: 0, y2: 24, class: 'phasor-axis' }, g);
      const arrow = el('line', { x1: 0, y1: 0, x2: 0, y2: 0, class: 'phasor-arrow' }, g);
      const lab = el('text', { y: 40, class: 'phasor-label' }, g);
      lab.textContent = label;
      this.phasors[key] = { g, arrow, label: lab };
    };
    phasor('armA', [140, 250], 'amplitud A');
    phasor('armB', [410, 300], 'amplitud B');
    phasor('d0', [700, 210], 'amplitud D₀');
    phasor('d1', [540, 64], 'amplitud D₁');

    this.photonLayer = el('g', {}, svg);
    this.setState(this.state);
  }

  setState(state: Partial<BenchState>): void {
    this.state = { ...this.state, ...state };
    const s = this.state;
    this.bs2.querySelector('rect')!.setAttribute('class', `optic-bs ${s.bs2 ? '' : 'removed'}`);
    (this.bs2.querySelector('line') as SVGElement).style.display = s.bs2 ? '' : 'none';
    this.phaseGroup.style.display = s.showPhase ? '' : 'none';
    this.phaseText.textContent = s.phaseLabel;
    this.obstacle.innerHTML = '';
    const [x, y] = GEO.block;
    if (s.obstacle === 'absorber') {
      el('rect', { x: x - 12, y: y - 24, width: 24, height: 48, rx: 4, class: 'absorber' }, this.obstacle);
      el('text', { x, y: y + 44, class: 'label-small', 'text-anchor': 'middle' }, this.obstacle).textContent = 'bloqueo';
    } else if (s.obstacle === 'bomb-live' || s.obstacle === 'bomb-dud') {
      const g = el('g', { class: `bomb ${s.obstacle === 'bomb-dud' ? 'dud' : ''}` }, this.obstacle);
      el('circle', { cx: x, cy: y + 2, r: 17, class: 'bomb-body' }, g);
      el('path', { d: `M ${x + 9} ${y - 12} q 8 -10 16 -6`, class: 'bomb-fuse' }, g);
      el('circle', { cx: x + 25, cy: y - 18, r: 4, class: 'bomb-spark' }, g);
      el('text', { x, y: y + 44, class: 'label-small', 'text-anchor': 'middle' }, this.obstacle).textContent = 'bomba';
    }
  }

  setPhaseLabel(text: string): void {
    this.phaseText.textContent = text;
  }

  /** Intensidad de cada haz (0…1), normalmente las probabilidades calculadas por el emulador. */
  setIntensities(I: { in?: number; armA: number; armB: number; armBAfter: number; d0: number; d1: number }): void {
    const set = (key: string, v: number) => {
      const [glow, core] = this.beams[key];
      core.style.opacity = String(v <= 1e-6 ? 0.06 : 0.25 + 0.75 * Math.sqrt(v));
      glow.style.opacity = String(v <= 1e-6 ? 0 : 0.4 * Math.sqrt(v));
    };
    set('in', I.in ?? 1);
    set('armA', I.armA);
    set('armB1', I.armB);
    set('armB2', I.armBAfter);
    set('d0', I.d0);
    set('d1', I.d1);
  }

  setAmplitudes(a: Amplitudes): void {
    for (const key of ['armA', 'armB', 'd0', 'd1'] as const) {
      const p = this.phasors[key];
      const z = a[key];
      if (!z) {
        p.arrow.setAttribute('x2', '0');
        p.arrow.setAttribute('y2', '0');
        p.g.setAttribute('opacity', '0.35');
        continue;
      }
      const mag = Math.hypot(z.re, z.im);
      const ang = Math.atan2(z.im, z.re);
      const r = 22 * Math.min(1, mag);
      p.g.setAttribute('opacity', '1');
      p.arrow.setAttribute('x2', String(r * Math.cos(ang)));
      p.arrow.setAttribute('y2', String(-r * Math.sin(ang)));
      p.arrow.setAttribute('stroke', mag > 1e-6 ? phaseColor(ang) : 'transparent');
    }
  }

  setCount(key: 'd0' | 'd1', n: number): void {
    this.detectors[key].count.textContent = String(n);
  }

  flash(key: 'd0' | 'd1'): void {
    const d = this.detectors[key];
    d.box.classList.add('flash');
    d.led.classList.add('on');
    setTimeout(() => {
      d.box.classList.remove('flash');
      d.led.classList.remove('on');
    }, 260);
  }

  explode(): void {
    if (prefersReducedMotion()) return;
    this.boom.animate(
      [
        { opacity: 0.95, r: '8' },
        { opacity: 0, r: '46' },
      ] as Keyframe[],
      { duration: 650, easing: 'ease-out' },
    );
  }

  /**
   * Anima un fotón. ``outcome`` decide el final: detector 0/1 o absorción en el obstáculo.
   * ``collapseAt`` indica si el obstáculo «mide» el camino (absorbente o bomba activa).
   */
  firePhoton(outcome: 'd0' | 'd1' | 'absorbed', opts: { measuring: boolean; bs2: boolean; duration?: number }): Promise<void> {
    const total = prefersReducedMotion() ? 10 : opts.duration ?? 1400;
    const mk = (opacity = 1) => el('circle', { r: 5.5, class: 'photon', opacity }, this.photonLayer);
    const whole = mk(1);
    const a = mk(0);
    const b = mk(0);
    const pathA: Pt[] = [GEO.bs1, GEO.m1, GEO.bs2];
    const pathB1: Pt[] = [GEO.bs1, GEO.block];
    const pathB2: Pt[] = [GEO.block, GEO.m2, GEO.bs2];
    const lenB1 = Math.hypot(GEO.block[0] - GEO.bs1[0], 0);
    const lenB = lenB1 + Math.hypot(GEO.m2[0] - GEO.block[0], 0) + Math.hypot(0, GEO.m2[1] - GEO.bs2[1]);
    const fracBlock = lenB1 / lenB;
    const end: Pt = outcome === 'd0' ? [GEO.d0[0] - 4, GEO.d0[1]] : [GEO.d1[0], GEO.d1[1] + 4];
    const t0 = performance.now();
    return new Promise((resolve) => {
      const frame = (now: number) => {
        const t = (now - t0) / total;
        const place = (c: SVGElement, p: Pt, op: number) => {
          c.setAttribute('cx', String(p[0]));
          c.setAttribute('cy', String(p[1]));
          c.setAttribute('opacity', String(op));
        };
        if (t < 0.2) {
          place(whole, along([GEO.source, GEO.bs1], t / 0.2), 1);
        } else if (t < 0.75) {
          const u = (t - 0.2) / 0.55;
          place(whole, GEO.bs1, 0);
          const pastBlock = u >= fracBlock;
          let opA = 0.6;
          let opB = 0.6;
          if (opts.measuring && pastBlock) {
            // El obstáculo actúa como detector: la superposición colapsa.
            if (outcome === 'absorbed') {
              opA = 0;
              opB = 0;
            } else {
              opA = 1;
              opB = 0;
            }
          }
          place(a, along(pathA, u), opA);
          if (u < fracBlock) place(b, along(pathB1, u / fracBlock), opB);
          else place(b, along(pathB2, (u - fracBlock) / (1 - fracBlock)), opB);
          if (outcome === 'absorbed' && opts.measuring && pastBlock && !this.boomed) {
            this.boomed = true;
            this.explode();
          }
        } else if (t < 1) {
          place(a, GEO.bs2, 0);
          place(b, GEO.bs2, 0);
          if (outcome !== 'absorbed') place(whole, along([GEO.bs2, end], (t - 0.75) / 0.25), 1);
        } else {
          whole.remove();
          a.remove();
          b.remove();
          this.boomed = false;
          if (outcome !== 'absorbed') this.flash(outcome);
          resolve();
          return;
        }
        requestAnimationFrame(frame);
      };
      requestAnimationFrame(frame);
    });
  }

  private boomed = false;
}

/** Curvas P(D0), P(D1) frente a φ con el punto que calcula el emulador. */
export function renderCurve(container: HTMLElement, opts: {
  theory: (phi: number) => [number, number];
  phi: number;
  emulator: [number, number] | null;
  colors: [string, string];
}): void {
  const W = Math.max(320, container.clientWidth || 520);
  const H = 220;
  const L = 36, R = 12, T = 12, B = 30;
  const x = (phi: number) => L + ((W - L - R) * phi) / (2 * Math.PI);
  const y = (p: number) => T + (H - T - B) * (1 - p);
  const parts: string[] = [];
  for (const p of [0, 0.25, 0.5, 0.75, 1]) {
    parts.push(`<line class="grid" x1="${L}" x2="${W - R}" y1="${y(p)}" y2="${y(p)}"/><text class="tick" x="${L - 6}" y="${y(p) + 4}" text-anchor="end">${p}</text>`);
  }
  const ticks: [number, string][] = [[0, '0'], [Math.PI / 2, 'π/2'], [Math.PI, 'π'], [1.5 * Math.PI, '3π/2'], [2 * Math.PI, '2π']];
  for (const [v, lbl] of ticks) parts.push(`<text class="tick" x="${x(v)}" y="${H - 10}" text-anchor="middle">${lbl}</text>`);
  for (let k = 0; k < 2; k++) {
    let d = '';
    for (let i = 0; i <= 120; i++) {
      const phi = (i / 120) * 2 * Math.PI;
      d += `${i ? 'L' : 'M'} ${x(phi).toFixed(1)} ${y(opts.theory(phi)[k]).toFixed(1)} `;
    }
    parts.push(`<path d="${d}" fill="none" stroke="${opts.colors[k]}" stroke-width="2"/>`);
  }
  parts.push(`<line class="axis" x1="${x(opts.phi)}" x2="${x(opts.phi)}" y1="${T}" y2="${H - B}" stroke-dasharray="3 3"/>`);
  if (opts.emulator) {
    opts.emulator.forEach((p, k) => {
      parts.push(`<circle cx="${x(opts.phi)}" cy="${y(p)}" r="6" fill="${opts.colors[k]}" stroke="#091018" stroke-width="2"/>`);
    });
  }
  container.innerHTML = `<svg class="curve" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-label="Probabilidad de detección en función de la fase">${parts.join('')}</svg>`;
}
