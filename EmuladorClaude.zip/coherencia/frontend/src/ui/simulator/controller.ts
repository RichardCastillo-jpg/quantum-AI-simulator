// Estado del simulador, historial, persistencia y ejecución automática.

import { api, ApiError } from '../../lib/api';
import { AutoRunner, type RunState } from '../../lib/autorun';
import { clone, emptyCircuit, reconcileInstances, removeOps, uid } from '../../lib/circuit';
import { Store } from '../../lib/store';
import type { Circuit, Health, SimConfig, SimResult, StepsResult, SubcircuitDef } from '../../lib/types';
import { toast } from '../common';
import type { ArmedTool, EditorModel, Pending } from './editor';

export interface DebugState {
  active: boolean;
  loading: boolean;
  data: StepsResult | null;
  index: number;
  error: string | null;
  playing: boolean;
}

export interface SimState {
  circuit: Circuit;
  config: SimConfig;
  selection: string[];
  selectedLoop: string | null;
  armed: ArmedTool | null;
  pending: Pending | null;
  library: SubcircuitDef[];
  result: SimResult | null;
  status: { state: RunState; elapsed?: number; message?: string; pending?: boolean; kind?: 'network' | 'circuit' | 'engine' };
  errors: Record<string, string>;
  globalErrors: string[];
  debug: DebugState;
  health: Health | null;
  history: { canUndo: boolean; canRedo: boolean };
  continuous: boolean;
  autorun: boolean;
}

export const DEFAULT_CONFIG: SimConfig = {
  mode: 'statevector',
  shots: 1024,
  seed: null,
  noise: { model: 'none', p1: 0.005, p2: 0.02, t1: 50, t2: 70, time_1q: 0.05, time_2q: 0.3, readout: 0.01 },
};

const STORAGE_KEY = 'coherencia.workspace.v1';

export function demoCircuit(): Circuit {
  const c = emptyCircuit(3, 0, 'Primer circuito');
  c.ops = [
    { id: uid(), kind: 'gate', gate: 'h', col: 0, targets: [0] },
    { id: uid(), kind: 'gate', gate: 'ry', col: 0, targets: [2], params: ['pi/3'] },
    { id: uid(), kind: 'gate', gate: 'x', col: 1, targets: [1], controls: [0] },
    { id: uid(), kind: 'gate', gate: 's', col: 1, targets: [2] },
  ];
  return c;
}

function loadWorkspace(): { circuit: Circuit; config: SimConfig } | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw);
    if (!data?.circuit?.num_qubits) return null;
    return { circuit: data.circuit, config: { ...DEFAULT_CONFIG, ...data.config, noise: { ...DEFAULT_CONFIG.noise, ...data.config?.noise } } };
  } catch {
    return null;
  }
}

export function encodeShare(circuit: Circuit): string {
  const bytes = new TextEncoder().encode(JSON.stringify(circuit));
  let bin = '';
  bytes.forEach((b) => (bin += String.fromCharCode(b)));
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function decodeShare(text: string): Circuit | null {
  try {
    const b64 = text.replace(/-/g, '+').replace(/_/g, '/');
    const bin = atob(b64 + '==='.slice((b64.length + 3) % 4));
    const bytes = Uint8Array.from(bin, (ch) => ch.charCodeAt(0));
    const data = JSON.parse(new TextDecoder().decode(bytes));
    return data?.num_qubits ? (data as Circuit) : null;
  } catch {
    return null;
  }
}

type RunReq = { circuit: Circuit; config: SimConfig };

export class SimController {
  readonly store: Store<SimState>;
  private runner: AutoRunner<RunReq, SimResult>;
  private stepRunner: AutoRunner<RunReq, StepsResult>;
  private past: { circuit: Circuit; key?: string; at: number }[] = [];
  private future: Circuit[] = [];
  private saveTimer: ReturnType<typeof setTimeout> | null = null;

  constructor() {
    const saved = loadWorkspace();
    this.store = new Store<SimState>({
      circuit: saved?.circuit ?? demoCircuit(),
      config: saved?.config ?? clone(DEFAULT_CONFIG),
      selection: [],
      selectedLoop: null,
      armed: null,
      pending: null,
      library: [],
      result: null,
      status: { state: 'idle' },
      errors: {},
      globalErrors: [],
      debug: { active: false, loading: false, data: null, index: 0, error: null, playing: false },
      health: null,
      history: { canUndo: false, canRedo: false },
      continuous: false,
      autorun: true,
    });

    this.runner = new AutoRunner<RunReq, SimResult>({
      run: (req, signal) =>
        api.simulate(req.circuit, req.config, { include_state: true, max_amplitudes: 256, max_probabilities: 64 }, signal),
      onResult: (result) => {
        this.store.set({
          result,
          errors: {},
          globalErrors: [],
          status: { state: 'ok', elapsed: result.elapsed_ms },
        });
      },
      onError: (err) => this.handleError(err),
      onState: (state, info) => {
        if (state === 'ok' || state === 'error') {
          // Los detalles se fijan en onResult/onError; aquí solo se restaura el estado al reanudar.
          if (this.store.get().status.state !== state) this.store.set((s) => ({ status: { ...s.status, state, pending: false } }));
          return;
        }
        this.store.set((s) => ({ status: { ...s.status, state, pending: info.pending } }));
      },
      debounceMs: 200,
      throttleMs: 110,
    });

    this.stepRunner = new AutoRunner<RunReq, StepsResult>({
      run: (req, signal) => api.steps(req.circuit, req.config, signal),
      onResult: (data) => {
        const d = this.store.get().debug;
        const last = data.steps.length - 1;
        const index = d.data ? Math.min(d.index, last) : last;
        this.store.set({ debug: { ...d, data, loading: false, error: null, index } });
      },
      onError: (err) => {
        const d = this.store.get().debug;
        const msg = err instanceof ApiError ? (err.errors[0]?.message ?? err.message) : String(err);
        this.store.set({ debug: { ...d, loading: false, error: msg, data: null } });
      },
      onState: (state) => {
        if (state === 'running') this.store.set((s) => ({ debug: { ...s.debug, loading: true } }));
      },
      debounceMs: 260,
      throttleMs: 200,
    });

    this.store.select(
      (s) => s.circuit,
      () => this.persist(),
    );
    this.store.select(
      (s) => s.config,
      () => this.persist(),
    );
  }

  // ------------------------------------------------------------------ arranque
  async init(): Promise<void> {
    const params = new URLSearchParams(location.search);
    const hash = location.hash.startsWith('#c=') ? decodeShare(location.hash.slice(3)) : null;
    if (hash) {
      this.loadCircuit(hash, 'Circuito compartido');
      history.replaceState(null, '', location.pathname);
    }
    const handoff = sessionStorage.getItem('coherencia.handoff');
    if (handoff) {
      sessionStorage.removeItem('coherencia.handoff');
      try {
        const data = JSON.parse(handoff);
        if (data.circuit) this.loadCircuit(data.circuit, data.circuit.name ?? 'Algoritmo');
        if (data.config) this.setConfig({ ...data.config });
      } catch {
        /* se ignora un traspaso dañado */
      }
    }
    api.health().then((health) => this.store.set({ health })).catch(() => undefined);
    await this.refreshLibrary();
    const preset = params.get('preset');
    if (preset) {
      const p: Record<string, string> = {};
      params.forEach((v, k) => k !== 'preset' && (p[k] = v));
      try {
        const circuit = await api.algorithm(preset, p);
        this.loadCircuit(circuit, circuit.name);
      } catch (err) {
        toast(err instanceof Error ? err.message : String(err), { kind: 'error' });
      }
      history.replaceState(null, '', location.pathname);
    }
    this.schedule(true);
  }

  async refreshLibrary(): Promise<void> {
    try {
      const library = await api.subcircuits();
      this.store.set({ library });
    } catch {
      /* sin backend: la biblioteca queda vacía */
    }
  }

  // ------------------------------------------------------------------ ejecución
  private request(): RunReq {
    const s = this.store.get();
    return { circuit: s.circuit, config: s.config };
  }

  schedule(immediate = false, continuous = false): void {
    const req = this.request();
    this.runner.schedule(req, { immediate, continuous });
    if (this.store.get().debug.active) this.stepRunner.schedule(req, { continuous });
  }

  runNow(): void {
    const req = this.request();
    this.runner.runNow(req);
    if (this.store.get().debug.active) this.stepRunner.runNow(req);
  }

  setAutorun(on: boolean): void {
    this.store.set({ autorun: on });
    if (on) {
      this.runner.resume();
      this.stepRunner.resume();
    } else {
      this.runner.pause();
      this.stepRunner.pause();
    }
  }

  private handleError(err: unknown): void {
    if (err instanceof ApiError) {
      const errors: Record<string, string> = {};
      const global: string[] = [];
      for (const e of err.errors) {
        if (e.op_id && this.store.get().circuit.ops.some((o) => o.id === e.op_id)) {
          errors[e.op_id] = errors[e.op_id] ? `${errors[e.op_id]} · ${e.message}` : e.message;
        } else global.push(e.message);
      }
      if (!err.errors.length) global.push(err.message);
      const kind = err.status === 0 || err.status >= 502 ? 'network' : err.status >= 500 ? 'engine' : 'circuit';
      this.store.set({ errors, globalErrors: global, status: { state: 'error', message: global[0] ?? err.message, kind } });
    } else {
      const message = err instanceof Error ? err.message : String(err);
      this.store.set({ globalErrors: [message], status: { state: 'error', message, kind: 'engine' } });
    }
  }

  // ------------------------------------------------------------------ edición
  commit(next: Circuit, opts: { label?: string; continuous?: boolean; select?: string[]; coalesce?: string } = {}): void {
    const s = this.store.get();
    if (next === s.circuit) return;
    const now = Date.now();
    const top = this.past[this.past.length - 1];
    if (!(opts.coalesce && top && top.key === opts.coalesce && now - top.at < 1500)) {
      this.past.push({ circuit: s.circuit, key: opts.coalesce, at: now });
      if (this.past.length > 150) this.past.shift();
    } else top.at = now;
    this.future = [];
    const ids = new Set(next.ops.map((o) => o.id));
    this.store.set({
      circuit: next,
      selection: opts.select ?? s.selection.filter((id) => ids.has(id)),
      selectedLoop: next.loops.some((l) => l.id === s.selectedLoop) ? s.selectedLoop : null,
      history: { canUndo: true, canRedo: false },
      continuous: !!opts.continuous,
    });
    this.schedule(false, !!opts.continuous);
  }

  undo(): void {
    const prev = this.past.pop();
    if (!prev) return;
    const s = this.store.get();
    this.future.push(s.circuit);
    this.store.set({ circuit: prev.circuit, selection: [], pending: null, history: { canUndo: this.past.length > 0, canRedo: true }, continuous: false });
    this.schedule();
  }

  redo(): void {
    const next = this.future.pop();
    if (!next) return;
    const s = this.store.get();
    this.past.push({ circuit: s.circuit, at: Date.now() });
    this.store.set({ circuit: next, selection: [], pending: null, history: { canUndo: true, canRedo: this.future.length > 0 }, continuous: false });
    this.schedule();
  }

  loadCircuit(circuit: Circuit, label = 'Cargar circuito'): void {
    const normalized: Circuit = {
      version: 1,
      name: circuit.name ?? label,
      num_qubits: circuit.num_qubits,
      num_clbits: circuit.num_clbits ?? 0,
      initial_state: circuit.initial_state || '0'.repeat(circuit.num_qubits),
      qubit_labels: circuit.qubit_labels ?? null,
      clbit_labels: circuit.clbit_labels ?? null,
      ops: (circuit.ops ?? []).map((o) => ({ ...o, id: o.id || uid() })),
      loops: (circuit.loops ?? []).map((l) => ({ ...l, id: l.id || uid('loop') })),
      meta: circuit.meta ?? {},
    };
    this.commit(normalized, { label, select: [] });
    this.store.set({ pending: null, armed: null, selectedLoop: null });
  }

  setConfig(patch: Partial<SimConfig>, continuous = false): void {
    const s = this.store.get();
    this.store.set({ config: { ...s.config, ...patch, noise: { ...s.config.noise, ...(patch.noise ?? {}) } }, continuous });
    this.schedule(false, continuous);
  }

  deleteSelection(): void {
    const s = this.store.get();
    if (s.selectedLoop) {
      const circuit = { ...s.circuit, loops: s.circuit.loops.filter((l) => l.id !== s.selectedLoop) };
      this.commit(circuit, { label: 'Quitar ciclo' });
      this.store.set({ selectedLoop: null });
      return;
    }
    if (!s.selection.length) return;
    const before = s.circuit;
    this.commit(removeOps(s.circuit, s.selection), { label: 'Eliminar', select: [] });
    toast(s.selection.length === 1 ? 'Compuerta eliminada' : `${s.selection.length} operaciones eliminadas`, {
      action: { label: 'Deshacer', run: () => this.commit(before, { label: 'Deshacer' }) },
    });
  }

  /** Tras editar un subcircuito: ajusta las instancias y vuelve a ejecutar. */
  applySubcircuitUpdate(sub: SubcircuitDef): void {
    const s = this.store.get();
    const library = s.library.some((x) => x.id === sub.id) ? s.library.map((x) => (x.id === sub.id ? sub : x)) : [...s.library, sub];
    this.store.set({ library });
    const count = s.circuit.ops.filter((o) => o.kind === 'subcircuit' && o.subcircuit_id === sub.id).length;
    const { circuit, changed, removed } = reconcileInstances(s.circuit, sub);
    if (changed || removed) this.commit(circuit, { label: `Actualizar «${sub.name}»` });
    else this.schedule(true);
    if (count) {
      toast(`«${sub.name}» actualizado en ${count} instancia${count === 1 ? '' : 's'}${removed ? ` (${removed} eliminada${removed === 1 ? '' : 's'} por no caber)` : ''}`);
    }
  }

  // ------------------------------------------------------------------ depurador
  setDebug(active: boolean): void {
    const d = this.store.get().debug;
    this.store.set({ debug: { ...d, active, playing: false, error: null, data: active ? d.data : null } });
    if (active) this.stepRunner.runNow(this.request());
    else this.stepRunner.cancel();
  }

  setStep(index: number): void {
    const d = this.store.get().debug;
    if (!d.data) return;
    const clamped = Math.max(0, Math.min(d.data.steps.length - 1, index));
    this.store.set({ debug: { ...d, index: clamped } });
  }

  private persist(): void {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => {
      const s = this.store.get();
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({ circuit: s.circuit, config: s.config }));
      } catch {
        /* almacenamiento lleno o no disponible */
      }
    }, 400);
  }

  // ------------------------------------------------------------------ modelo del editor
  editorModel(extra: Partial<EditorModel> = {}): EditorModel {
    const store = this.store;
    return {
      getCircuit: () => store.get().circuit,
      commit: (next, opts) => this.commit(next, opts),
      getLibrary: () => store.get().library,
      getSelection: () => store.get().selection,
      setSelection: (ids) => store.set({ selection: ids }),
      getSelectedLoop: () => store.get().selectedLoop,
      setSelectedLoop: (id) => store.set({ selectedLoop: id }),
      getArmed: () => store.get().armed,
      setArmed: (tool) => store.set({ armed: tool }),
      getPending: () => store.get().pending,
      setPending: (p) => store.set({ pending: p }),
      getErrors: () => store.get().errors,
      getHighlight: () => {
        const d = store.get().debug;
        if (!d.active || !d.data) return null;
        const step = d.data.steps[d.index];
        return step ? { col: step.col, activeOps: step.ops } : null;
      },
      subscribe: (fn) => {
        let last = store.get();
        return store.subscribe((s) => {
          if (
            s.circuit !== last.circuit || s.selection !== last.selection || s.selectedLoop !== last.selectedLoop ||
            s.pending !== last.pending || s.errors !== last.errors || s.library !== last.library ||
            s.debug !== last.debug || s.armed !== last.armed
          ) {
            last = s;
            fn();
          }
        });
      },
      ...extra,
    };
  }
}
