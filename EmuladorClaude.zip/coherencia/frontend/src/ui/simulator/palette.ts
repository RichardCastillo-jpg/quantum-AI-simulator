// Paleta de compuertas: arrastrar para colocar o pulsar para «armar» la herramienta.

import { h } from '../../lib/dom';
import { PALETTE, PALETTE_GROUPS, type PaletteItem } from '../../lib/gates';
import { startDrag } from '../drag';
import type { EditorModel } from './editor';

export function gateGhost(item: { label: string; category: string }): HTMLElement {
  const el = h('div', { class: `gate-ghost cat-${item.category}` }, item.label);
  return el;
}

export class Palette {
  readonly element: HTMLElement;
  private model: EditorModel;
  private buttons = new Map<string, HTMLButtonElement>();
  private unsub: () => void;

  constructor(container: HTMLElement, model: EditorModel, opts: { compact?: boolean } = {}) {
    this.model = model;
    this.element = container;
    container.classList.add('palette');
    if (opts.compact) container.classList.add('compact');
    for (const group of PALETTE_GROUPS) {
      const items = PALETTE.filter((p) => p.group === group);
      const grid = h('div', { class: 'palette-grid' });
      for (const item of items) grid.appendChild(this.tile(item));
      container.appendChild(h('section', { class: 'palette-group' }, h('h3', null, group), grid));
    }
    this.unsub = model.subscribe(() => this.sync());
    this.sync();
  }

  destroy(): void {
    this.unsub();
  }

  private tile(item: PaletteItem): HTMLButtonElement {
    const btn = h(
      'button',
      {
        class: `gate-tile cat-${item.category} ${item.label.length > 3 ? 'long' : ''}`,
        title: item.title,
        'aria-label': item.title,
        'aria-pressed': 'false',
        type: 'button',
      },
      h('span', { class: item.label.includes('|') ? 'math' : '' }, item.label),
    );
    btn.addEventListener('pointerdown', (ev) => {
      startDrag(ev, { type: 'palette', item }, {
        ghost: () => gateGhost(item),
        onClick: () => {
          const armed = this.model.getArmed();
          const same = armed?.type === 'palette' && armed.item.id === item.id;
          this.model.setPending(null);
          this.model.setArmed(same ? null : { type: 'palette', item });
        },
      });
    });
    btn.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter' || ev.key === ' ') {
        ev.preventDefault();
        const armed = this.model.getArmed();
        const same = armed?.type === 'palette' && armed.item.id === item.id;
        this.model.setArmed(same ? null : { type: 'palette', item });
      }
    });
    this.buttons.set(item.id, btn);
    return btn;
  }

  private sync(): void {
    const armed = this.model.getArmed();
    for (const [id, btn] of this.buttons) {
      const on = armed?.type === 'palette' && armed.item.id === id;
      btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    }
  }
}
