// Histograma de probabilidades (SVG). Columnas finas con extremo redondeado, rejilla tenue,
// etiquetas selectivas y tooltip por barra. En modo exacto el color de cada barra es la fase.

import { esc, h } from '../../lib/dom';
import { fmtAngle, fmtProb, ket } from '../../lib/format';
import { phaseColor, phaseWheelGradient } from '../../lib/phase';
import type { ProbEntry } from '../../lib/types';
import { hideTooltip, showTooltip } from '../common';

export interface HistogramOptions {
  colorByPhase: boolean;
  shots: number | null;
  other: number;
  truncated: boolean;
  registerLabel: string;
  highlight?: string | null;
}

const NEUTRAL = '#7fa6d6';

function niceMax(v: number): number {
  if (v >= 0.5) return 1;
  for (const step of [0.05, 0.1, 0.2, 0.25, 0.4, 0.5]) if (v <= step) return step;
  return 1;
}

function barPath(x: number, y: number, w: number, base: number, r: number): string {
  const hgt = base - y;
  if (hgt <= 0.5) return '';
  const rr = Math.min(r, w / 2, hgt);
  return `M ${x} ${base} L ${x} ${y + rr} Q ${x} ${y} ${x + rr} ${y} L ${x + w - rr} ${y} Q ${x + w} ${y} ${x + w} ${y + rr} L ${x + w} ${base} Z`;
}

export function renderHistogram(container: HTMLElement, entries: ProbEntry[], opts: HistogramOptions): void {
  const width = Math.max(280, container.clientWidth || 600);
  const items = [...entries];
  if (opts.truncated && opts.other > 1e-6) items.push({ state: 'otros', p: opts.other });
  const n = items.length;
  const height = 236;
  const longest = Math.max(1, ...items.map((e) => e.state.length));
  const rotate = n > 10 || longest * n * 7.4 > width - 60;
  const bottom = rotate ? Math.min(96, 22 + longest * 6.4) : 30;
  const left = 40;
  const right = 12;
  const top = 22;
  const plotH = height - top - bottom;
  const plotW = width - left - right;
  const band = plotW / Math.max(n, 1);
  const barW = Math.max(3, Math.min(24, band - 2));
  const maxP = Math.max(0, ...items.map((e) => e.p));
  const yMax = niceMax(maxP || 0.01);
  const y = (p: number) => top + plotH * (1 - p / yMax);
  const parts: string[] = [];
  const ticks = yMax === 1 ? [0, 0.25, 0.5, 0.75, 1] : [0, yMax / 2, yMax];
  for (const t of ticks) {
    parts.push(`<line class="grid" x1="${left}" x2="${width - right}" y1="${y(t)}" y2="${y(t)}"/>`);
    parts.push(`<text class="tick" x="${left - 6}" y="${y(t) + 4}" text-anchor="end">${t === 0 ? '0' : t.toFixed(t < 0.1 ? 2 : 2).replace(/0$/, '')}</text>`);
  }
  const labelAll = n <= 16;
  items.forEach((e, i) => {
    const x0 = left + i * band + (band - barW) / 2;
    const isOther = e.state === 'otros';
    const color = isOther ? 'var(--ink-3)' : opts.colorByPhase && e.phase !== undefined && e.p > 1e-9 ? phaseColor(e.phase) : NEUTRAL;
    const d = barPath(x0, y(e.p), barW, y(0), 4);
    const hl = opts.highlight && e.state === opts.highlight ? ' hl' : '';
    parts.push(`<g class="bar${hl}" data-i="${i}">
      <rect class="bar-hit" x="${left + i * band}" y="${top}" width="${band}" height="${plotH}"/>
      ${d ? `<path d="${d}" fill="${color}"/>` : `<line class="zero" x1="${x0}" x2="${x0 + barW}" y1="${y(0) - 0.5}" y2="${y(0) - 0.5}"/>`}
    </g>`);
    if (!isOther && e.p > 0 && ((labelAll && e.p >= 0.1) || e.p === maxP)) {
      parts.push(`<text class="vlabel" x="${x0 + barW / 2}" y="${y(e.p) - 6}" text-anchor="middle">${fmtProb(e.p)}</text>`);
    }
    const lx = left + i * band + band / 2;
    const ly = y(0) + 14;
    const text = isOther ? 'otros' : e.state;
    if (rotate) {
      parts.push(`<text class="xlabel mono" transform="translate(${lx + 3} ${ly - 4}) rotate(-60)" text-anchor="end">${esc(text)}</text>`);
    } else {
      parts.push(`<text class="xlabel mono" x="${lx}" y="${ly + 2}" text-anchor="middle">${esc(text)}</text>`);
    }
  });
  parts.push(`<line class="axis" x1="${left}" x2="${width - right}" y1="${y(0)}" y2="${y(0)}"/>`);
  const svg = `<svg class="histogram" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-label="Histograma de probabilidades sobre ${esc(opts.registerLabel)}">${parts.join('')}</svg>`;
  container.innerHTML = svg;
  const el = container.querySelector('svg')!;
  el.addEventListener('pointermove', (ev) => {
    const g = (ev.target as Element).closest('.bar');
    if (!g) {
      hideTooltip();
      return;
    }
    const e = items[Number(g.getAttribute('data-i'))];
    const lines: (Node | string)[] = [h('strong', null, e.state === 'otros' ? 'Resto de estados' : ket(e.state)), h('br')];
    lines.push(`Probabilidad ${fmtProb(e.p)} (${(e.p * 100).toFixed(2)} %)`);
    if (e.count !== undefined) lines.push(h('br'), `${e.count} de ${opts.shots} disparos`);
    if (e.phase !== undefined && opts.colorByPhase && e.p > 1e-9) lines.push(h('br'), `Fase ${fmtAngle(e.phase)}`);
    showTooltip(ev.clientX, ev.clientY, h('div', null, ...lines));
  });
  el.addEventListener('pointerleave', hideTooltip);
}

export function phaseLegend(): HTMLElement {
  return h('span', { class: 'phase-legend', title: 'El color de cada barra indica la fase de la amplitud' },
    h('i', { class: 'wheel', style: { background: phaseWheelGradient(24) } }), 'color = fase');
}
