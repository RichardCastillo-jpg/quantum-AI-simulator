// Diálogos del simulador: guardar, inspeccionar y editar subcircuitos; exportar; ciclos; algoritmos.

import { api, ApiError } from '../../lib/api';
import { addLoop, canAddLoop, clone, extractSelection, freeParams, insertColumn, isFree, opQubits, replaceWithInstance, setNumClbits, setNumQubits, uid } from '../../lib/circuit';
import { copyText, debounce, download, h } from '../../lib/dom';
import { isIdentifier } from '../../lib/expr';
import { GATES } from '../../lib/gates';
import { prettyParam } from '../../lib/format';
import { Store } from '../../lib/store';
import type { Circuit, Op, Preset, SubcircuitDef } from '../../lib/types';
import { confirmDialog, icon, openModal, promptDialog, toast } from '../common';
import { presetForm } from '../presets';
import type { SimController } from './controller';
import { CircuitEditor, type ArmedTool, type EditorModel, type Pending } from './editor';
import { Inspector } from './inspector';
import { Palette } from './palette';

const COLORS = ['aqua', 'amber', 'violet', 'blue', 'green', 'rose'];

function colorPicker(value: string, onpick: (c: string) => void): HTMLElement {
  const wrap = h('div', { class: 'swatches', role: 'radiogroup', 'aria-label': 'Color' });
  const render = (current: string) => {
    wrap.replaceChildren(...COLORS.map((c) => h('button', {
      type: 'button', role: 'radio', 'aria-checked': c === current ? 'true' : 'false', 'aria-label': c,
      class: `swatch-btn sub-${c}`, onclick: () => { onpick(c); render(c); },
    })));
  };
  render(value);
  return wrap;
}

// ------------------------------------------------------------------------- guardar
export function openSaveSubcircuit(ctrl: SimController, source: 'selection' | 'circuit'): void {
  const s = ctrl.store.get();
  const circuit = s.circuit;
  const ids = source === 'selection' ? s.selection : circuit.ops.map((o) => o.id);
  if (!ids.length) {
    toast(source === 'selection' ? 'Selecciona primero las compuertas que quieres guardar' : 'El circuito está vacío', { kind: 'error' });
    return;
  }
  const ex = extractSelection(circuit, ids);
  if (!ex) return;
  if (source === 'circuit') {
    // El circuito completo conserva todos sus cúbits y bits (aunque alguno no se use).
    ex.qubits = Array.from({ length: circuit.num_qubits }, (_, i) => i);
    ex.clbits = Array.from({ length: circuit.num_clbits }, (_, i) => i);
    const full = extractSelectionFull(circuit);
    ex.ops = full.ops;
    ex.loops = full.loops;
    ex.colStart = 0;
  }
  let color = 'rose';
  const m = openModal(source === 'selection' ? 'Guardar selección como subcircuito' : 'Guardar circuito como subcircuito');
  const name = h('input', { class: 'field', value: source === 'circuit' ? circuit.name : '', placeholder: 'Por ejemplo: Oráculo de fase', maxlength: '60' }) as HTMLInputElement;
  const desc = h('textarea', { class: 'field', placeholder: 'Qué hace y cómo se usa', maxlength: '600' }) as HTMLTextAreaElement;
  const replace = h('input', { type: 'checkbox', checked: source === 'selection' }) as HTMLInputElement;
  const err = h('p', { class: 'error-text', role: 'alert' });
  m.body.append(
    h('div', { class: 'form-grid' },
      h('label', null, h('span', { class: 'label' }, 'Nombre'), name),
      h('label', null, h('span', { class: 'label' }, 'Descripción'), desc),
      h('div', { class: 'form-row' },
        h('div', null, h('span', { class: 'label' }, 'Cúbits requeridos'), h('p', { class: 'mono' }, `${ex.qubits.length} (q${ex.qubits.join(', q')} → 0…${ex.qubits.length - 1})`)),
        h('div', null, h('span', { class: 'label' }, 'Bits clásicos'), h('p', { class: 'mono' }, String(ex.clbits.length)))),
      ex.params.length ? h('div', null, h('span', { class: 'label' }, 'Parámetros detectados'), h('p', { class: 'soft' }, ex.params.map(prettyParam).join(', '), ' — cada instancia podrá darles un valor.')) : null,
      h('div', null, h('span', { class: 'label' }, 'Color'), colorPicker(color, (c) => (color = c))),
      source === 'selection' ? h('label', { class: 'check' }, replace, 'Reemplazar la selección por el bloque') : null,
      err,
    ),
  );
  const save = h('button', { class: 'btn btn-primary' }, 'Guardar subcircuito') as HTMLButtonElement;
  m.foot.append(h('button', { class: 'btn btn-ghost', onclick: () => m.close() }, 'Cancelar'), save);
  save.addEventListener('click', async () => {
    if (!name.value.trim()) {
      err.textContent = 'Ponle un nombre al subcircuito.';
      name.focus();
      return;
    }
    save.disabled = true;
    try {
      const sub = await api.createSubcircuit({
        name: name.value.trim(), description: desc.value.trim(), num_qubits: ex.qubits.length, num_clbits: ex.clbits.length,
        params: ex.params, ops: ex.ops, loops: ex.loops, color,
      });
      ctrl.store.set({ library: [...ctrl.store.get().library, sub] });
      if (source === 'selection' && replace.checked) {
        ctrl.commit(replaceWithInstance(ctrl.store.get().circuit, ids, ex, sub), { label: 'Agrupar en subcircuito' });
      }
      toast(`Subcircuito «${sub.name}» guardado`);
      m.close();
    } catch (e) {
      err.textContent = e instanceof ApiError ? [e.message, ...e.errors.map((x) => x.message)].join(' · ') : String(e);
      save.disabled = false;
    }
  });
}

function extractSelectionFull(circuit: Circuit): { ops: Op[]; loops: Circuit['loops'] } {
  return { ops: clone(circuit.ops).map((o) => ({ ...o, id: uid() })), loops: clone(circuit.loops).map((l) => ({ ...l, id: uid('loop') })) };
}

// ------------------------------------------------------------------------- inspeccionar
export function describeOp(op: Op, label: (q: number) => string, library: SubcircuitDef[]): string {
  const ctrl = (op.controls ?? []).map(label);
  const anti = (op.anticontrols ?? []).map((q) => `¬${label(q)}`);
  const allCtrl = [...ctrl, ...anti];
  const t = op.targets.map(label).join(', ');
  const cond = op.condition?.length ? ` si ${op.condition.map((c) => `c${c.clbit}=${c.value}`).join(' y ')}` : '';
  if (op.kind === 'measure') return `Medir ${t} → c${op.clbits?.[0] ?? 0}`;
  if (op.kind === 'reset') return `Reiniciar ${t}`;
  if (op.kind === 'barrier') return 'Barrera';
  if (op.kind === 'subcircuit') {
    const sub = library.find((s) => s.id === op.subcircuit_id);
    return `«${sub?.name ?? op.subcircuit_id}» en ${t}${allCtrl.length ? ` controlado por ${allCtrl.join(', ')}` : ''}${cond}`;
  }
  const info = GATES[op.gate ?? ''];
  let name = info?.label ?? op.gate ?? '?';
  if (op.gate === 'x' && allCtrl.length === 1) name = 'CNOT';
  if (op.gate === 'x' && allCtrl.length === 2) name = 'Toffoli';
  const params = op.params?.length ? `(${op.params.map(prettyParam).join(', ')})` : '';
  if (allCtrl.length) return `${name}${params}: ${allCtrl.join(', ')} → ${t}${cond}`;
  return `${name}${params} en ${t}${cond}`;
}

function subCircuitOf(sub: SubcircuitDef): Circuit {
  return {
    version: 1, name: sub.name, num_qubits: sub.num_qubits, num_clbits: sub.num_clbits,
    initial_state: '0'.repeat(sub.num_qubits), ops: clone(sub.ops), loops: clone(sub.loops), meta: {},
  };
}

interface LocalState {
  circuit: Circuit;
  selection: string[];
  selectedLoop: string | null;
  armed: ArmedTool | null;
  pending: Pending | null;
  errors: Record<string, string>;
}

export function localModel(initial: Circuit, library: () => SubcircuitDef[], readOnly = false, labels?: string[]) {
  const store = new Store<LocalState>({ circuit: initial, selection: [], selectedLoop: null, armed: null, pending: null, errors: {} });
  const past: Circuit[] = [];
  const future: Circuit[] = [];
  const model: EditorModel = {
    readOnly,
    labels: labels ? { qubits: labels } : undefined,
    getCircuit: () => store.get().circuit,
    commit: (next, opts) => {
      past.push(store.get().circuit);
      future.length = 0;
      const ids = new Set(next.ops.map((o) => o.id));
      store.set({ circuit: next, selection: opts?.select ?? store.get().selection.filter((id) => ids.has(id)) });
    },
    getLibrary: library,
    getSelection: () => store.get().selection,
    setSelection: (ids) => store.set({ selection: ids }),
    getSelectedLoop: () => store.get().selectedLoop,
    setSelectedLoop: (id) => store.set({ selectedLoop: id }),
    getArmed: () => store.get().armed,
    setArmed: (t) => store.set({ armed: t }),
    getPending: () => store.get().pending,
    setPending: (p) => store.set({ pending: p }),
    getErrors: () => store.get().errors,
    getHighlight: () => null,
    subscribe: (fn) => store.subscribe(() => fn()),
  };
  const undo = () => {
    const prev = past.pop();
    if (!prev) return;
    future.push(store.get().circuit);
    store.set({ circuit: prev, selection: [] });
  };
  const redo = () => {
    const next = future.pop();
    if (!next) return;
    past.push(store.get().circuit);
    store.set({ circuit: next, selection: [] });
  };
  return { store, model, undo, redo };
}

export function openInspectSubcircuit(ctrl: SimController, sub: SubcircuitDef, instanceId?: string): void {
  const s = ctrl.store.get();
  const instance = instanceId ? s.circuit.ops.find((o) => o.id === instanceId) : undefined;
  const labels = Array.from({ length: sub.num_qubits }, (_, i) => (instance ? `b${i}→q${instance.targets[i]}` : `b${i}`));
  const m = openModal(`Subcircuito «${sub.name}»`, { size: 'medium' });
  const { model } = localModel(subCircuitOf(sub), () => ctrl.store.get().library, true, labels);
  const editorHost = h('div', { class: 'modal-editor' });
  const uses = s.circuit.ops.filter((o) => o.kind === 'subcircuit' && o.subcircuit_id === sub.id).length;
  const cols = [...new Set(sub.ops.map((o) => o.col))].sort((a, b) => a - b);
  const label = (q: number) => `b${q}`;
  const layers = h('ol', { class: 'layers' }, ...cols.map((c) => h('li', null,
    h('span', { class: 'muted' }, `Capa ${c}: `),
    sub.ops.filter((o) => o.col === c).map((o) => describeOp(o, label, ctrl.store.get().library)).join(' · '))));
  m.body.append(
    h('p', { class: 'soft' }, sub.description || 'Sin descripción.'),
    h('div', { class: 'chips-row' },
      h('span', { class: 'chip' }, `${sub.num_qubits} cúbit${sub.num_qubits === 1 ? '' : 's'}`),
      sub.num_clbits ? h('span', { class: 'chip' }, `${sub.num_clbits} bit(s) clásicos`) : null,
      sub.params.length ? h('span', { class: 'chip' }, `parámetros: ${sub.params.map(prettyParam).join(', ')}`) : null,
      sub.loops.length ? h('span', { class: 'chip' }, `${sub.loops.length} ciclo(s) for`) : null,
      h('span', { class: 'chip' }, uses ? `${uses} instancia(s) en el circuito` : 'sin instancias en el circuito')),
    editorHost,
    h('div', { class: 'inspect-grid' },
      h('div', null, h('h4', null, 'Orden de capas'), cols.length ? layers : h('p', { class: 'muted' }, 'Vacío')),
      instance
        ? h('div', null, h('h4', null, 'Flujo de cúbits'),
          h('table', { class: 'data-table compact' },
            h('thead', null, h('tr', null, h('th', null, 'Bloque'), h('th', null, 'Circuito'))),
            h('tbody', null, ...instance.targets.map((q, i) => h('tr', null, h('td', { class: 'mono' }, `b${i}`), h('td', { class: 'mono' }, `q${q}`))))),
          (instance.controls?.length || instance.anticontrols?.length)
            ? h('p', { class: 'hint' }, `Controlado por ${[...(instance.controls ?? []).map((q) => `q${q}`), ...(instance.anticontrols ?? []).map((q) => `¬q${q}`)].join(', ')}: cada compuerta interna hereda esos controles.`)
            : null)
        : h('div', null, h('h4', null, 'Uso'), h('p', { class: 'hint' }, 'Arrastra el subcircuito desde la biblioteca hasta la línea del primer cúbit donde quieras colocarlo; ocupa cúbits consecutivos y puedes reasignarlos en el inspector.'))),
  );
  new CircuitEditor(editorHost, model);
  m.foot.append(
    h('button', { class: 'btn btn-ghost', onclick: () => m.close() }, 'Cerrar'),
    h('button', { class: 'btn btn-primary', onclick: () => { m.close(); openEditSubcircuit(ctrl, sub); } }, icon('edit'), 'Editar subcircuito'),
  );
}

// ------------------------------------------------------------------------- editar
export function openEditSubcircuit(ctrl: SimController, sub: SubcircuitDef): void {
  const { store, model, undo, redo } = localModel(subCircuitOf(sub), () => ctrl.store.get().library.filter((x) => x.id !== sub.id));
  let color = sub.color ?? 'rose';
  let dirty = false;
  const m = openModal(`Editar «${sub.name}»`, {
    size: 'wide',
    onClose: () => {
      document.removeEventListener('keydown', onKey, true);
    },
  });
  const name = h('input', { class: 'field', value: sub.name, maxlength: '60', 'aria-label': 'Nombre' }) as HTMLInputElement;
  const desc = h('input', { class: 'field', value: sub.description, maxlength: '600', 'aria-label': 'Descripción', placeholder: 'Descripción' }) as HTMLInputElement;
  const qubits = h('input', { class: 'field mono', type: 'number', min: '1', max: '24', value: String(sub.num_qubits), 'aria-label': 'Cúbits' }) as HTMLInputElement;
  const clbits = h('input', { class: 'field mono', type: 'number', min: '0', max: '64', value: String(sub.num_clbits), 'aria-label': 'Bits clásicos' }) as HTMLInputElement;
  const paramsLine = h('p', { class: 'hint' });
  const status = h('p', { class: 'hint', role: 'status' });
  qubits.addEventListener('change', () => {
    const v = Math.max(1, Math.min(24, Math.round(Number(qubits.value) || 1)));
    qubits.value = String(v);
    model.commit(setNumQubits(store.get().circuit, v));
  });
  clbits.addEventListener('change', () => {
    const v = Math.max(0, Math.min(64, Math.round(Number(clbits.value) || 0)));
    clbits.value = String(v);
    model.commit(setNumClbits(store.get().circuit, v));
  });
  const paletteHost = h('div', { class: 'modal-palette' });
  const editorHost = h('div', { class: 'modal-editor tall' });
  const inspHost = h('div', { class: 'modal-inspector' });
  m.body.classList.add('edit-sub-body');
  m.body.append(
    h('div', { class: 'edit-sub-fields' },
      h('label', { class: 'mini-field grow' }, h('span', { class: 'label' }, 'Nombre'), name),
      h('label', { class: 'mini-field grow2' }, h('span', { class: 'label' }, 'Descripción'), desc),
      h('label', { class: 'mini-field' }, h('span', { class: 'label' }, 'Cúbits'), qubits),
      h('label', { class: 'mini-field' }, h('span', { class: 'label' }, 'Bits'), clbits),
      h('div', { class: 'mini-field color-field' }, h('span', { class: 'label' }, 'Color'), colorPicker(color, (c) => { color = c; dirty = true; }))),
    h('div', { class: 'edit-sub-grid' }, paletteHost, editorHost, inspHost),
    h('div', { class: 'edit-sub-status' }, paramsLine, status),
  );
  new Palette(paletteHost, model, { compact: true });
  new CircuitEditor(editorHost, model);
  new Inspector(inspHost, model, { extraEnv: () => Object.fromEntries(detectParams().map((p) => [p, 0])) });

  const detectParams = () => {
    const c = store.get().circuit;
    const declared = sub.params.filter((p) => isIdentifier(p));
    const found = freeParams(c.ops, c.loops.map((l) => l.var));
    return [...new Set([...declared.filter((p) => found.includes(p)), ...found])];
  };
  const validate = debounce(async () => {
    const c = store.get().circuit;
    const params = detectParams();
    paramsLine.textContent = params.length ? `Parámetros: ${params.map(prettyParam).join(', ')} (cada instancia les da un valor).` : 'Sin parámetros libres.';
    try {
      const res = await api.validateSubcircuit({
        name: name.value.trim() || sub.name, num_qubits: c.num_qubits, num_clbits: c.num_clbits, params, ops: c.ops, loops: c.loops,
      }, sub.id);
      const errors: Record<string, string> = {};
      const global: string[] = [];
      for (const e of res.errors ?? []) {
        if (e.op_id && c.ops.some((o: Op) => o.id === e.op_id)) errors[e.op_id] = e.message;
        else global.push(e.message);
      }
      store.set({ errors });
      status.textContent = res.ok ? `Válido · ${res.ops} operaciones expandidas · profundidad ${res.depth}` : global.join(' · ') || 'Hay operaciones con errores (marcadas en rojo).';
      status.classList.toggle('error-text', !res.ok);
    } catch (e) {
      status.textContent = e instanceof Error ? e.message : 'No se pudo validar con el servidor.';
    }
  }, 300);
  store.subscribe((st, prev) => {
    if (st.circuit !== prev.circuit) {
      dirty = true;
      validate();
    }
  });
  validate();

  const onKey = (ev: KeyboardEvent) => {
    const tag = (ev.target as HTMLElement).tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    const mod = ev.ctrlKey || ev.metaKey;
    if (mod && ev.key.toLowerCase() === 'z') {
      ev.preventDefault();
      ev.stopPropagation();
      if (ev.shiftKey) redo();
      else undo();
    } else if (ev.key === 'Delete' || ev.key === 'Backspace') {
      const sel = store.get().selection;
      if (sel.length) {
        ev.preventDefault();
        ev.stopPropagation();
        model.commit({ ...store.get().circuit, ops: store.get().circuit.ops.filter((o) => !sel.includes(o.id)) }, { select: [] });
      }
    } else if (ev.key === 'Escape' && (store.get().pending || store.get().armed)) {
      ev.stopPropagation();
      store.set({ pending: null, armed: null });
    }
  };
  document.addEventListener('keydown', onKey, true);

  const save = h('button', { class: 'btn btn-primary' }, 'Guardar cambios') as HTMLButtonElement;
  m.foot.append(
    h('span', { class: 'hint grow' }, 'Los cambios se aplican a todas las instancias y vuelven a ejecutar el circuito.'),
    h('button', { class: 'btn btn-ghost', onclick: async () => {
      if (!dirty || (await confirmDialog('Descartar cambios', 'Hay cambios sin guardar en el subcircuito.', 'Descartar', true))) m.close();
    } }, 'Cancelar'),
    save,
  );
  save.addEventListener('click', async () => {
    const c = store.get().circuit;
    if (!name.value.trim()) {
      status.textContent = 'El subcircuito necesita un nombre.';
      return;
    }
    save.disabled = true;
    try {
      const updated = await api.updateSubcircuit(sub.id, {
        name: name.value.trim(), description: desc.value.trim(), num_qubits: c.num_qubits, num_clbits: c.num_clbits,
        params: detectParams(), ops: c.ops, loops: c.loops, color,
      });
      ctrl.applySubcircuitUpdate(updated);
      m.close();
      toast(`Subcircuito «${updated.name}» guardado`);
    } catch (e) {
      status.textContent = e instanceof ApiError ? [e.message, ...e.errors.map((x) => x.message)].join(' · ') : String(e);
      status.classList.add('error-text');
      save.disabled = false;
    }
  });
}

// ------------------------------------------------------------------------- gestión
export async function renameSubcircuit(ctrl: SimController, sub: SubcircuitDef): Promise<void> {
  const name = await promptDialog('Renombrar subcircuito', 'Nombre', sub.name, 'Renombrar');
  if (!name || name === sub.name) return;
  try {
    const updated = await api.updateSubcircuit(sub.id, { name });
    ctrl.store.set({ library: ctrl.store.get().library.map((s) => (s.id === sub.id ? updated : s)) });
    toast(`Renombrado a «${updated.name}»`);
  } catch (e) {
    toast(e instanceof Error ? e.message : String(e), { kind: 'error' });
  }
}

export async function duplicateSubcircuit(ctrl: SimController, sub: SubcircuitDef): Promise<void> {
  try {
    const copy = await api.createSubcircuit({ ...sub, name: `${sub.name} (copia)`.slice(0, 60), ops: sub.ops, loops: sub.loops });
    ctrl.store.set({ library: [...ctrl.store.get().library, copy] });
    toast(`Duplicado como «${copy.name}»`);
  } catch (e) {
    toast(e instanceof Error ? e.message : String(e), { kind: 'error' });
  }
}

export async function deleteSubcircuit(ctrl: SimController, sub: SubcircuitDef): Promise<void> {
  const circuit = ctrl.store.get().circuit;
  const uses = circuit.ops.filter((o) => o.kind === 'subcircuit' && o.subcircuit_id === sub.id);
  let deps: { id: string; name: string }[] = [];
  try {
    deps = await api.dependents(sub.id);
  } catch {
    /* sin datos de dependencias */
  }
  const parts = [`Se eliminará «${sub.name}» de la biblioteca.`];
  if (uses.length) parts.push(`También se quitarán sus ${uses.length} instancia(s) del circuito actual.`);
  if (deps.length) parts.push(`Lo usan otros subcircuitos (${deps.map((d) => d.name).join(', ')}); dejarán de funcionar hasta que los edites.`);
  if (!(await confirmDialog('Eliminar subcircuito', parts.join(' '), 'Eliminar', true))) return;
  try {
    await api.deleteSubcircuit(sub.id, deps.length > 0);
    ctrl.store.set({ library: ctrl.store.get().library.filter((s) => s.id !== sub.id) });
    if (uses.length) ctrl.commit({ ...circuit, ops: circuit.ops.filter((o) => !uses.includes(o)) }, { label: 'Eliminar instancias' });
    toast(`«${sub.name}» eliminado`);
  } catch (e) {
    toast(e instanceof Error ? e.message : String(e), { kind: 'error' });
  }
}

/** Sustituye una instancia por las compuertas internas del subcircuito (un nivel). */
export function ungroupInstance(ctrl: SimController, opId: string): void {
  const s = ctrl.store.get();
  const op = s.circuit.ops.find((o) => o.id === opId);
  const sub = op ? s.library.find((x) => x.id === op.subcircuit_id) : undefined;
  if (!op || !sub) return;
  if (sub.params.length || sub.loops.length) {
    toast('Solo se pueden desagrupar subcircuitos sin parámetros ni ciclos', { kind: 'error' });
    return;
  }
  const width = Math.max(0, ...sub.ops.map((o) => o.col)) + 1;
  let c = clone(s.circuit);
  c.ops = c.ops.filter((o) => o.id !== opId);
  for (const o of c.ops) if (o.col > op.col) o.col += width - 1;
  for (const lp of c.loops) {
    if (lp.col_start > op.col) lp.col_start += width - 1;
    if (lp.col_end >= op.col) lp.col_end += width - 1;
  }
  const map = (q: number) => op.targets[q];
  const newIds: string[] = [];
  for (const inner of sub.ops) {
    const x: Op = clone(inner);
    x.id = uid();
    x.col = op.col + inner.col;
    x.targets = inner.targets.map(map);
    x.controls = [...(inner.controls ?? []).map(map), ...(op.controls ?? [])];
    x.anticontrols = [...(inner.anticontrols ?? []).map(map), ...(op.anticontrols ?? [])];
    if (inner.clbits) x.clbits = inner.clbits.map((cb) => op.clbits?.[cb] ?? cb);
    if (inner.condition) x.condition = inner.condition.map((cd) => ({ ...cd, clbit: op.clbits?.[cd.clbit] ?? cd.clbit }));
    if (op.condition?.length) x.condition = [...(x.condition ?? []), ...op.condition];
    if (inner.kind === 'barrier' && !inner.targets.length) x.targets = [...op.targets];
    newIds.push(x.id);
    c.ops.push(x);
  }
  // Las compuertas con controles añadidos pueden solaparse en su columna: se separan.
  for (const id of newIds) {
    const o = c.ops.find((y) => y.id === id)!;
    const qs = opQubits(o, c.num_qubits);
    const lo = Math.min(...qs);
    const hi = Math.max(...qs);
    const others = { ...c, ops: c.ops.filter((y) => y.id !== id) };
    if (!isFree(others, o.col, lo, hi)) {
      const col = o.col;
      c = insertColumn(c, col + 1);
      const moved = c.ops.find((y) => y.id === id)!;
      moved.col = col + 1;
    }
  }
  ctrl.commit(c, { label: `Desagrupar «${sub.name}»`, select: newIds });
}

// ------------------------------------------------------------------------- ciclo for
export function openLoopDialog(ctrl: SimController): void {
  const s = ctrl.store.get();
  const ops = s.circuit.ops.filter((o) => s.selection.includes(o.id));
  if (!ops.length) {
    toast('Selecciona las compuertas (o columnas) que quieres repetir', { kind: 'error' });
    return;
  }
  const start = Math.min(...ops.map((o) => o.col));
  const end = Math.max(...ops.map((o) => o.col));
  const problem = canAddLoop(s.circuit, start, end);
  if (problem) {
    toast(problem, { kind: 'error' });
    return;
  }
  const m = openModal('Repetir con un ciclo for');
  const iters = h('input', { class: 'field mono', type: 'number', min: '1', max: '10000', value: '4' }) as HTMLInputElement;
  const variable = h('input', { class: 'field mono', value: 'i', maxlength: '24' }) as HTMLInputElement;
  m.body.append(
    h('p', { class: 'soft' }, `Las columnas ${start}–${end} se repetirán sin duplicar compuertas en el lienzo. La variable puede usarse en los parámetros (por ejemplo, RZ(i·π/8)).`),
    h('div', { class: 'form-row' },
      h('label', null, h('span', { class: 'label' }, 'Iteraciones'), iters),
      h('label', null, h('span', { class: 'label' }, 'Variable'), variable)),
  );
  const ok = h('button', { class: 'btn btn-primary' }, 'Crear ciclo');
  ok.addEventListener('click', () => {
    const n = Math.max(1, Math.min(10000, Math.round(Number(iters.value) || 1)));
    if (!isIdentifier(variable.value.trim())) {
      variable.classList.add('invalid');
      return;
    }
    const next = addLoop(ctrl.store.get().circuit, start, end, n, variable.value.trim());
    ctrl.commit(next, { label: 'Crear ciclo for' });
    ctrl.store.set({ selectedLoop: next.loops[next.loops.length - 1].id, selection: [] });
    m.close();
  });
  m.foot.append(h('button', { class: 'btn btn-ghost', onclick: () => m.close() }, 'Cancelar'), ok);
}

// ------------------------------------------------------------------------- exportar
export async function openExport(ctrl: SimController): Promise<void> {
  const circuit = ctrl.store.get().circuit;
  const m = openModal('Exportar el circuito', { size: 'medium' });
  const tabs = h('div', { class: 'seg', role: 'tablist' });
  const pre = h('pre', { class: 'code' }, 'Generando…');
  const tools = h('div', { class: 'insp-actions' });
  m.body.append(tabs, pre, tools);
  const json = JSON.stringify(circuit, null, 2);
  let data: Record<string, string | null> = { json };
  try {
    const res = await api.export(circuit);
    data = { python: res.python, qasm3: res.qasm3, qasm2: res.qasm2, json };
    if (res.errors.length) tools.append(h('p', { class: 'hint' }, res.errors.join(' · ')));
  } catch (e) {
    tools.append(h('p', { class: 'error-text' }, e instanceof Error ? e.message : String(e)));
  }
  const names: [string, string, string][] = [
    ['python', 'Python (Qiskit)', 'circuito.py'],
    ['qasm3', 'OpenQASM 3', 'circuito.qasm'],
    ['qasm2', 'OpenQASM 2', 'circuito_v2.qasm'],
    ['json', 'JSON', 'circuito.json'],
  ];
  let current = data.python ? 'python' : 'json';
  const show = () => {
    tabs.replaceChildren(...names.filter(([k]) => data[k]).map(([k, label]) => h('button', { role: 'tab', 'aria-pressed': k === current ? 'true' : 'false', onclick: () => { current = k; show(); } }, label)));
    pre.textContent = data[current] ?? '';
  };
  show();
  m.foot.append(
    h('button', { class: 'btn', onclick: async () => toast((await copyText(data[current] ?? '')) ? 'Copiado al portapapeles' : 'No se pudo copiar') }, icon('copy'), 'Copiar'),
    h('button', { class: 'btn btn-primary', onclick: () => {
      const entry = names.find(([k]) => k === current)!;
      download(entry[2], data[current] ?? '', current === 'json' ? 'application/json' : 'text/plain');
    } }, icon('download'), 'Descargar'),
  );
}

// ------------------------------------------------------------------------- algoritmos
export async function openAlgorithms(ctrl: SimController): Promise<void> {
  const m = openModal('Cargar un algoritmo', { size: 'medium' });
  let presets: Preset[] = [];
  try {
    presets = await api.algorithms();
  } catch (e) {
    m.body.append(h('p', { class: 'error-text' }, e instanceof Error ? e.message : String(e)));
    return;
  }
  const list = h('div', { class: 'algo-pick' });
  const formHost = h('div', { class: 'algo-form' });
  const pick = (p: Preset) => {
    list.querySelectorAll('button').forEach((b) => b.setAttribute('aria-pressed', b.dataset.key === p.key ? 'true' : 'false'));
    formHost.replaceChildren(
      h('h3', null, p.name), h('p', { class: 'soft' }, p.summary),
      presetForm(p, async (params) => {
        try {
          const circuit = await api.algorithm(p.key, params);
          ctrl.loadCircuit(circuit, circuit.name);
          if (p.key === 'rqc' || p.key === 'shor') ctrl.setConfig({ mode: 'shots' });
          m.close();
          toast(`«${circuit.name}» cargado`);
        } catch (e) {
          toast(e instanceof Error ? e.message : String(e), { kind: 'error' });
        }
      }),
    );
  };
  for (const p of presets) list.appendChild(h('button', { class: 'algo-item', 'data-key': p.key, 'aria-pressed': 'false', onclick: () => pick(p) }, h('strong', null, p.name), h('span', null, p.tags.join(' · '))));
  m.body.append(h('div', { class: 'algo-layout' }, list, formHost));
  if (presets[0]) pick(presets[0]);
}
