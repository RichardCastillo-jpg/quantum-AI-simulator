// Editor de circuitos: cuadrícula SVG con arrastrar y soltar, colocación en varios clics,
// selección por rectángulo, ciclos for y bloques de subcircuitos.

import {
  instanceFits,
  isFree,
  lastColumn,
  moveOp,
  opAt,
  opQubits,
  opSpan,
  opsInRect,
  placeOp,
  removeOps,
  setNumClbits,
  toggleInitialBit,
  uid,
  updateOp,
  insertColumn,
  deleteColumn,
} from '../../lib/circuit';
import { esc } from '../../lib/dom';
import { categoryOf, GATES, type PaletteItem } from '../../lib/gates';
import { prettyParam } from '../../lib/format';
import type { Circuit, Op, SubcircuitDef } from '../../lib/types';
import { hideTooltip, showMenu, showTooltip, toast, type MenuItem } from '../common';
import { registerZone, startDrag, type DragPayload, type DropZone } from '../drag';

export const COL_W = 56;
export const ROW_H = 52;
export const LEFT = 98;
export const TOP = 44;
const BOX = 38;

export type ArmedTool = { type: 'palette'; item: PaletteItem } | { type: 'subcircuit'; sub: SubcircuitDef };

export interface Pending {
  item: PaletteItem;
  col: number;
  picks: number[];
}

export interface EditorModel {
  getCircuit(): Circuit;
  commit(next: Circuit, opts?: { label?: string; continuous?: boolean; select?: string[]; coalesce?: string }): void;
  getLibrary(): SubcircuitDef[];
  getSelection(): string[];
  setSelection(ids: string[]): void;
  getSelectedLoop(): string | null;
  setSelectedLoop(id: string | null): void;
  getArmed(): ArmedTool | null;
  setArmed(tool: ArmedTool | null): void;
  getPending(): Pending | null;
  setPending(p: Pending | null): void;
  getErrors(): Record<string, string>;
  getHighlight(): { col: number | null; activeOps: string[] } | null;
  subscribe(fn: () => void): () => void;
  readOnly?: boolean;
  labels?: { qubits?: string[] };
  openInstance?(opId: string): void;
  editSubcircuit?(id: string): void;
  saveSelection?(): void;
  wrapSelectionInLoop?(): void;
  ungroupInstance?(opId: string): void;
}

const CAT_VAR: Record<string, string> = {
  pauli: 'var(--cat-pauli)', clifford: 'var(--cat-clifford)', phase: 'var(--cat-phase)', rotation: 'var(--cat-rotation)',
  multi: 'var(--cat-multi)', block: 'var(--cat-block)', measure: 'var(--cat-measure)', control: 'var(--cat-control)',
};
const SUB_VAR: Record<string, string> = {
  aqua: 'var(--sub-aqua)', amber: 'var(--sub-amber)', violet: 'var(--sub-violet)', blue: 'var(--sub-blue)',
  green: 'var(--sub-green)', rose: 'var(--sub-rose)',
};

let editorCount = 0;

export function cx(col: number): number {
  return LEFT + col * COL_W + COL_W / 2;
}
export function cy(row: number): number {
  return TOP + row * ROW_H + ROW_H / 2;
}

function fit(text: string, max: number): string {
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

export class CircuitEditor implements DropZone {
  readonly element: HTMLElement;
  private svg: SVGSVGElement;
  private model: EditorModel;
  private uidPrefix = `e${++editorCount}`;
  private hoverCell: { col: number; row: number } | null = null;
  private dropPreview: { col: number; row: number; payload: DragPayload; ok: boolean } | null = null;
  private band: { x0: number; y0: number; x1: number; y1: number } | null = null;
  private cols = 16;
  private unsubs: (() => void)[] = [];
  private overlay: SVGGElement | null = null;
  private resizeObs: ResizeObserver | null = null;

  constructor(container: HTMLElement, model: EditorModel) {
    this.model = model;
    this.element = container;
    container.classList.add('editor-scroll');
    this.svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    this.svg.classList.add('circuit');
    this.svg.setAttribute('role', 'application');
    this.svg.setAttribute('aria-label', 'Editor del circuito: arrastra compuertas a las líneas de los cúbits');
    container.appendChild(this.svg);
    this.unsubs.push(model.subscribe(() => this.render()));
    if (!model.readOnly) this.unsubs.push(registerZone(this));
    this.bindEvents();
    this.resizeObs = new ResizeObserver(() => this.render());
    this.resizeObs.observe(container);
    this.render();
  }

  destroy(): void {
    this.unsubs.forEach((u) => u());
    this.resizeObs?.disconnect();
  }

  // ---------------------------------------------------------------- geometría
  private get circuit(): Circuit {
    return this.model.getCircuit();
  }

  private cellFromClient(x: number, y: number): { col: number; row: number; inside: boolean } {
    const r = this.svg.getBoundingClientRect();
    const px = x - r.left;
    const py = y - r.top;
    const col = Math.floor((px - LEFT) / COL_W);
    const row = Math.floor((py - TOP) / ROW_H);
    const inside = col >= 0 && row >= 0 && row < this.circuit.num_qubits;
    return { col: Math.max(0, col), row: Math.max(0, Math.min(this.circuit.num_qubits - 1, row)), inside };
  }

  // ---------------------------------------------------------------- render
  render(): void {
    const c = this.circuit;
    const n = c.num_qubits;
    const m = c.num_clbits;
    const avail = Math.max(0, (this.element.clientWidth || 900) - LEFT - 24);
    this.cols = Math.max(lastColumn(c) + 4, Math.floor(avail / COL_W), 8);
    const width = LEFT + this.cols * COL_W + 24;
    const busY = TOP + n * ROW_H + 22;
    const height = m > 0 ? busY + 26 : TOP + n * ROW_H + 14;
    this.svg.setAttribute('width', String(width));
    this.svg.setAttribute('height', String(height));
    this.svg.setAttribute('viewBox', `0 0 ${width} ${height}`);

    const sel = new Set(this.model.getSelection());
    const errors = this.model.getErrors();
    const highlight = this.model.getHighlight();
    const P = this.uidPrefix;
    const parts: string[] = [];

    parts.push(`<defs>
      <pattern id="${P}-holes" x="${LEFT}" y="${TOP}" width="${COL_W}" height="${ROW_H}" patternUnits="userSpaceOnUse">
        <circle cx="${COL_W / 2}" cy="${ROW_H / 2 - 16}" r="1.2" class="hole"/>
        <circle cx="${COL_W / 2}" cy="${ROW_H / 2 + 16}" r="1.2" class="hole"/>
      </pattern>
      <filter id="${P}-glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="3" result="b"/>
        <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    </defs>`);

    // Fondo perforado (las celdas donde se puede soltar una compuerta).
    parts.push(`<rect x="${LEFT}" y="${TOP}" width="${this.cols * COL_W}" height="${n * ROW_H}" fill="url(#${P}-holes)"/>`);

    // Bandas de ciclos for.
    const loops = [...c.loops].sort((a, b) => a.col_start - b.col_start || b.col_end - a.col_end);
    const depthOf = (lp: (typeof loops)[number]) =>
      loops.filter((o) => o !== lp && o.col_start <= lp.col_start && lp.col_end <= o.col_end).length;
    const selLoop = this.model.getSelectedLoop();
    for (const lp of loops) {
      const x0 = LEFT + lp.col_start * COL_W + 3;
      const w = (lp.col_end - lp.col_start + 1) * COL_W - 6;
      const d = depthOf(lp);
      parts.push(`<rect class="loop-band ${selLoop === lp.id ? 'selected' : ''}" x="${x0}" y="${TOP - 6 + d * 4}" width="${w}" height="${n * ROW_H + 12 - d * 8}" rx="10"/>`);
    }

    // Columna activa del depurador.
    if (highlight && highlight.col !== null) {
      parts.push(`<rect class="step-band" x="${LEFT + highlight.col * COL_W + 2}" y="${TOP - 4}" width="${COL_W - 4}" height="${n * ROW_H + 8}" rx="8"/>`);
    }

    // Etiquetas de cúbits y estado inicial.
    const init = (c.initial_state || '').padStart(n, '0');
    for (let q = 0; q < n; q++) {
      const y = cy(q);
      const label = this.model.labels?.qubits?.[q] ?? c.qubit_labels?.[q] ?? `q${q}`;
      const bit = init[n - 1 - q] ?? '0';
      parts.push(`<text class="qlabel" x="12" y="${y + 5}">${esc(fit(label, 6))}</text>`);
      if (this.model.readOnly) {
        parts.push(`<text class="init-ket ro" x="${LEFT - 34}" y="${y + 5}">|${bit}⟩</text>`);
      } else {
        parts.push(`<g class="init" data-init="${q}" tabindex="0" role="button" aria-label="Estado inicial de q${q}: ${bit}. Pulsa para alternar">
          <rect x="${LEFT - 52}" y="${y - 13}" width="38" height="26" rx="6"/>
          <text class="init-ket ${bit === '1' ? 'one' : ''}" x="${LEFT - 33}" y="${y + 5}">|${bit}⟩</text></g>`);
      }
      parts.push(`<line class="wire" x1="${LEFT - 10}" y1="${y}" x2="${width - 12}" y2="${y}"/>`);
    }
    if (m > 0) {
      parts.push(`<text class="qlabel" x="12" y="${busY + 5}">c</text>`);
      parts.push(`<text class="clabel" x="${LEFT - 33}" y="${busY + 4}">${m} bit${m === 1 ? '' : 's'}</text>`);
      parts.push(`<line class="bus" x1="${LEFT - 10}" y1="${busY - 2}" x2="${width - 12}" y2="${busY - 2}"/>`);
      parts.push(`<line class="bus" x1="${LEFT - 10}" y1="${busY + 2}" x2="${width - 12}" y2="${busY + 2}"/>`);
    }

    // Números de columna.
    for (let col = 0; col < this.cols; col++) {
      parts.push(`<text class="colnum" data-col="${col}" x="${cx(col)}" y="${TOP - 10}">${col}</text>`);
    }

    // Etiquetas de ciclos.
    for (const lp of loops) {
      const d = depthOf(lp);
      const x0 = LEFT + lp.col_start * COL_W + 6;
      const label = `↻ ×${lp.iterations} · ${lp.var}`;
      const w = Math.max(54, label.length * 6.4 + 14);
      parts.push(`<g class="loop-tag ${selLoop === lp.id ? 'selected' : ''}" data-loop="${esc(lp.id)}" role="button" tabindex="0" aria-label="Ciclo for ${esc(label)}">
        <rect x="${x0}" y="${4 + d * 13}" width="${w}" height="17" rx="8.5"/>
        <text x="${x0 + w / 2}" y="${16 + d * 13}">${esc(label)}</text></g>`);
    }

    // Operaciones.
    const dimAfter = highlight && highlight.col !== null ? highlight.col : null;
    const active = new Set(highlight?.activeOps ?? []);
    for (const op of c.ops) {
      const cls = ['op'];
      if (sel.has(op.id)) cls.push('selected');
      if (errors[op.id]) cls.push('has-error');
      if (dimAfter !== null && op.col > dimAfter) cls.push('future');
      if (active.has(op.id)) cls.push('active');
      parts.push(`<g class="${cls.join(' ')}" data-op="${esc(op.id)}">${this.drawOp(op, busY)}${errors[op.id] ? `<title>${esc(errors[op.id])}</title>` : ''}</g>`);
    }

    parts.push(`<g class="overlay"></g>`);
    this.svg.innerHTML = parts.join('');
    this.overlay = this.svg.querySelector('g.overlay');
    this.renderOverlay();
  }

  private drawOp(op: Op, busY: number): string {
    const c = this.circuit;
    const n = c.num_qubits;
    const x = cx(op.col);
    const [lo, hi] = opSpan(op, n);
    const out: string[] = [];
    const cat = categoryOf(op);
    const color = CAT_VAR[cat] ?? 'var(--cat-block)';
    const ctrls = op.controls ?? [];
    const antis = op.anticontrols ?? [];
    const targets = op.targets;
    const half = BOX / 2;

    // Hit area de toda la operación.
    out.push(`<rect class="hit" x="${x - COL_W / 2 + 2}" y="${cy(lo) - ROW_H / 2 + 2}" width="${COL_W - 4}" height="${(hi - lo + 1) * ROW_H - 4}" rx="8"/>`);

    if (op.kind === 'barrier') {
      out.push(`<line class="barrier" x1="${x}" y1="${cy(lo) - 22}" x2="${x}" y2="${cy(hi) + 22}"/>`);
      return out.join('');
    }

    // Conector vertical.
    if (hi > lo && !(this.isBlock(op) && ctrls.length + antis.length === 0)) {
      out.push(`<line class="connector" x1="${x}" y1="${cy(lo)}" x2="${x}" y2="${cy(hi)}"/>`);
    }

    // Control clásico.
    if (op.condition?.length && c.num_clbits > 0) {
      const ty = cy(Math.max(...targets)) + half;
      out.push(`<line class="cond-line" x1="${x + 10}" y1="${ty}" x2="${x + 10}" y2="${busY - 2}"/>`);
      const label = op.condition.map((cd) => `c${cd.clbit}=${cd.value}`).join(' ∧ ');
      const w = Math.max(40, label.length * 6.2 + 10);
      out.push(`<g class="cond-tag"><rect x="${x + 10 - w / 2}" y="${busY - 22}" width="${w}" height="15" rx="7.5"/><text x="${x + 10}" y="${busY - 11}">${esc(label)}</text></g>`);
    }

    if (op.kind === 'measure') {
      const y = cy(targets[0]);
      out.push(this.box(x, y, 'var(--cat-measure)', ''));
      out.push(`<path class="meter" d="M ${x - 11} ${y + 3} A 12 12 0 0 1 ${x + 11} ${y + 3}"/>`);
      out.push(`<line class="meter" x1="${x}" y1="${y + 4}" x2="${x + 8}" y2="${y - 9}"/>`);
      if (c.num_clbits > 0) {
        const cb = op.clbits?.[0] ?? 0;
        out.push(`<line class="mline" x1="${x - 2}" y1="${y + half}" x2="${x - 2}" y2="${busY - 6}"/>`);
        out.push(`<line class="mline" x1="${x + 2}" y1="${y + half}" x2="${x + 2}" y2="${busY - 6}"/>`);
        out.push(`<path class="marrow" d="M ${x - 6} ${busY - 9} L ${x} ${busY - 2} L ${x + 6} ${busY - 9} Z"/>`);
        const lbl = c.clbit_labels?.[cb] ?? `c${cb}`;
        out.push(`<text class="mlabel" x="${x}" y="${y + 16}">${esc(fit(lbl, 4))}</text>`);
      }
      return out.join('');
    }

    if (op.kind === 'reset') {
      const y = cy(targets[0]);
      out.push(this.box(x, y, 'var(--cat-measure)', '|0⟩', 'math'));
      return out.join('');
    }

    for (const q of ctrls) out.push(`<circle class="ctrl" cx="${x}" cy="${cy(q)}" r="5.5"/>`);
    for (const q of antis) out.push(`<circle class="actrl" cx="${x}" cy="${cy(q)}" r="5.5"/>`);

    if (op.kind === 'subcircuit') {
      const sub = this.model.getLibrary().find((s) => s.id === op.subcircuit_id);
      const subColor = sub?.color ? SUB_VAR[sub.color] ?? 'var(--cat-block)' : 'var(--cat-block)';
      out.push(this.block(op, x, sub ? sub.name : `¿${op.subcircuit_id}?`, subColor, true));
      return out.join('');
    }

    const gate = op.gate ?? '';
    const info = GATES[gate];
    if (gate === 'x' && ctrls.length + antis.length > 0) {
      for (const t of targets) {
        out.push(`<circle class="oplus" cx="${x}" cy="${cy(t)}" r="13"/>`);
        out.push(`<line class="oplus-line" x1="${x - 13}" y1="${cy(t)}" x2="${x + 13}" y2="${cy(t)}"/>`);
        out.push(`<line class="oplus-line" x1="${x}" y1="${cy(t) - 13}" x2="${x}" y2="${cy(t) + 13}"/>`);
      }
      return out.join('');
    }
    if (gate === 'swap') {
      if (targets.length === 2 && ctrls.length + antis.length === 0) {
        out.push(`<line class="connector" x1="${x}" y1="${cy(targets[0])}" x2="${x}" y2="${cy(targets[1])}"/>`);
      }
      for (const t of targets) {
        const y = cy(t);
        out.push(`<path class="swapx" d="M ${x - 8} ${y - 8} L ${x + 8} ${y + 8} M ${x + 8} ${y - 8} L ${x - 8} ${y + 8}"/>`);
      }
      return out.join('');
    }
    if (this.isBlock(op) || targets.length > 1) {
      let label = op.label ?? info?.label ?? gate;
      if (gate === 'modmul') {
        const [a, nn] = op.params ?? [];
        label = `×${prettyParam(a ?? '?')} mod ${prettyParam(nn ?? '?')}`;
      }
      out.push(this.block(op, x, label, color, false));
      return out.join('');
    }
    const y = cy(targets[0]);
    const label = op.label && op.label.length <= 4 ? op.label : info?.label ?? gate;
    const param = op.params?.length ? prettyParam(op.params[0]) + (op.params.length > 1 ? '…' : '') : '';
    out.push(this.box(x, y, color, label, label.includes('|') ? 'math' : '', param));
    return out.join('');
  }

  private isBlock(op: Op): boolean {
    if (op.kind === 'subcircuit') return true;
    const info = op.gate ? GATES[op.gate] : undefined;
    return !!info && (info.targets === 'var' || (typeof info.targets === 'number' && info.targets > 1 && op.gate !== 'swap'));
  }

  private box(x: number, y: number, color: string, label: string, font = '', param = ''): string {
    const half = BOX / 2;
    const size = label.length <= 2 ? 15 : label.length <= 4 ? 12 : 10;
    const ly = param ? y + 1 : y + 5;
    return `<rect class="tile" x="${x - half}" y="${y - half}" width="${BOX}" height="${BOX}" rx="8"/>
      <rect class="band" x="${x - half + 4}" y="${y - half}" width="${BOX - 8}" height="3" rx="1.5" style="fill:${color}"/>
      ${label ? `<text class="glabel ${font}" x="${x}" y="${ly}" style="font-size:${size}px">${esc(label)}</text>` : ''}
      ${param ? `<text class="gparam" x="${x}" y="${y + 13}">${esc(fit(param, 7))}</text>` : ''}`;
  }

  private block(op: Op, x: number, label: string, color: string, isSub: boolean): string {
    const ts = op.targets;
    const lo = Math.min(...ts);
    const hi = Math.max(...ts);
    const half = BOX / 2;
    const y0 = cy(lo) - half;
    const y1 = cy(hi) + half;
    const w = BOX + 6;
    const parts = [
      `<rect class="tile block ${isSub ? 'sub' : ''}" x="${x - w / 2}" y="${y0}" width="${w}" height="${y1 - y0}" rx="9"/>`,
      `<rect class="band" x="${x - w / 2 + 4}" y="${y0}" width="${w - 8}" height="3" rx="1.5" style="fill:${color}"/>`,
    ];
    // Filas que el bloque cruza sin usar: el cable pasa por encima.
    for (let q = lo + 1; q < hi; q++) {
      if (!ts.includes(q)) parts.push(`<line class="passthrough" x1="${x - w / 2}" y1="${cy(q)}" x2="${x + w / 2}" y2="${cy(q)}"/>`);
    }
    // Pines: índice local de cada cúbit objetivo (importa el orden en QFT, ×a mod N y subcircuitos).
    if (ts.length > 1) {
      ts.forEach((q, i) => parts.push(`<text class="pin" x="${x - w / 2 + 5}" y="${cy(q) + 4}">${i}</text>`));
    }
    const tall = hi - lo >= 1;
    if (tall) {
      const midY = (y0 + y1) / 2;
      const maxChars = Math.floor((y1 - y0 - 16) / 7.2);
      parts.push(`<text class="blabel" transform="translate(${x + 3} ${midY}) rotate(-90)" x="0" y="4">${esc(fit(label, Math.max(4, maxChars)))}</text>`);
    } else {
      parts.push(`<text class="blabel" x="${x}" y="${cy(lo) + 4}">${esc(fit(label, 6))}</text>`);
    }
    return parts.join('');
  }

  private renderOverlay(): void {
    if (!this.overlay) return;
    const c = this.circuit;
    const n = c.num_qubits;
    const parts: string[] = [];
    const pending = this.model.getPending();
    if (this.hoverCell && !this.dropPreview && !pending && !this.model.readOnly && this.hoverCell.col < this.cols) {
      const occupied = opAt(c, this.hoverCell.col, this.hoverCell.row);
      if (!occupied || this.model.getArmed()) {
        parts.push(`<rect class="cell-hover" x="${LEFT + this.hoverCell.col * COL_W + 4}" y="${TOP + this.hoverCell.row * ROW_H + 4}" width="${COL_W - 8}" height="${ROW_H - 8}" rx="8"/>`);
      }
    }
    if (this.dropPreview) {
      const { col, row, payload, ok } = this.dropPreview;
      let rows = 1;
      let start = row;
      if (payload.type === 'subcircuit') rows = payload.sub.num_qubits;
      if (payload.type === 'op') {
        const op = c.ops.find((o) => o.id === payload.opId);
        if (op) {
          const [a, b] = opSpan(op, n);
          start = a + (row - payload.grabRow);
          rows = b - a + 1;
        }
      }
      const h = Math.max(1, Math.min(rows, n - Math.max(0, start)));
      parts.push(`<rect class="drop-preview ${ok ? '' : 'bad'}" x="${LEFT + col * COL_W + 3}" y="${TOP + Math.max(0, start) * ROW_H + 3}" width="${COL_W - 6}" height="${h * ROW_H - 6}" rx="9"/>`);
    }
    if (pending) {
      const x = cx(pending.col);
      parts.push(`<rect class="pending-band" x="${LEFT + pending.col * COL_W + 2}" y="${TOP - 4}" width="${COL_W - 4}" height="${n * ROW_H + 8}" rx="8"/>`);
      const rows = [...pending.picks];
      if (this.hoverCell && !rows.includes(this.hoverCell.row)) rows.push(this.hoverCell.row);
      if (rows.length > 1) {
        parts.push(`<line class="connector pending" x1="${x}" y1="${cy(Math.min(...rows))}" x2="${x}" y2="${cy(Math.max(...rows))}"/>`);
      }
      rows.forEach((r, i) => {
        const role = pending.item.roles?.[i] ?? 'target';
        const ghost = i >= pending.picks.length ? 'ghost' : '';
        if (role === 'control') parts.push(`<circle class="ctrl pending ${ghost}" cx="${x}" cy="${cy(r)}" r="6"/>`);
        else parts.push(`<rect class="tile pending ${ghost}" x="${x - 17}" y="${cy(r) - 17}" width="34" height="34" rx="8"/><text class="glabel" x="${x}" y="${cy(r) + 5}" style="font-size:11px">${esc(pending.item.label === 'CNOT' ? 'X' : pending.item.label)}</text>`);
      });
    }
    if (this.band) {
      const { x0, y0, x1, y1 } = this.band;
      parts.push(`<rect class="rubber" x="${Math.min(x0, x1)}" y="${Math.min(y0, y1)}" width="${Math.abs(x1 - x0)}" height="${Math.abs(y1 - y0)}"/>`);
    }
    this.overlay.innerHTML = parts.join('');
  }

  // ---------------------------------------------------------------- interacción
  private bindEvents(): void {
    const svg = this.svg;
    svg.addEventListener('pointermove', (ev) => {
      if (this.band) return;
      const cell = this.cellFromClient(ev.clientX, ev.clientY);
      const next = cell.inside ? { col: cell.col, row: cell.row } : null;
      if (next?.col !== this.hoverCell?.col || next?.row !== this.hoverCell?.row) {
        this.hoverCell = next;
        this.renderOverlay();
      }
      const opEl = (ev.target as Element).closest('[data-op]');
      const id = opEl?.getAttribute('data-op');
      if (id && this.model.getErrors()[id]) showTooltip(ev.clientX, ev.clientY, this.model.getErrors()[id]);
      else hideTooltip();
    });
    svg.addEventListener('pointerleave', () => {
      this.hoverCell = null;
      hideTooltip();
      this.renderOverlay();
    });
    svg.addEventListener('pointerdown', (ev) => this.onPointerDown(ev));
    svg.addEventListener('contextmenu', (ev) => this.onContextMenu(ev));
    svg.addEventListener('dblclick', (ev) => {
      const id = (ev.target as Element).closest('[data-op]')?.getAttribute('data-op');
      const op = id ? this.circuit.ops.find((o) => o.id === id) : undefined;
      if (op?.kind === 'subcircuit') this.model.openInstance?.(op.id);
    });
    svg.addEventListener('keydown', (ev) => {
      const t = ev.target as Element;
      if ((ev.key === 'Enter' || ev.key === ' ') && t.closest('[data-init]')) {
        ev.preventDefault();
        this.model.commit(toggleInitialBit(this.circuit, Number(t.closest('[data-init]')!.getAttribute('data-init'))), { label: 'Estado inicial' });
      }
      if ((ev.key === 'Enter' || ev.key === ' ') && t.closest('[data-loop]')) {
        ev.preventDefault();
        this.model.setSelectedLoop(t.closest('[data-loop]')!.getAttribute('data-loop'));
      }
    });
  }

  private onPointerDown(ev: PointerEvent): void {
    if (ev.button !== 0) return;
    const target = ev.target as Element;
    const initEl = target.closest('[data-init]');
    if (initEl && !this.model.readOnly) {
      this.model.commit(toggleInitialBit(this.circuit, Number(initEl.getAttribute('data-init'))), { label: 'Estado inicial' });
      return;
    }
    const loopEl = target.closest('[data-loop]');
    if (loopEl) {
      this.model.setSelectedLoop(loopEl.getAttribute('data-loop'));
      this.model.setSelection([]);
      return;
    }
    const cell = this.cellFromClient(ev.clientX, ev.clientY);
    const pending = this.model.getPending();
    if (pending && !this.model.readOnly) {
      if (cell.inside) this.pickPending(cell.row);
      return;
    }
    const opEl = target.closest('[data-op]');
    const armed = this.model.readOnly ? null : this.model.getArmed();
    if (armed && cell.inside) {
      const startX = ev.clientX;
      const startY = ev.clientY;
      const up = (e: PointerEvent) => {
        window.removeEventListener('pointerup', up);
        if (Math.hypot(e.clientX - startX, e.clientY - startY) < 6) {
          this.applyDrop(armed.type === 'palette' ? { type: 'palette', item: armed.item } : { type: 'subcircuit', sub: armed.sub }, cell.col, cell.row);
        }
      };
      window.addEventListener('pointerup', up);
      return;
    }
    if (opEl) {
      const id = opEl.getAttribute('data-op')!;
      const select = (e: PointerEvent) => {
        const cur = this.model.getSelection();
        if (e.shiftKey || e.metaKey || e.ctrlKey) {
          this.model.setSelection(cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]);
        } else {
          this.model.setSelection([id]);
        }
        this.model.setSelectedLoop(null);
      };
      if (this.model.readOnly) {
        select(ev);
        return;
      }
      startDrag(ev, { type: 'op', opId: id, grabRow: cell.row, zone: this }, {
        ghost: () => this.ghostFor(id),
        onClick: select,
        onDropOutside: () => {
          const removed = this.circuit;
          this.model.commit(removeOps(removed, [id]), { label: 'Eliminar compuerta' });
          toast('Compuerta eliminada', { action: { label: 'Deshacer', run: () => this.model.commit(removed, { label: 'Deshacer eliminación' }) } });
        },
      });
      return;
    }
    if (this.model.readOnly) return;
    this.startBand(ev);
  }

  private startBand(ev: PointerEvent): void {
    const r = this.svg.getBoundingClientRect();
    const x0 = ev.clientX - r.left;
    const y0 = ev.clientY - r.top;
    let moved = false;
    const move = (e: PointerEvent) => {
      const x1 = e.clientX - r.left;
      const y1 = e.clientY - r.top;
      if (!moved && Math.hypot(x1 - x0, y1 - y0) < 6) return;
      moved = true;
      this.band = { x0, y0, x1, y1 };
      this.renderOverlay();
    };
    const up = (e: PointerEvent) => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      if (!moved) {
        this.model.setSelection([]);
        this.model.setSelectedLoop(null);
        return;
      }
      const band = this.band!;
      this.band = null;
      const c0 = Math.floor((Math.min(band.x0, band.x1) - LEFT) / COL_W);
      const c1 = Math.floor((Math.max(band.x0, band.x1) - LEFT) / COL_W);
      const r0 = Math.floor((Math.min(band.y0, band.y1) - TOP) / ROW_H);
      const r1 = Math.floor((Math.max(band.y0, band.y1) - TOP) / ROW_H);
      const ids = opsInRect(this.circuit, c0, c1, r0, r1);
      this.model.setSelection(e.shiftKey ? [...new Set([...this.model.getSelection(), ...ids])] : ids);
      this.model.setSelectedLoop(null);
      this.renderOverlay();
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  }

  private ghostFor(id: string): HTMLElement {
    const op = this.circuit.ops.find((o) => o.id === id);
    const el = document.createElement('div');
    el.className = 'gate-ghost';
    el.textContent = op?.kind === 'subcircuit' ? '▣' : op?.kind === 'measure' ? 'M' : GATES[op?.gate ?? '']?.label ?? '•';
    return el;
  }

  // ---------------------------------------------------------------- zona de soltar
  accepts(payload: DragPayload): boolean {
    return !this.model.readOnly && (payload.type !== 'op' || payload.zone === this);
  }

  hover(payload: DragPayload, x: number, y: number): void {
    const cell = this.cellFromClient(x, y);
    const ok = cell.inside && this.dropValid(payload, cell.col, cell.row);
    this.dropPreview = { col: cell.col, row: cell.row, payload, ok };
    this.renderOverlay();
  }

  leave(): void {
    this.dropPreview = null;
    this.renderOverlay();
  }

  drop(payload: DragPayload, x: number, y: number): boolean {
    const cell = this.cellFromClient(x, y);
    this.dropPreview = null;
    if (!cell.inside) {
      this.renderOverlay();
      return false;
    }
    this.applyDrop(payload, cell.col, cell.row);
    return true;
  }

  private dropValid(payload: DragPayload, col: number, row: number): boolean {
    const c = this.circuit;
    if (payload.type === 'subcircuit') return instanceFits(c, payload.sub, row) === null;
    if (payload.type === 'op') {
      const op = c.ops.find((o) => o.id === payload.opId);
      if (!op) return false;
      const delta = row - payload.grabRow;
      return opQubits(op, c.num_qubits).every((q) => q + delta >= 0 && q + delta < c.num_qubits);
    }
    if (payload.item.kind === 'control' || payload.item.kind === 'anticontrol') {
      return !!this.controlCandidate(col, row);
    }
    return true;
  }

  private controlCandidate(col: number, row: number): Op | undefined {
    const c = this.circuit;
    const candidates = c.ops.filter(
      (op) =>
        op.col === col &&
        (op.kind === 'gate' || (op.kind === 'subcircuit' && !(op.clbits ?? []).length)) &&
        !opQubits(op, c.num_qubits).includes(row),
    );
    candidates.sort((a, b) => {
      const da = Math.min(...opQubits(a, c.num_qubits).map((q) => Math.abs(q - row)));
      const db = Math.min(...opQubits(b, c.num_qubits).map((q) => Math.abs(q - row)));
      return da - db;
    });
    return candidates[0];
  }

  /** Aplica una suelta (o un clic con herramienta armada) en la celda (col, row). */
  applyDrop(payload: DragPayload, col: number, row: number): void {
    const c = this.circuit;
    const n = c.num_qubits;
    if (payload.type === 'op') {
      const next = moveOp(c, payload.opId, col, row - payload.grabRow);
      if (!next) {
        toast('La compuerta no cabe en esa posición', { kind: 'error' });
        return;
      }
      this.model.commit(next, { label: 'Mover compuerta', select: [payload.opId] });
      return;
    }
    if (payload.type === 'subcircuit') {
      const sub = payload.sub;
      const problem = instanceFits(c, sub, row);
      if (problem) {
        toast(problem, { kind: 'error' });
        return;
      }
      let base = c;
      if (sub.num_clbits > c.num_clbits) {
        base = setNumClbits(c, sub.num_clbits);
        toast(`Se añadieron bits clásicos: «${sub.name}» mide ${sub.num_clbits} bit(s)`);
      }
      const op: Op = {
        id: uid(),
        kind: 'subcircuit',
        col,
        subcircuit_id: sub.id,
        targets: Array.from({ length: sub.num_qubits }, (_, i) => row + i),
        clbits: Array.from({ length: sub.num_clbits }, (_, i) => i),
        sub_params: Object.fromEntries(sub.params.map((p) => [p, 0])),
      };
      this.model.commit(placeOp(base, op), { label: `Insertar «${sub.name}»`, select: [op.id] });
      return;
    }
    const item = payload.item;
    if (item.kind === 'control' || item.kind === 'anticontrol') {
      const target = this.controlCandidate(col, row);
      if (!target) {
        toast('Suelta el control en una columna que ya tenga una compuerta', { kind: 'error' });
        return;
      }
      const key = item.kind === 'control' ? 'controls' : 'anticontrols';
      const updated: Op = { ...target, [key]: [...(target[key] ?? []), row] };
      const [lo, hi] = opSpan(updated, n);
      let next = removeOps(c, [target.id]);
      if (!isFree(next, col, lo, hi)) next = insertColumn(next, col);
      next = placeOp(next, updated);
      this.model.commit(next, { label: 'Añadir control', select: [target.id] });
      return;
    }
    if (item.roles && item.roles.length > 1) {
      this.model.setPending({ item, col, picks: [row] });
      this.model.setSelection([]);
      return;
    }
    const op = this.buildSimpleOp(item, col, row);
    if (!op) return;
    let base = c;
    if (op.kind === 'measure' && (op.clbits?.[0] ?? 0) >= c.num_clbits) {
      base = setNumClbits(c, (op.clbits?.[0] ?? 0) + 1);
      toast(`Se añadió el bit clásico c${op.clbits?.[0]} para guardar la medición`);
    }
    this.model.commit(placeOp(base, op), { label: `Añadir ${item.title}`, select: [op.id] });
  }

  private buildSimpleOp(item: PaletteItem, col: number, row: number): Op | null {
    const c = this.circuit;
    const n = c.num_qubits;
    const base = { id: uid(), col };
    if (item.kind === 'measure') {
      const used = new Set(c.ops.filter((o) => o.kind === 'measure').map((o) => o.clbits?.[0]));
      let cb = row;
      if (used.has(cb) && c.num_clbits > 0) {
        const free = Array.from({ length: c.num_clbits }, (_, i) => i).find((i) => !used.has(i));
        if (free !== undefined) cb = free;
      }
      return { ...base, kind: 'measure', targets: [row], clbits: [cb] };
    }
    if (item.kind === 'reset') return { ...base, kind: 'reset', targets: [row] };
    if (item.kind === 'barrier') return { ...base, kind: 'barrier', targets: [] };
    const gate = item.gate!;
    if (gate === 'qft' || gate === 'iqft') {
      const k = Math.max(1, Math.min(3, n - row));
      return { ...base, kind: 'gate', gate, targets: Array.from({ length: k }, (_, i) => row + i) };
    }
    if (gate === 'modmul') {
      const avail = n - row;
      const choice = avail >= 4 ? { k: 4, a: 7, N: 15 } : avail >= 3 ? { k: 3, a: 2, N: 7 } : avail >= 2 ? { k: 2, a: 2, N: 3 } : null;
      if (!choice) {
        toast('×a mod N necesita al menos 2 cúbits a partir de esa fila', { kind: 'error' });
        return null;
      }
      return { ...base, kind: 'gate', gate, targets: Array.from({ length: choice.k }, (_, i) => row + i), params: [choice.a, choice.N] };
    }
    if (gate === 'unitary') {
      return { ...base, kind: 'gate', gate, targets: [row], matrix: [[[1, 0], [0, 0]], [[0, 0], [1, 0]]], label: 'U' };
    }
    return { ...base, kind: 'gate', gate, targets: [row], params: [...(item.params ?? [])] };
  }

  private pickPending(row: number): void {
    const pending = this.model.getPending()!;
    if (pending.picks.includes(row)) {
      toast('Ese cúbit ya forma parte de la compuerta; elige otro', { kind: 'error' });
      return;
    }
    const picks = [...pending.picks, row];
    const roles = pending.item.roles!;
    if (picks.length < roles.length) {
      this.model.setPending({ ...pending, picks });
      return;
    }
    const controls = picks.filter((_, i) => roles[i] === 'control');
    const targets = picks.filter((_, i) => roles[i] === 'target');
    const op: Op = {
      id: uid(),
      kind: 'gate',
      gate: pending.item.gate!,
      col: pending.col,
      targets,
      controls,
      params: [...(pending.item.params ?? [])],
    };
    this.model.setPending(null);
    this.model.commit(placeOp(this.circuit, op), { label: `Añadir ${pending.item.title}`, select: [op.id] });
  }

  // ---------------------------------------------------------------- menús
  private onContextMenu(ev: MouseEvent): void {
    if (this.model.readOnly) return;
    const target = ev.target as Element;
    const opEl = target.closest('[data-op]');
    const colEl = target.closest('[data-col]');
    const c = this.circuit;
    if (opEl) {
      ev.preventDefault();
      const id = opEl.getAttribute('data-op')!;
      const op = c.ops.find((o) => o.id === id)!;
      if (!this.model.getSelection().includes(id)) this.model.setSelection([id]);
      const items: MenuItem[] = [];
      if (op.kind === 'subcircuit') {
        items.push({ label: 'Inspeccionar subcircuito', run: () => this.model.openInstance?.(id) });
        if (op.subcircuit_id) items.push({ label: 'Editar definición', run: () => this.model.editSubcircuit?.(op.subcircuit_id!) });
        items.push({ label: 'Desagrupar aquí', run: () => this.model.ungroupInstance?.(id) });
        items.push({ separator: true, label: '' });
      }
      const sel = this.model.getSelection();
      items.push({ label: 'Guardar como subcircuito', run: () => this.model.saveSelection?.() });
      items.push({ label: 'Repetir con un ciclo for', run: () => this.model.wrapSelectionInLoop?.() });
      items.push({ separator: true, label: '' });
      items.push({
        label: sel.length > 1 ? `Eliminar ${sel.length} operaciones` : 'Eliminar',
        hint: 'Supr',
        danger: true,
        run: () => this.model.commit(removeOps(c, sel.length ? sel : [id]), { label: 'Eliminar' }),
      });
      showMenu(ev.clientX, ev.clientY, items);
      return;
    }
    if (colEl) {
      ev.preventDefault();
      const col = Number(colEl.getAttribute('data-col'));
      showMenu(ev.clientX, ev.clientY, [
        { label: `Insertar columna antes de la ${col}`, run: () => this.model.commit(insertColumn(c, col), { label: 'Insertar columna' }) },
        { label: `Eliminar la columna ${col}`, danger: true, run: () => this.model.commit(deleteColumn(c, col), { label: 'Eliminar columna' }) },
      ]);
      return;
    }
    const cell = this.cellFromClient(ev.clientX, ev.clientY);
    if (cell.inside) {
      ev.preventDefault();
      showMenu(ev.clientX, ev.clientY, [
        { label: `Insertar columna en la ${cell.col}`, run: () => this.model.commit(insertColumn(c, cell.col), { label: 'Insertar columna' }) },
        { label: `Eliminar la columna ${cell.col}`, danger: true, run: () => this.model.commit(deleteColumn(c, cell.col), { label: 'Eliminar columna' }) },
      ]);
    }
  }

  /** Útil para mover la selección con el teclado. */
  nudgeSelection(dCol: number, dRow: number): void {
    const sel = this.model.getSelection();
    if (sel.length !== 1) return;
    const op = this.circuit.ops.find((o) => o.id === sel[0]);
    if (!op) return;
    const next = moveOp(this.circuit, op.id, op.col + dCol, dRow);
    if (next) this.model.commit(next, { label: 'Mover compuerta', select: [op.id] });
  }

  /** Expone la actualización de parámetros para el inspector. */
  static patchOp(circuit: Circuit, id: string, patch: Partial<Op>): Circuit {
    return updateOp(circuit, id, patch);
  }
}
