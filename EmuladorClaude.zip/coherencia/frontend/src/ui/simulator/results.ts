// Panel de resultados: estado dominante, histograma, esferas de Bloch, amplitudes y análisis.

import { clear, h } from '../../lib/dom';
import { fmtAngle, fmtComplex, fmtProb, ket, trimNum } from '../../lib/format';
import { phaseColor } from '../../lib/phase';
import { GATES } from '../../lib/gates';
import type { Amplitude, BlochVector, DensityMatrix, Op, ProbEntry, SimResult } from '../../lib/types';
import { amplitudesKet, fmtProbability, type KetExpr, ketText, qubitKet } from '../../lib/dirac';
import { Bars3D } from '../bars3d';
import { BlochSphere, DEFAULT_VIEW, type View } from '../bloch';
import { icon, iconButton, toast } from '../common';
import { renderAnalysis } from './analysis';
import type { SimController, SimState } from './controller';
import { phaseLegend, renderHistogram } from './histogram';
import { densityBars, MODE_LABEL, type Mode3D, NEGATIVE, POSITIVE, probabilityBars } from './plot3d';

function readPref<T extends string>(key: string, allowed: readonly T[], fallback: T): T {
  try {
    const v = localStorage.getItem(key) as T | null;
    return v && allowed.includes(v) ? v : fallback;
  } catch {
    return fallback;
  }
}

function writePref(key: string, value: string): void {
  try {
    localStorage.setItem(key, value);
  } catch { /* sin almacenamiento */ }
}

interface View3 {
  entries: ProbEntry[];
  other: number;
  truncated: boolean;
  colorByPhase: boolean;
  shots: number | null;
  register: string;
  bloch: BlochVector[];
  amplitudes: Amplitude[] | null;
  label: string;
  density: DensityMatrix | null;
  densityNote: string;
}

export class ResultsPanel {
  readonly element: HTMLElement;
  private ctrl: SimController;
  private spheres: { sphere: BlochSphere; card: HTMLElement; info: HTMLElement }[] = [];
  private view: View = { ...DEFAULT_VIEW };
  private syncViews = true;
  private histMode: 'qubits' | 'clbits' = 'qubits';
  private histDim: '2d' | '3d' = readPref('coherencia:hist-dim', ['2d', '3d'] as const, '2d');
  private mode3d: Mode3D = readPref('coherencia:hist-3d-mode', ['probs', 're', 'im', 'abs'] as const, 'probs');
  private bars3d: Bars3D | null = null;
  private branchIndex = 0;
  private fixPhase = false;
  private sortByProb = false;
  private els: Record<string, HTMLElement> = {};
  private lastResult: SimResult | null = null;
  private lastStep = -2;
  private resizeObs: ResizeObserver;

  constructor(container: HTMLElement, ctrl: SimController) {
    this.element = container;
    this.ctrl = ctrl;
    container.classList.add('results');
    this.build();
    ctrl.store.subscribe((s, prev) => {
      if (s.result !== prev.result || s.debug !== prev.debug) this.update(s);
      if (s.status !== prev.status) this.updateStatus(s);
    });
    this.resizeObs = new ResizeObserver(() => this.renderHistogramOnly());
    this.resizeObs.observe(this.els.hist);
    this.update(ctrl.store.get());
  }

  private build(): void {
    const e = this.els;
    e.head = h('div', { class: 'results-head' });
    e.dominant = h('div', { class: 'card dominant' });
    e.histCard = h('div', { class: 'card hist-card' });
    e.hist = h('div', { class: 'hist' });
    e.hist3d = h('div', { class: 'hist3d' });
    e.blochCard = h('div', { class: 'card bloch-card' });
    e.blochGrid = h('div', { class: 'bloch-grid' });
    e.ampCard = h('div', { class: 'card amp-card' });
    e.ketCard = h('div', { class: 'card ket-card' });
    e.analysis = h('div', { class: 'card analysis-card', hidden: true });
    e.footer = h('div', { class: 'results-foot' });
    e.empty = h('div', { class: 'card empty-results' }, 'Construye un circuito: los resultados aparecerán aquí automáticamente.');

    const replay = iconButton('play', 'Repetir la animación desde el estado inicial', () => this.animateFromInitial());
    const syncBox = h('input', { type: 'checkbox', checked: true }) as HTMLInputElement;
    syncBox.addEventListener('change', () => (this.syncViews = syncBox.checked));
    e.blochCard.append(
      h('div', { class: 'card-head' }, h('h3', null, 'Esferas de Bloch'), h('div', { class: 'grow' }),
        h('label', { class: 'check' }, syncBox, 'Girar juntas'), replay),
      e.blochGrid,
      h('p', { class: 'hint' }, 'Arrastra una esfera para girarla; doble clic para volver a la vista inicial. Un vector más corto que el radio indica un cúbit entrelazado o con ruido.'),
    );
    this.element.append(e.head, e.empty, h('div', { class: 'results-grid' }, e.dominant, e.histCard, e.ketCard, e.blochCard, e.analysis, e.ampCard), e.footer);
  }

  private updateStatus(s: SimState): void {
    this.element.classList.toggle('stale', s.status.state === 'running' || s.status.state === 'scheduled');
  }

  private currentView(s: SimState): View3 | null {
    const r = s.result;
    const d = s.debug;
    if (d.active && d.data && d.data.steps[d.index]) {
      const step = d.data.steps[d.index];
      return {
        entries: step.probabilities,
        other: step.probabilities_other,
        truncated: step.probabilities_truncated,
        colorByPhase: !!step.amplitudes,
        shots: null,
        register: 'cúbits',
        bloch: step.bloch,
        amplitudes: step.amplitudes,
        density: null,
        densityNote: 'La matriz densidad se muestra para el estado final: sal del depurador para verla.',
        label: `${step.index < 0 ? 'Estado inicial' : `Paso ${step.index + 1} de ${d.data.steps.length - 1}`} · ${step.index < 0 ? 'antes de la primera columna' : step.label}`,
      };
    }
    if (!r) return null;
    const state = r.state;
    let entries = r.histogram?.entries ?? [];
    let other = r.histogram?.other ?? 0;
    let truncated = r.histogram?.truncated ?? false;
    let register = r.histogram?.register === 'clbits' ? 'bits clásicos' : 'cúbits';
    let colorByPhase = r.mode === 'statevector' && !!state?.amplitudes;
    if (r.mode === 'statevector' && this.histMode === 'clbits' && r.classical) {
      entries = r.classical.entries;
      other = r.classical.other;
      truncated = r.classical.truncated;
      register = 'bits clásicos';
      colorByPhase = false;
    }
    const label = r.mode === 'shots'
      ? `${r.shots?.shots ?? 0} disparos · método ${r.shots?.method ?? ''}`
      : state?.kind === 'mixed' ? `Estado exacto (mixto, pureza ${trimNum(state.purity, 3)})` : 'Estado exacto (vector de estado)';
    return {
      entries, other, truncated, colorByPhase, shots: r.histogram?.shots ?? null, register,
      bloch: state?.bloch ?? [], amplitudes: state?.amplitudes ?? null, label,
      density: state?.density ?? null,
      densityNote: state ? 'La vista 3D de la matriz densidad está disponible hasta 5 cúbits.' : 'Sin estado exacto que mostrar.',
    };
  }

  private update(s: SimState): void {
    const r = s.result;
    const v = this.currentView(s);
    this.els.empty.hidden = !!v;
    for (const k of ['dominant', 'histCard', 'blochCard', 'ampCard']) this.els[k].hidden = !v;
    if (!v) this.els.ketCard.hidden = true;
    if (!v) {
      this.els.analysis.hidden = true;
      clear(this.els.head);
      return;
    }
    this.renderHead(s, v);
    this.renderDominant(s, v);
    this.renderHistCard(s, v);
    this.renderKets(s, v);
    const debugIndex = s.debug.active && s.debug.data ? s.debug.index : -2;
    const fromInitial = !s.debug.active && r !== this.lastResult && !s.continuous;
    const quick = s.continuous || (s.debug.active && debugIndex !== this.lastStep);
    this.renderBloch(v.bloch, r?.bloch_initial ?? [], fromInitial, quick);
    this.lastResult = r;
    this.lastStep = debugIndex;
    this.renderAmplitudes(s, v);
    const analysis = s.debug.active ? null : renderAnalysis(r?.analysis);
    this.els.analysis.hidden = !analysis;
    clear(this.els.analysis);
    if (analysis) {
      this.els.analysis.append(h('div', { class: 'card-head' }, h('h3', null, r?.analysis?.title ?? 'Análisis')), analysis);
    }
    this.renderFooter(s);
  }

  private renderHead(s: SimState, v: View3): void {
    clear(this.els.head);
    this.els.head.append(
      h('h2', null, s.debug.active ? 'Depurador paso a paso' : 'Resultados'),
      h('span', { class: 'chip' }, v.label),
    );
  }

  private renderDominant(s: SimState, v: View3): void {
    const el = this.els.dominant;
    clear(el);
    const best = v.entries.reduce<ProbEntry | null>((acc, e) => (!acc || e.p > acc.p ? e : acc), null);
    el.append(h('div', { class: 'card-head' }, h('h3', null, 'Estado dominante')));
    if (!best) {
      el.append(h('p', { class: 'muted' }, 'Sin datos'));
      return;
    }
    const ring = h('div', { class: 'prob-ring', style: { background: `conic-gradient(var(--accent) ${best.p * 360}deg, var(--panel-3) 0)` } },
      h('div', { class: 'prob-ring-in' }, h('span', null, `${(best.p * 100).toFixed(best.p > 0.9995 ? 0 : 1)}`), h('small', null, '%')));
    const len = best.state.length;
    const size = len <= 4 ? '' : len <= 7 ? 'mid' : len <= 11 ? 'small' : 'tiny';
    el.append(
      h('div', { class: 'dominant-row' },
        h('div', { class: `dominant-ket math ${size}` }, ket(best.state)),
        ring,
      ),
      h('p', { class: 'soft' },
        best.count !== undefined ? `${best.count} de ${v.shots} disparos en ${v.register}` : `Probabilidad ${fmtProb(best.p)} sobre los ${v.register}`),
      h('p', { class: 'hint' }, 'Orden de Qiskit: el bit de la derecha corresponde a q0 (o c0).'),
    );
    const r = s.result;
    if (r?.state && r.state.kind === 'mixed' && !s.debug.active) {
      el.append(h('p', { class: 'hint' }, `Estado mixto: pureza Tr(ρ²) = ${trimNum(r.state.purity, 3)}.`));
    }
  }

  private renderHistCard(s: SimState, v: View3): void {
    const card = this.els.histCard;
    clear(card);
    const r = s.result;
    const is3d = this.histDim === '3d';
    const mode: Mode3D = is3d && this.mode3d !== 'probs' && v.density ? this.mode3d : 'probs';
    const head = h('div', { class: 'card-head' }, h('h3', null, mode === 'probs' ? 'Probabilidades' : 'Matriz densidad ρ'), h('div', { class: 'grow' }));
    if ((mode === 'probs' && v.colorByPhase) || mode === 'abs') head.append(phaseLegend());
    if (mode === 're' || mode === 'im') {
      const sw = (rgb: number[], text: string) => h('span', { class: 'sign-key' }, h('i', { style: { background: `rgb(${rgb.join(' ')})` } }), text);
      head.append(h('span', { class: 'sign-legend' }, sw(POSITIVE, 'positivo'), sw(NEGATIVE, 'negativo')));
    }
    if (mode === 'probs' && !s.debug.active && r?.mode === 'statevector' && r.classical) {
      const seg = h('div', { class: 'seg' },
        h('button', { 'aria-pressed': this.histMode === 'qubits' ? 'true' : 'false', onclick: () => { this.histMode = 'qubits'; this.update(this.ctrl.store.get()); } }, 'Cúbits'),
        h('button', { 'aria-pressed': this.histMode === 'clbits' ? 'true' : 'false', onclick: () => { this.histMode = 'clbits'; this.update(this.ctrl.store.get()); } }, 'Bits clásicos'),
      );
      head.append(seg);
    }
    const setDim = (dim: '2d' | '3d') => {
      this.histDim = dim;
      writePref('coherencia:hist-dim', dim);
      this.update(this.ctrl.store.get());
    };
    head.append(h('div', { class: 'seg', role: 'group', 'aria-label': 'Tipo de gráfico' },
      h('button', { 'aria-pressed': is3d ? 'false' : 'true', onclick: () => setDim('2d') }, '2D'),
      h('button', { 'aria-pressed': is3d ? 'true' : 'false', onclick: () => setDim('3d'), title: 'Barras en 3D que puedes girar' }, '3D')));
    card.append(head);

    if (!is3d) {
      card.append(this.els.hist);
      this.lastHist = v;
      this.renderHistogramOnly();
      return;
    }

    const setMode = (m: Mode3D) => {
      this.mode3d = m;
      writePref('coherencia:hist-3d-mode', m);
      this.update(this.ctrl.store.get());
    };
    const modeSeg = h('div', { class: 'seg seg-modes', role: 'group', 'aria-label': 'Qué representar' },
      ...(['probs', 're', 'im', 'abs'] as Mode3D[]).map((m) => {
        const needsRho = m !== 'probs';
        const disabled = needsRho && !v.density;
        return h('button', {
          'aria-pressed': mode === m ? 'true' : 'false',
          disabled,
          title: disabled ? v.densityNote : m === 'probs' ? 'Probabilidad de cada resultado' : m === 'abs' ? 'Módulo de cada elemento de ρ; el color es su fase' : `Parte ${m === 're' ? 'real' : 'imaginaria'} de cada elemento de ρ`,
          onclick: () => setMode(m),
        }, MODE_LABEL[m]);
      }));
    const name = s.circuit.name || 'circuito';
    const tools = h('div', { class: 'tools3d' },
      iconButton('minus', 'Alejar', () => this.bars3d?.zoomBy(1 / 1.2)),
      iconButton('plus', 'Acercar', () => this.bars3d?.zoomBy(1.2)),
      h('button', { class: 'btn btn-sm', title: 'Volver a la vista inicial (doble clic en el gráfico)', onclick: () => this.bars3d?.resetView() }, 'Vista inicial'),
      h('button', { class: 'btn btn-sm', title: 'Descargar la figura en PNG con fondo blanco, lista para un documento', onclick: () => {
        if (!this.bars3d) return;
        const a = h('a', { href: this.bars3d.toPNG(), download: `${name.replace(/[^\w\-áéíóúñ ]+/gi, '').trim() || 'circuito'} - ${MODE_LABEL[mode].replace('|ρ|', 'modulo rho').replace('ρ', 'rho')}.png` });
        document.body.append(a);
        a.click();
        a.remove();
        toast('Figura descargada en PNG');
      } }, icon('download'), 'PNG'));
    card.append(h('div', { class: 'toolbar3d' }, modeSeg, tools), this.els.hist3d);
    if (!this.bars3d) this.bars3d = new Bars3D(this.els.hist3d, 400);
    const title = `${name} · ${MODE_LABEL[mode]}`;
    this.bars3d.set(mode === 'probs'
      ? probabilityBars({ entries: v.entries, other: v.other, truncated: v.truncated, colorByPhase: v.colorByPhase, shots: v.shots, register: v.register, title })
      : densityBars(v.density!, mode, title));
    const notes: string[] = [];
    if (mode !== 'probs' && v.density) {
      notes.push(`ρ de ${v.density.n} cúbit${v.density.n === 1 ? '' : 's'} en el estado exacto${r?.mode === 'shots' ? ' (no de los conteos)' : ''}${r?.state?.kind === 'mixed' ? `, pureza ${trimNum(r.state.purity, 3)}` : ''}. La diagonal son las poblaciones y fuera de ella están las coherencias.`);
    } else if (mode === 'probs' && v.entries.length && v.entries[0].state.length > 1 && !v.truncated) {
      notes.push('Cada eje agrupa la mitad de los bits: el estado de una barra se lee juntando la fila y la columna.');
    }
    notes.push('Arrastra para girar, Mayús + arrastrar para mover, Ctrl + rueda o los botones para acercar y doble clic para volver a la vista inicial.');
    card.append(h('p', { class: 'hint' }, notes.join(' ')));
  }

  private renderKets(s: SimState, v: View3): void {
    const card = this.els.ketCard;
    clear(card);
    const d = s.debug;
    const n = v.bloch.length;
    const psi = amplitudesKet(v.amplitudes, 16);
    if (!psi && !n) {
      card.hidden = true;
      return;
    }
    card.hidden = false;
    const step = d.active && d.data ? d.data.steps[d.index] : null;
    const prev = d.active && d.data && d.index > 0 ? d.data.steps[d.index - 1] : null;
    const head = h('div', { class: 'card-head' }, h('h3', null, 'Estado en notación de Dirac'), h('div', { class: 'grow' }));
    if (step) {
      const byId = new Map(s.circuit.ops.map((o) => [o.id, o]));
      const names = step.ops.map((id) => byId.get(id)).filter((o): o is Op => !!o).map(describeOp).filter(Boolean);
      head.append(h('span', { class: 'ket-step' },
        step.index < 0 ? 'Estado inicial' : `Paso ${step.index + 1}: ${names.length ? names.join(' · ') : step.label}`));
    }
    card.append(head);

    if (psi) {
      card.append(h('p', { class: 'ket-line', 'aria-label': `psi igual a ${ketText(psi)}` },
        h('span', { class: 'ket-psi' }, '|ψ⟩ = '), renderKet(psi)));
    } else {
      card.append(h('p', { class: 'hint ket-mixed' },
        'El estado conjunto es mixto (por ruido o por una medición): no se puede escribir como un solo ket. Abajo, cada cúbit por separado.'));
    }

    if (n && n <= 12) {
      const rows = h('div', { class: 'ket-qubits', role: 'list' });
      for (let q = 0; q < n; q++) {
        const b = v.bloch[q];
        const now = qubitKet(b);
        const before = prev ? qubitKet(prev.bloch[q]) : null;
        const beforeText = prev ? (before ? ketText(before) : 'entrelazado') : null;
        const nowText = now ? ketText(now) : 'entrelazado';
        const changed = prev !== null && beforeText !== nowText;
        const expr = h('span', { class: 'ket-q-expr' });
        if (changed) {
          expr.append(before ? renderKet(before) : h('span', { class: 'ket-ent' }, 'entrelazado'), h('span', { class: 'ket-arrow', 'aria-label': 'pasa a' }, ' → '));
        }
        expr.append(now ? renderKet(now) : h('span', { class: 'ket-ent', title: 'Su vector de Bloch es más corto que el radio: el cúbit está entrelazado con otros (o tiene ruido) y no tiene un estado propio.' },
          `entrelazado (|r| = ${trimNum(b.r, 2)})`));
        rows.append(h('div', { class: `ket-q${changed ? ' changed' : ''}`, role: 'listitem' },
          h('span', { class: 'ket-q-name' }, `q${q}`),
          expr,
          h('span', { class: 'ket-q-prob' }, `P(0) = ${fmtProbability(1 - b.p1)} · P(1) = ${fmtProbability(b.p1)}`)));
      }
      card.append(rows);
    }
    const note = d.active
      ? 'Los cúbits resaltados cambiaron en este paso. La amplitud es el número delante de cada ket; la probabilidad es su módulo al cuadrado (1/√2 → 1/2).'
      : 'La amplitud es el número delante de cada ket; la probabilidad es su módulo al cuadrado (1/√2 → 1/2). Un cúbit entrelazado no tiene un estado propio.';
    card.append(h('p', { class: 'hint' }, note));
  }

  private lastHist: View3 | null = null;

  private renderHistogramOnly(): void {
    const v = this.lastHist;
    if (!v || this.histDim === '3d') return;
    renderHistogram(this.els.hist, v.entries, {
      colorByPhase: v.colorByPhase,
      shots: v.shots,
      other: v.other,
      truncated: v.truncated,
      registerLabel: v.register,
    });
  }

  private ensureSpheres(n: number): void {
    const narrow = window.matchMedia('(max-width: 760px)').matches;
    const size = narrow ? (n <= 1 ? 156 : 128) : n <= 4 ? 156 : n <= 10 ? 132 : 112;
    while (this.spheres.length > n) {
      const s = this.spheres.pop()!;
      s.sphere.destroy();
      s.card.remove();
    }
    while (this.spheres.length < n) {
      const q = this.spheres.length;
      const canvas = h('canvas', { 'aria-label': `Esfera de Bloch del cúbit q${q}`, role: 'img' }) as HTMLCanvasElement;
      const info = h('div', { class: 'bloch-info' });
      const card = h('figure', { class: 'bloch-item' }, canvas, h('figcaption', null, h('strong', null, `q${q}`), info));
      this.els.blochGrid.appendChild(card);
      const sphere = new BlochSphere(canvas, size, this.view);
      sphere.onViewChange = (view) => {
        this.view = view;
        if (this.syncViews) this.spheres.forEach((o) => o.sphere !== sphere && o.sphere.setView(view));
      };
      this.spheres.push({ sphere, card, info });
    }
    this.spheres.forEach((s) => {
      if (s.sphere.canvas.width !== Math.round(size * Math.min(window.devicePixelRatio || 1, 2))) s.sphere.resize(size);
    });
  }

  private renderBloch(bloch: BlochVector[], initial: BlochVector[], fromInitial: boolean, quick: boolean): void {
    this.ensureSpheres(bloch.length);
    bloch.forEach((b, q) => {
      const s = this.spheres[q];
      const target = { x: b.x, y: b.y, z: b.z };
      if (fromInitial && initial[q]) {
        s.sphere.setVector(target, { from: { x: initial[q].x, y: initial[q].y, z: initial[q].z }, duration: 850 });
      } else {
        s.sphere.setVector(target, { duration: quick ? 260 : 500 });
      }
      clear(s.info);
      const mixed = b.r < 0.999;
      s.info.append(
        h('span', { class: 'mono' }, `θ ${fmtAngle(b.theta)} · φ ${fmtAngle(b.phi)}`),
        h('span', { class: 'mono soft' }, `P(1) ${fmtProb(b.p1)}`),
        h('span', { class: 'purity', title: `Pureza del cúbit ${trimNum(b.purity, 3)} · entropía ${trimNum(b.entropy, 3)} bits` },
          h('i', { style: { width: `${Math.max(0, Math.min(1, (b.purity - 0.5) / 0.5)) * 100}%` } })),
      );
      if (mixed) s.info.append(h('span', { class: 'hint' }, `|r| = ${trimNum(b.r, 3)}`));
    });
  }

  private animateFromInitial(): void {
    const s = this.ctrl.store.get();
    const v = this.currentView(s);
    if (!v) return;
    const init = s.result?.bloch_initial ?? [];
    v.bloch.forEach((b, q) => {
      const from = init[q] ?? { x: 0, y: 0, z: 1 };
      this.spheres[q]?.sphere.setVector({ x: b.x, y: b.y, z: b.z }, { from: { x: from.x, y: from.y, z: from.z }, duration: 1000 });
    });
  }

  private renderAmplitudes(s: SimState, v: View3): void {
    const card = this.els.ampCard;
    clear(card);
    const r = s.result;
    const head = h('div', { class: 'card-head' }, h('h3', null, 'Amplitudes'), h('div', { class: 'grow' }));
    let amps = v.amplitudes;
    let note: string | null = null;
    const branches = !s.debug.active ? r?.state?.branches ?? [] : [];
    if (!amps && branches.length) {
      if (this.branchIndex >= branches.length) this.branchIndex = 0;
      const sel = h('select', { class: 'field', 'aria-label': 'Rama clásica' }) as HTMLSelectElement;
      branches.forEach((b, i) => sel.appendChild(h('option', { value: String(i), selected: i === this.branchIndex }, `${b.label} · ${(b.probability * 100).toFixed(1)} %`)));
      sel.addEventListener('change', () => {
        this.branchIndex = Number(sel.value);
        this.renderAmplitudes(this.ctrl.store.get(), v);
      });
      head.append(h('label', { class: 'branch-pick' }, h('span', { class: 'muted' }, 'Rama'), sel));
      amps = branches[this.branchIndex].amplitudes;
      note = 'El circuito mide a mitad de camino: cada resultado clásico deja un estado condicionado distinto (rama). Selecciona una rama para ver sus amplitudes.';
    }
    if (!amps) {
      card.append(head, h('p', { class: 'muted amp-mixed' },
        s.debug.active ? 'Con ruido o mediciones el estado es mixto en este paso: consulta las probabilidades y las esferas de Bloch.'
          : `Estado mixto (pureza ${trimNum(r?.state?.purity ?? 0, 3)}): no existe un único vector de amplitudes. Las probabilidades y las esferas de Bloch describen el estado.`));
      return;
    }
    const fixBox = h('input', { type: 'checkbox', checked: this.fixPhase }) as HTMLInputElement;
    fixBox.addEventListener('change', () => {
      this.fixPhase = fixBox.checked;
      this.renderAmplitudes(this.ctrl.store.get(), v);
    });
    const sortBox = h('input', { type: 'checkbox', checked: this.sortByProb }) as HTMLInputElement;
    sortBox.addEventListener('change', () => {
      this.sortByProb = sortBox.checked;
      this.renderAmplitudes(this.ctrl.store.get(), v);
    });
    head.append(h('label', { class: 'check', title: 'Multiplica por una fase global para que la mayor amplitud sea real y positiva' }, fixBox, 'Fijar fase global'),
      h('label', { class: 'check' }, sortBox, 'Ordenar por P'));
    let list = [...amps];
    if (this.fixPhase && list.length) {
      const ref = list.reduce((a, b) => (b.p > a.p ? b : a));
      const rot = -ref.phase;
      const c = Math.cos(rot), sn = Math.sin(rot);
      list = list.map((a) => {
        const re = a.re * c - a.im * sn;
        const im = a.re * sn + a.im * c;
        return { ...a, re, im, phase: Math.atan2(im, re) };
      });
    }
    if (this.sortByProb) list.sort((a, b) => b.p - a.p);
    const tbody = h('tbody');
    for (const a of list) {
      const zero = a.p < 1e-12;
      tbody.appendChild(h('tr', { class: zero ? 'zero' : '' },
        h('td', { class: 'math ketcell' }, ket(a.state)),
        h('td', { class: 'mono' }, fmtComplex(a.re, a.im, 4)),
        h('td', null, h('div', { class: 'pbar' }, h('i', { style: { width: `${a.p * 100}%`, background: zero ? 'transparent' : phaseColor(a.phase) } })), h('span', { class: 'mono soft' }, fmtProb(a.p))),
        h('td', { class: 'mono' }, zero ? '—' : h('span', { class: 'phase-cell' }, h('i', { class: 'swatch', style: { background: phaseColor(a.phase) } }), fmtAngle(a.phase))),
      ));
    }
    card.append(head);
    if (note) card.append(h('p', { class: 'hint' }, note));
    card.append(h('div', { class: 'table-scroll amp-scroll' },
      h('table', { class: 'data-table amp-table' },
        h('thead', null, h('tr', null, h('th', null, 'Estado'), h('th', null, 'Amplitud'), h('th', null, 'Probabilidad'), h('th', null, 'Fase'))),
        tbody)));
    if (r?.state?.amplitudes_truncated && !s.debug.active) card.append(h('p', { class: 'hint' }, `Se muestran las ${list.length} amplitudes de mayor magnitud de 2^${r.num_qubits}.`));
  }

  private renderFooter(s: SimState): void {
    const f = this.els.footer;
    clear(f);
    const r = s.result;
    if (!r) return;
    const chip = (t: string, title?: string) => h('span', { class: 'chip', title }, t);
    const chips = [
      chip(`profundidad ${r.stats.depth}`),
      chip(`${r.stats.gates} compuertas`),
      chip(`${r.stats.steps} pasos`),
      r.stats.noise_channels ? chip(`${r.stats.noise_channels} canales de ruido`) : null,
      r.stats.dynamic ? chip('circuito dinámico', 'Mediciones intermedias o control clásico') : null,
      chip(`${r.engine} · ${r.elapsed_ms.toFixed(1)} ms`, r.engine_version),
    ];
    f.append(...chips.filter((x): x is HTMLSpanElement => !!x));
    const warnings = [...(s.debug.active ? s.debug.data?.warnings ?? [] : r.warnings)];
    if (warnings.length) {
      f.append(h('ul', { class: 'warnings' }, ...warnings.map((w) => h('li', null, w))));
    }
  }
}


function renderKet(e: KetExpr): HTMLElement {
  const span = h('span', { class: 'ket-expr' });
  if (e.factor) span.append(h('span', { class: 'k-factor' }, e.factor), ' (');
  e.terms.forEach((t, i) => {
    if (i > 0) span.append(h('span', { class: 'k-op' }, ` ${t.sign} `));
    else if (t.sign === '−') span.append('−');
    if (t.magnitude) span.append(h('span', { class: 'k-mag' }, t.magnitude), '\u2009');
    if (t.phase.kind === 'i') span.append('i');
    if (t.phase.kind === 'exp') span.append('e', h('sup', null, t.phase.exponent));
    span.append(h('span', { class: 'k-ket' }, `|${t.ket}⟩`));
  });
  if (e.factor) span.append(')');
  if (e.hidden) span.append(h('span', { class: 'muted' }, ` + … (${e.hidden} términos más)`));
  return span;
}

/** «H en q2», «P(π/2) en q2, controlada por q1», «SWAP q0 ↔ q2», «Medición q0 → c0». */
function describeOp(op: Op): string {
  const qs = (list: number[] | undefined) => (list ?? []).map((q) => `q${q}`).join(', ');
  const param = (p: unknown) => (typeof p === 'number' ? trimNum(p, 3) : String(p).replace(/\bpi\b/g, 'π'));
  if (op.kind === 'measure') return `Medición ${qs(op.targets)} → c${op.clbits?.[0] ?? op.targets[0]}`;
  if (op.kind === 'reset') return `Reinicio ${qs(op.targets)}`;
  if (op.kind === 'barrier') return '';
  if (op.kind === 'subcircuit') return `Bloque en ${qs(op.targets)}`;
  const name = (op.gate ?? '').toLowerCase();
  const label = name === 'qft' ? 'QFT' : name === 'iqft' ? 'QFT†' : GATES[name]?.label ?? name.toUpperCase();
  const params = op.params?.length && name !== 'modmul' ? `(${op.params.map(param).join(', ')})` : '';
  const ctrl = [op.controls?.length ? `controlada por ${qs(op.controls)}` : '', op.anticontrols?.length ? `con anticontrol ${qs(op.anticontrols)}` : '']
    .filter(Boolean).join(' y ');
  const where = name === 'swap' && op.targets.length === 2 ? `${label} q${op.targets[0]} ↔ q${op.targets[1]}` : `${label}${params} en ${qs(op.targets)}`;
  return ctrl ? `${where}, ${ctrl}` : where;
}
