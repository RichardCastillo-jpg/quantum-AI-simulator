// Montaje de la página del simulador.

import { compactColumns, duplicateOps, emptyCircuit, extractSelection } from '../../lib/circuit';
import { copyText, download, h } from '../../lib/dom';
import type { Circuit } from '../../lib/types';
import { closeMenu, icon, iconButton, isModalOpen, menuFromButton, toast, confirmDialog } from '../common';
import { encodeShare, SimController } from './controller';
import { CodePanel } from './code';
import { CircuitEditor } from './editor';
import { ConfigPanel, Inspector } from './inspector';
import { LibraryPanel } from './library';
import {
  deleteSubcircuit,
  duplicateSubcircuit,
  openAlgorithms,
  openEditSubcircuit,
  openExport,
  openInspectSubcircuit,
  openLoopDialog,
  openSaveSubcircuit,
  renameSubcircuit,
  ungroupInstance,
} from './modals';
import { Palette } from './palette';
import { ResultsPanel } from './results';
import { Timeline } from './timeline';

export function mountSimulator(root: HTMLElement): SimController {
  const ctrl = new SimController();
  const store = ctrl.store;

  const openInstance = (opId: string) => {
    const s = store.get();
    const op = s.circuit.ops.find((o) => o.id === opId);
    const sub = op ? s.library.find((x) => x.id === op.subcircuit_id) : undefined;
    if (sub) openInspectSubcircuit(ctrl, sub, opId);
  };
  const editSub = (id: string) => {
    const sub = store.get().library.find((x) => x.id === id);
    if (sub) openEditSubcircuit(ctrl, sub);
  };
  const model = ctrl.editorModel({
    openInstance,
    editSubcircuit: editSub,
    saveSelection: () => openSaveSubcircuit(ctrl, 'selection'),
    wrapSelectionInLoop: () => openLoopDialog(ctrl),
    ungroupInstance: (id) => ungroupInstance(ctrl, id),
  });

  // ------------------------------------------------------------ estructura
  const paletteHost = h('div');
  const libraryHost = h('div');
  const editorHost = h('div', { class: 'editor-host' });
  const timelineHost = h('div');
  const hintBar = h('div', { class: 'hintbar', role: 'status', 'aria-live': 'polite' });
  const globalErrors = h('div', { class: 'global-errors', role: 'alert' });
  const inspHost = h('div');
  const configHost = h('div');
  const resultsHost = h('section', { class: 'results-host', 'aria-label': 'Resultados de la simulación' });

  const nameInput = h('input', { class: 'circuit-name', 'aria-label': 'Nombre del circuito', maxlength: '120' }) as HTMLInputElement;
  nameInput.addEventListener('change', () => {
    const c = store.get().circuit;
    const v = nameInput.value.trim() || 'Circuito sin título';
    if (v !== c.name) ctrl.commit({ ...c, name: v }, { label: 'Renombrar circuito' });
  });

  const undoBtn = iconButton('undo', 'Deshacer (Ctrl+Z)', () => ctrl.undo());
  const redoBtn = iconButton('redo', 'Rehacer (Ctrl+Shift+Z)', () => ctrl.redo());
  const selActions = h('div', { class: 'sel-actions' },
    h('button', { class: 'btn btn-sm', onclick: () => openSaveSubcircuit(ctrl, 'selection') }, icon('box'), 'Subcircuito'),
    h('button', { class: 'btn btn-sm', onclick: () => openLoopDialog(ctrl) }, icon('loop'), 'Repetir'),
    h('button', { class: 'btn btn-sm', onclick: () => {
      const { circuit, ids } = duplicateOps(store.get().circuit, store.get().selection);
      ctrl.commit(circuit, { label: 'Duplicar', select: ids });
    } }, icon('copy'), 'Duplicar'),
    h('button', { class: 'btn btn-sm btn-danger', onclick: () => ctrl.deleteSelection() }, icon('trash'), 'Eliminar'),
  );
  const debugBtn = h('button', { class: 'btn btn-sm debug-toggle', 'aria-pressed': 'false', onclick: () => ctrl.setDebug(!store.get().debug.active), title: 'Recorre el estado columna a columna' }, icon('bug'), 'Depurar paso a paso');
  const fileInput = h('input', { type: 'file', accept: '.json,application/json', hidden: true }) as HTMLInputElement;
  fileInput.addEventListener('change', async () => {
    const file = fileInput.files?.[0];
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      const circuit: Circuit = data.circuit ?? data;
      if (!circuit.num_qubits) throw new Error('El archivo no contiene un circuito');
      ctrl.loadCircuit(circuit, `Importar ${file.name}`);
      toast(`Circuito «${circuit.name ?? file.name}» importado`);
    } catch (e) {
      toast(`No se pudo importar: ${e instanceof Error ? e.message : String(e)}`, { kind: 'error' });
    }
    fileInput.value = '';
  });
  const moreBtn = iconButton('more', 'Más acciones', (ev) => menuFromButton(ev.currentTarget as HTMLElement, [
    { label: 'Nuevo circuito', run: async () => {
      if (store.get().circuit.ops.length && !(await confirmDialog('Nuevo circuito', 'Se vaciará el lienzo (puedes deshacerlo con Ctrl+Z).', 'Vaciar'))) return;
      ctrl.loadCircuit(emptyCircuit(3, 0), 'Nuevo circuito');
    } },
    { label: 'Importar JSON…', run: () => fileInput.click() },
    { label: 'Descargar JSON', run: () => download(`${store.get().circuit.name || 'circuito'}.json`, JSON.stringify(store.get().circuit, null, 2)) },
    { label: 'Exportar a Qiskit / OpenQASM…', run: () => openExport(ctrl) },
    { label: 'Copiar enlace para compartir', run: async () => {
      const url = `${location.origin}${location.pathname}#c=${encodeShare(store.get().circuit)}`;
      toast((await copyText(url)) ? 'Enlace copiado: contiene el circuito completo' : 'No se pudo copiar el enlace');
    } },
    { separator: true, label: '' },
    { label: 'Compactar columnas vacías', run: () => ctrl.commit(compactColumns(store.get().circuit), { label: 'Compactar' }) },
    { label: 'Guardar circuito como subcircuito…', run: () => openSaveSubcircuit(ctrl, 'circuit') },
  ]));

  const toolbar = h('div', { class: 'toolbar' },
    nameInput,
    h('div', { class: 'tb-group' }, undoBtn, redoBtn),
    h('button', { class: 'btn btn-sm', onclick: () => openAlgorithms(ctrl) }, 'Algoritmos'),
    selActions,
    h('div', { class: 'grow' }),
    debugBtn,
    moreBtn,
    fileInput,
  );

  const codeHost = h('div', { class: 'code-host' });
  const tabGate = h('button', { role: 'tab', 'aria-selected': 'true', id: 'tab-gate', 'aria-controls': 'panel-gate' }, 'Compuerta');
  const tabRun = h('button', { role: 'tab', 'aria-selected': 'false', id: 'tab-run', 'aria-controls': 'panel-run' }, 'Ejecución');
  const tabCode = h('button', { role: 'tab', 'aria-selected': 'false', id: 'tab-code', 'aria-controls': 'panel-code', title: 'Programa el circuito en Qiskit' }, 'Código');
  const panelGate = h('div', { class: 'tab-panel', role: 'tabpanel', id: 'panel-gate', 'aria-labelledby': 'tab-gate' }, inspHost);
  const panelRun = h('div', { class: 'tab-panel', role: 'tabpanel', id: 'panel-run', 'aria-labelledby': 'tab-run', hidden: true }, configHost);
  const panelCode = h('div', { class: 'tab-panel tab-panel-code', role: 'tabpanel', id: 'panel-code', 'aria-labelledby': 'tab-code', hidden: true }, codeHost);
  let codePanel: CodePanel | null = null;
  const selectTab = (which: 'gate' | 'run' | 'code') => {
    tabGate.setAttribute('aria-selected', String(which === 'gate'));
    tabRun.setAttribute('aria-selected', String(which === 'run'));
    tabCode.setAttribute('aria-selected', String(which === 'code'));
    panelGate.hidden = which !== 'gate';
    panelRun.hidden = which !== 'run';
    panelCode.hidden = which !== 'code';
    root.classList.toggle('code-open', which === 'code');
    codePanel?.setVisible(which === 'code');
    try { localStorage.setItem('coherencia:side-tab', which); } catch { /* sin almacenamiento */ }
  };
  tabGate.addEventListener('click', () => selectTab('gate'));
  tabRun.addEventListener('click', () => selectTab('run'));
  tabCode.addEventListener('click', () => selectTab('code'));

  root.classList.add('sim-app');
  root.append(
    h('aside', { class: 'rail', 'aria-label': 'Compuertas y subcircuitos' }, h('div', { class: 'rail-scroll' }, paletteHost, libraryHost)),
    h('section', { class: 'stage', 'aria-label': 'Editor del circuito' }, toolbar, hintBar, globalErrors, editorHost, timelineHost, resultsHost),
    h('aside', { class: 'side', 'aria-label': 'Inspector, ejecución y código' }, h('div', { class: 'tabs', role: 'tablist' }, tabGate, tabRun, tabCode), panelGate, panelRun, panelCode),
  );

  // ------------------------------------------------------------ componentes
  new Palette(paletteHost, model);
  new LibraryPanel(libraryHost, ctrl, {
    inspect: (sub) => openInspectSubcircuit(ctrl, sub),
    edit: (sub) => openEditSubcircuit(ctrl, sub),
    rename: (sub) => renameSubcircuit(ctrl, sub),
    duplicate: (sub) => duplicateSubcircuit(ctrl, sub),
    remove: (sub) => deleteSubcircuit(ctrl, sub),
    saveSelection: () => openSaveSubcircuit(ctrl, 'selection'),
    saveCircuit: () => openSaveSubcircuit(ctrl, 'circuit'),
  });
  const editor = new CircuitEditor(editorHost, model);
  codePanel = new CodePanel(codeHost, ctrl);
  try {
    if (localStorage.getItem('coherencia:side-tab') === 'code') selectTab('code');
  } catch { /* sin almacenamiento */ }
  new Timeline(timelineHost, ctrl);
  new Inspector(inspHost, model, {
    openInstance,
    editSubcircuit: editSub,
    ungroup: (id) => ungroupInstance(ctrl, id),
    saveSelection: () => openSaveSubcircuit(ctrl, 'selection'),
    wrapLoop: () => openLoopDialog(ctrl),
  });
  new ConfigPanel(configHost, {
    getCircuit: () => store.get().circuit,
    getConfig: () => store.get().config,
    maxQubits: () => store.get().health?.limits.max_qubits ?? 22,
    engineLabel: () => {
      const hl = store.get().health;
      return hl ? `Motor: ${hl.engine} (${hl.engine_version})` : 'Motor: conectando…';
    },
    commitCircuit: (next, label) => ctrl.commit(next, { label }),
    setConfig: (patch, continuous) => ctrl.setConfig(patch, continuous),
    subscribe: (fn) => store.subscribe(() => fn()),
  });
  new ResultsPanel(resultsHost, ctrl);

  // ------------------------------------------------------------ cabecera: estado de ejecución
  const pill = h('div', { class: 'run-pill', 'data-state': 'idle', role: 'status', 'aria-live': 'polite' }, h('i', { class: 'dot' }), h('span', { class: 'pill-text' }, 'Conectando…'));
  const pauseBtn = h('button', { class: 'btn btn-sm', 'aria-pressed': 'false', title: 'Pausar la ejecución automática', 'aria-label': 'Pausar' }, icon('pause'), h('span', { class: 'btn-label' }, 'Pausar')) as HTMLButtonElement;
  const runBtn = h('button', { class: 'btn btn-sm btn-primary', title: 'Ejecutar ahora (Ctrl+Enter)', 'aria-label': 'Ejecutar', onclick: () => ctrl.runNow() }, icon('play'), h('span', { class: 'btn-label' }, 'Ejecutar')) as HTMLButtonElement;
  pauseBtn.addEventListener('click', () => ctrl.setAutorun(!store.get().autorun));
  const slot = document.querySelector('.header-slot');
  (slot ?? root).append(pill, pauseBtn, runBtn);

  const syncChrome = () => {
    const s = store.get();
    nameInput.value = document.activeElement === nameInput ? nameInput.value : s.circuit.name;
    undoBtn.disabled = !s.history.canUndo;
    redoBtn.disabled = !s.history.canRedo;
    selActions.hidden = s.selection.length === 0;
    debugBtn.setAttribute('aria-pressed', String(s.debug.active));
    pauseBtn.setAttribute('aria-pressed', String(!s.autorun));
    const pauseLabel = s.autorun ? 'Pausar' : 'Reanudar';
    if (pauseBtn.getAttribute('aria-label') !== pauseLabel || !pauseBtn.firstChild) {
      pauseBtn.replaceChildren(icon(s.autorun ? 'pause' : 'play'), h('span', { class: 'btn-label' }, pauseLabel));
      pauseBtn.setAttribute('aria-label', pauseLabel);
      pauseBtn.title = s.autorun ? 'Pausar la ejecución automática' : 'Reanudar la ejecución automática';
    }
    runBtn.hidden = s.autorun && s.status.state !== 'error';
    const st = s.status;
    pill.dataset.state = !s.autorun ? 'paused' : st.state;
    const text = pill.querySelector('.pill-text')!;
    text.textContent = !s.autorun
      ? st.pending ? 'En pausa · cambios sin ejecutar' : 'En pausa'
      : st.state === 'running' || st.state === 'scheduled' ? 'Calculando…'
        : st.state === 'error' ? (st.kind === 'network' ? 'Sin conexión con el motor' : st.kind === 'engine' ? 'Error del motor' : 'Error en el circuito')
          : st.state === 'ok' ? `Sincronizado · ${st.elapsed == null ? '?' : st.elapsed < 1 ? '<1' : st.elapsed.toFixed(0)} ms` : 'Listo';
    pill.title = st.message ?? '';
    // Barra de ayuda contextual.
    const p = s.pending;
    if (p) {
      const roles = p.item.roles ?? [];
      const next = roles[p.picks.length];
      const which = roles.slice(0, p.picks.length + 1).filter((r) => r === next).length;
      const total = roles.filter((r) => r === next).length;
      hintBar.textContent = `${p.item.title.split(':')[0]}: haz clic en la línea del ${next === 'control' ? 'control' : 'objetivo'}${total > 1 ? ` ${which} de ${total}` : ''} (columna ${p.col}). Esc para cancelar.`;
      hintBar.dataset.tone = 'accent';
    } else if (s.armed) {
      const name = s.armed.type === 'palette' ? s.armed.item.title.split(':')[0] : `«${s.armed.sub.name}»`;
      hintBar.textContent = `Herramienta: ${name}. Haz clic en una celda para colocarla; Esc para soltarla.`;
      hintBar.dataset.tone = 'accent';
    } else if (s.debug.active) {
      hintBar.textContent = 'Depurador activo: mueve el control de pasos para ver el estado después de cada columna. Los cambios en el circuito se recalculan al momento.';
      hintBar.dataset.tone = '';
    } else {
      hintBar.textContent = 'Arrastra compuertas a las líneas de los cúbits. Arrastra una compuerta fuera del lienzo para eliminarla; clic derecho para más opciones.';
      hintBar.dataset.tone = '';
    }
    globalErrors.replaceChildren(...s.globalErrors.map((e) => h('p', null, e)));
    globalErrors.hidden = !s.globalErrors.length;
  };
  store.subscribe(syncChrome);
  syncChrome();

  // ------------------------------------------------------------ teclado
  document.addEventListener('keydown', (ev) => {
    if (isModalOpen()) return;
    const t = ev.target as HTMLElement;
    const typing = t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable;
    const mod = ev.ctrlKey || ev.metaKey;
    if (mod && ev.key === 'Enter') {
      ev.preventDefault();
      ctrl.runNow();
      return;
    }
    if (typing) return;
    const s = store.get();
    if (ev.key === 'Escape') {
      closeMenu();
      if (s.pending) store.set({ pending: null });
      else if (s.armed) store.set({ armed: null });
      else store.set({ selection: [], selectedLoop: null });
    } else if (ev.key === 'Delete' || ev.key === 'Backspace') {
      if (s.selection.length || s.selectedLoop) {
        ev.preventDefault();
        ctrl.deleteSelection();
      }
    } else if (mod && ev.key.toLowerCase() === 'z') {
      ev.preventDefault();
      if (ev.shiftKey) ctrl.redo();
      else ctrl.undo();
    } else if (mod && ev.key.toLowerCase() === 'y') {
      ev.preventDefault();
      ctrl.redo();
    } else if (mod && ev.key.toLowerCase() === 'd') {
      ev.preventDefault();
      if (s.selection.length) {
        const { circuit, ids } = duplicateOps(s.circuit, s.selection);
        ctrl.commit(circuit, { label: 'Duplicar', select: ids });
      }
    } else if (mod && ev.key.toLowerCase() === 'a') {
      ev.preventDefault();
      store.set({ selection: s.circuit.ops.map((o) => o.id) });
    } else if (ev.key.startsWith('Arrow') && s.selection.length === 1) {
      ev.preventDefault();
      const d = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[ev.key] as [number, number];
      editor.nudgeSelection(d[0], d[1]);
    } else if (mod && ev.key.toLowerCase() === 'g' && s.selection.length) {
      ev.preventDefault();
      if (extractSelection(s.circuit, s.selection)) openSaveSubcircuit(ctrl, 'selection');
    }
  });

  ctrl.init();
  return ctrl;
}
