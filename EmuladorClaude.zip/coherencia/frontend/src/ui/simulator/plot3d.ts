// Datos para las figuras 3D de resultados:
// * Probabilidades sobre una cuadrícula (bits altos × bits bajos) o en fila si hay demasiados estados.
// * Matriz densidad ρ de los cúbits: parte real, parte imaginaria y módulo con la fase como color
//   (los «city plots» habituales en los artículos de tomografía cuántica).

import { h } from '../../lib/dom';
import { fmtAngle, fmtComplex, fmtProb, ket, trimNum } from '../../lib/format';
import { oklchToRgb, phaseHue } from '../../lib/phase';
import type { DensityMatrix, ProbEntry } from '../../lib/types';
import type { Bars3Data, Bar3, RGB } from '../bars3d';

export type Mode3D = 'probs' | 're' | 'im' | 'abs';

export const MODE_LABEL: Record<Mode3D, string> = {
  probs: 'Probabilidades',
  re: 'Re ρ',
  im: 'Im ρ',
  abs: '|ρ| y fase',
};

const NEUTRAL: RGB = [127, 166, 214];
export const POSITIVE: RGB = [242, 181, 68];
export const NEGATIVE: RGB = [111, 160, 240];

const phaseRgb = (phase: number): RGB => oklchToRgb(0.76, 0.13, phaseHue(phase));

function niceMax(v: number): number {
  for (const step of [0.05, 0.1, 0.2, 0.25, 0.4, 0.5, 0.6, 0.8, 1]) if (v <= step + 1e-12) return step;
  return Math.ceil(v * 2) / 2;
}

const fmtTick = (v: number) => (v === 0 ? '0' : trimNum(v, 2));

/** Marcas «limpias»: la mitad solo si se escribe con dos decimales exactos (0,25 → sin 0,125). */
function cleanTicks(zMax: number, symmetric: boolean): number[] {
  const half = zMax / 2;
  const halfOk = Math.abs(half * 100 - Math.round(half * 100)) < 1e-9;
  const quarterOk = zMax >= 0.8;
  const pos = quarterOk ? [zMax / 4, zMax / 2, (3 * zMax) / 4, zMax] : halfOk ? [half, zMax] : [zMax];
  return symmetric ? [...pos.map((t) => -t).reverse(), 0, ...pos] : [0, ...pos];
}

function bits(k: number, width: number): string {
  return width > 0 ? k.toString(2).padStart(width, '0') : '';
}

function rangeTitle(prefix: string, hi: number, lo: number): string {
  if (hi < lo) return '';
  return hi === lo ? `${prefix}${lo}` : `${prefix}${hi}…${prefix}${lo}`;
}

export interface ProbInput {
  entries: ProbEntry[];
  other: number;
  truncated: boolean;
  colorByPhase: boolean;
  shots: number | null;
  register: string; // «cúbits» | «bits clásicos»
  title: string;
}

export function probabilityBars(input: ProbInput): Bars3Data {
  const entries = input.entries;
  const width = entries[0]?.state.length ?? 1;
  const prefix = input.register === 'bits clásicos' ? 'c' : 'q';
  const complete = !input.truncated && width <= 8 && entries.length === 1 << width;
  const maxP = Math.max(0, ...entries.map((e) => e.p), input.truncated ? input.other : 0);
  const zMax = niceMax(Math.max(maxP, 0.01));
  const color = (e: ProbEntry): RGB => (input.colorByPhase && e.phase !== undefined && e.p > 1e-9 ? phaseRgb(e.phase) : NEUTRAL);
  const tip = (e: ProbEntry) => () => {
    const lines: (Node | string)[] = [h('strong', null, ket(e.state)), h('br'), `Probabilidad ${fmtProb(e.p)} (${(e.p * 100).toFixed(2)} %)`];
    if (e.count !== undefined && input.shots) lines.push(h('br'), `${e.count} de ${input.shots} disparos`);
    if (input.colorByPhase && e.phase !== undefined && e.p > 1e-9) lines.push(h('br'), `Fase ${fmtAngle(e.phase)}`);
    return h('div', null, ...lines);
  };
  const ticks = cleanTicks(zMax, false);
  if (complete) {
    const low = Math.ceil(width / 2);
    const high = width - low;
    const cols = 1 << low, rows = 1 << high;
    const bars: Bar3[] = entries.map((e) => {
      const lo = e.state.slice(width - low);
      const hi = e.state.slice(0, width - low);
      return { row: hi ? parseInt(hi, 2) : 0, col: parseInt(lo, 2), value: e.p, rgb: color(e), key: e.state, tip: tip(e) };
    });
    return {
      rows, cols, bars,
      rowLabels: Array.from({ length: rows }, (_, k) => bits(k, high)),
      colLabels: Array.from({ length: cols }, (_, k) => bits(k, low)),
      rowTitle: rangeTitle(prefix, width - 1, low),
      colTitle: rangeTitle(prefix, low - 1, 0),
      zTitle: 'Probabilidad',
      zMin: 0, zMax, ticks, fmtTick,
      ariaLabel: `Probabilidades en 3D: ${entries.filter((e) => e.p > 0.005).map((e) => `${e.state} ${(e.p * 100).toFixed(1)} %`).join(', ')}`,
      title: input.title,
    };
  }
  // Demasiados estados para una cuadrícula completa: los más probables, en fila.
  const items = [...entries];
  const bars: Bar3[] = items.map((e, i) => ({ row: 0, col: i, value: e.p, rgb: color(e), key: e.state, tip: tip(e) }));
  if (input.truncated && input.other > 1e-6) {
    bars.push({ row: 0, col: items.length, value: input.other, rgb: [117, 133, 154], key: 'otros',
      tip: () => h('div', null, h('strong', null, 'Resto de estados'), h('br'), `Probabilidad ${fmtProb(input.other)}`) });
  }
  return {
    rows: 1, cols: bars.length, bars,
    rowLabels: [''],
    colLabels: bars.map((b) => b.key),
    rowTitle: '',
    colTitle: 'estado',
    zTitle: 'Probabilidad',
    zMin: 0, zMax, ticks, fmtTick,
    ariaLabel: `Probabilidades en 3D de los ${bars.length} estados más probables`,
    title: input.title,
  };
}

export function densityBars(d: DensityMatrix, mode: Exclude<Mode3D, 'probs'>, title: string): Bars3Data {
  const N = 1 << d.n;
  let maxAbs = 0;
  let maxPart = 0;
  for (let i = 0; i < N; i++) {
    for (let j = 0; j < N; j++) {
      const re = d.re[i][j], im = d.im[i][j];
      maxAbs = Math.max(maxAbs, Math.hypot(re, im));
      maxPart = Math.max(maxPart, Math.abs(re), Math.abs(im));
    }
  }
  const bars: Bar3[] = [];
  for (let i = 0; i < N; i++) {
    for (let j = 0; j < N; j++) {
      const re = d.re[i][j], im = d.im[i][j];
      const mag = Math.hypot(re, im);
      const phase = Math.atan2(im, re);
      const value = mode === 're' ? re : mode === 'im' ? im : mag;
      const rgb = mode === 'abs' ? (mag > 1e-9 ? phaseRgb(phase) : NEUTRAL) : value >= 0 ? POSITIVE : NEGATIVE;
      const bi = bits(i, d.n), bj = bits(j, d.n);
      bars.push({
        row: i, col: j, value, rgb, key: `${i},${j}`,
        tip: () => h('div', null,
          h('strong', null, `⟨${bi}|ρ|${bj}⟩`), h('br'),
          `= ${fmtComplex(re, im, 4)}`, h('br'),
          `|ρ| = ${trimNum(mag, 4)}${mag > 1e-9 ? ` · fase ${fmtAngle(phase)}` : ''}`, h('br'),
          h('span', { class: 'muted' }, i === j ? 'Diagonal: población del estado' : 'Fuera de la diagonal: coherencia')),
      });
    }
  }
  const sym = mode !== 'abs';
  const zMax = niceMax(Math.max(sym ? maxPart : maxAbs, 0.05));
  const ticks = cleanTicks(zMax, sym);
  const zTitle = mode === 're' ? 'Re ρ' : mode === 'im' ? 'Im ρ' : '|ρ|';
  const labels = Array.from({ length: N }, (_, k) => bits(k, d.n));
  return {
    rows: N, cols: N, bars,
    rowLabels: labels, colLabels: labels,
    rowTitle: 'fila |i⟩', colTitle: 'columna ⟨j|',
    zTitle,
    zMin: sym ? -zMax : 0, zMax, ticks, fmtTick,
    ariaLabel: `Matriz densidad en 3D (${zTitle}) de ${d.n} cúbit(s)`,
    title,
  };
}
