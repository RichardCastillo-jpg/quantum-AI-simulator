// Paneles de análisis específicos de cada algoritmo (Shor, RQC, Deutsch, teleportación…).

import { h } from '../../lib/dom';
import { fmtProb, ket, trimNum } from '../../lib/format';

type A = Record<string, any>;

function fact(label: string, value: string | Node, title?: string): HTMLElement {
  return h('div', { class: 'fact', title }, h('span', { class: 'fact-label' }, label), h('span', { class: 'fact-value' }, value));
}

function verdict(ok: boolean | undefined, text: string): HTMLElement {
  return h('p', { class: `verdict ${ok === undefined ? '' : ok ? 'ok' : 'bad'}` }, ok === undefined ? '' : ok ? '✓ ' : '✕ ', text);
}

function shor(a: A): HTMLElement {
  const factors: number[] = a.factors ?? [];
  const head = factors.length
    ? h('p', { class: 'big-eq math' }, `${a.N} = ${factors[0]} × ${a.N / factors[0]}`)
    : h('p', { class: 'big-eq math muted' }, `${a.N} = ? × ?`);
  const table = h('table', { class: 'data-table' },
    h('thead', null, h('tr', null, ...['y', 'bits', 'P', 'y/2ᵗ', '≈ s/r', 'r', 'factores'].map((t) => h('th', null, t)))),
    h('tbody', null, ...(a.rows ?? []).slice(0, 12).map((r: A) =>
      h('tr', { class: r.factors ? 'good' : '' },
        h('td', { class: 'mono' }, String(r.y)),
        h('td', { class: 'mono' }, r.bits),
        h('td', { class: 'mono' }, fmtProb(r.p)),
        h('td', { class: 'mono' }, trimNum(r.phase, 4)),
        h('td', { class: 'mono' }, r.fraction),
        h('td', { class: 'mono' }, r.r ?? '—'),
        h('td', { class: 'mono' }, r.factors ? r.factors.join(' · ') : '—'),
      ))),
  );
  return h('div', { class: 'analysis shor' },
    head,
    h('div', { class: 'facts' },
      fact('Base a', String(a.a)), fact('Cúbits de conteo', String(a.t)), fact('Orden real r', String(a.true_order)),
      fact('Éxito por ejecución', `${(a.success_probability * 100).toFixed(1)} %`, 'Probabilidad de que una medición lleve a un factor no trivial'),
    ),
    h('p', { class: 'hint' }, 'Cada resultado y aproxima s/r ≈ y/2ᵗ; las fracciones continuas dan el periodo r y mcd(a^(r/2) ± 1, N) los factores. y = 0 no aporta información.'),
    h('div', { class: 'table-scroll' }, table),
  );
}

function rqc(a: A): HTMLElement {
  const sampled = a.sampled_xeb as number | null;
  const ideal = a.ideal_xeb as number;
  const scale = Math.max(1.2, ideal * 1.15, (sampled ?? 0) * 1.1);
  const pct = (v: number) => `${Math.max(0, Math.min(100, (v / scale) * 100))}%`;
  const gauge = h('div', { class: 'xeb-gauge', role: 'img', 'aria-label': `XEB ${sampled === null ? '' : trimNum(sampled, 3)} de un ideal de ${trimNum(ideal, 3)}` },
    h('div', { class: 'xeb-track' },
      sampled !== null ? h('div', { class: 'xeb-fill', style: { width: pct(Math.max(0, sampled)) } }) : null,
      h('div', { class: 'xeb-ideal', style: { left: pct(ideal) }, title: 'XEB del muestreador ideal' }),
    ),
    h('div', { class: 'xeb-scale' }, h('span', null, '0 · ruido puro'), h('span', null, `ideal ${trimNum(ideal, 3)}`)),
  );
  // Porter–Thomas: densidad de x = 2ⁿ·p frente a e^(−x).
  const bins: A[] = a.porter_thomas ?? [];
  const W = 320, H = 150, L = 30, B = 24, T = 8, R = 8;
  const maxY = Math.max(1, ...bins.map((b) => b.density));
  const xs = (x: number) => L + ((W - L - R) * x) / 6;
  const ys = (y: number) => T + (H - T - B) * (1 - y / maxY);
  const bw = (W - L - R) / Math.max(bins.length, 1);
  const bars = bins.map((b) => `<rect x="${xs(b.x0) + 1}" y="${ys(b.density)}" width="${Math.max(1, bw - 2)}" height="${Math.max(0, ys(0) - ys(b.density))}" rx="2" class="pt-bar"/>`).join('');
  const curve = Array.from({ length: 61 }, (_, i) => {
    const x = (i / 60) * 6;
    return `${i ? 'L' : 'M'} ${xs(x).toFixed(1)} ${ys(Math.exp(-x)).toFixed(1)}`;
  }).join(' ');
  const pt = h('div', { class: 'pt-chart', html: `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-label="Distribución de Porter–Thomas">
      <line class="axis" x1="${L}" x2="${W - R}" y1="${ys(0)}" y2="${ys(0)}"/>
      ${bars}
      <path d="${curve}" class="pt-curve"/>
      ${[0, 2, 4, 6].map((x) => `<text class="tick" x="${xs(x)}" y="${H - 6}" text-anchor="middle">${x}</text>`).join('')}
      <text class="tick" x="${W - R}" y="${T + 10}" text-anchor="end">e^(−x)</text>
    </svg>` });
  return h('div', { class: 'analysis rqc' },
    h('div', { class: 'facts' },
      fact('XEB lineal', sampled === null ? '—' : trimNum(sampled, 3), 'F = 2ⁿ·⟨p_ideal(x)⟩ − 1 sobre las muestras'),
      fact('XEB ideal', trimNum(ideal, 3)),
      fact('Fidelidad estimada', a.fidelity_estimate === null || a.fidelity_estimate === undefined ? '—' : `${(a.fidelity_estimate * 100).toFixed(1)} %`),
      a.xeb_stderr ? fact('Error típico', `± ${trimNum(a.xeb_stderr, 3)}`) : null,
    ),
    gauge,
    h('div', { class: 'pt-wrap' }, pt, h('p', { class: 'hint' }, 'Histograma de 2ⁿ·p(x) para el circuito ideal. Un circuito suficientemente aleatorio sigue la ley exponencial de Porter–Thomas (curva). Añade ruido para ver cómo cae la XEB.')),
  );
}

export function renderAnalysis(a: A | null | undefined): HTMLElement | null {
  if (!a) return null;
  switch (a.kind) {
    case 'shor':
      return shor(a);
    case 'rqc':
      return rqc(a);
    case 'deutsch':
      return h('div', { class: 'analysis' },
        h('p', { class: 'big-eq' }, a.verdict === 'balanceada' ? 'f es balanceada' : 'f es constante'),
        verdict(a.correct, `Oráculo real: ${a.expected}. Probabilidad de medir 1: ${fmtProb(a.p_one)}.`),
        h('p', { class: 'hint' }, 'Una sola consulta basta: la interferencia deja q0 en |0⟩ si f es constante y en |1⟩ si es balanceada.'));
    case 'teleportation': {
      const e = a.expected_bloch ?? [0, 0, 0];
      const r = a.received_bloch ?? [0, 0, 0];
      return h('div', { class: 'analysis' },
        h('p', { class: 'big-eq' }, a.fidelity !== undefined ? `Fidelidad ${trimNum(a.fidelity, 4)}` : 'Fidelidad —'),
        h('table', { class: 'data-table compact' },
          h('thead', null, h('tr', null, h('th', null, ''), h('th', null, 'x'), h('th', null, 'y'), h('th', null, 'z'))),
          h('tbody', null,
            h('tr', null, h('td', null, 'Enviado (q0)'), ...e.map((v: number) => h('td', { class: 'mono' }, trimNum(v, 3)))),
            h('tr', null, h('td', null, 'Recibido (q2)'), ...r.map((v: number) => h('td', { class: 'mono' }, trimNum(v, 3)))))),
        a.bell_outcomes ? h('p', { class: 'hint' }, `Resultados de la medición de Bell (m1 m0): ${a.bell_outcomes.map((o: A) => `${o.state} → ${fmtProb(o.p)}`).join(' · ')}`) : null,
        h('p', { class: 'hint' }, 'Las correcciones X (si m1 = 1) y Z (si m0 = 1) se aplican en tiempo real tras medir: la fidelidad 1 confirma que el estado llegó intacto.'));
    }
    case 'grover':
      return h('div', { class: 'analysis' },
        h('p', { class: 'big-eq' }, `P(${ket(a.marked)}) = ${fmtProb(a.p_marked)}`),
        h('div', { class: 'facts' }, fact('Teoría sin²((2k+1)θ)', fmtProb(a.p_theory)), fact('Iteraciones k', String(a.iterations))));
    case 'bv':
      return h('div', { class: 'analysis' },
        h('p', { class: 'big-eq mono' }, a.found),
        verdict(a.correct, `Cadena secreta ${a.secret}; recuperada con probabilidad ${fmtProb(a.p)} en una sola consulta.`));
    case 'qft':
      return h('div', { class: 'analysis' },
        h('p', { class: 'big-eq' }, `Fidelidad con la DFT ${trimNum(a.fidelity_with_dft, 6)}`),
        h('p', { class: 'hint' }, 'Las amplitudes tienen igual magnitud; la fase avanza un paso constante de un estado al siguiente (mira los colores).'));
    default:
      return a.summary ? h('div', { class: 'analysis' }, h('p', null, a.summary)) : null;
  }
}
