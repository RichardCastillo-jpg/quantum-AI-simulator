// Depurador temporal: recorre el estado después de cada columna (con los ciclos desenrollados).

import { clear, h } from '../../lib/dom';
import { icon } from '../common';
import type { SimController } from './controller';

export class Timeline {
  readonly element: HTMLElement;
  private ctrl: SimController;
  private timer: ReturnType<typeof setInterval> | null = null;

  constructor(container: HTMLElement, ctrl: SimController) {
    this.element = container;
    this.ctrl = ctrl;
    container.classList.add('timeline');
    ctrl.store.select((s) => s.debug, () => this.render());
    this.render();
  }

  private stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  private play(): void {
    const d = this.ctrl.store.get().debug;
    if (!d.data) return;
    if (this.timer) {
      this.stop();
      this.render();
      return;
    }
    if (d.index >= d.data.steps.length - 1) this.ctrl.setStep(0);
    this.timer = setInterval(() => {
      const cur = this.ctrl.store.get().debug;
      if (!cur.data || !cur.active || cur.index >= cur.data.steps.length - 1) {
        this.stop();
        this.render();
        return;
      }
      this.ctrl.setStep(cur.index + 1);
    }, 650);
    this.render();
  }

  render(): void {
    const d = this.ctrl.store.get().debug;
    this.element.hidden = !d.active;
    clear(this.element);
    if (!d.active) {
      this.stop();
      return;
    }
    const steps = d.data?.steps ?? [];
    const last = Math.max(0, steps.length - 1);
    const step = steps[d.index];
    const slider = h('input', { type: 'range', min: '0', max: String(last), step: '1', value: String(d.index), 'aria-label': 'Paso del depurador', disabled: !steps.length }) as HTMLInputElement;
    slider.addEventListener('input', () => {
      this.stop();
      this.ctrl.setStep(Number(slider.value));
    });
    const btn = (name: string, label: string, fn: () => void, disabled = false) =>
      h('button', { class: 'btn btn-ghost btn-icon', 'aria-label': label, title: label, onclick: fn, disabled }, icon(name));
    const ticks = h('div', { class: 'tl-ticks', 'aria-hidden': 'true' },
      ...steps.map((s, i) => h('i', { class: `${i === d.index ? 'on' : ''} ${s.purity < 0.999 ? 'mixed' : ''}`, title: s.label, onclick: () => this.ctrl.setStep(i) })));
    this.element.append(
      h('div', { class: 'tl-controls' },
        btn('back', 'Primer paso', () => { this.stop(); this.ctrl.setStep(0); }, !steps.length),
        btn('prev', 'Paso anterior', () => { this.stop(); this.ctrl.setStep(d.index - 1); }, d.index <= 0),
        btn(this.timer ? 'pause' : 'play', this.timer ? 'Pausar' : 'Reproducir', () => this.play(), !steps.length),
        btn('next', 'Paso siguiente', () => { this.stop(); this.ctrl.setStep(d.index + 1); }, d.index >= last),
        btn('step', 'Último paso', () => { this.stop(); this.ctrl.setStep(last); }, !steps.length),
      ),
      h('div', { class: 'tl-track' }, slider, ticks),
      h('div', { class: 'tl-label' },
        d.loading && !steps.length ? 'Calculando los pasos…'
          : d.error ? h('span', { class: 'error-text' }, d.error)
            : step ? h('span', null, h('strong', null, step.index < 0 ? 'Inicio' : `Paso ${step.index + 1}/${last}`), ' · ', step.index < 0 ? 'estado inicial' : step.label,
              d.data?.noisy ? h('span', { class: 'chip' }, 'con ruido') : null) : ''),
    );
  }
}
