// Biblioteca de subcircuitos: lista, arrastrar al lienzo, inspeccionar, editar y gestionar.

import { clear, h } from '../../lib/dom';
import type { SubcircuitDef } from '../../lib/types';
import { icon, iconButton, menuFromButton } from '../common';
import { startDrag } from '../drag';
import type { SimController } from './controller';

export interface LibraryActions {
  inspect(sub: SubcircuitDef): void;
  edit(sub: SubcircuitDef): void;
  rename(sub: SubcircuitDef): void;
  duplicate(sub: SubcircuitDef): void;
  remove(sub: SubcircuitDef): void;
  saveSelection(): void;
  saveCircuit(): void;
}

export class LibraryPanel {
  readonly element: HTMLElement;
  private ctrl: SimController;
  private actions: LibraryActions;
  private list: HTMLElement;
  private saveSelBtn: HTMLButtonElement;
  private filter = '';

  constructor(container: HTMLElement, ctrl: SimController, actions: LibraryActions) {
    this.element = container;
    this.ctrl = ctrl;
    this.actions = actions;
    container.classList.add('library');
    this.list = h('div', { class: 'lib-list', role: 'list' });
    this.saveSelBtn = h('button', { class: 'btn btn-sm', onclick: () => actions.saveSelection(), title: 'Guardar las compuertas seleccionadas como subcircuito' }, icon('box'), 'Desde selección') as HTMLButtonElement;
    const search = h('input', { class: 'field', placeholder: 'Buscar…', 'aria-label': 'Buscar subcircuitos' }) as HTMLInputElement;
    search.addEventListener('input', () => {
      this.filter = search.value.trim().toLowerCase();
      this.render();
    });
    container.append(
      h('div', { class: 'lib-head' }, h('h3', null, 'Subcircuitos'), h('div', { class: 'grow' }),
        iconButton('plus', 'Guardar el circuito completo como subcircuito', () => actions.saveCircuit())),
      h('div', { class: 'lib-tools' }, this.saveSelBtn, search),
      this.list,
    );
    ctrl.store.select((s) => s.library, () => this.render());
    ctrl.store.select((s) => s.selection, () => this.syncButtons());
    ctrl.store.select((s) => s.armed, () => this.render());
    this.render();
  }

  private syncButtons(): void {
    this.saveSelBtn.disabled = this.ctrl.store.get().selection.length === 0;
  }

  render(): void {
    this.syncButtons();
    clear(this.list);
    const { library, armed, circuit } = this.ctrl.store.get();
    const items = library.filter((s) => !this.filter || s.name.toLowerCase().includes(this.filter) || (s.tags ?? []).some((t) => t.toLowerCase().includes(this.filter)));
    if (!library.length) {
      this.list.appendChild(h('p', { class: 'empty' }, 'Aún no hay subcircuitos. Selecciona varias compuertas y guárdalas para reutilizarlas.'));
      return;
    }
    if (!items.length) {
      this.list.appendChild(h('p', { class: 'empty' }, 'Ningún subcircuito coincide con la búsqueda.'));
      return;
    }
    for (const sub of items) {
      const uses = circuit.ops.filter((o) => o.kind === 'subcircuit' && o.subcircuit_id === sub.id).length;
      const isArmed = armed?.type === 'subcircuit' && armed.sub.id === sub.id;
      const body = h('div', { class: 'lib-body', title: 'Arrastra al lienzo o pulsa y haz clic en una celda' },
        h('i', { class: `lib-swatch sub-${sub.color ?? 'rose'}` }),
        h('div', { class: 'lib-text' },
          h('span', { class: 'lib-name' }, sub.name),
          h('span', { class: 'lib-meta' }, `${sub.num_qubits} cúbit${sub.num_qubits === 1 ? '' : 's'}${sub.params.length ? ` · ${sub.params.join(', ')}` : ''}${uses ? ` · ${uses} en uso` : ''}`)),
      );
      body.addEventListener('pointerdown', (ev) => {
        startDrag(ev, { type: 'subcircuit', sub }, {
          ghost: () => h('div', { class: 'gate-ghost sub' }, sub.name.slice(0, 10)),
          onClick: () => {
            const current = this.ctrl.store.get().armed;
            const same = current?.type === 'subcircuit' && current.sub.id === sub.id;
            this.ctrl.store.set({ armed: same ? null : { type: 'subcircuit', sub }, pending: null });
          },
        });
      });
      const more = iconButton('more', `Más acciones para ${sub.name}`, (ev) => {
        menuFromButton(ev.currentTarget as HTMLElement, [
          { label: 'Renombrar', run: () => this.actions.rename(sub) },
          { label: 'Duplicar', run: () => this.actions.duplicate(sub) },
          { separator: true, label: '' },
          { label: 'Eliminar', danger: true, run: () => this.actions.remove(sub) },
        ]);
      });
      this.list.appendChild(
        h('div', { class: `lib-item ${isArmed ? 'armed' : ''}`, role: 'listitem' },
          body,
          h('div', { class: 'lib-actions' },
            iconButton('eye', `Inspeccionar ${sub.name}`, () => this.actions.inspect(sub)),
            iconButton('edit', `Editar ${sub.name}`, () => this.actions.edit(sub)),
            more)),
      );
    }
  }
}
