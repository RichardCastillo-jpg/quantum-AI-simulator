// Inspector de la operación seleccionada (parámetros, cúbits, controles, condiciones,
// asignación de subcircuitos, matriz) y panel de configuración de la ejecución.

import { duplicateOps, isFree, loopsContaining, opSpan, placeOp, removeOps, updateLoop, insertColumn, setNumClbits, setNumQubits } from '../../lib/circuit';
import { abs2, arg, c as cnum, isUnitary, type Matrix } from '../../lib/complex';
import { clear, h } from '../../lib/dom';
import { tryEvaluate, isIdentifier } from '../../lib/expr';
import { fmtAngle, fmtComplex, prettyParam, trimNum } from '../../lib/format';
import { GATES, opMatrix } from '../../lib/gates';
import { phaseColor } from '../../lib/phase';
import type { Circuit, Op, SimConfig, SubcircuitDef } from '../../lib/types';
import { icon, toast } from '../common';
import type { EditorModel } from './editor';

export interface InspectorHooks {
  openInstance?(opId: string): void;
  editSubcircuit?(id: string): void;
  ungroup?(opId: string): void;
  saveSelection?(): void;
  wrapLoop?(): void;
  extraEnv?: () => Record<string, number>;
}

export function angleExpr(v: number): string {
  for (const d of [1, 2, 3, 4, 6, 8, 12, 16]) {
    const k = Math.round((v * d) / Math.PI);
    if (Math.abs(v - (k * Math.PI) / d) < 0.012) {
      if (k === 0) return '0';
      const sign = k < 0 ? '-' : '';
      const a = Math.abs(k);
      const num = a === 1 ? 'pi' : `${a}*pi`;
      return d === 1 ? `${sign}${num}` : `${sign}${num}/${d}`;
    }
  }
  return v.toFixed(4);
}

function section(title: string, ...children: (Node | null)[]): HTMLElement {
  return h('section', { class: 'insp-section' }, h('h4', null, title), ...children);
}

function qubitSelect(n: number, value: number, onchange: (q: number) => void, label: string): HTMLSelectElement {
  const sel = h('select', { class: 'field', 'aria-label': label }) as HTMLSelectElement;
  for (let q = 0; q < n; q++) sel.appendChild(h('option', { value: String(q), selected: q === value }, `q${q}`));
  sel.addEventListener('change', () => onchange(Number(sel.value)));
  return sel;
}

export function renderMatrix(m: Matrix): HTMLElement {
  const table = h('table', { class: 'matrix', 'aria-label': 'Matriz de la operación' });
  for (const row of m) {
    const tr = h('tr');
    for (const z of row) {
      const mag = abs2(z);
      const cell = h(
        'td',
        { title: `${fmtComplex(z.re, z.im)} · |·|² = ${trimNum(mag, 3)}` },
        mag > 1e-9 ? h('i', { class: 'mdot', style: { background: phaseColor(arg(z)), opacity: String(0.35 + 0.65 * Math.sqrt(mag)) } }) : null,
        h('span', null, fmtComplex(z.re, z.im, 2)),
      );
      tr.appendChild(cell);
    }
    table.appendChild(tr);
  }
  return h('div', { class: 'matrix-wrap' }, table);
}

function randomUnitary(dim: number): number[][][] {
  // QR de una matriz gaussiana compleja (Gram–Schmidt) → unitaria distribuida según Haar.
  const gauss = () => {
    const u = Math.random() || 1e-12;
    const v = Math.random();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  };
  const cols: { re: number; im: number }[][] = [];
  for (let j = 0; j < dim; j++) {
    let v = Array.from({ length: dim }, () => ({ re: gauss(), im: gauss() }));
    for (const q of cols) {
      let dr = 0, di = 0;
      for (let i = 0; i < dim; i++) {
        dr += q[i].re * v[i].re + q[i].im * v[i].im;
        di += q[i].re * v[i].im - q[i].im * v[i].re;
      }
      v = v.map((z, i) => ({ re: z.re - (dr * q[i].re - di * q[i].im), im: z.im - (dr * q[i].im + di * q[i].re) }));
    }
    const norm = Math.sqrt(v.reduce((s, z) => s + z.re * z.re + z.im * z.im, 0));
    cols.push(v.map((z) => ({ re: z.re / norm, im: z.im / norm })));
  }
  return Array.from({ length: dim }, (_, i) => Array.from({ length: dim }, (_, j) => [+cols[j][i].re.toFixed(6), +cols[j][i].im.toFixed(6)]));
}

export class Inspector {
  readonly element: HTMLElement;
  private model: EditorModel;
  private hooks: InspectorHooks;
  private lastKey = '';
  private lastTarget = '';
  private unsub: () => void;

  constructor(container: HTMLElement, model: EditorModel, hooks: InspectorHooks = {}) {
    this.element = container;
    this.model = model;
    this.hooks = hooks;
    container.classList.add('inspector');
    this.unsub = model.subscribe(() => this.maybeRender());
    this.render();
  }

  destroy(): void {
    this.unsub();
  }

  private get circuit(): Circuit {
    return this.model.getCircuit();
  }

  private maybeRender(): void {
    const sel = this.model.getSelection();
    const loopId = this.model.getSelectedLoop();
    const op = sel.length === 1 ? this.circuit.ops.find((o) => o.id === sel[0]) : undefined;
    const loop = loopId ? this.circuit.loops.find((l) => l.id === loopId) : undefined;
    const key = JSON.stringify([sel, loopId, op, loop, this.circuit.num_qubits, this.circuit.num_clbits, this.model.getErrors()[sel[0] ?? ''], this.model.getLibrary().length]);
    if (key === this.lastKey) return;
    const target = JSON.stringify([sel, loopId]);
    const focusInside = this.element.contains(document.activeElement) && document.activeElement !== this.element;
    const sameTarget = target === this.lastTarget;
    this.lastKey = key;
    this.lastTarget = target;
    if (focusInside && sameTarget) return; // no interrumpir mientras se escribe
    this.render();
  }

  private commit(next: Circuit, label: string, coalesce?: string, continuous = false): void {
    this.model.commit(next, { label, coalesce, continuous });
  }

  private env(op?: Op): Record<string, number> {
    const env: Record<string, number> = { ...(this.hooks.extraEnv?.() ?? {}) };
    if (op) for (const lp of loopsContaining(this.circuit, op.col)) env[lp.var] = lp.start ?? 0;
    return env;
  }

  render(): void {
    const sel = this.model.getSelection();
    const loopId = this.model.getSelectedLoop();
    this.lastTarget = JSON.stringify([sel, loopId]);
    clear(this.element);
    const loop = loopId ? this.circuit.loops.find((l) => l.id === loopId) : undefined;
    if (loop) {
      this.element.appendChild(this.loopView(loop.id));
      return;
    }
    if (sel.length > 1) {
      this.element.appendChild(this.multiView(sel));
      return;
    }
    const op = sel.length === 1 ? this.circuit.ops.find((o) => o.id === sel[0]) : undefined;
    if (!op) {
      this.element.appendChild(this.emptyView());
      return;
    }
    this.element.appendChild(this.opView(op));
  }

  private emptyView(): HTMLElement {
    return h(
      'div',
      { class: 'insp-empty' },
      h('p', { class: 'insp-lead' }, 'Selecciona una compuerta para editar sus parámetros, cúbits y controles.'),
      h(
        'ul',
        { class: 'tips' },
        h('li', null, 'Arrastra una compuerta desde la paleta a la línea de un cúbit, o púlsala y luego haz clic en la celda.'),
        h('li', null, 'CNOT, CZ, SWAP y Toffoli se colocan con varios clics: primero el control, después el objetivo.'),
        h('li', null, 'Arrastra en una zona vacía para seleccionar varias compuertas y guardarlas como subcircuito o repetirlas con un ciclo for.'),
        h('li', null, 'Pulsa |0⟩ junto a cada cúbit para cambiar su estado inicial.'),
      ),
      h(
        'dl',
        { class: 'shortcuts' },
        ...[
          ['Supr', 'Eliminar selección'],
          ['Esc', 'Cancelar / soltar herramienta'],
          ['Ctrl Z', 'Deshacer'],
          ['Ctrl ⇧ Z', 'Rehacer'],
          ['Ctrl D', 'Duplicar'],
          ['← →', 'Mover compuerta'],
          ['Ctrl ↵', 'Ejecutar ahora'],
        ].flatMap(([k, v]) => [h('dt', null, h('span', { class: 'kbd' }, k)), h('dd', null, v)]),
      ),
    );
  }

  private multiView(sel: string[]): HTMLElement {
    const c = this.circuit;
    return h(
      'div',
      { class: 'insp-body' },
      h('header', { class: 'insp-head' }, h('h3', null, `${sel.length} operaciones seleccionadas`)),
      h(
        'div',
        { class: 'insp-actions stack' },
        h('button', { class: 'btn', onclick: () => this.hooks.saveSelection?.() }, icon('box'), 'Guardar como subcircuito'),
        h('button', { class: 'btn', onclick: () => this.hooks.wrapLoop?.() }, icon('loop'), 'Repetir con un ciclo for'),
        h('button', { class: 'btn', onclick: () => {
          const { circuit, ids } = duplicateOps(c, sel);
          this.model.commit(circuit, { label: 'Duplicar', select: ids });
        } }, icon('copy'), 'Duplicar'),
        h('button', { class: 'btn btn-danger', onclick: () => this.model.commit(removeOps(c, sel), { label: 'Eliminar', select: [] }) }, icon('trash'), 'Eliminar'),
      ),
    );
  }

  private loopView(id: string): HTMLElement {
    const c = this.circuit;
    const lp = c.loops.find((l) => l.id === id)!;
    const values = Array.from({ length: Math.min(lp.iterations, 6) }, (_, k) => trimNum((lp.start ?? 0) + k * (lp.step ?? 1), 3));
    const preview = `${lp.var} = ${values.join(', ')}${lp.iterations > 6 ? ', …' : ''}`;
    const num = (label: string, value: number, key: keyof typeof lp, opts: { min?: number; max?: number; step?: number; int?: boolean } = {}) => {
      const input = h('input', { class: 'field mono', type: 'number', value: String(value), min: opts.min, max: opts.max, step: opts.step ?? 1, 'aria-label': label }) as HTMLInputElement;
      input.addEventListener('change', () => {
        let v = Number(input.value);
        if (!Number.isFinite(v)) return;
        if (opts.int) v = Math.round(v);
        if (opts.min !== undefined) v = Math.max(opts.min, v);
        if (opts.max !== undefined) v = Math.min(opts.max, v);
        this.commit(updateLoop(this.circuit, id, { [key]: v }), 'Editar ciclo', `loop:${id}:${String(key)}`);
      });
      return h('label', { class: 'mini-field' }, h('span', { class: 'label' }, label), input);
    };
    const varInput = h('input', { class: 'field mono', value: lp.var, 'aria-label': 'Variable' }) as HTMLInputElement;
    varInput.addEventListener('change', () => {
      const v = varInput.value.trim();
      if (!isIdentifier(v)) {
        varInput.classList.add('invalid');
        return;
      }
      varInput.classList.remove('invalid');
      this.commit(updateLoop(this.circuit, id, { var: v }), 'Renombrar variable');
    });
    return h(
      'div',
      { class: 'insp-body' },
      h('header', { class: 'insp-head' }, h('span', { class: 'chip' }, '↻ ciclo for'), h('h3', null, `Columnas ${lp.col_start}–${lp.col_end}`)),
      h('p', { class: 'insp-desc' }, `Repite las columnas ${lp.col_start} a ${lp.col_end} ${lp.iterations} veces. Usa la variable en los parámetros, por ejemplo «${lp.var}*pi/8».`),
      section(
        'Repetición',
        h('div', { class: 'grid2' }, num('Iteraciones', lp.iterations, 'iterations', { min: 1, max: 10000, int: true }), h('label', { class: 'mini-field' }, h('span', { class: 'label' }, 'Variable'), varInput)),
        h('div', { class: 'grid2' }, num('Valor inicial', lp.start ?? 0, 'start', { step: 0.5 }), num('Incremento', lp.step ?? 1, 'step', { step: 0.5 })),
        h('div', { class: 'grid2' }, num('Desde columna', lp.col_start, 'col_start', { min: 0, int: true }), num('Hasta columna', lp.col_end, 'col_end', { min: 0, int: true })),
        h('p', { class: 'hint mono' }, preview),
      ),
      h('div', { class: 'insp-actions' }, h('button', { class: 'btn btn-danger', onclick: () => {
        this.model.commit({ ...this.circuit, loops: this.circuit.loops.filter((l) => l.id !== id) }, { label: 'Quitar ciclo' });
        this.model.setSelectedLoop(null);
      } }, icon('trash'), 'Quitar ciclo')),
    );
  }

  /** Sustituye la operación y, si ya no cabe en su columna, abre una columna nueva. */
  private replaceOp(op: Op, next: Op, label: string, coalesce?: string, continuous = false): void {
    const c = this.circuit;
    const [lo, hi] = opSpan(next, c.num_qubits);
    let base = removeOps(c, [op.id]);
    if (!isFree(base, next.col, lo, hi)) base = insertColumn(base, next.col);
    this.commit(placeOp(base, next), label, coalesce, continuous);
    this.model.setSelection([op.id]);
  }

  private opView(op: Op): HTMLElement {
    const info = op.gate ? GATES[op.gate] : undefined;
    const sub = op.kind === 'subcircuit' ? this.model.getLibrary().find((s) => s.id === op.subcircuit_id) : undefined;
    const title =
      op.kind === 'measure' ? 'Medición' : op.kind === 'reset' ? 'Reinicio' : op.kind === 'barrier' ? 'Barrera'
        : op.kind === 'subcircuit' ? sub?.name ?? 'Subcircuito desconocido'
          : op.gate === 'x' && (op.controls?.length ?? 0) === 1 && !(op.anticontrols?.length) ? 'CNOT'
            : op.gate === 'x' && (op.controls?.length ?? 0) === 2 && !(op.anticontrols?.length) ? 'Toffoli (CCNOT)'
              : info?.title ?? op.gate ?? 'Compuerta';
    const desc =
      op.kind === 'measure' ? 'Medición proyectiva en la base computacional; guarda el resultado en un bit clásico.'
        : op.kind === 'reset' ? 'Lleva el cúbit a |0⟩ (equivale a medir y corregir).'
          : op.kind === 'barrier' ? 'Separador visual; no modifica el estado.'
            : op.kind === 'subcircuit' ? sub?.description || 'Bloque reutilizable de la biblioteca.'
              : info?.description ?? '';
    const body = h('div', { class: 'insp-body' });
    const err = this.model.getErrors()[op.id];
    body.appendChild(h('header', { class: 'insp-head' }, h('span', { class: 'chip' }, `columna ${op.col}`), h('h3', null, title)));
    if (desc) body.appendChild(h('p', { class: 'insp-desc' }, desc));
    if (err) body.appendChild(h('p', { class: 'insp-error', role: 'alert' }, err));

    if (op.kind === 'gate' || op.kind === 'measure' || op.kind === 'reset') body.appendChild(this.qubitsSection(op));
    if (op.kind === 'gate' && op.gate && ['qft', 'iqft', 'modmul', 'unitary'].includes(op.gate)) body.appendChild(this.blockSizeSection(op));
    if (op.kind === 'gate' && (op.params?.length ?? 0) > 0) body.appendChild(this.paramsSection(op));
    if (op.kind === 'gate' && op.gate === 'unitary') body.appendChild(this.unitarySection(op));
    if (op.kind === 'measure') body.appendChild(this.measureSection(op));
    if (op.kind === 'subcircuit') body.appendChild(this.subcircuitSection(op, sub));
    if (op.kind === 'gate' || op.kind === 'subcircuit') body.appendChild(this.conditionSection(op));
    if (op.kind === 'gate') {
      const m = opMatrix(op, this.env(op));
      if (m) body.appendChild(section(m.length <= 2 ? 'Matriz' : `Matriz (${m.length}×${m.length}, controles en los bits bajos)`, renderMatrix(m)));
    }
    body.appendChild(
      h(
        'div',
        { class: 'insp-actions' },
        h('button', { class: 'btn', onclick: () => {
          const { circuit, ids } = duplicateOps(this.circuit, [op.id]);
          this.model.commit(circuit, { label: 'Duplicar', select: ids });
        } }, icon('copy'), 'Duplicar'),
        h('button', { class: 'btn btn-danger', onclick: () => this.model.commit(removeOps(this.circuit, [op.id]), { label: 'Eliminar', select: [] }) }, icon('trash'), 'Eliminar'),
      ),
    );
    return body;
  }

  private qubitsSection(op: Op): HTMLElement {
    const c = this.circuit;
    const n = c.num_qubits;
    const wrap = h('div', { class: 'qubit-roles' });
    const isBlock = op.gate && ['qft', 'iqft', 'modmul', 'unitary'].includes(op.gate);
    if (!isBlock) {
      op.targets.forEach((q, i) => {
        wrap.appendChild(
          h('label', { class: 'role-row' }, h('span', { class: 'role-name' }, op.targets.length > 1 ? `Objetivo ${i}` : 'Objetivo'),
            qubitSelect(n, q, (nq) => {
              const next: Op = JSON.parse(JSON.stringify(op));
              const all = [...next.targets, ...(next.controls ?? []), ...(next.anticontrols ?? [])];
              if (all.includes(nq)) {
                // Intercambio: el cúbit elegido pasa a la posición que queda libre.
                const swap = (arr?: number[]) => arr?.map((x) => (x === nq ? q : x));
                next.targets = swap(next.targets)!;
                next.controls = swap(next.controls);
                next.anticontrols = swap(next.anticontrols);
              }
              next.targets[i] = nq;
              this.replaceOp(op, next, 'Cambiar cúbit');
            }, `Cúbit objetivo ${i}`)),
        );
      });
    }
    if (op.kind === 'gate') {
      const chips = h('div', { class: 'chips' });
      const used = new Set([...op.targets, ...(op.controls ?? []), ...(op.anticontrols ?? [])]);
      for (const [key, symbol] of [['controls', '●'], ['anticontrols', '○']] as const) {
        for (const q of op[key] ?? []) {
          chips.appendChild(
            h('span', { class: 'chip ctrl-chip' },
              h('button', { class: 'chip-btn', title: 'Alternar control/anticontrol', onclick: () => {
                const other = key === 'controls' ? 'anticontrols' : 'controls';
                const next: Op = { ...op, [key]: (op[key] ?? []).filter((x) => x !== q), [other]: [...(op[other] ?? []), q] };
                this.replaceOp(op, next, 'Cambiar control');
              } }, `${symbol} q${q}`),
              h('button', { class: 'chip-x', 'aria-label': `Quitar control q${q}`, onclick: () => {
                this.replaceOp(op, { ...op, [key]: (op[key] ?? []).filter((x) => x !== q) }, 'Quitar control');
              } }, '×')),
          );
        }
      }
      const free = Array.from({ length: n }, (_, i) => i).filter((q) => !used.has(q));
      const add = h('select', { class: 'field add-ctrl', 'aria-label': 'Añadir control' }) as HTMLSelectElement;
      add.appendChild(h('option', { value: '' }, free.length ? '+ Añadir control…' : 'Sin cúbits libres'));
      for (const q of free) {
        add.appendChild(h('option', { value: `c${q}` }, `● control en q${q}`));
        add.appendChild(h('option', { value: `a${q}` }, `○ anticontrol en q${q}`));
      }
      add.disabled = !free.length;
      add.addEventListener('change', () => {
        const v = add.value;
        if (!v) return;
        const q = Number(v.slice(1));
        const key = v[0] === 'c' ? 'controls' : 'anticontrols';
        this.replaceOp(op, { ...op, [key]: [...(op[key] ?? []), q] }, 'Añadir control');
      });
      wrap.appendChild(h('div', { class: 'role-row' }, h('span', { class: 'role-name' }, 'Controles'), h('div', { class: 'ctrl-box' }, chips, add)));
    }
    return section('Cúbits', wrap);
  }

  private blockSizeSection(op: Op): HTMLElement {
    const n = this.circuit.num_qubits;
    const k = op.targets.length;
    const start = Math.min(...op.targets);
    const maxK = op.gate === 'unitary' ? 2 : op.gate === 'modmul' ? 10 : 24;
    const minK = op.gate === 'modmul' ? 2 : 1;
    const kSel = h('select', { class: 'field', 'aria-label': 'Número de cúbits' }) as HTMLSelectElement;
    for (let v = minK; v <= Math.min(maxK, n); v++) kSel.appendChild(h('option', { value: String(v), selected: v === k }, `${v} cúbit${v === 1 ? '' : 's'}`));
    const sSel = qubitSelect(n, start, () => undefined, 'Primer cúbit');
    const apply = () => {
      const nk = Number(kSel.value);
      const ns = Math.min(Number(sSel.value), n - nk);
      const next: Op = { ...op, targets: Array.from({ length: nk }, (_, i) => ns + i) };
      next.controls = (op.controls ?? []).filter((q) => !next.targets.includes(q));
      next.anticontrols = (op.anticontrols ?? []).filter((q) => !next.targets.includes(q));
      if (op.gate === 'unitary' && nk !== k) {
        const dim = 1 << nk;
        next.matrix = Array.from({ length: dim }, (_, i) => Array.from({ length: dim }, (_, j) => [i === j ? 1 : 0, 0]));
      }
      this.replaceOp(op, next, 'Tamaño del bloque');
    };
    kSel.addEventListener('change', apply);
    sSel.addEventListener('change', apply);
    return section(
      'Bloque',
      h('div', { class: 'grid2' }, h('label', { class: 'mini-field' }, h('span', { class: 'label' }, 'Tamaño'), kSel), h('label', { class: 'mini-field' }, h('span', { class: 'label' }, 'Desde'), sSel)),
      h('p', { class: 'hint' }, 'El cúbit de menor índice es el bit menos significativo del registro.'),
    );
  }

  private paramsSection(op: Op): HTMLElement {
    const info = op.gate ? GATES[op.gate] : undefined;
    const names = info?.params ?? [];
    const wrap = h('div', { class: 'params' });
    const env = this.env(op);
    const isInteger = op.gate === 'modmul';
    (op.params ?? []).forEach((value, i) => {
      const name = names[i] ?? `p${i}`;
      const input = h('input', { class: 'field mono', value: String(value), 'aria-label': `Parámetro ${name}`, spellcheck: 'false' }) as HTMLInputElement;
      const evalEl = h('div', { class: 'param-eval mono' });
      const slider = isInteger ? null : (h('input', { type: 'range', min: String(-2 * Math.PI), max: String(2 * Math.PI), step: '0.001', 'aria-label': `Deslizador ${name}` }) as HTMLInputElement);
      const show = (raw: string) => {
        const r = tryEvaluate(/^-?\d+(\.\d+)?$/.test(raw.trim()) ? Number(raw) : raw, env);
        if (r.value === undefined) {
          input.classList.add('invalid');
          evalEl.textContent = r.error ?? 'Expresión no válida';
          evalEl.classList.add('bad');
          return null;
        }
        input.classList.remove('invalid');
        evalEl.classList.remove('bad');
        evalEl.textContent = isInteger ? `= ${trimNum(r.value, 0)}` : `= ${trimNum(r.value, 4)} rad · ${fmtAngle(r.value)}`;
        if (slider && Math.abs(r.value) <= 2 * Math.PI) slider.value = String(r.value);
        return r.value;
      };
      show(String(value));
      const commitValue = (raw: string, continuous: boolean) => {
        const params = [...(op.params ?? [])];
        params[i] = /^-?\d+(\.\d+)?$/.test(raw.trim()) ? Number(raw) : raw.trim();
        const latest = this.circuit.ops.find((o) => o.id === op.id) ?? op;
        const merged = [...(latest.params ?? [])];
        merged[i] = params[i];
        this.commit({ ...this.circuit, ops: this.circuit.ops.map((o) => (o.id === op.id ? { ...latest, params: merged } : o)) },
          `Parámetro ${name}`, `param:${op.id}:${i}`, continuous);
      };
      input.addEventListener('input', () => {
        if (show(input.value) !== null) commitValue(input.value, false);
      });
      slider?.addEventListener('input', () => {
        const expr = angleExpr(Number(slider.value));
        input.value = expr;
        show(expr);
        commitValue(expr, true);
      });
      wrap.appendChild(
        h('div', { class: 'param' },
          h('div', { class: 'param-top' }, h('label', { class: 'param-name math' }, name), input),
          evalEl,
          slider,
        ),
      );
    });
    const loops = loopsContaining(this.circuit, op.col);
    if (loops.length) wrap.appendChild(h('p', { class: 'hint' }, `Variables disponibles: ${loops.map((l) => l.var).join(', ')} (ciclo for).`));
    return section('Parámetros', wrap);
  }

  private unitarySection(op: Op): HTMLElement {
    const dim = op.matrix?.length ?? 2;
    const mat = op.matrix ?? [];
    const grid = h('div', { class: 'umatrix', style: { gridTemplateColumns: `repeat(${dim}, minmax(0, 1fr))` } });
    const status = h('p', { class: 'hint' });
    const parse = (text: string): [number, number] | null => {
      // Acepta «a», «bi», «a+bi», «a-bi» con expresiones (p. ej. 1/sqrt(2)).
      const t = text.replace(/\s+/g, '');
      if (!t) return [0, 0];
      const m = t.match(/^(.*?)([+-][^+-]*)i$/);
      if (m && m[1] !== '') {
        const re = tryEvaluate(m[1]).value;
        const im = tryEvaluate(m[2] === '+' || m[2] === '-' ? `${m[2]}1` : m[2]).value;
        return re === undefined || im === undefined ? null : [re, im];
      }
      if (t.endsWith('i')) {
        const core = t.slice(0, -1);
        const im = tryEvaluate(core === '' || core === '+' ? '1' : core === '-' ? '-1' : core).value;
        return im === undefined ? null : [0, im];
      }
      const re = tryEvaluate(t).value;
      return re === undefined ? null : [re, 0];
    };
    const fmt = (z: number[]) => fmtComplex(z[0], z[1] ?? 0, 4).replace(/−/g, '-').replace(/\s/g, '');
    const update = () => {
      const values: number[][][] = [];
      let ok = true;
      for (let i = 0; i < dim; i++) {
        const row: number[][] = [];
        for (let j = 0; j < dim; j++) {
          const cell = grid.querySelector(`[data-cell="${i}-${j}"]`) as HTMLInputElement;
          const z = parse(cell.value);
          cell.classList.toggle('invalid', !z);
          if (!z) ok = false;
          row.push(z ?? [0, 0]);
        }
        values.push(row);
      }
      if (!ok) {
        status.textContent = 'Hay celdas que no son números complejos válidos.';
        return;
      }
      const m: Matrix = values.map((r) => r.map(([re, im]) => cnum(re, im)));
      if (!isUnitary(m, 1e-6)) {
        status.textContent = 'La matriz no es unitaria (U†U ≠ I): no se aplicará hasta corregirla.';
        status.classList.add('error-text');
        return;
      }
      status.classList.remove('error-text');
      status.textContent = 'Unitaria ✓';
      this.commit({ ...this.circuit, ops: this.circuit.ops.map((o) => (o.id === op.id ? { ...o, matrix: values } : o)) }, 'Editar matriz', `matrix:${op.id}`);
    };
    for (let i = 0; i < dim; i++) {
      for (let j = 0; j < dim; j++) {
        const cell = h('input', { class: 'field mono', 'data-cell': `${i}-${j}`, value: fmt(mat[i]?.[j] ?? [0, 0]), 'aria-label': `Elemento ${i},${j}` }) as HTMLInputElement;
        cell.addEventListener('change', update);
        grid.appendChild(cell);
      }
    }
    const presets = h('div', { class: 'insp-actions wrap' },
      h('button', { class: 'btn btn-sm', onclick: () => setPreset('id') }, 'Identidad'),
      h('button', { class: 'btn btn-sm', onclick: () => setPreset('haar') }, 'Aleatoria (Haar)'),
      dim === 2 ? h('button', { class: 'btn btn-sm', onclick: () => setPreset('h') }, 'Hadamard') : h('button', { class: 'btn btn-sm', onclick: () => setPreset('sqrtswap') }, '√SWAP'),
    );
    const setPreset = (kind: string) => {
      let m: number[][][];
      const s2 = Math.SQRT1_2;
      if (kind === 'haar') m = randomUnitary(dim);
      else if (kind === 'h') m = [[[s2, 0], [s2, 0]], [[s2, 0], [-s2, 0]]];
      else if (kind === 'sqrtswap') m = [[[1, 0], [0, 0], [0, 0], [0, 0]], [[0, 0], [0.5, 0.5], [0.5, -0.5], [0, 0]], [[0, 0], [0.5, -0.5], [0.5, 0.5], [0, 0]], [[0, 0], [0, 0], [0, 0], [1, 0]]];
      else m = Array.from({ length: dim }, (_, i) => Array.from({ length: dim }, (_, j) => [i === j ? 1 : 0, 0]));
      this.commit({ ...this.circuit, ops: this.circuit.ops.map((o) => (o.id === op.id ? { ...o, matrix: m } : o)) }, 'Matriz predefinida');
      this.render();
    };
    const nameInput = h('input', { class: 'field', value: op.label ?? 'U', maxlength: '8', 'aria-label': 'Etiqueta' }) as HTMLInputElement;
    nameInput.addEventListener('change', () => this.commit({ ...this.circuit, ops: this.circuit.ops.map((o) => (o.id === op.id ? { ...o, label: nameInput.value || 'U' } : o)) }, 'Etiqueta'));
    return section('Matriz unitaria', h('label', { class: 'mini-field' }, h('span', { class: 'label' }, 'Etiqueta'), nameInput),
      h('p', { class: 'hint' }, 'Escribe cada elemento como a+bi; se admiten expresiones (1/sqrt(2), cos(pi/8)…).'), grid, status, presets);
  }

  private measureSection(op: Op): HTMLElement {
    const c = this.circuit;
    const m = c.num_clbits;
    const current = op.clbits?.[0] ?? 0;
    if (m === 0) {
      return section('Bit clásico', h('button', { class: 'btn', onclick: () => this.commit(setNumClbits(c, 1), 'Añadir bit clásico') }, icon('plus'), 'Añadir un bit clásico'));
    }
    const sel = h('select', { class: 'field', 'aria-label': 'Bit clásico' }) as HTMLSelectElement;
    for (let i = 0; i < m; i++) sel.appendChild(h('option', { value: String(i), selected: i === current }, c.clbit_labels?.[i] ?? `c${i}`));
    sel.addEventListener('change', () => this.commit({ ...c, ops: c.ops.map((o) => (o.id === op.id ? { ...o, clbits: [Number(sel.value)] } : o)) }, 'Bit clásico'));
    return section('Bit clásico', sel);
  }

  private conditionSection(op: Op): HTMLElement {
    const c = this.circuit;
    const m = c.num_clbits;
    if (m === 0) return section('Control clásico', h('p', { class: 'hint' }, 'Añade bits clásicos (pestaña Ejecución) para condicionar esta compuerta a una medición.'));
    const conds = op.condition ?? [];
    const list = h('div', { class: 'conds' });
    const save = (next: { clbit: number; value: 0 | 1 }[]) =>
      this.commit({ ...this.circuit, ops: this.circuit.ops.map((o) => (o.id === op.id ? { ...o, condition: next.length ? next : null } : o)) }, 'Control clásico');
    conds.forEach((cond, idx) => {
      const bit = h('select', { class: 'field', 'aria-label': 'Bit' }) as HTMLSelectElement;
      for (let i = 0; i < m; i++) bit.appendChild(h('option', { value: String(i), selected: i === cond.clbit }, c.clbit_labels?.[i] ?? `c${i}`));
      const val = h('select', { class: 'field', 'aria-label': 'Valor' }) as HTMLSelectElement;
      for (const v of [1, 0]) val.appendChild(h('option', { value: String(v), selected: v === cond.value }, `= ${v}`));
      const upd = () => save(conds.map((x, j) => (j === idx ? { clbit: Number(bit.value), value: Number(val.value) as 0 | 1 } : x)));
      bit.addEventListener('change', upd);
      val.addEventListener('change', upd);
      list.appendChild(h('div', { class: 'cond-row' }, h('span', { class: 'muted' }, idx === 0 ? 'si' : 'y'), bit, val,
        h('button', { class: 'btn btn-ghost btn-icon', 'aria-label': 'Quitar condición', onclick: () => save(conds.filter((_, j) => j !== idx)) }, '×')));
    });
    const used = new Set(conds.map((x) => x.clbit));
    const freeBit = Array.from({ length: m }, (_, i) => i).find((i) => !used.has(i));
    return section(
      'Control clásico',
      list,
      freeBit !== undefined ? h('button', { class: 'btn btn-sm', onclick: () => save([...conds, { clbit: freeBit, value: 1 }]) }, '+ Condición') : null,
      h('p', { class: 'hint' }, 'La compuerta solo se aplica si el bit medido vale lo indicado (circuito dinámico).'),
    );
  }

  private subcircuitSection(op: Op, sub?: SubcircuitDef): HTMLElement {
    const c = this.circuit;
    const n = c.num_qubits;
    const box = h('div', { class: 'sub-insp' });
    if (!sub) {
      box.appendChild(h('p', { class: 'insp-error' }, 'Este subcircuito ya no existe en la biblioteca.'));
      return section('Subcircuito', box);
    }
    const mapping = h('div', { class: 'mapping' });
    op.targets.forEach((q, i) => {
      mapping.appendChild(h('label', { class: 'role-row' }, h('span', { class: 'role-name' }, `Cúbit ${i} del bloque →`), qubitSelect(n, q, (nq) => {
        const next: Op = JSON.parse(JSON.stringify(op));
        const j = next.targets.indexOf(nq);
        if (j >= 0) next.targets[j] = q;
        next.controls = (next.controls ?? []).filter((x: number) => x !== nq);
        next.anticontrols = (next.anticontrols ?? []).filter((x: number) => x !== nq);
        next.targets[i] = nq;
        this.replaceOp(op, next, 'Asignar cúbit');
      }, `Asignación del cúbit ${i}`)));
    });
    box.appendChild(mapping);
    if (sub.num_clbits) {
      const cm = h('div', { class: 'mapping' });
      (op.clbits ?? []).forEach((cb, i) => {
        const sel = h('select', { class: 'field' }) as HTMLSelectElement;
        for (let k = 0; k < c.num_clbits; k++) sel.appendChild(h('option', { value: String(k), selected: k === cb }, `c${k}`));
        sel.addEventListener('change', () => {
          const clbits = [...(op.clbits ?? [])];
          clbits[i] = Number(sel.value);
          this.commit({ ...c, ops: c.ops.map((o) => (o.id === op.id ? { ...o, clbits } : o)) }, 'Asignar bit');
        });
        cm.appendChild(h('label', { class: 'role-row' }, h('span', { class: 'role-name' }, `Bit ${i} del bloque →`), sel));
      });
      box.appendChild(cm);
    }
    if (sub.params.length) {
      const env = this.env(op);
      const pw = h('div', { class: 'params' });
      for (const p of sub.params) {
        const raw = op.sub_params?.[p] ?? 0;
        const input = h('input', { class: 'field mono', value: String(raw), 'aria-label': `Parámetro ${p}` }) as HTMLInputElement;
        const ev = h('div', { class: 'param-eval mono' });
        const show = () => {
          const r = tryEvaluate(/^-?\d+(\.\d+)?$/.test(input.value.trim()) ? Number(input.value) : input.value, env);
          input.classList.toggle('invalid', r.value === undefined);
          ev.textContent = r.value === undefined ? r.error ?? '' : `= ${trimNum(r.value, 4)} · ${fmtAngle(r.value)}`;
          return r.value !== undefined;
        };
        show();
        input.addEventListener('input', () => {
          if (!show()) return;
          const v = /^-?\d+(\.\d+)?$/.test(input.value.trim()) ? Number(input.value) : input.value.trim();
          this.commit({ ...this.circuit, ops: this.circuit.ops.map((o) => (o.id === op.id ? { ...o, sub_params: { ...(o.sub_params ?? {}), [p]: v } } : o)) }, `Parámetro ${p}`, `sub:${op.id}:${p}`);
        });
        pw.appendChild(h('div', { class: 'param' }, h('div', { class: 'param-top' }, h('label', { class: 'param-name math' }, prettyParam(p)), input), ev));
      }
      box.appendChild(h('h4', null, 'Parámetros'));
      box.appendChild(pw);
    }
    box.appendChild(
      h('div', { class: 'insp-actions wrap' },
        h('button', { class: 'btn btn-sm', onclick: () => this.hooks.openInstance?.(op.id) }, icon('eye'), 'Inspeccionar'),
        h('button', { class: 'btn btn-sm', onclick: () => this.hooks.editSubcircuit?.(sub.id) }, icon('edit'), 'Editar definición'),
        h('button', { class: 'btn btn-sm', onclick: () => this.hooks.ungroup?.(op.id) }, icon('ungroup'), 'Desagrupar'),
      ),
    );
    return section(`Subcircuito · ${sub.num_qubits} cúbit${sub.num_qubits === 1 ? '' : 's'}`, box);
  }
}

// ---------------------------------------------------------------------------------------------
// Panel de configuración de la ejecución.
// ---------------------------------------------------------------------------------------------

export interface ConfigHost {
  getCircuit(): Circuit;
  getConfig(): SimConfig;
  maxQubits(): number;
  engineLabel(): string;
  commitCircuit(next: Circuit, label: string): void;
  setConfig(patch: Partial<SimConfig>, continuous?: boolean): void;
  subscribe(fn: () => void): () => void;
}

function stepper(label: string, value: number, min: number, max: number, onchange: (v: number) => void): HTMLElement {
  const input = h('input', { class: 'field mono', type: 'number', value: String(value), min: String(min), max: String(max), 'aria-label': label }) as HTMLInputElement;
  const set = (v: number) => {
    const clamped = Math.max(min, Math.min(max, Math.round(v)));
    input.value = String(clamped);
    if (clamped !== value) onchange(clamped);
  };
  input.addEventListener('change', () => set(Number(input.value)));
  return h('div', { class: 'stepper' },
    h('button', { class: 'btn btn-icon', 'aria-label': `Reducir ${label}`, onclick: () => set(value - 1), disabled: value <= min }, icon('minus')),
    input,
    h('button', { class: 'btn btn-icon', 'aria-label': `Aumentar ${label}`, onclick: () => set(value + 1), disabled: value >= max }, icon('plus')),
  );
}

export class ConfigPanel {
  readonly element: HTMLElement;
  private host: ConfigHost;
  private lastKey = '';

  constructor(container: HTMLElement, host: ConfigHost) {
    this.element = container;
    this.host = host;
    container.classList.add('config-panel');
    host.subscribe(() => this.maybeRender());
    this.render();
  }

  private maybeRender(): void {
    const c = this.host.getCircuit();
    const key = JSON.stringify([c.num_qubits, c.num_clbits, c.initial_state, this.host.getConfig(), this.host.maxQubits(), this.host.engineLabel()]);
    if (key === this.lastKey) return;
    this.lastKey = key;
    if (this.element.contains(document.activeElement) && (document.activeElement as HTMLElement).tagName === 'INPUT' && (document.activeElement as HTMLInputElement).type !== 'range') return;
    this.render();
  }

  render(): void {
    const c = this.host.getCircuit();
    const cfg = this.host.getConfig();
    clear(this.element);
    const n = c.num_qubits;

    const initInput = h('input', { class: 'field mono', value: (c.initial_state || '').padStart(n, '0'), maxlength: String(n), 'aria-label': 'Estado inicial', spellcheck: 'false' }) as HTMLInputElement;
    initInput.addEventListener('change', () => {
      const v = initInput.value.trim();
      if (v.length !== n || /[^01]/.test(v)) {
        initInput.classList.add('invalid');
        toast(`El estado inicial debe tener ${n} bits (0 o 1)`, { kind: 'error' });
        return;
      }
      initInput.classList.remove('invalid');
      this.host.commitCircuit({ ...c, initial_state: v }, 'Estado inicial');
    });

    const seg = (options: [string, string][], value: string, onpick: (v: string) => void, label: string) =>
      h('div', { class: 'seg full', role: 'group', 'aria-label': label },
        ...options.map(([v, text]) => h('button', { 'aria-pressed': v === value ? 'true' : 'false', onclick: () => onpick(v) }, text)));

    const noise = cfg.noise;
    const slider = (label: string, key: 'p1' | 'p2' | 'readout', max: number, stepV: number) => {
      const val = h('span', { class: 'mono soft' }, `${(noise[key] * 100).toFixed(2)} %`);
      const r = h('input', { type: 'range', min: '0', max: String(max), step: String(stepV), value: String(noise[key]), 'aria-label': label }) as HTMLInputElement;
      r.addEventListener('input', () => {
        val.textContent = `${(Number(r.value) * 100).toFixed(2)} %`;
        this.host.setConfig({ noise: { ...this.host.getConfig().noise, [key]: Number(r.value) } }, true);
      });
      return h('div', { class: 'slider-row' }, h('div', { class: 'slider-top' }, h('span', { class: 'label' }, label), val), r);
    };
    const numField = (label: string, key: 't1' | 't2' | 'time_1q' | 'time_2q', unit: string) => {
      const input = h('input', { class: 'field mono', type: 'number', step: 'any', min: '0', value: String(noise[key]), 'aria-label': label }) as HTMLInputElement;
      input.addEventListener('change', () => {
        const v = Number(input.value);
        if (!(v > 0) && key.startsWith('t')) {
          input.classList.add('invalid');
          return;
        }
        input.classList.remove('invalid');
        this.host.setConfig({ noise: { ...this.host.getConfig().noise, [key]: v } });
      });
      return h('label', { class: 'mini-field' }, h('span', { class: 'label' }, `${label} (${unit})`), input);
    };

    const shotsInput = h('input', { class: 'field mono', type: 'number', min: '1', max: '100000', value: String(cfg.shots), 'aria-label': 'Disparos' }) as HTMLInputElement;
    shotsInput.addEventListener('change', () => {
      const v = Math.max(1, Math.min(100000, Math.round(Number(shotsInput.value) || 1024)));
      shotsInput.value = String(v);
      this.host.setConfig({ shots: v });
    });
    const seedInput = h('input', { class: 'field mono', type: 'number', min: '0', placeholder: 'aleatoria', value: cfg.seed === null ? '' : String(cfg.seed), 'aria-label': 'Semilla' }) as HTMLInputElement;
    seedInput.addEventListener('change', () => this.host.setConfig({ seed: seedInput.value === '' ? null : Math.max(0, Math.round(Number(seedInput.value))) }));

    this.element.append(
      section('Registros',
        h('div', { class: 'grid2' },
          h('div', null, h('span', { class: 'label' }, 'Cúbits'), stepper('cúbits', n, 1, this.host.maxQubits(), (v) => this.host.commitCircuit(setNumQubits(c, v), 'Número de cúbits'))),
          h('div', null, h('span', { class: 'label' }, 'Bits clásicos'), stepper('bits clásicos', c.num_clbits, 0, 64, (v) => this.host.commitCircuit(setNumClbits(c, v), 'Bits clásicos'))),
        ),
        h('label', { class: 'mini-field' }, h('span', { class: 'label' }, 'Estado inicial (q0 es el bit de la derecha)'), initInput),
      ),
      section('Modo de ejecución',
        seg([['statevector', 'Statevector'], ['shots', 'Shots']], cfg.mode, (v) => this.host.setConfig({ mode: v as SimConfig['mode'] }), 'Modo'),
        h('p', { class: 'hint' }, cfg.mode === 'statevector'
          ? 'Estado exacto: amplitudes y probabilidades sin muestreo. Las mediciones intermedias se resuelven con medición diferida.'
          : 'Muestreo con mediciones reales y control clásico en tiempo real, como en un dispositivo.'),
        cfg.mode === 'shots'
          ? h('div', { class: 'grid2' },
            h('label', { class: 'mini-field' }, h('span', { class: 'label' }, 'Disparos'), shotsInput),
            h('label', { class: 'mini-field' }, h('span', { class: 'label' }, 'Semilla'), seedInput))
          : null,
        cfg.mode === 'shots'
          ? h('div', { class: 'insp-actions wrap' }, ...[128, 1024, 8192].map((v) => h('button', { class: 'btn btn-sm', onclick: () => this.host.setConfig({ shots: v }) }, String(v))))
          : null,
      ),
      section('Modelo de ruido',
        seg([['none', 'Ninguno'], ['depolarizing', 'Despolarizante'], ['thermal', 'Térmico']], noise.model, (v) => this.host.setConfig({ noise: { ...noise, model: v as SimConfig['noise']['model'] } }), 'Ruido'),
        noise.model === 'depolarizing'
          ? h('div', { class: 'stack' }, slider('Error por compuerta de 1 cúbit (p1)', 'p1', 0.2, 0.0005), slider('Error por compuerta de 2 cúbits (p2)', 'p2', 0.3, 0.0005), slider('Error de lectura', 'readout', 0.3, 0.0005))
          : null,
        noise.model === 'thermal'
          ? h('div', { class: 'stack' },
            h('div', { class: 'grid2' }, numField('T1', 't1', 'µs'), numField('T2', 't2', 'µs')),
            h('div', { class: 'grid2' }, numField('Compuerta 1q', 'time_1q', 'µs'), numField('Compuerta 2q', 'time_2q', 'µs')),
            slider('Error de lectura', 'readout', 0.3, 0.0005),
            h('p', { class: 'hint' }, 'Debe cumplirse T2 ≤ 2·T1. La compuerta I sirve como espera para ver la decoherencia.'))
          : null,
      ),
      h('p', { class: 'engine-line muted' }, this.host.engineLabel()),
    );
  }
}
