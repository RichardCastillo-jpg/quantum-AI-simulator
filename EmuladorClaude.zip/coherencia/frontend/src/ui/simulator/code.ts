// Editor de código Qiskit sincronizado con el circuito.
//
// * Circuito → código: cada cambio hecho en el editor visual regenera el código (el backend
//   lo escribe con ciclos for y subcircuitos como funciones).
// * Código → circuito: al dejar de escribir (o con Ctrl+Enter) el backend interpreta el código
//   (sin ejecutarlo: recorre su árbol sintáctico) y el circuito resultante sustituye al actual,
//   con lo que se re-ejecuta la simulación y se actualizan histograma, amplitudes y esferas.
// * Selección: al seleccionar compuertas se resaltan sus líneas; al hacer clic en una línea se
//   selecciona la compuerta que crea.

import { api, ApiError } from '../../lib/api';
import { copyText, download, h } from '../../lib/dom';
import type { Circuit, Op } from '../../lib/types';
import { icon, toast } from '../common';
import type { SimController } from './controller';

type Sync = 'loading' | 'synced' | 'editing' | 'applying' | 'error' | 'offline';

const APPLY_DELAY = 700;
const LINE_H = 20;

const KEYWORDS = new Set([
  'False', 'None', 'True', 'and', 'as', 'assert', 'break', 'class', 'continue', 'def', 'del', 'elif', 'else',
  'except', 'for', 'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'not', 'or', 'pass', 'return',
  'while', 'with', 'yield',
]);
const BUILTINS = new Set(['range', 'len', 'list', 'enumerate', 'zip', 'reversed', 'int', 'float', 'print', 'abs',
  'min', 'max', 'sum', 'round', 'pi', 'np', 'math', 'sqrt']);

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/** Resaltado sintáctico ligero de Python (un solo recorrido, admite cadenas triples). */
export function highlightPython(src: string): string {
  const re = /("""[\s\S]*?(?:"""|$)|'''[\s\S]*?(?:'''|$)|[rRbBfF]{0,2}"(?:\\.|[^"\\\n])*"?|[rRbBfF]{0,2}'(?:\\.|[^'\\\n])*'?)|(#[^\n]*)|(\b\d+(?:\.\d*)?(?:[eE][+-]?\d+)?j?\b|\.\d+\b)|([A-Za-z_À-￿][\wÀ-￿]*)/g;
  let out = '';
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(src))) {
    out += escapeHtml(src.slice(last, m.index));
    const [tok, str, com, num, ident] = m;
    if (str) out += `<span class="t-str">${escapeHtml(tok)}</span>`;
    else if (com) out += `<span class="t-com">${escapeHtml(tok)}</span>`;
    else if (num) out += `<span class="t-num">${tok}</span>`;
    else if (ident) {
      const next = src.slice(re.lastIndex).match(/^\s*\(/);
      const prev = src.slice(Math.max(0, m.index - 1), m.index);
      let cls = '';
      if (KEYWORDS.has(ident)) cls = 't-kw';
      else if (prev === '.' && next) cls = 't-meth';
      else if (/^[A-Z]/.test(ident) && next) cls = 't-cls';
      else if (next || BUILTINS.has(ident)) cls = 't-fn';
      out += cls ? `<span class="${cls}">${escapeHtml(tok)}</span>` : escapeHtml(tok);
    }
    last = re.lastIndex;
  }
  out += escapeHtml(src.slice(last));
  return out + '\n';
}

/** Limpia los null del modelo devuelto por el backend para ajustarlo a los tipos del frontend. */
function cleanCircuit(raw: Circuit): Circuit {
  const ops = raw.ops.map((op) => {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(op)) if (v !== null && v !== undefined) out[k] = v;
    return out as unknown as Op;
  });
  return { ...raw, ops, loops: raw.loops ?? [] };
}

export class CodePanel {
  readonly root: HTMLElement;
  private ta: HTMLTextAreaElement;
  private hl: HTMLElement;
  private gutter: HTMLElement;
  private marks: HTMLElement;
  private status: HTMLElement;
  private msgs: HTMLElement;
  private staleBar: HTMLElement;

  private visible = false;
  private dirty = false;
  private applyingFromCode = false;
  private syncedCircuit: Circuit | null = null;
  private opToLine = new Map<string, number>();
  private lineToOps = new Map<number, string[]>();
  private errorLine: number | null = null;
  private applyTimer = 0;
  private genTimer = 0;
  private seq = 0;
  private abort: AbortController | null = null;

  constructor(host: HTMLElement, private ctrl: SimController) {
    this.status = h('span', { class: 'code-status', role: 'status', 'aria-live': 'polite' });
    this.ta = h('textarea', {
      class: 'code-input', spellcheck: 'false', autocapitalize: 'off', autocomplete: 'off', wrap: 'off',
      'aria-label': 'Código Qiskit del circuito',
    }) as HTMLTextAreaElement;
    this.hl = h('pre', { class: 'code-hl', 'aria-hidden': 'true' });
    this.marks = h('div', { class: 'code-marks', 'aria-hidden': 'true' });
    this.gutter = h('div', { class: 'code-gutter', 'aria-hidden': 'true' });
    this.msgs = h('div', { class: 'code-msgs' });
    this.staleBar = h('div', { class: 'code-stale', hidden: true },
      h('span', null, 'El circuito cambió en el editor visual y tu código tiene cambios sin aplicar.'),
      h('button', { class: 'btn btn-sm', onclick: () => this.regenerate(true) }, 'Usar el código del circuito'));

    const regenBtn = h('button', { class: 'btn btn-sm', title: 'Vuelve a escribir el código a partir del circuito', onclick: () => this.regenerate(true) }, icon('undo'), 'Desde el circuito');
    const copyBtn = h('button', { class: 'btn btn-sm', title: 'Copiar el código', onclick: async () => {
      toast((await copyText(this.ta.value)) ? 'Código copiado' : 'No se pudo copiar');
    } }, icon('copy'), 'Copiar');
    const dlBtn = h('button', { class: 'btn btn-sm', title: 'Descargar como archivo .py', onclick: () => {
      const name = (this.ctrl.store.get().circuit.name || 'circuito').replace(/[^\w\-áéíóúñ ]+/gi, '').trim() || 'circuito';
      download(`${name}.py`, this.ta.value, 'text/x-python');
    } }, icon('download'), '.py');

    this.root = h('div', { class: 'code-panel' },
      h('div', { class: 'code-head' },
        h('div', { class: 'code-title' }, h('h3', null, 'Código Qiskit'), this.status),
        h('div', { class: 'code-actions' }, regenBtn, copyBtn, dlBtn)),
      this.staleBar,
      h('div', { class: 'code-editor' },
        this.gutter,
        h('div', { class: 'code-area' }, this.marks, this.hl, this.ta)),
      this.msgs,
      h('p', { class: 'hint code-hint' },
        'Escribe Qiskit como en IBM Quantum: al dejar de escribir (o con Ctrl+Enter) el circuito, el histograma y las esferas se actualizan. ',
        'Las líneas para ejecutar o dibujar (AerSimulator, print, plot_histogram) se ignoran. Clic en una línea para seleccionar su compuerta.'),
    );
    host.append(this.root);

    this.ta.addEventListener('input', () => this.onInput());
    this.ta.addEventListener('scroll', () => this.syncScroll());
    this.ta.addEventListener('keydown', (ev) => this.onKey(ev));
    this.ta.addEventListener('click', () => this.selectFromCaret());
    this.ta.addEventListener('keyup', (ev) => {
      if (ev.key.startsWith('Arrow') || ev.key === 'Home' || ev.key === 'End' || ev.key.startsWith('Page')) this.selectFromCaret();
    });

    const store = ctrl.store;
    store.select((s) => s.circuit, (c) => this.onCircuit(c));
    store.select((s) => s.selection, () => this.paintMarks());
    this.setStatus('loading');
  }

  setVisible(v: boolean): void {
    this.visible = v;
    if (v && !this.dirty && this.syncedCircuit !== this.ctrl.store.get().circuit) this.regenerate();
    if (v) requestAnimationFrame(() => this.syncScroll());
  }

  // ------------------------------------------------------------------ circuito → código
  private onCircuit(c: Circuit): void {
    if (this.applyingFromCode) {
      this.syncedCircuit = c;
      return;
    }
    if (c === this.syncedCircuit) return;
    if (this.dirty) {
      this.staleBar.hidden = false;
      return;
    }
    if (!this.visible) return; // se regenera al mostrarse
    clearTimeout(this.genTimer);
    this.genTimer = window.setTimeout(() => this.regenerate(), 120);
  }

  async regenerate(force = false): Promise<void> {
    if (this.dirty && !force) return;
    clearTimeout(this.applyTimer);
    this.abort?.abort();
    const circuit = this.ctrl.store.get().circuit;
    const mySeq = ++this.seq;
    this.setStatus('loading');
    try {
      const res = await api.codeFromCircuit(circuit);
      if (mySeq !== this.seq) return;
      this.syncedCircuit = circuit;
      this.dirty = false;
      this.errorLine = null;
      this.staleBar.hidden = true;
      this.setText(res.code);
      this.setMap(Object.entries(res.line_map));
      this.showMessages([], res.warnings);
      this.setStatus('synced');
    } catch (err) {
      if (mySeq !== this.seq) return;
      this.setStatus('offline');
      this.showMessages([err instanceof Error ? err.message : String(err)], []);
    }
  }

  // ------------------------------------------------------------------ código → circuito
  private onInput(): void {
    this.dirty = true;
    this.errorLine = null;
    this.render();
    this.setStatus('editing');
    clearTimeout(this.applyTimer);
    this.applyTimer = window.setTimeout(() => this.apply(), APPLY_DELAY);
  }

  async apply(): Promise<void> {
    clearTimeout(this.applyTimer);
    const code = this.ta.value;
    const mySeq = ++this.seq;
    this.abort?.abort();
    const abort = new AbortController();
    this.abort = abort;
    this.setStatus('applying');
    try {
      const current = this.ctrl.store.get().circuit;
      const res = await api.codeToCircuit(code, current.name, abort.signal);
      if (mySeq !== this.seq) return;
      const next = cleanCircuit(res.circuit);
      this.applyingFromCode = true;
      try {
        this.ctrl.commit(next, { label: 'Código Qiskit', coalesce: 'qiskit-code', select: [] });
      } finally {
        this.applyingFromCode = false;
      }
      this.syncedCircuit = this.ctrl.store.get().circuit;
      this.dirty = false;
      this.errorLine = null;
      this.staleBar.hidden = true;
      this.setMap(Object.entries(res.op_lines));
      this.showMessages([], res.warnings);
      this.setStatus('synced');
    } catch (err) {
      if ((err as Error)?.name === 'AbortError' || mySeq !== this.seq) return;
      if (err instanceof ApiError) {
        const line = err.errors.find((e) => e.line)?.line ?? null;
        this.errorLine = line ?? null;
        this.setStatus(err.status === 0 || err.status >= 500 ? 'offline' : 'error', line);
        this.showMessages([err.message], [], line);
      } else {
        this.setStatus('error');
        this.showMessages([String(err)], []);
      }
      this.paintMarks();
    }
  }

  // ------------------------------------------------------------------ vista
  private setText(code: string): void {
    const { selectionStart, selectionEnd, scrollTop, scrollLeft } = this.ta;
    this.ta.value = code;
    if (document.activeElement === this.ta) {
      this.ta.setSelectionRange(Math.min(selectionStart, code.length), Math.min(selectionEnd, code.length));
    }
    this.ta.scrollTop = scrollTop;
    this.ta.scrollLeft = scrollLeft;
    this.render();
  }

  private setMap(entries: [string, number][]): void {
    this.opToLine = new Map(entries);
    this.lineToOps = new Map();
    for (const [id, line] of entries) {
      const list = this.lineToOps.get(line) ?? [];
      list.push(id);
      this.lineToOps.set(line, list);
    }
    this.paintMarks();
  }

  private render(): void {
    const text = this.ta.value;
    this.hl.innerHTML = highlightPython(text);
    const lines = text.split('\n').length;
    let nums = '';
    for (let i = 1; i <= lines; i++) nums += `${i}\n`;
    this.gutter.textContent = nums;
    this.paintMarks();
    this.syncScroll();
  }

  private paintMarks(): void {
    const sel = new Set(this.ctrl.store.get().selection);
    const lines = new Set<number>();
    if (!this.dirty) for (const id of sel) {
      const line = this.opToLine.get(id);
      if (line) lines.add(line);
    }
    this.marks.replaceChildren();
    for (const line of lines) {
      this.marks.append(h('div', { class: 'code-mark sel', style: `top:${(line - 1) * LINE_H + 10}px` }));
    }
    if (this.errorLine) {
      this.marks.append(h('div', { class: 'code-mark err', style: `top:${(this.errorLine - 1) * LINE_H + 10}px` }));
    }
    if (lines.size && this.visible && document.activeElement !== this.ta) {
      const first = Math.min(...lines);
      const top = (first - 1) * LINE_H;
      if (top < this.ta.scrollTop || top > this.ta.scrollTop + this.ta.clientHeight - 3 * LINE_H) {
        this.ta.scrollTop = Math.max(0, top - 3 * LINE_H);
      }
    }
  }

  private syncScroll(): void {
    const t = `translate(${-this.ta.scrollLeft}px, ${-this.ta.scrollTop}px)`;
    this.hl.style.transform = t;
    this.marks.style.transform = t;
    this.gutter.style.transform = `translateY(${-this.ta.scrollTop}px)`;
  }

  private setStatus(state: Sync, line?: number | null): void {
    const text: Record<Sync, string> = {
      loading: 'Generando…',
      synced: 'Sincronizado con el circuito',
      editing: 'Editando…',
      applying: 'Aplicando…',
      error: line ? `Error en la línea ${line}` : 'El código tiene errores',
      offline: 'Sin conexión con el motor',
    };
    this.status.textContent = text[state];
    this.status.dataset.state = state;
  }

  private showMessages(errors: string[], warnings: string[], line?: number | null): void {
    this.msgs.replaceChildren(
      ...errors.map((m) => h('p', { class: 'code-msg err' }, line
        ? h('button', { class: 'linklike', onclick: () => this.goToLine(line) }, `Línea ${line}`)
        : null, line ? ` · ${m.replace(/^Línea \d+:\s*/, '')}` : m)),
      ...warnings.map((m) => h('p', { class: 'code-msg warn' }, m)),
    );
  }

  private goToLine(line: number): void {
    const lines = this.ta.value.split('\n');
    let pos = 0;
    for (let i = 0; i < line - 1 && i < lines.length; i++) pos += lines[i].length + 1;
    this.ta.focus();
    this.ta.setSelectionRange(pos, pos + (lines[line - 1]?.length ?? 0));
    this.ta.scrollTop = Math.max(0, (line - 4) * LINE_H);
  }

  private caretLine(): number {
    return this.ta.value.slice(0, this.ta.selectionStart).split('\n').length;
  }

  private selectFromCaret(): void {
    if (this.dirty) return;
    const ids = this.lineToOps.get(this.caretLine());
    const circuitIds = new Set(this.ctrl.store.get().circuit.ops.map((o) => o.id));
    const valid = (ids ?? []).filter((id) => circuitIds.has(id));
    if (valid.length) this.ctrl.store.set({ selection: valid });
  }

  // ------------------------------------------------------------------ teclado
  private onKey(ev: KeyboardEvent): void {
    const ta = this.ta;
    if ((ev.ctrlKey || ev.metaKey) && ev.key === 'Enter') {
      ev.preventDefault();
      ev.stopPropagation();
      this.apply();
      return;
    }
    if (ev.key === 'Tab') {
      ev.preventDefault();
      const { selectionStart: a, selectionEnd: b, value } = ta;
      const lineStart = value.lastIndexOf('\n', a - 1) + 1;
      if (ev.shiftKey || b > a) {
        // Sangrar o desangrar las líneas seleccionadas.
        const end = b;
        const block = value.slice(lineStart, end);
        const changed = ev.shiftKey
          ? block.replace(/^ {1,4}/gm, '')
          : block.replace(/^/gm, '    ');
        this.replaceRange(lineStart, end, changed, lineStart, lineStart + changed.length);
      } else {
        this.replaceRange(a, b, '    ', a + 4, a + 4);
      }
      return;
    }
    if (ev.key === 'Enter' && !ev.shiftKey && !ev.altKey) {
      const { selectionStart: a, selectionEnd: b, value } = ta;
      const lineStart = value.lastIndexOf('\n', a - 1) + 1;
      const line = value.slice(lineStart, a);
      let indent = line.match(/^\s*/)?.[0] ?? '';
      if (/:\s*(#.*)?$/.test(line)) indent += '    ';
      ev.preventDefault();
      this.replaceRange(a, b, `\n${indent}`, a + 1 + indent.length, a + 1 + indent.length);
      return;
    }
    if (ev.key === 'Backspace' && ta.selectionStart === ta.selectionEnd) {
      const a = ta.selectionStart;
      const before = ta.value.slice(ta.value.lastIndexOf('\n', a - 1) + 1, a);
      if (before.length >= 4 && /^ +$/.test(before) && before.length % 4 === 0) {
        ev.preventDefault();
        this.replaceRange(a - 4, a, '', a - 4, a - 4);
      }
    }
  }

  /** Reemplaza texto conservando el historial nativo de deshacer del textarea cuando es posible. */
  private replaceRange(start: number, end: number, text: string, selStart: number, selEnd: number): void {
    const ta = this.ta;
    ta.focus();
    ta.setSelectionRange(start, end);
    let ok = false;
    try {
      ok = document.execCommand('insertText', false, text);
    } catch {
      ok = false;
    }
    if (!ok) {
      ta.setRangeText(text, start, end, 'end');
      ta.dispatchEvent(new Event('input', { bubbles: true }));
    }
    ta.setSelectionRange(selStart, selEnd);
  }
}
