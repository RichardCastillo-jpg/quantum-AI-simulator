// Piezas de interfaz compartidas: avisos, menús contextuales, tooltips y diálogos.

import { h } from '../lib/dom';

// --- Avisos -----------------------------------------------------------------------------
let toastRoot: HTMLElement | null = null;

export interface ToastOptions {
  kind?: 'info' | 'error';
  action?: { label: string; run: () => void };
  duration?: number;
}

export function toast(message: string, opts: ToastOptions = {}): void {
  if (!toastRoot) {
    toastRoot = h('div', { class: 'toasts', role: 'status', 'aria-live': 'polite' });
    document.body.appendChild(toastRoot);
  }
  const el = h('div', { class: `toast ${opts.kind === 'error' ? 'error' : ''}` }, h('span', null, message));
  if (opts.action) {
    const { label, run } = opts.action;
    el.appendChild(h('button', { class: 'btn btn-sm', onclick: () => { run(); el.remove(); } }, label));
  }
  toastRoot.appendChild(el);
  while (toastRoot.children.length > 3) toastRoot.firstElementChild?.remove();
  setTimeout(() => el.remove(), opts.duration ?? (opts.kind === 'error' ? 6000 : 3600));
}

// --- Menú contextual -------------------------------------------------------------------
export interface MenuItem {
  label: string;
  hint?: string;
  danger?: boolean;
  disabled?: boolean;
  run?: () => void;
  separator?: boolean;
}

let openMenu: HTMLElement | null = null;

export function closeMenu(): void {
  openMenu?.remove();
  openMenu = null;
}

export function showMenu(x: number, y: number, items: MenuItem[]): void {
  closeMenu();
  const menu = h('div', { class: 'menu', role: 'menu' });
  for (const item of items) {
    if (item.separator) {
      menu.appendChild(h('hr'));
      continue;
    }
    const btn = h(
      'button',
      {
        role: 'menuitem',
        class: item.danger ? 'danger' : '',
        disabled: item.disabled,
        onclick: () => {
          closeMenu();
          item.run?.();
        },
      },
      h('span', null, item.label),
      item.hint ? h('span', { class: 'kbd' }, item.hint) : null,
    );
    menu.appendChild(btn);
  }
  document.body.appendChild(menu);
  const rect = menu.getBoundingClientRect();
  menu.style.left = `${Math.min(x, window.innerWidth - rect.width - 8)}px`;
  menu.style.top = `${Math.min(y, window.innerHeight - rect.height - 8)}px`;
  openMenu = menu;
  (menu.querySelector('button:not([disabled])') as HTMLButtonElement | null)?.focus();
  setTimeout(() => {
    const away = (ev: Event) => {
      if (!menu.contains(ev.target as Node)) {
        closeMenu();
        document.removeEventListener('pointerdown', away, true);
      }
    };
    document.addEventListener('pointerdown', away, true);
  });
}

export function menuFromButton(button: HTMLElement, items: MenuItem[]): void {
  const r = button.getBoundingClientRect();
  showMenu(r.left, r.bottom + 6, items);
}

// --- Tooltip ---------------------------------------------------------------------------
let tip: HTMLElement | null = null;

export function showTooltip(x: number, y: number, content: Node | string): void {
  if (!tip) {
    tip = h('div', { class: 'tooltip', role: 'tooltip' });
    document.body.appendChild(tip);
  }
  tip.replaceChildren(typeof content === 'string' ? document.createTextNode(content) : content);
  tip.style.display = 'block';
  const r = tip.getBoundingClientRect();
  let left = x + 14;
  let top = y + 14;
  if (left + r.width > window.innerWidth - 8) left = x - r.width - 14;
  if (top + r.height > window.innerHeight - 8) top = y - r.height - 14;
  tip.style.left = `${left}px`;
  tip.style.top = `${top}px`;
}

export function hideTooltip(): void {
  if (tip) tip.style.display = 'none';
}

// --- Diálogos ----------------------------------------------------------------------------
export interface ModalHandle {
  root: HTMLElement;
  body: HTMLElement;
  foot: HTMLElement;
  close: () => void;
}

const modalStack: HTMLElement[] = [];

export function isModalOpen(): boolean {
  return modalStack.length > 0;
}

export function openModal(title: string, opts: { size?: 'wide' | 'medium'; onClose?: () => void; headExtra?: Node } = {}): ModalHandle {
  const body = h('div', { class: 'modal-body' });
  const foot = h('div', { class: 'modal-foot' });
  const titleId = `m-${Math.random().toString(36).slice(2, 8)}`;
  const close = () => {
    backdrop.remove();
    const idx = modalStack.indexOf(backdrop);
    if (idx >= 0) modalStack.splice(idx, 1);
    document.removeEventListener('keydown', onKey, true);
    opts.onClose?.();
    previous?.focus?.();
  };
  const onKey = (ev: KeyboardEvent) => {
    if (ev.key === 'Escape' && modalStack[modalStack.length - 1] === backdrop) {
      ev.stopPropagation();
      close();
    }
  };
  const modal = h(
    'div',
    { class: `modal ${opts.size ?? ''}`, role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': titleId },
    h(
      'div',
      { class: 'modal-head' },
      h('h2', { id: titleId }, title),
      h('div', { class: 'grow' }),
      opts.headExtra ?? null,
      h('button', { class: 'btn btn-ghost btn-icon', 'aria-label': 'Cerrar', onclick: () => close() }, '✕'),
    ),
    body,
    foot,
  );
  const backdrop = h('div', { class: 'modal-backdrop' }, modal);
  backdrop.addEventListener('pointerdown', (ev) => {
    if (ev.target === backdrop) close();
  });
  const previous = document.activeElement as HTMLElement | null;
  document.body.appendChild(backdrop);
  modalStack.push(backdrop);
  document.addEventListener('keydown', onKey, true);
  setTimeout(() => (modal.querySelector('input, textarea, select, button.btn-primary') as HTMLElement | null)?.focus());
  return { root: modal, body, foot, close };
}

export function confirmDialog(title: string, message: string, confirmLabel = 'Confirmar', danger = false): Promise<boolean> {
  return new Promise((resolve) => {
    let done = false;
    const m = openModal(title, { onClose: () => !done && resolve(false) });
    m.body.appendChild(h('p', { class: 'soft', style: { margin: '0' } }, message));
    m.foot.append(
      h('button', { class: 'btn btn-ghost', onclick: () => m.close() }, 'Cancelar'),
      h('button', { class: `btn ${danger ? 'btn-danger' : 'btn-primary'}`, onclick: () => { done = true; resolve(true); m.close(); } }, confirmLabel),
    );
  });
}

export function promptDialog(title: string, label: string, value: string, confirmLabel = 'Guardar'): Promise<string | null> {
  return new Promise((resolve) => {
    let done = false;
    const m = openModal(title, { onClose: () => !done && resolve(null) });
    const input = h('input', { class: 'field', value, 'aria-label': label });
    const submit = () => {
      const v = input.value.trim();
      if (!v) return;
      done = true;
      resolve(v);
      m.close();
    };
    input.addEventListener('keydown', (ev) => ev.key === 'Enter' && submit());
    m.body.append(h('label', { class: 'label' }, label), input);
    m.foot.append(
      h('button', { class: 'btn btn-ghost', onclick: () => m.close() }, 'Cancelar'),
      h('button', { class: 'btn btn-primary', onclick: submit }, confirmLabel),
    );
    setTimeout(() => input.select());
  });
}

// --- Iconos (trazos SVG en línea) ---------------------------------------------------------
const ICONS: Record<string, string> = {
  undo: 'M9 14 4 9l5-5M4 9h10a6 6 0 0 1 0 12h-3',
  redo: 'm15 14 5-5-5-5M20 9H10a6 6 0 0 0 0 12h3',
  play: 'M7 4v16l13-8z',
  prev: 'M15 5l-7 7 7 7',
  next: 'M9 5l7 7-7 7',
  pause: 'M7 4h4v16H7zM14 4h4v16h-4z',
  step: 'M6 4v16M10 4l10 8-10 8z',
  back: 'M18 4v16M14 4 4 12l10 8z',
  eye: 'M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12zm10 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  edit: 'm4 20 4-1 11-11-3-3L5 16zM14 6l3 3',
  trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13',
  plus: 'M12 5v14M5 12h14',
  minus: 'M5 12h14',
  more: 'M5 12h.01M12 12h.01M19 12h.01',
  download: 'M12 4v11m0 0-4-4m4 4 4-4M5 20h14',
  copy: 'M9 9h10v11H9zM5 15V4h10',
  loop: 'M4 12a8 8 0 0 1 14-5.3L20 9M20 4v5h-5M20 12a8 8 0 0 1-14 5.3L4 15m0 5v-5h5',
  box: 'M4 7l8-4 8 4v10l-8 4-8-4zM4 7l8 4 8-4M12 11v10',
  bug: 'M8 9h8v7a4 4 0 0 1-8 0zM9 9V7a3 3 0 0 1 6 0v2M4 13h4M16 13h4M5 8l3 2M19 8l-3 2M5 19l3-2M19 19l-3-2',
  rename: 'M4 20h16M6 16l9-9 3 3-9 9H6z',
  ungroup: 'M4 4h7v7H4zM13 13h7v7h-7zM14 4h6v6M4 14v6h6',
};

export function icon(name: string, title?: string): SVGSVGElement {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '1.8');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');
  const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  path.setAttribute('d', ICONS[name] ?? '');
  if (name === 'play') {
    path.setAttribute('fill', 'currentColor');
  }
  svg.appendChild(path);
  if (title) {
    const t = document.createElementNS('http://www.w3.org/2000/svg', 'title');
    t.textContent = title;
    svg.appendChild(t);
  }
  return svg;
}

export function iconButton(name: string, label: string, onclick: (ev: MouseEvent) => void, extraClass = ''): HTMLButtonElement {
  return h('button', { class: `btn btn-ghost btn-icon ${extraClass}`, 'aria-label': label, title: label, onclick }, icon(name));
}
