// Portada: un cúbit en la esfera de Bloch que responde a las compuertas que se pulsan.

import { add, mul, type C } from '../lib/complex';
import { h } from '../lib/dom';
import { fmtComplex } from '../lib/format';
import { baseMatrix } from '../lib/gates';
import { phaseColor } from '../lib/phase';
import { BlochSphere } from './bloch';

const GATES: [string, string, string][] = [
  ['h', 'H', 'clifford'], ['x', 'X', 'pauli'], ['y', 'Y', 'pauli'], ['z', 'Z', 'pauli'],
  ['s', 'S', 'phase'], ['t', 'T', 'phase'], ['sx', '√X', 'clifford'],
];

export function mountHero(root: HTMLElement): void {
  let a: C = { re: 1, im: 0 };
  let b: C = { re: 0, im: 0 };
  const history: string[] = [];
  const canvas = h('canvas', { role: 'img', 'aria-label': 'Esfera de Bloch del cúbit de demostración' }) as HTMLCanvasElement;
  const ketEl = h('div', { class: 'hero-ket', 'aria-live': 'polite' });
  const seqEl = h('p', { class: 'hero-caption' });
  const size = Math.min(340, Math.max(240, Math.floor((root.clientWidth || 360) - 40)));
  const sphere = new BlochSphere(canvas, size);

  const bloch = () => {
    const ab = mul({ re: a.re, im: -a.im }, b);
    return { x: 2 * ab.re, y: 2 * ab.im, z: a.re * a.re + a.im * a.im - (b.re * b.re + b.im * b.im) };
  };
  const amp = (z: C) => {
    const mag = Math.hypot(z.re, z.im);
    const span = h('span', { class: 'amp', style: { color: mag > 1e-9 ? phaseColor(Math.atan2(z.im, z.re)) : 'var(--ink-3)' } });
    const text = fmtComplex(z.re, z.im, 3);
    span.textContent = text.includes(' ') ? `(${text})` : text;
    return span;
  };
  const render = () => {
    ketEl.replaceChildren(amp(a), '|0⟩ + ', amp(b), '|1⟩');
    seqEl.textContent = history.length
      ? `Compuertas aplicadas: ${history.join(' → ')}. El color de cada amplitud es su fase.`
      : 'Pulsa una compuerta: el estado gira sobre la esfera y la fase se ve como color.';
  };

  const apply = (name: string, label: string) => {
    const m = baseMatrix(name, [])!;
    const na = add(mul(m[0][0], a), mul(m[0][1], b));
    const nb = add(mul(m[1][0], a), mul(m[1][1], b));
    const from = bloch();
    a = na;
    b = nb;
    history.push(label);
    if (history.length > 8) history.shift();
    sphere.setVector(bloch(), { from, duration: 650 });
    render();
  };

  const gates = h('div', { class: 'hero-gates', role: 'group', 'aria-label': 'Compuertas de un cúbit' },
    ...GATES.map(([name, label, cat]) => h('button', { class: `gate-tile cat-${cat}`, type: 'button', title: `Aplicar ${label}`, onclick: () => apply(name, label) }, label)),
    h('button', { class: 'btn btn-ghost', type: 'button', onclick: () => {
      const from = bloch();
      a = { re: 1, im: 0 };
      b = { re: 0, im: 0 };
      history.length = 0;
      sphere.setVector(bloch(), { from, duration: 500 });
      render();
    } }, 'Reiniciar a |0⟩'),
  );
  root.append(canvas, ketEl, gates, seqEl);
  sphere.setVector({ x: 0, y: 0, z: 1 }, { duration: 0 });
  render();
}
