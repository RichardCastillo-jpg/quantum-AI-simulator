// Formulario de parámetros de un algoritmo precargado (usado en el simulador y en /algoritmos).

import { h } from '../lib/dom';
import type { Preset } from '../lib/types';

export function presetForm(preset: Preset, onSubmit: (params: Record<string, unknown>) => void, submitLabel = 'Cargar en el simulador'): HTMLFormElement {
  const form = h('form', { class: 'preset-form', novalidate: true }) as HTMLFormElement;
  const inputs: Record<string, HTMLInputElement | HTMLSelectElement> = {};
  for (const p of preset.params) {
    let input: HTMLInputElement | HTMLSelectElement;
    if (p.type === 'select') {
      input = h('select', { class: 'field', name: p.key }) as HTMLSelectElement;
      for (const o of p.options ?? []) input.appendChild(h('option', { value: o.value, selected: String(p.default) === o.value }, o.label));
    } else if (p.type === 'bits') {
      input = h('input', { class: 'field mono', name: p.key, value: String(p.default), pattern: '[01]+', spellcheck: 'false', inputmode: 'numeric' }) as HTMLInputElement;
    } else {
      input = h('input', {
        class: 'field mono', name: p.key, type: 'number', value: String(p.default),
        min: p.min !== undefined ? String(p.min) : undefined, max: p.max !== undefined ? String(p.max) : undefined,
        step: p.type === 'integer' ? '1' : 'any',
      }) as HTMLInputElement;
    }
    inputs[p.key] = input;
    form.appendChild(h('label', { class: 'mini-field' }, h('span', { class: 'label' }, p.label), input));
  }
  const submit = h('button', { class: 'btn btn-primary', type: 'submit' }, submitLabel);
  form.appendChild(h('div', { class: 'form-actions' }, submit));
  form.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const params: Record<string, unknown> = {};
    for (const p of preset.params) {
      const raw = inputs[p.key].value.trim();
      params[p.key] = p.type === 'integer' || p.type === 'number' ? Number(raw) : raw;
    }
    // Grover: el estado marcado debe tener n bits; se ajusta para evitar un error evitable.
    if (preset.key === 'grover' && typeof params.marked === 'string' && typeof params.n === 'number') {
      const n = params.n as number;
      params.marked = (params.marked as string).padStart(n, '0').slice(-n);
    }
    onSubmit(params);
  });
  return form;
}
