// Esfera de Bloch 3D dibujada en canvas 2D con proyección y orden de profundidad propios.
// Se puede girar arrastrando (las vistas pueden sincronizarse) y anima el vector de estado
// por la geodésica entre dos estados, dejando una estela.

import { phaseColor } from '../lib/phase';
import { prefersReducedMotion } from '../lib/dom';

export interface Vec3 { x: number; y: number; z: number }
export interface View { yaw: number; pitch: number }

export const DEFAULT_VIEW: View = { yaw: (-32 * Math.PI) / 180, pitch: (18 * Math.PI) / 180 };

const cssVar = (name: string, fallback: string) =>
  (typeof document !== 'undefined' && getComputedStyle(document.documentElement).getPropertyValue(name).trim()) || fallback;

function norm(v: Vec3): number {
  return Math.hypot(v.x, v.y, v.z);
}

/** Interpolación esférica de direcciones y lineal de longitudes (estados mixtos). */
export function slerpVec(a: Vec3, b: Vec3, t: number): Vec3 {
  const ra = norm(a), rb = norm(b);
  const r = ra + (rb - ra) * t;
  if (ra < 1e-6 || rb < 1e-6) {
    return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t, z: a.z + (b.z - a.z) * t };
  }
  const ua = { x: a.x / ra, y: a.y / ra, z: a.z / ra };
  const ub = { x: b.x / rb, y: b.y / rb, z: b.z / rb };
  let dot = ua.x * ub.x + ua.y * ub.y + ua.z * ub.z;
  dot = Math.max(-1, Math.min(1, dot));
  if (dot > 0.99999) return { x: ub.x * r, y: ub.y * r, z: ub.z * r };
  let axis: Vec3;
  let omega = Math.acos(dot);
  if (dot < -0.99999) {
    // Antípodas: se gira alrededor de un eje perpendicular cualquiera.
    axis = Math.abs(ua.x) < 0.9 ? { x: 0, y: -ua.z, z: ua.y } : { x: -ua.z, y: 0, z: ua.x };
    const n = norm(axis);
    axis = { x: axis.x / n, y: axis.y / n, z: axis.z / n };
    omega = Math.PI;
    const ang = omega * t;
    const c = Math.cos(ang), s = Math.sin(ang);
    const cross = { x: axis.y * ua.z - axis.z * ua.y, y: axis.z * ua.x - axis.x * ua.z, z: axis.x * ua.y - axis.y * ua.x };
    return { x: (ua.x * c + cross.x * s) * r, y: (ua.y * c + cross.y * s) * r, z: (ua.z * c + cross.z * s) * r };
  }
  const so = Math.sin(omega);
  const wa = Math.sin((1 - t) * omega) / so;
  const wb = Math.sin(t * omega) / so;
  return { x: (ua.x * wa + ub.x * wb) * r, y: (ua.y * wa + ub.y * wb) * r, z: (ua.z * wa + ub.z * wb) * r };
}

const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

export class BlochSphere {
  readonly canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private size: number;
  private view: View;
  private current: Vec3 = { x: 0, y: 0, z: 1 };
  private trail: Vec3[] = [];
  private anim: { from: Vec3; to: Vec3; start: number; duration: number } | null = null;
  private raf = 0;
  private dragging: { x: number; y: number; view: View } | null = null;
  private colors = {
    ink: '#e6edf5', ink2: '#a8b6c7', ink3: '#75859a', line: '#2d3f57', surface: '#111a25', accent: '#f2b544', wire: '#6d8db3',
  };
  private fontMath = 'serif';
  onViewChange?: (view: View) => void;

  constructor(canvas: HTMLCanvasElement, size = 168, view: View = DEFAULT_VIEW) {
    this.canvas = canvas;
    this.size = size;
    this.view = { ...view };
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D no disponible');
    this.ctx = ctx;
    this.colors = {
      ink: cssVar('--ink', this.colors.ink), ink2: cssVar('--ink-2', this.colors.ink2), ink3: cssVar('--ink-3', this.colors.ink3),
      line: cssVar('--line-2', this.colors.line), surface: cssVar('--panel', this.colors.surface), accent: cssVar('--accent', this.colors.accent),
      wire: cssVar('--wire', this.colors.wire),
    };
    this.fontMath = cssVar('--font-math', 'serif');
    this.resize(size);
    canvas.addEventListener('pointerdown', this.onDown);
    canvas.addEventListener('dblclick', () => this.setView(DEFAULT_VIEW, true));
    canvas.style.touchAction = 'none';
  }

  resize(size: number): void {
    this.size = size;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.round(size * dpr);
    this.canvas.height = Math.round(size * dpr);
    this.canvas.style.width = `${size}px`;
    this.canvas.style.height = `${size}px`;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.draw();
  }

  setView(view: View, notify = false): void {
    this.view = { ...view };
    this.draw();
    if (notify) this.onViewChange?.(this.view);
  }

  getVector(): Vec3 {
    return { ...this.current };
  }

  setVector(target: Vec3, opts: { from?: Vec3; duration?: number; keepTrail?: boolean } = {}): void {
    const from = opts.from ?? this.current;
    const duration = prefersReducedMotion() ? 0 : opts.duration ?? 700;
    if (!opts.keepTrail) this.trail = [];
    if (duration <= 0) {
      this.current = { ...target };
      this.anim = null;
      this.draw();
      return;
    }
    this.anim = { from: { ...from }, to: { ...target }, start: performance.now(), duration };
    this.current = { ...from };
    this.trail = [{ ...from }];
    cancelAnimationFrame(this.raf);
    this.raf = requestAnimationFrame(this.tick);
  }

  private tick = (now: number): void => {
    if (!this.anim) return;
    const t = Math.min(1, (now - this.anim.start) / this.anim.duration);
    this.current = slerpVec(this.anim.from, this.anim.to, ease(t));
    this.trail.push({ ...this.current });
    this.draw();
    if (t < 1) this.raf = requestAnimationFrame(this.tick);
    else this.anim = null;
  };

  destroy(): void {
    cancelAnimationFrame(this.raf);
    this.canvas.removeEventListener('pointerdown', this.onDown);
  }

  private onDown = (ev: PointerEvent): void => {
    this.dragging = { x: ev.clientX, y: ev.clientY, view: { ...this.view } };
    this.canvas.setPointerCapture(ev.pointerId);
    this.canvas.addEventListener('pointermove', this.onMove);
    this.canvas.addEventListener('pointerup', this.onUp, { once: true });
    this.canvas.addEventListener('pointercancel', this.onUp, { once: true });
  };

  private onMove = (ev: PointerEvent): void => {
    if (!this.dragging) return;
    const dx = ev.clientX - this.dragging.x;
    const dy = ev.clientY - this.dragging.y;
    const pitch = Math.max(-1.35, Math.min(1.35, this.dragging.view.pitch + dy * 0.012));
    this.setView({ yaw: this.dragging.view.yaw + dx * 0.012, pitch }, true);
  };

  private onUp = (): void => {
    this.dragging = null;
    this.canvas.removeEventListener('pointermove', this.onMove);
  };

  /** Proyección: devuelve coordenadas de pantalla y profundidad (positivo = hacia el observador). */
  private project(v: Vec3): { X: number; Y: number; d: number } {
    const { yaw, pitch } = this.view;
    const t1 = v.x * Math.cos(yaw) - v.y * Math.sin(yaw);
    const r1 = v.x * Math.sin(yaw) + v.y * Math.cos(yaw);
    const u1 = v.z;
    const t2 = t1 * Math.cos(pitch) + u1 * Math.sin(pitch);
    const u2 = -t1 * Math.sin(pitch) + u1 * Math.cos(pitch);
    const R = this.size * 0.36;
    const c = this.size / 2;
    return { X: c + R * r1, Y: c - R * u2, d: t2 };
  }

  private circle(points: (a: number) => Vec3, front: boolean): void {
    const ctx = this.ctx;
    const N = 120;
    let drawing = false;
    ctx.beginPath();
    for (let i = 0; i <= N; i++) {
      const p = this.project(points((i / N) * Math.PI * 2));
      const isFront = p.d >= -0.0001;
      if (isFront === front) {
        if (!drawing) {
          ctx.moveTo(p.X, p.Y);
          drawing = true;
        } else ctx.lineTo(p.X, p.Y);
      } else drawing = false;
    }
    ctx.stroke();
  }

  draw(): void {
    const ctx = this.ctx;
    const S = this.size;
    const c = S / 2;
    const R = S * 0.36;
    ctx.clearRect(0, 0, S, S);

    // Cuerpo de la esfera.
    const g = ctx.createRadialGradient(c - R * 0.35, c - R * 0.45, R * 0.1, c, c, R);
    g.addColorStop(0, 'rgba(150, 180, 220, 0.16)');
    g.addColorStop(0.7, 'rgba(110, 140, 180, 0.06)');
    g.addColorStop(1, 'rgba(110, 140, 180, 0.02)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(c, c, R, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(150, 178, 214, 0.38)';
    ctx.lineWidth = 1;
    ctx.stroke();

    const rings: ((a: number) => Vec3)[] = [
      (a) => ({ x: Math.cos(a), y: Math.sin(a), z: 0 }),
      (a) => ({ x: Math.cos(a), y: 0, z: Math.sin(a) }),
      (a) => ({ x: 0, y: Math.cos(a), z: Math.sin(a) }),
    ];
    // Mitad trasera: discontinua y tenue.
    ctx.setLineDash([2, 3]);
    ctx.strokeStyle = 'rgba(150, 178, 214, 0.16)';
    rings.forEach((r) => this.circle(r, false));
    ctx.setLineDash([]);

    // Ejes.
    const axes: [Vec3, string][] = [
      [{ x: 1, y: 0, z: 0 }, 'x'],
      [{ x: 0, y: 1, z: 0 }, 'y'],
      [{ x: 0, y: 0, z: 1 }, '|0⟩'],
      [{ x: 0, y: 0, z: -1 }, '|1⟩'],
    ];
    ctx.strokeStyle = 'rgba(150, 178, 214, 0.22)';
    for (const [v] of axes.slice(0, 3)) {
      const a = this.project({ x: -v.x, y: -v.y, z: -v.z });
      const b = this.project(v);
      ctx.beginPath();
      ctx.moveTo(a.X, a.Y);
      ctx.lineTo(b.X, b.Y);
      ctx.stroke();
    }

    // Vector de estado y su proyección sobre el ecuador.
    const v = this.current;
    const tip = this.project(v);
    const origin = this.project({ x: 0, y: 0, z: 0 });
    const behind = tip.d < 0;

    const drawVector = () => {
      const foot = this.project({ x: v.x, y: v.y, z: 0 });
      if (Math.hypot(v.x, v.y) > 0.05) {
        ctx.setLineDash([2, 3]);
        ctx.strokeStyle = 'rgba(230, 237, 245, 0.28)';
        ctx.beginPath();
        ctx.moveTo(origin.X, origin.Y);
        ctx.lineTo(foot.X, foot.Y);
        ctx.lineTo(tip.X, tip.Y);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      // Estela.
      if (this.trail.length > 1) {
        ctx.lineWidth = 2;
        for (let i = 1; i < this.trail.length; i++) {
          const a = this.project(this.trail[i - 1]);
          const b = this.project(this.trail[i]);
          const alpha = 0.08 + 0.5 * (i / this.trail.length);
          ctx.strokeStyle = `rgba(242, 181, 68, ${alpha})`;
          ctx.beginPath();
          ctx.moveTo(a.X, a.Y);
          ctx.lineTo(b.X, b.Y);
          ctx.stroke();
        }
      }
      ctx.lineWidth = 2;
      ctx.strokeStyle = behind ? 'rgba(230, 237, 245, 0.55)' : this.colors.ink;
      ctx.beginPath();
      ctx.moveTo(origin.X, origin.Y);
      ctx.lineTo(tip.X, tip.Y);
      ctx.stroke();
      const r = norm(v);
      const phi = Math.atan2(v.y, v.x);
      ctx.beginPath();
      ctx.arc(tip.X, tip.Y, 5.5, 0, Math.PI * 2);
      ctx.fillStyle = Math.hypot(v.x, v.y) > 0.02 ? phaseColor(phi) : this.colors.ink;
      ctx.globalAlpha = r < 0.02 ? 0.4 : 1;
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.lineWidth = 2;
      ctx.strokeStyle = this.colors.surface;
      ctx.stroke();
      ctx.lineWidth = 1;
    };

    if (behind) drawVector();

    ctx.strokeStyle = 'rgba(150, 178, 214, 0.42)';
    ctx.lineWidth = 1;
    rings.forEach((r) => this.circle(r, true));

    if (!behind) drawVector();

    // Etiquetas de los ejes.
    ctx.fillStyle = this.colors.ink2;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const [vec, label] of axes) {
      const p = this.project({ x: vec.x * 1.22, y: vec.y * 1.22, z: vec.z * 1.22 });
      ctx.globalAlpha = p.d < -0.3 ? 0.45 : 0.9;
      ctx.font = label.startsWith('|') ? `13px ${this.fontMath}` : `italic 12px ${this.fontMath}`;
      ctx.fillText(label, p.X, p.Y);
    }
    ctx.globalAlpha = 1;
  }
}
