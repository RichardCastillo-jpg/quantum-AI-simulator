// Arrastrar y soltar con eventos de puntero (funciona con ratón, lápiz y pantallas táctiles).

import type { PaletteItem } from '../lib/gates';
import type { SubcircuitDef } from '../lib/types';

export type DragPayload =
  | { type: 'palette'; item: PaletteItem }
  | { type: 'subcircuit'; sub: SubcircuitDef }
  | { type: 'op'; opId: string; grabRow: number; zone: DropZone };

export interface DropZone {
  element: Element;
  accepts(payload: DragPayload): boolean;
  hover(payload: DragPayload, x: number, y: number): void;
  leave(): void;
  drop(payload: DragPayload, x: number, y: number): boolean;
}

const zones: DropZone[] = [];

export function registerZone(zone: DropZone): () => void {
  zones.push(zone);
  return () => {
    const i = zones.indexOf(zone);
    if (i >= 0) zones.splice(i, 1);
  };
}

function zoneAt(x: number, y: number, payload: DragPayload): DropZone | null {
  for (let i = zones.length - 1; i >= 0; i--) {
    const z = zones[i];
    if (!z.element.isConnected) continue;
    const r = z.element.getBoundingClientRect();
    if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom && z.accepts(payload)) {
      // Solo la zona visible más alta: si hay un diálogo encima, las zonas de debajo no cuentan.
      const topEl = document.elementFromPoint(x, y);
      if (topEl && !z.element.contains(topEl) && !topEl.closest('.drag-ghost')) continue;
      return z;
    }
  }
  return null;
}

export interface DragOptions {
  ghost: () => HTMLElement;
  onClick?: (ev: PointerEvent) => void;
  onDropOutside?: () => void;
  threshold?: number;
}

export function startDrag(ev: PointerEvent, payload: DragPayload, opts: DragOptions): void {
  if (ev.button !== 0) return;
  const sx = ev.clientX;
  const sy = ev.clientY;
  const threshold = opts.threshold ?? 5;
  let ghost: HTMLElement | null = null;
  let current: DropZone | null = null;
  const target = ev.currentTarget as Element | null;
  try {
    (target as Element & { setPointerCapture?: (id: number) => void })?.setPointerCapture?.(ev.pointerId);
  } catch {
    /* algunos elementos SVG no admiten la captura */
  }

  const move = (e: PointerEvent) => {
    if (!ghost) {
      if (Math.hypot(e.clientX - sx, e.clientY - sy) < threshold) return;
      ghost = opts.ghost();
      ghost.classList.add('drag-ghost');
      document.body.appendChild(ghost);
      document.body.classList.add('is-dragging');
    }
    ghost.style.transform = `translate(${e.clientX - 22}px, ${e.clientY - 22}px)`;
    const z = zoneAt(e.clientX, e.clientY, payload);
    if (z !== current) {
      current?.leave();
      current = z;
    }
    ghost.classList.toggle('no-drop', !z);
    z?.hover(payload, e.clientX, e.clientY);
  };

  const up = (e: PointerEvent) => {
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', up);
    window.removeEventListener('pointercancel', cancel);
    document.body.classList.remove('is-dragging');
    if (!ghost) {
      opts.onClick?.(e);
      return;
    }
    ghost.remove();
    const z = zoneAt(e.clientX, e.clientY, payload);
    current?.leave();
    if (z) z.drop(payload, e.clientX, e.clientY);
    else opts.onDropOutside?.();
  };

  const cancel = () => {
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', up);
    window.removeEventListener('pointercancel', cancel);
    document.body.classList.remove('is-dragging');
    ghost?.remove();
    current?.leave();
  };

  window.addEventListener('pointermove', move);
  window.addEventListener('pointerup', up);
  window.addEventListener('pointercancel', cancel);
}
