// Ejecución automática reactiva con control de frecuencia y cancelación de peticiones obsoletas.
//
// * Cambios discretos (insertar, borrar, mover) → debounce: se agrupan durante `debounceMs`.
// * Cambios continuos (deslizadores) → throttle con disparo inicial y final cada `throttleMs`.
// * Una nueva ejecución aborta la anterior (AbortController) y solo el resultado más reciente
//   se publica, aunque una respuesta antigua llegue después.
// * En pausa los cambios quedan pendientes hasta reanudar o pedir "Ejecutar ahora".

export type RunState = 'idle' | 'scheduled' | 'running' | 'ok' | 'error' | 'paused';

export interface AutoRunnerOptions<Req, Res> {
  run: (req: Req, signal: AbortSignal) => Promise<Res>;
  onResult: (res: Res, req: Req) => void;
  onError?: (err: unknown, req: Req) => void;
  onState?: (state: RunState, info: { pending: boolean; startedAt?: number }) => void;
  debounceMs?: number;
  throttleMs?: number;
}

export class AutoRunner<Req, Res> {
  private opts: Required<Omit<AutoRunnerOptions<Req, Res>, 'onError' | 'onState'>> &
    Pick<AutoRunnerOptions<Req, Res>, 'onError' | 'onState'>;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private controller: AbortController | null = null;
  private seq = 0;
  private lastFire = 0;
  private latest: Req | null = null;
  private _paused = false;
  private pending = false;
  /** Último estado definitivo (ok / error), para restaurarlo al reanudar sin cambios pendientes. */
  private settled: RunState = 'idle';

  constructor(opts: AutoRunnerOptions<Req, Res>) {
    this.opts = { debounceMs: 220, throttleMs: 120, ...opts };
  }

  get paused(): boolean {
    return this._paused;
  }

  get hasPending(): boolean {
    return this.pending;
  }

  schedule(req: Req, opts: { continuous?: boolean; immediate?: boolean } = {}): void {
    this.latest = req;
    if (this._paused) {
      this.pending = true;
      this.opts.onState?.('paused', { pending: true });
      return;
    }
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    if (opts.immediate) {
      this.fire();
      return;
    }
    if (opts.continuous) {
      const wait = this.opts.throttleMs - (performance.now() - this.lastFire);
      if (wait <= 0) {
        this.fire();
      } else {
        this.timer = setTimeout(() => this.fire(), wait);
      }
      return;
    }
    this.opts.onState?.('scheduled', { pending: true });
    this.timer = setTimeout(() => this.fire(), this.opts.debounceMs);
  }

  runNow(req?: Req): void {
    if (req !== undefined) this.latest = req;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.fire(true);
  }

  pause(): void {
    this._paused = true;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
      this.pending = true;
    }
    this.opts.onState?.('paused', { pending: this.pending });
  }

  resume(): void {
    this._paused = false;
    if (this.pending) this.fire();
    else this.opts.onState?.(this.settled, { pending: false });
  }

  cancel(): void {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.controller?.abort();
    this.controller = null;
  }

  private fire(force = false): void {
    this.timer = null;
    if (this.latest === null) return;
    if (this._paused && !force) {
      this.pending = true;
      this.opts.onState?.('paused', { pending: true });
      return;
    }
    this.pending = false;
    this.controller?.abort();
    const controller = new AbortController();
    this.controller = controller;
    const id = ++this.seq;
    const req = this.latest;
    this.lastFire = performance.now();
    this.opts.onState?.('running', { pending: false, startedAt: this.lastFire });
    this.opts
      .run(req, controller.signal)
      .then((res) => {
        if (id !== this.seq) return; // respuesta obsoleta
        this.controller = null;
        this.opts.onResult(res, req);
        this.settled = 'ok';
        this.opts.onState?.('ok', { pending: false });
      })
      .catch((err: unknown) => {
        if (controller.signal.aborted || id !== this.seq) return;
        this.controller = null;
        this.opts.onError?.(err, req);
        this.settled = 'error';
        this.opts.onState?.('error', { pending: false });
      });
  }
}
