// Color de fase: la fase de una amplitud compleja se codifica como tono en OKLCH
// (luminosidad y croma constantes → todas las fases pesan lo mismo visualmente).

function toSrgb(x: number): number {
  const v = x <= 0.0031308 ? 12.92 * x : 1.055 * Math.pow(x, 1 / 2.4) - 0.055;
  return Math.round(Math.min(1, Math.max(0, v)) * 255);
}

export function oklchToRgb(L: number, C: number, hDeg: number): [number, number, number] {
  const h = (hDeg * Math.PI) / 180;
  const a = C * Math.cos(h);
  const b = C * Math.sin(h);
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
  const s_ = L - 0.0894841775 * a - 1.291485548 * b;
  const l = l_ ** 3, m = m_ ** 3, s = s_ ** 3;
  const r = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s;
  const g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s;
  const bb = -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s;
  return [toSrgb(r), toSrgb(g), toSrgb(bb)];
}

export const PHASE_HUE_OFFSET = 30; // fase 0 → tono cálido

export function phaseHue(phase: number): number {
  const deg = (phase * 180) / Math.PI;
  return (((PHASE_HUE_OFFSET + deg) % 360) + 360) % 360;
}

export function phaseColor(phase: number, alpha = 1, L = 0.76, C = 0.13): string {
  const [r, g, b] = oklchToRgb(L, C, phaseHue(phase));
  return alpha >= 1 ? `rgb(${r} ${g} ${b})` : `rgb(${r} ${g} ${b} / ${alpha})`;
}

/** Gradiente cónico CSS para la leyenda de fase (rueda de colores). */
export function phaseWheelGradient(steps = 12): string {
  // conic-gradient gira en sentido horario; con «from 90deg» el origen queda a la derecha y,
  // asignando la fase −ángulo, la fase crece en sentido antihorario como en el plano complejo.
  const stops: string[] = [];
  for (let i = 0; i <= steps; i++) {
    const phase = -(i / steps) * 2 * Math.PI;
    stops.push(`${phaseColor(phase)} ${((i / steps) * 360).toFixed(1)}deg`);
  }
  return `conic-gradient(from 90deg, ${stops.join(', ')})`;
}
