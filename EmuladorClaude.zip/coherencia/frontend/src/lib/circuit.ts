// Operaciones puras de edición del circuito (inmutables y sin DOM).

import { freeVariables } from './expr';
import type { Circuit, Loop, Op, SubcircuitDef } from './types';

let counter = 0;
export function uid(prefix = 'op'): string {
  counter = (counter + 1) % 1e6;
  return `${prefix}-${Date.now().toString(36).slice(-4)}${Math.random().toString(36).slice(2, 6)}${counter.toString(36)}`;
}

export function emptyCircuit(n = 3, m = 0, name = 'Circuito sin título'): Circuit {
  return { version: 1, name, num_qubits: n, num_clbits: m, initial_state: '0'.repeat(n), ops: [], loops: [], meta: {} };
}

export function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

export function opQubits(op: Op, n: number): number[] {
  const qs = [...op.targets, ...(op.controls ?? []), ...(op.anticontrols ?? [])];
  if (op.kind === 'barrier' && qs.length === 0) return Array.from({ length: n }, (_, i) => i);
  return qs;
}

export function opSpan(op: Op, n: number): [number, number] {
  const qs = opQubits(op, n);
  if (!qs.length) return [0, 0];
  return [Math.min(...qs), Math.max(...qs)];
}

export function lastColumn(circuit: Circuit): number {
  let last = -1;
  for (const op of circuit.ops) last = Math.max(last, op.col);
  for (const lp of circuit.loops) last = Math.max(last, lp.col_end);
  return last;
}

export function isFree(circuit: Circuit, col: number, lo: number, hi: number, exclude: Set<string> = new Set()): boolean {
  for (const op of circuit.ops) {
    if (op.col !== col || exclude.has(op.id)) continue;
    const [a, b] = opSpan(op, circuit.num_qubits);
    if (a <= hi && lo <= b) return false;
  }
  return true;
}

export function opAt(circuit: Circuit, col: number, row: number): Op | undefined {
  return circuit.ops.find((op) => {
    if (op.col !== col) return false;
    const [a, b] = opSpan(op, circuit.num_qubits);
    return a <= row && row <= b;
  });
}

export function insertColumn(circuit: Circuit, col: number): Circuit {
  const out = clone(circuit);
  for (const op of out.ops) if (op.col >= col) op.col += 1;
  for (const lp of out.loops) {
    if (lp.col_start >= col) {
      lp.col_start += 1;
      lp.col_end += 1;
    } else if (lp.col_end >= col) {
      lp.col_end += 1;
    }
  }
  return out;
}

export function deleteColumn(circuit: Circuit, col: number): Circuit {
  const out = clone(circuit);
  out.ops = out.ops.filter((op) => op.col !== col);
  for (const op of out.ops) if (op.col > col) op.col -= 1;
  const loops: Loop[] = [];
  for (const lp of out.loops) {
    if (col < lp.col_start) {
      lp.col_start -= 1;
      lp.col_end -= 1;
    } else if (col <= lp.col_end) {
      lp.col_end -= 1;
    }
    if (lp.col_end >= lp.col_start) loops.push(lp);
  }
  out.loops = loops;
  return out;
}

/** Inserta una operación; si su intervalo de cúbits está ocupado en la columna, abre una columna nueva. */
export function placeOp(circuit: Circuit, op: Op): Circuit {
  const [lo, hi] = opSpan(op, circuit.num_qubits);
  let base = circuit;
  if (!isFree(circuit, op.col, lo, hi)) base = insertColumn(circuit, op.col);
  const out = clone(base);
  out.ops.push(clone(op));
  return out;
}

export function removeOps(circuit: Circuit, ids: Iterable<string>): Circuit {
  const set = new Set(ids);
  const out = clone(circuit);
  out.ops = out.ops.filter((op) => !set.has(op.id));
  return out;
}

export function updateOp(circuit: Circuit, id: string, patch: Partial<Op>): Circuit {
  const out = clone(circuit);
  out.ops = out.ops.map((op) => (op.id === id ? { ...op, ...clone(patch) } : op));
  return out;
}

export function shiftQubits(op: Op, delta: number): Op {
  const moved = clone(op);
  moved.targets = moved.targets.map((q) => q + delta);
  if (moved.controls) moved.controls = moved.controls.map((q) => q + delta);
  if (moved.anticontrols) moved.anticontrols = moved.anticontrols.map((q) => q + delta);
  return moved;
}

/** Mueve una operación a otra columna desplazando sus cúbits; devuelve null si no cabe. */
export function moveOp(circuit: Circuit, id: string, col: number, rowDelta: number): Circuit | null {
  const op = circuit.ops.find((o) => o.id === id);
  if (!op) return null;
  const moved = shiftQubits(op, rowDelta);
  moved.col = Math.max(0, col);
  const qs = opQubits(moved, circuit.num_qubits);
  if (qs.some((q) => q < 0 || q >= circuit.num_qubits)) return null;
  const without = removeOps(circuit, [id]);
  return placeOp(without, moved);
}

export function setNumQubits(circuit: Circuit, n: number): Circuit {
  const out = clone(circuit);
  out.num_qubits = n;
  out.ops = out.ops.filter((op) => opQubits(op, 1e9).every((q) => q < n));
  const bits = (out.initial_state || '').padStart(circuit.num_qubits, '0');
  out.initial_state = bits.length >= n ? bits.slice(bits.length - n) : bits.padStart(n, '0');
  if (out.qubit_labels) out.qubit_labels = out.qubit_labels.slice(0, n);
  return out;
}

export function setNumClbits(circuit: Circuit, m: number): Circuit {
  const out = clone(circuit);
  out.num_clbits = m;
  out.ops = out.ops.filter((op) => {
    if (op.kind === 'measure' && (op.clbits ?? []).some((cb) => cb >= m)) return false;
    if (op.kind === 'subcircuit' && (op.clbits ?? []).some((cb) => cb >= m)) return false;
    return true;
  });
  for (const op of out.ops) {
    if (op.condition) {
      op.condition = op.condition.filter((cnd) => cnd.clbit < m);
      if (!op.condition.length) op.condition = null;
    }
  }
  if (out.clbit_labels) out.clbit_labels = out.clbit_labels.slice(0, m);
  return out;
}

export function toggleInitialBit(circuit: Circuit, q: number): Circuit {
  const out = clone(circuit);
  const n = out.num_qubits;
  const bits = (out.initial_state || '0'.repeat(n)).padStart(n, '0').split('');
  const idx = n - 1 - q;
  bits[idx] = bits[idx] === '1' ? '0' : '1';
  out.initial_state = bits.join('');
  return out;
}

export function loopsContaining(circuit: Circuit, col: number): Loop[] {
  return circuit.loops.filter((lp) => lp.col_start <= col && col <= lp.col_end);
}

export function canAddLoop(circuit: Circuit, start: number, end: number): string | null {
  if (end < start) return 'El rango del ciclo no es válido';
  for (const lp of circuit.loops) {
    const overlap = lp.col_start <= end && start <= lp.col_end;
    const nested = (lp.col_start <= start && end <= lp.col_end) || (start <= lp.col_start && lp.col_end <= end);
    if (overlap && !nested) return `Se solaparía con el ciclo de las columnas ${lp.col_start}–${lp.col_end}`;
  }
  return null;
}

export function addLoop(circuit: Circuit, start: number, end: number, iterations: number, variable: string): Circuit {
  const out = clone(circuit);
  const used = new Set(loopsContaining(circuit, start).map((l) => l.var));
  let name = variable;
  const pool = ['i', 'j', 'k', 'l', 'm', 'r'];
  if (used.has(name)) name = pool.find((v) => !used.has(v)) ?? `${variable}2`;
  out.loops.push({ id: uid('loop'), col_start: start, col_end: end, iterations, var: name, start: 0, step: 1 });
  return out;
}

export function updateLoop(circuit: Circuit, id: string, patch: Partial<Loop>): Circuit {
  const out = clone(circuit);
  out.loops = out.loops.map((lp) => (lp.id === id ? { ...lp, ...patch } : lp));
  return out;
}

export function removeLoop(circuit: Circuit, id: string): Circuit {
  const out = clone(circuit);
  out.loops = out.loops.filter((lp) => lp.id !== id);
  return out;
}

export function opsInRect(circuit: Circuit, c0: number, c1: number, r0: number, r1: number): string[] {
  const [ca, cb] = [Math.min(c0, c1), Math.max(c0, c1)];
  const [ra, rb] = [Math.min(r0, r1), Math.max(r0, r1)];
  return circuit.ops
    .filter((op) => {
      if (op.col < ca || op.col > cb) return false;
      const [a, b] = opSpan(op, circuit.num_qubits);
      return a <= rb && ra <= b;
    })
    .map((op) => op.id);
}

export function duplicateOps(circuit: Circuit, ids: string[]): { circuit: Circuit; ids: string[] } {
  const chosen = circuit.ops.filter((op) => ids.includes(op.id));
  if (!chosen.length) return { circuit, ids: [] };
  const minCol = Math.min(...chosen.map((o) => o.col));
  const maxCol = Math.max(...chosen.map((o) => o.col));
  const width = maxCol - minCol + 1;
  let out = circuit;
  for (let k = 0; k < width; k++) out = insertColumn(out, maxCol + 1);
  out = clone(out);
  const newIds: string[] = [];
  for (const op of chosen) {
    const copy = clone(op);
    copy.id = uid();
    copy.col = op.col + width;
    newIds.push(copy.id);
    out.ops.push(copy);
  }
  return { circuit: out, ids: newIds };
}

/** Parámetros libres (identificadores no ligados a ciclos) usados por un conjunto de operaciones. */
export function freeParams(ops: Op[], boundVars: string[] = []): string[] {
  const bound = new Set(boundVars);
  const found = new Set<string>();
  const scan = (v: unknown) => {
    if (typeof v !== 'string') return;
    try {
      for (const name of freeVariables(v)) if (!bound.has(name)) found.add(name);
    } catch {
      /* expresiones inválidas se ignoran aquí: el backend las reporta */
    }
  };
  for (const op of ops) {
    (op.params ?? []).forEach(scan);
    Object.values(op.sub_params ?? {}).forEach(scan);
  }
  return [...found].sort();
}

export interface Extraction {
  qubits: number[];
  clbits: number[];
  colStart: number;
  colEnd: number;
  ops: Op[];
  loops: Loop[];
  params: string[];
}

export function extractSelection(circuit: Circuit, ids: string[]): Extraction | null {
  const chosen = circuit.ops.filter((op) => ids.includes(op.id));
  if (!chosen.length) return null;
  const qubits = [...new Set(chosen.flatMap((op) => opQubits(op, circuit.num_qubits)))].sort((a, b) => a - b);
  const clbits = [
    ...new Set(
      chosen.flatMap((op) => [...(op.kind === 'measure' || op.kind === 'subcircuit' ? op.clbits ?? [] : []),
        ...(op.condition ?? []).map((c) => c.clbit)]),
    ),
  ].sort((a, b) => a - b);
  const colStart = Math.min(...chosen.map((o) => o.col));
  const colEnd = Math.max(...chosen.map((o) => o.col));
  const qmap = new Map(qubits.map((q, i) => [q, i]));
  const cmap = new Map(clbits.map((c, i) => [c, i]));
  const ops = chosen.map((op) => {
    const local = clone(op);
    local.id = uid();
    local.col = op.col - colStart;
    local.targets = op.targets.map((q) => qmap.get(q)!);
    if (local.controls) local.controls = local.controls.map((q) => qmap.get(q)!);
    if (local.anticontrols) local.anticontrols = local.anticontrols.map((q) => qmap.get(q)!);
    if (local.kind === 'barrier' && !op.targets.length) local.targets = qubits.map((_, i) => i);
    if (local.clbits) local.clbits = local.clbits.map((cb) => cmap.get(cb)!);
    if (local.condition) local.condition = local.condition.map((cnd) => ({ ...cnd, clbit: cmap.get(cnd.clbit)! }));
    return local;
  });
  const loops = circuit.loops
    .filter((lp) => lp.col_start >= colStart && lp.col_end <= colEnd)
    .map((lp) => ({ ...clone(lp), id: uid('loop'), col_start: lp.col_start - colStart, col_end: lp.col_end - colStart }));
  const params = freeParams(ops, loops.map((l) => l.var));
  return { qubits, clbits, colStart, colEnd, ops, loops, params };
}

export function replaceWithInstance(circuit: Circuit, ids: string[], ex: Extraction, sub: SubcircuitDef): Circuit {
  let out = removeOps(circuit, ids);
  out.loops = out.loops.filter((lp) => !(lp.col_start >= ex.colStart && lp.col_end <= ex.colEnd));
  // Compacta las columnas del rango que quedaron vacías (excepto la primera, donde va el bloque).
  for (let col = ex.colEnd; col > ex.colStart; col--) {
    if (!out.ops.some((op) => op.col === col)) out = deleteColumn(out, col);
  }
  const instance: Op = {
    id: uid(),
    kind: 'subcircuit',
    col: ex.colStart,
    subcircuit_id: sub.id,
    targets: ex.qubits,
    clbits: ex.clbits,
    sub_params: Object.fromEntries(ex.params.map((p) => [p, p])),
  };
  return placeOp(out, instance);
}

export function instanceFits(circuit: Circuit, sub: SubcircuitDef, row: number): string | null {
  if (sub.num_qubits > circuit.num_qubits) {
    return `«${sub.name}» necesita ${sub.num_qubits} cúbits y el circuito tiene ${circuit.num_qubits}. Añade cúbits primero.`;
  }
  if (row + sub.num_qubits > circuit.num_qubits) {
    return `«${sub.name}» necesita ${sub.num_qubits} cúbits consecutivos desde q${row}; suéltalo en q${circuit.num_qubits - sub.num_qubits} o más arriba.`;
  }
  return null;
}

/** Ajusta las instancias de un subcircuito cuyo número de cúbits/bits cambió. */
export function reconcileInstances(circuit: Circuit, sub: SubcircuitDef): { circuit: Circuit; changed: number; removed: number } {
  let changed = 0;
  let removed = 0;
  const out = clone(circuit);
  out.ops = out.ops.filter((op) => {
    if (op.kind !== 'subcircuit' || op.subcircuit_id !== sub.id) return true;
    let ok = true;
    if (op.targets.length !== sub.num_qubits) {
      changed++;
      if (op.targets.length > sub.num_qubits) op.targets = op.targets.slice(0, sub.num_qubits);
      else {
        const used = new Set([...op.targets, ...(op.controls ?? []), ...(op.anticontrols ?? [])]);
        for (let q = 0; q < out.num_qubits && op.targets.length < sub.num_qubits; q++) {
          if (!used.has(q)) {
            op.targets.push(q);
            used.add(q);
          }
        }
        if (op.targets.length < sub.num_qubits) ok = false;
      }
    }
    const clb = op.clbits ?? [];
    if (clb.length !== sub.num_clbits) {
      changed++;
      if (clb.length > sub.num_clbits) op.clbits = clb.slice(0, sub.num_clbits);
      else if (sub.num_clbits <= out.num_clbits) op.clbits = Array.from({ length: sub.num_clbits }, (_, i) => i);
      else ok = false;
    }
    const params = op.sub_params ?? {};
    for (const p of sub.params) if (!(p in params)) params[p] = 0;
    op.sub_params = params;
    if (!ok) removed++;
    return ok;
  });
  return { circuit: out, changed, removed };
}

export function compactColumns(circuit: Circuit): Circuit {
  let out = circuit;
  const last = lastColumn(circuit);
  for (let col = last; col >= 0; col--) {
    const used = out.ops.some((op) => op.col === col);
    const inLoop = out.loops.some((lp) => lp.col_start === col && lp.col_end === col);
    if (!used && !inLoop) out = deleteColumn(out, col);
  }
  return out;
}
