// Catálogo de compuertas del frontend (nombres idénticos a backend/app/core/gates.py).

import { c, controlled, expi, type C, type Matrix } from './complex';
import { tryEvaluate } from './expr';
import type { Op, OpKind, ParamValue } from './types';

export type Category = 'pauli' | 'clifford' | 'phase' | 'rotation' | 'multi' | 'block' | 'measure' | 'control';

export interface GateInfo {
  name: string;
  label: string;
  title: string;
  category: Category;
  targets: number | 'var';
  params: string[];
  defaults: ParamValue[];
  description: string;
  symbol?: 'box' | 'target' | 'swap' | 'dot';
}

const S2 = Math.SQRT1_2;

export const GATES: Record<string, GateInfo> = {};
const reg = (g: GateInfo) => (GATES[g.name] = g);

reg({ name: 'id', label: 'I', title: 'Identidad', category: 'pauli', targets: 1, params: [], defaults: [], description: 'No modifica el estado. Con ruido, representa un tiempo de espera.' });
reg({ name: 'x', label: 'X', title: 'Pauli X (NOT)', category: 'pauli', targets: 1, params: [], defaults: [], description: 'Invierte el estado: |0⟩↔|1⟩. Rotación de π en torno a X.' });
reg({ name: 'y', label: 'Y', title: 'Pauli Y', category: 'pauli', targets: 1, params: [], defaults: [], description: 'Rotación de π en torno a Y: combina inversión de bit y de fase.' });
reg({ name: 'z', label: 'Z', title: 'Pauli Z', category: 'pauli', targets: 1, params: [], defaults: [], description: 'Añade una fase de π al estado |1⟩.' });
reg({ name: 'h', label: 'H', title: 'Hadamard', category: 'clifford', targets: 1, params: [], defaults: [], description: 'Crea superposición: |0⟩ → (|0⟩+|1⟩)/√2.' });
reg({ name: 's', label: 'S', title: 'Fase S', category: 'phase', targets: 1, params: [], defaults: [], description: 'Añade π/2 a |1⟩. Raíz cuadrada de Z.' });
reg({ name: 'sdg', label: 'S†', title: 'S daga', category: 'phase', targets: 1, params: [], defaults: [], description: 'Inversa de S: añade −π/2 a |1⟩.' });
reg({ name: 't', label: 'T', title: 'Fase T', category: 'phase', targets: 1, params: [], defaults: [], description: 'Añade π/4 a |1⟩.' });
reg({ name: 'tdg', label: 'T†', title: 'T daga', category: 'phase', targets: 1, params: [], defaults: [], description: 'Inversa de T: añade −π/4 a |1⟩.' });
reg({ name: 'sx', label: '√X', title: 'Raíz de NOT', category: 'clifford', targets: 1, params: [], defaults: [], description: 'Media rotación en torno a X; aplicada dos veces equivale a X.' });
reg({ name: 'sxdg', label: '√X†', title: 'Inversa de √X', category: 'clifford', targets: 1, params: [], defaults: [], description: 'Deshace √X.' });
reg({ name: 'sy', label: '√Y', title: 'Raíz de Y', category: 'rotation', targets: 1, params: [], defaults: [], description: 'Media rotación en torno a Y (circuitos aleatorios).' });
reg({ name: 'sw', label: '√W', title: 'Raíz de W', category: 'rotation', targets: 1, params: [], defaults: [], description: 'Raíz de W = (X+Y)/√2 (circuitos aleatorios).' });
reg({ name: 'p', label: 'P', title: 'Fase P(φ)', category: 'phase', targets: 1, params: ['φ'], defaults: ['pi/4'], description: 'Añade una fase arbitraria φ a |1⟩.' });
reg({ name: 'rx', label: 'RX', title: 'Rotación RX(θ)', category: 'rotation', targets: 1, params: ['θ'], defaults: ['pi/2'], description: 'Gira el estado un ángulo θ alrededor del eje X.' });
reg({ name: 'ry', label: 'RY', title: 'Rotación RY(θ)', category: 'rotation', targets: 1, params: ['θ'], defaults: ['pi/2'], description: 'Gira el estado un ángulo θ alrededor del eje Y.' });
reg({ name: 'rz', label: 'RZ', title: 'Rotación RZ(θ)', category: 'rotation', targets: 1, params: ['θ'], defaults: ['pi/2'], description: 'Gira el estado un ángulo θ alrededor del eje Z.' });
reg({ name: 'u', label: 'U', title: 'U(θ, φ, λ)', category: 'rotation', targets: 1, params: ['θ', 'φ', 'λ'], defaults: ['pi/2', '0', 'pi'], description: 'Compuerta general de un cúbit.' });
reg({ name: 'swap', label: 'SWAP', title: 'SWAP', category: 'multi', targets: 2, params: [], defaults: [], description: 'Intercambia los estados de dos cúbits.', symbol: 'swap' });
reg({ name: 'iswap', label: 'iSWAP', title: 'iSWAP', category: 'multi', targets: 2, params: [], defaults: [], description: 'Intercambio con fase i.' });
reg({ name: 'rxx', label: 'RXX', title: 'RXX(θ)', category: 'multi', targets: 2, params: ['θ'], defaults: ['pi/2'], description: 'Interacción de Ising exp(−iθ X⊗X/2).' });
reg({ name: 'ryy', label: 'RYY', title: 'RYY(θ)', category: 'multi', targets: 2, params: ['θ'], defaults: ['pi/2'], description: 'Interacción de Ising exp(−iθ Y⊗Y/2).' });
reg({ name: 'rzz', label: 'RZZ', title: 'RZZ(θ)', category: 'multi', targets: 2, params: ['θ'], defaults: ['pi/2'], description: 'Interacción de Ising exp(−iθ Z⊗Z/2).' });
reg({ name: 'fsim', label: 'fSim', title: 'fSim(θ, φ)', category: 'multi', targets: 2, params: ['θ', 'φ'], defaults: ['pi/2', 'pi/6'], description: 'Compuerta fermiónica de los procesadores de Google.' });
reg({ name: 'qft', label: 'QFT', title: 'Transformada de Fourier', category: 'block', targets: 'var', params: [], defaults: [], description: 'QFT sobre los cúbits del bloque (q más bajo = bit menos significativo).' });
reg({ name: 'iqft', label: 'QFT†', title: 'QFT inversa', category: 'block', targets: 'var', params: [], defaults: [], description: 'Transformada de Fourier inversa.' });
reg({ name: 'modmul', label: '×a mod N', title: 'Multiplicación modular', category: 'block', targets: 'var', params: ['a', 'N'], defaults: [7, 15], description: '|y⟩ → |a·y mod N⟩ para y < N. Núcleo del algoritmo de Shor.' });
reg({ name: 'unitary', label: 'U', title: 'Unitaria personalizada', category: 'block', targets: 'var', params: [], defaults: [], description: 'Compuerta definida por su matriz (se comprueba que sea unitaria).' });

export interface PaletteItem {
  id: string;
  label: string;
  title: string;
  group: string;
  category: Category;
  kind: OpKind | 'control' | 'anticontrol';
  gate?: string;
  roles?: ('control' | 'target')[];
  params?: ParamValue[];
  hint?: string;
}

const g = (name: string, group: string, extra: Partial<PaletteItem> = {}): PaletteItem => ({
  id: name,
  label: GATES[name].label,
  title: GATES[name].title,
  group,
  category: GATES[name].category,
  kind: 'gate',
  gate: name,
  params: GATES[name].defaults,
  ...extra,
});

export const PALETTE: PaletteItem[] = [
  g('h', 'Básicas'), g('x', 'Básicas'), g('y', 'Básicas'), g('z', 'Básicas'), g('id', 'Básicas'),
  g('s', 'Básicas'), g('sdg', 'Básicas'), g('t', 'Básicas'), g('tdg', 'Básicas'),
  g('rx', 'Rotaciones'), g('ry', 'Rotaciones'), g('rz', 'Rotaciones'), g('p', 'Rotaciones'), g('u', 'Rotaciones'),
  g('sx', 'Rotaciones'), g('sxdg', 'Rotaciones'), g('sy', 'Rotaciones'), g('sw', 'Rotaciones'),
  { id: 'cx', label: 'CNOT', title: 'CNOT: clic en el control y después en el objetivo', group: 'Varios cúbits', category: 'multi', kind: 'gate', gate: 'x', roles: ['control', 'target'], params: [] },
  { id: 'cz', label: 'CZ', title: 'Z controlada', group: 'Varios cúbits', category: 'multi', kind: 'gate', gate: 'z', roles: ['control', 'target'], params: [] },
  { id: 'ccx', label: 'CCX', title: 'Toffoli: dos controles y un objetivo', group: 'Varios cúbits', category: 'multi', kind: 'gate', gate: 'x', roles: ['control', 'control', 'target'], params: [] },
  { id: 'cp', label: 'CP', title: 'Fase controlada', group: 'Varios cúbits', category: 'multi', kind: 'gate', gate: 'p', roles: ['control', 'target'], params: ['pi/2'] },
  g('swap', 'Varios cúbits', { roles: ['target', 'target'] }),
  g('iswap', 'Varios cúbits', { roles: ['target', 'target'] }),
  g('rxx', 'Varios cúbits', { roles: ['target', 'target'] }),
  g('ryy', 'Varios cúbits', { roles: ['target', 'target'] }),
  g('rzz', 'Varios cúbits', { roles: ['target', 'target'] }),
  g('fsim', 'Varios cúbits', { roles: ['target', 'target'] }),
  { id: 'ctrl', label: '●', title: 'Control: suéltalo en una columna con una compuerta', group: 'Controles', category: 'control', kind: 'control' },
  { id: 'actrl', label: '○', title: 'Anticontrol (actúa si el cúbit está en |0⟩)', group: 'Controles', category: 'control', kind: 'anticontrol' },
  g('qft', 'Bloques'), g('iqft', 'Bloques'), g('modmul', 'Bloques', { label: '×a mod N' }),
  { id: 'unitary', label: 'U', title: 'Unitaria personalizada (edita su matriz)', group: 'Bloques', category: 'block', kind: 'gate', gate: 'unitary', params: [] },
  { id: 'measure', label: 'M', title: 'Medir en la base computacional', group: 'Medida', category: 'measure', kind: 'measure' },
  { id: 'reset', label: '|0⟩', title: 'Reiniciar el cúbit a |0⟩', group: 'Medida', category: 'measure', kind: 'reset' },
  { id: 'barrier', label: '┊', title: 'Barrera (separador visual)', group: 'Medida', category: 'measure', kind: 'barrier' },
];

export const PALETTE_GROUPS = ['Básicas', 'Rotaciones', 'Varios cúbits', 'Controles', 'Bloques', 'Medida'];

// --- Matrices para mostrar en el inspector ------------------------------------------------
function m2(a: C, b: C, cc: C, d: C): Matrix {
  return [[a, b], [cc, d]];
}

export function baseMatrix(name: string, p: number[]): Matrix | null {
  const cos = Math.cos, sin = Math.sin;
  switch (name) {
    case 'id': return m2(c(1), c(0), c(0), c(1));
    case 'x': return m2(c(0), c(1), c(1), c(0));
    case 'y': return m2(c(0), c(0, -1), c(0, 1), c(0));
    case 'z': return m2(c(1), c(0), c(0), c(-1));
    case 'h': return m2(c(S2), c(S2), c(S2), c(-S2));
    case 's': return m2(c(1), c(0), c(0), c(0, 1));
    case 'sdg': return m2(c(1), c(0), c(0), c(0, -1));
    case 't': return m2(c(1), c(0), c(0), expi(Math.PI / 4));
    case 'tdg': return m2(c(1), c(0), c(0), expi(-Math.PI / 4));
    case 'sx': return m2(c(0.5, 0.5), c(0.5, -0.5), c(0.5, -0.5), c(0.5, 0.5));
    case 'sxdg': return m2(c(0.5, -0.5), c(0.5, 0.5), c(0.5, 0.5), c(0.5, -0.5));
    case 'sy': return m2(c(0.5, 0.5), c(-0.5, -0.5), c(0.5, 0.5), c(0.5, 0.5));
    case 'sw': return m2(c(0.5, 0.5), c(0, -S2), c(S2), c(0.5, 0.5));
    case 'p': return m2(c(1), c(0), c(0), expi(p[0]));
    case 'rx': return m2(c(cos(p[0] / 2)), c(0, -sin(p[0] / 2)), c(0, -sin(p[0] / 2)), c(cos(p[0] / 2)));
    case 'ry': return m2(c(cos(p[0] / 2)), c(-sin(p[0] / 2)), c(sin(p[0] / 2)), c(cos(p[0] / 2)));
    case 'rz': return m2(expi(-p[0] / 2), c(0), c(0), expi(p[0] / 2));
    case 'u': {
      const [th, ph, la] = p;
      const e1 = expi(la), e2 = expi(ph), e3 = expi(ph + la);
      return m2(c(cos(th / 2)), { re: -e1.re * sin(th / 2), im: -e1.im * sin(th / 2) },
        { re: e2.re * sin(th / 2), im: e2.im * sin(th / 2) }, { re: e3.re * cos(th / 2), im: e3.im * cos(th / 2) });
    }
    case 'swap': return [[c(1), c(0), c(0), c(0)], [c(0), c(0), c(1), c(0)], [c(0), c(1), c(0), c(0)], [c(0), c(0), c(0), c(1)]];
    case 'iswap': return [[c(1), c(0), c(0), c(0)], [c(0), c(0), c(0, 1), c(0)], [c(0), c(0, 1), c(0), c(0)], [c(0), c(0), c(0), c(1)]];
    case 'rxx': { const a = cos(p[0] / 2), b = sin(p[0] / 2); return [[c(a), c(0), c(0), c(0, -b)], [c(0), c(a), c(0, -b), c(0)], [c(0), c(0, -b), c(a), c(0)], [c(0, -b), c(0), c(0), c(a)]]; }
    case 'ryy': { const a = cos(p[0] / 2), b = sin(p[0] / 2); return [[c(a), c(0), c(0), c(0, b)], [c(0), c(a), c(0, -b), c(0)], [c(0), c(0, -b), c(a), c(0)], [c(0, b), c(0), c(0), c(a)]]; }
    case 'rzz': { const e = expi(-p[0] / 2), f = expi(p[0] / 2); return [[e, c(0), c(0), c(0)], [c(0), f, c(0), c(0)], [c(0), c(0), f, c(0)], [c(0), c(0), c(0), e]]; }
    case 'fsim': { const a = cos(p[0]), b = sin(p[0]); return [[c(1), c(0), c(0), c(0)], [c(0), c(a), c(0, -b), c(0)], [c(0), c(0, -b), c(a), c(0)], [c(0), c(0), c(0), expi(-p[1])]]; }
    default: return null;
  }
}

/** Matriz completa de la operación (controles en los bits bajos). Solo para ≤ 3 cúbits. */
export function opMatrix(op: Op, env: Record<string, number> = {}): Matrix | null {
  if (op.kind !== 'gate' || !op.gate) return null;
  if (op.gate === 'unitary' && op.matrix) {
    return op.matrix.map((row) => row.map(([re, im]) => c(re, im ?? 0)));
  }
  const values: number[] = [];
  for (const v of op.params ?? []) {
    const r = tryEvaluate(v, env);
    if (r.value === undefined) return null;
    values.push(r.value);
  }
  const base = baseMatrix(op.gate, values);
  if (!base) return null;
  const k = (op.controls?.length ?? 0) + (op.anticontrols?.length ?? 0);
  if (k + Math.log2(base.length) > 3) return null;
  return controlled(base, k);
}

export function isMultiQubitGate(name: string): boolean {
  const info = GATES[name];
  return !!info && (info.targets === 'var' || (typeof info.targets === 'number' && info.targets > 1));
}

export function categoryOf(op: Op): Category {
  if (op.kind === 'measure' || op.kind === 'reset' || op.kind === 'barrier') return 'measure';
  if (op.kind === 'subcircuit') return 'block';
  const info = op.gate ? GATES[op.gate] : undefined;
  if (!info) return 'block';
  if ((op.controls?.length || op.anticontrols?.length) && info.category !== 'block') return 'multi';
  return info.category;
}
