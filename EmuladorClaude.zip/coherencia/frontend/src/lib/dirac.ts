// Notación de Dirac legible: reconoce magnitudes exactas (1, 1/√2, √3/2, 1/(2√2)…) y fases
// múltiplos racionales de π (i, −1, e^{iπ/4}…), factoriza la magnitud común y devuelve una
// estructura que la interfaz convierte en texto con superíndices.

import type { Amplitude, BlochVector } from './types';

const TOL = 2e-6;

function fraction(x: number, maxDen: number): [number, number] | null {
  // Aproximación racional por fracciones continuas, aceptada solo si es (casi) exacta.
  let h1 = 1, h0 = 0, k1 = 0, k0 = 1, b = x;
  for (let i = 0; i < 24; i++) {
    const a = Math.floor(b);
    const h2 = a * h1 + h0, k2 = a * k1 + k0;
    if (k2 > maxDen) break;
    [h0, h1, k0, k1] = [h1, h2, k1, k2];
    if (Math.abs(x - h1 / k1) < TOL) return [h1, k1];
    const rest = b - a;
    if (rest < 1e-12) break;
    b = 1 / rest;
  }
  return Math.abs(x - h1 / k1) < TOL && k1 > 0 ? [h1, k1] : null;
}

/** √n = a·√b con b libre de cuadrados. */
function sqrtParts(n: number): [number, number] {
  let a = 1, b = n;
  for (let f = 2; f * f <= b; f++) {
    while (b % (f * f) === 0) {
      a *= f;
      b /= f * f;
    }
  }
  return [a, b];
}

function radical(n: number): string {
  const [a, b] = sqrtParts(n);
  if (b === 1) return String(a);
  return a === 1 ? `√${b}` : `${a}√${b}`;
}

/** Magnitud exacta si m² es un racional sencillo (1/2 → «1/√2», 3/4 → «√3/2»); si no, decimal. */
export function fmtMagnitude(m: number): string {
  if (Math.abs(m - 1) < TOL) return '1';
  const fr = fraction(m * m, 64);
  if (fr && fr[0] > 0) {
    const [p, q] = fr;
    const num = radical(p);
    const [qa, qb] = sqrtParts(q);
    if (q === 1) return num;
    const den = qb === 1 ? String(qa) : qa === 1 ? `√${qb}` : `${qa}√${qb}`;
    const needsParen = qa !== 1 && qb !== 1;
    return `${num}/${needsParen ? `(${den})` : den}`;
  }
  return m.toFixed(4).replace(/0+$/, '').replace(/\.$/, '');
}

/** Probabilidad como fracción sencilla si lo es (0.25 → «1/4»). */
export function fmtProbability(p: number): string {
  if (p < TOL) return '0';
  if (Math.abs(p - 1) < TOL) return '1';
  const fr = fraction(p, 64);
  if (fr) return `${fr[0]}/${fr[1]}`;
  return p.toFixed(4).replace(/0+$/, '').replace(/\.$/, '');
}

export type PhaseFactor =
  | { kind: 'one' }
  | { kind: 'minus' }
  | { kind: 'i'; negative: boolean }
  | { kind: 'exp'; exponent: string };

/** Fase φ ∈ (−π, π] como 1, −1, ±i o e^{iφ} (con φ como fracción de π si es posible). */
export function phaseFactor(phi: number): PhaseFactor {
  let x = Math.atan2(Math.sin(phi), Math.cos(phi));
  if (Math.abs(x + Math.PI) < TOL) x = Math.PI;
  if (Math.abs(x) < TOL) return { kind: 'one' };
  if (Math.abs(Math.abs(x) - Math.PI) < TOL) return { kind: 'minus' };
  if (Math.abs(Math.abs(x) - Math.PI / 2) < TOL) return { kind: 'i', negative: x < 0 };
  const fr = fraction(Math.abs(x) / Math.PI, 32);
  const sign = x < 0 ? '−' : '';
  if (fr) {
    const [p, q] = fr;
    return { kind: 'exp', exponent: `${sign}i${p === 1 ? '' : p}π${q === 1 ? '' : `/${q}`}` };
  }
  return { kind: 'exp', exponent: `${sign}i·${Math.abs(x).toFixed(3)}` };
}

export interface KetTerm {
  sign: '+' | '−';
  magnitude: string | null; // null si está factorizada o vale 1
  phase: PhaseFactor;       // ya sin el signo (minus → sign)
  ket: string;
}

export interface KetExpr {
  factor: string | null;
  terms: KetTerm[];
  hidden: number;
}

/** Expresión de un vector (amplitudes complejas por estado de la base). */
export function ketExpression(amps: { state: string; re: number; im: number }[], maxTerms = 16): KetExpr {
  const nz = amps
    .map((a) => ({ ...a, m: Math.hypot(a.re, a.im), phi: Math.atan2(a.im, a.re) }))
    .filter((a) => a.m > 1e-6)
    .sort((a, b) => (a.state < b.state ? -1 : a.state > b.state ? 1 : 0));
  const shown = nz.length > maxTerms ? [...nz].sort((a, b) => b.m - a.m).slice(0, maxTerms)
    .sort((a, b) => (a.state < b.state ? -1 : 1)) : nz;
  const equal = shown.length > 1 && shown.every((a) => Math.abs(a.m - shown[0].m) < 1e-6) && nz.length === shown.length;
  const factor = equal && Math.abs(shown[0].m - 1) > TOL ? fmtMagnitude(shown[0].m) : null;
  const terms: KetTerm[] = shown.map((a) => {
    let ph = phaseFactor(a.phi);
    let sign: '+' | '−' = '+';
    if (ph.kind === 'minus') {
      sign = '−';
      ph = { kind: 'one' };
    } else if (ph.kind === 'i' && ph.negative) {
      sign = '−';
      ph = { kind: 'i', negative: false };
    }
    const mag = equal ? null : Math.abs(a.m - 1) < TOL ? null : fmtMagnitude(a.m);
    return { sign, magnitude: mag, phase: ph, ket: a.state };
  });
  return { factor, terms, hidden: nz.length - shown.length };
}

/** Estado propio de un cúbit a partir de su vector de Bloch (solo si es puro, |r| ≈ 1). */
export function qubitKet(b: BlochVector): KetExpr | null {
  if (b.r < 1 - 1e-4) return null;
  const theta = Math.acos(Math.max(-1, Math.min(1, b.z / (b.r || 1))));
  const phi = Math.atan2(b.y, b.x);
  const c = Math.cos(theta / 2), s = Math.sin(theta / 2);
  return ketExpression([
    { state: '0', re: c, im: 0 },
    { state: '1', re: s * Math.cos(phi), im: s * Math.sin(phi) },
  ]);
}

/** Versión de texto plano (para comparar pasos, accesibilidad y copiar). */
export function ketText(e: KetExpr): string {
  const body = e.terms.map((t, i) => {
    const ph = t.phase.kind === 'i' ? 'i' : t.phase.kind === 'exp' ? `e^(${t.phase.exponent})` : '';
    const coef = [t.magnitude, ph].filter(Boolean).join('·');
    const sign = i === 0 ? (t.sign === '−' ? '−' : '') : ` ${t.sign} `;
    return `${sign}${coef}|${t.ket}⟩`;
  }).join('') + (e.hidden ? ` + … (${e.hidden} términos más)` : '');
  return e.factor ? `${e.factor} (${body})` : body;
}

export function amplitudesKet(amps: Amplitude[] | null, maxTerms?: number): KetExpr | null {
  return amps && amps.length ? ketExpression(amps, maxTerms) : null;
}
