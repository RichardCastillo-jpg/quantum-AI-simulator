// Formato de números, ángulos, complejos y kets para la interfaz.

const PI = Math.PI;

export function trimNum(x: number, digits = 3): string {
  if (!Number.isFinite(x)) return '—';
  if (Math.abs(x) < 0.5 * 10 ** -digits) return '0';
  let s = x.toFixed(digits);
  if (s.includes('.')) s = s.replace(/0+$/, '').replace(/\.$/, '');
  return s === '-0' ? '0' : s;
}

export function fmtProb(p: number): string {
  if (p >= 0.9995) return '1';
  if (p < 0.0005) return p === 0 ? '0' : '<0.001';
  return p.toFixed(3).replace(/^0/, '0');
}

export function fmtPercent(p: number, digits = 1): string {
  return `${(p * 100).toFixed(digits)} %`;
}

/** Reconoce múltiplos racionales sencillos de π. */
export function piFraction(x: number): string | null {
  if (Math.abs(x) < 1e-10) return '0';
  for (const d of [1, 2, 3, 4, 6, 8, 12, 16]) {
    const k = (x * d) / PI;
    const r = Math.round(k);
    if (r !== 0 && Math.abs(k - r) < 1e-9 && Math.abs(r) <= 4 * d) {
      const sign = r < 0 ? '−' : '';
      const a = Math.abs(r);
      const num = a === 1 ? 'π' : `${a}π`;
      return d === 1 ? `${sign}${num}` : `${sign}${num}/${d}`;
    }
  }
  return null;
}

export function fmtAngle(rad: number): string {
  return piFraction(rad) ?? `${trimNum((rad * 180) / PI, 1)}°`;
}

export function fmtComplex(re: number, im: number, digits = 3): string {
  const r = Math.abs(re) < 5e-4 ? 0 : re;
  const i = Math.abs(im) < 5e-4 ? 0 : im;
  if (i === 0) return trimNum(r, digits);
  if (r === 0) return `${trimNum(i, digits)}i`.replace(/^1i$/, 'i').replace(/^-1i$/, '−i').replace('-', '−');
  const sign = i < 0 ? '−' : '+';
  return `${trimNum(r, digits).replace('-', '−')} ${sign} ${trimNum(Math.abs(i), digits)}i`;
}

export function ket(state: string): string {
  return `|${state}⟩`;
}

/** Valor de parámetro legible para mostrar en la compuerta (π en lugar de pi, etc.). */
export function prettyParam(value: number | string): string {
  if (typeof value === 'number') return piFraction(value) ?? trimNum(value, 3);
  return value
    .replace(/\bpi\b/g, 'π')
    .replace(/\btau\b/g, 'τ')
    .replace(/\*\*/g, '^')
    .replace(/\s*\*\s*/g, '·')
    .replace(/\btheta\b/g, 'θ')
    .replace(/\bphi\b/g, 'φ')
    .replace(/\blambda\b/g, 'λ');
}

export function plural(n: number, one: string, many: string): string {
  return `${n} ${n === 1 ? one : many}`;
}
