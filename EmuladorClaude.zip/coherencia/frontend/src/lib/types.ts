// Tipos compartidos con la API (ver backend/app/core/models.py).

export type ParamValue = number | string;

export interface Condition {
  clbit: number;
  value: 0 | 1;
}

export type OpKind = 'gate' | 'measure' | 'reset' | 'barrier' | 'subcircuit';

export interface Op {
  id: string;
  kind: OpKind;
  gate?: string;
  col: number;
  targets: number[];
  controls?: number[];
  anticontrols?: number[];
  params?: ParamValue[];
  clbits?: number[];
  condition?: Condition[] | null;
  subcircuit_id?: string;
  sub_params?: Record<string, ParamValue>;
  matrix?: number[][][];
  label?: string;
}

export interface Loop {
  id: string;
  col_start: number;
  col_end: number;
  iterations: number;
  var: string;
  start?: number;
  step?: number;
  label?: string;
}

export interface Circuit {
  version?: number;
  name: string;
  num_qubits: number;
  num_clbits: number;
  initial_state: string;
  qubit_labels?: string[] | null;
  clbit_labels?: string[] | null;
  ops: Op[];
  loops: Loop[];
  meta?: Record<string, unknown>;
}

export type NoiseModelName = 'none' | 'depolarizing' | 'thermal';

export interface NoiseConfig {
  model: NoiseModelName;
  p1: number;
  p2: number;
  t1: number;
  t2: number;
  time_1q: number;
  time_2q: number;
  readout: number;
}

export interface SimConfig {
  mode: 'statevector' | 'shots';
  shots: number;
  seed: number | null;
  noise: NoiseConfig;
}

export interface SimOptions {
  memory?: boolean;
  include_state?: boolean;
  max_amplitudes?: number;
  max_probabilities?: number;
}

export interface SubcircuitDef {
  id: string;
  name: string;
  description: string;
  num_qubits: number;
  num_clbits: number;
  params: string[];
  ops: Op[];
  loops: Loop[];
  color?: string | null;
  tags?: string[];
  created_at?: string;
  updated_at?: string;
  system?: boolean;
}

export interface BlochVector {
  qubit: number;
  x: number;
  y: number;
  z: number;
  r: number;
  purity: number;
  entropy: number;
  p1: number;
  theta: number;
  phi: number;
}

export interface ProbEntry {
  state: string;
  p: number;
  count?: number;
  phase?: number;
}

export interface Amplitude {
  state: string;
  re: number;
  im: number;
  p: number;
  phase: number;
}

export interface Branch {
  label: string;
  probability: number;
  record: { clbit: number; qubit: number; value: number; step: number }[];
  amplitudes: Amplitude[];
  truncated: boolean;
}

export interface StatePayload {
  kind: 'pure' | 'mixed';
  purity: number;
  probabilities: ProbEntry[];
  probabilities_other: number;
  probabilities_truncated: boolean;
  bloch: BlochVector[];
  num_ancillas: number;
  amplitudes: Amplitude[] | null;
  amplitudes_truncated: boolean;
  branches: Branch[];
  /** Matriz densidad de los cúbits (solo hasta 5 cúbits). */
  density?: DensityMatrix | null;
}

export interface DensityMatrix {
  n: number;
  re: number[][];
  im: number[][];
}

export interface Histogram {
  source: 'state' | 'counts' | 'classical';
  register: 'qubits' | 'clbits';
  width: number;
  entries: ProbEntry[];
  other: number;
  truncated: boolean;
  shots: number | null;
}

export interface SimResult {
  ok: boolean;
  engine: string;
  engine_version: string;
  mode: 'statevector' | 'shots';
  num_qubits: number;
  num_clbits: number;
  initial_state: string;
  bloch_initial: BlochVector[];
  stats: { depth: number; gates: number; ops: Record<string, number>; steps: number; dynamic: boolean; noise_channels: number };
  state: StatePayload | null;
  classical: { entries: ProbEntry[]; other: number; truncated: boolean; width: number } | null;
  shots: {
    shots: number;
    register: 'qubits' | 'clbits';
    width: number;
    counts: Record<string, number>;
    entries: ProbEntry[];
    other: number;
    truncated: boolean;
    memory: string[] | null;
    method: string;
  } | null;
  histogram: Histogram | null;
  dominant: { state: string; p: number; register: 'qubits' | 'clbits'; count?: number | null } | null;
  analysis: Record<string, any> | null;
  warnings: string[];
  elapsed_ms: number;
}

export interface StepSnapshot {
  index: number;
  label: string;
  col: number | null;
  ops: string[];
  bloch: BlochVector[];
  purity: number;
  probabilities: ProbEntry[];
  probabilities_other: number;
  probabilities_truncated: boolean;
  amplitudes: Amplitude[] | null;
}

export interface StepsResult {
  ok: boolean;
  engine: string;
  num_qubits: number;
  noisy: boolean;
  steps: StepSnapshot[];
  warnings: string[];
  elapsed_ms: number;
}

export interface Health {
  status: string;
  engine: string;
  engine_version: string;
  limits: {
    max_qubits: number;
    max_density_qubits: number;
    max_step_qubits: number;
    max_steps: number;
    max_shots: number;
    max_memory_shots: number;
    max_ops: number;
  };
}

export interface PresetParam {
  key: string;
  label: string;
  type: 'number' | 'integer' | 'select' | 'bits';
  default: number | string;
  min?: number;
  max?: number;
  step?: number;
  options?: { value: string; label: string }[];
}

export interface Preset {
  key: string;
  name: string;
  summary: string;
  tags: string[];
  params: PresetParam[];
}

export interface ApiErrorItem {
  op_id: string | null;
  message: string;
  /** Línea del código Qiskit (solo en errores del editor de código). */
  line?: number | null;
  col?: number | null;
}
