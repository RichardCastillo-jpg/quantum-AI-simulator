// Evaluador seguro de expresiones (espejo de backend/app/core/expressions.py).
// Se usa para previsualizar valores en el inspector y detectar parámetros libres.

export class ExprError extends Error {}

type Tok = { k: 'num' | 'id' | 'op' | 'lp' | 'rp' | 'comma' | 'end'; v: string; pos: number };

const CONSTANTS: Record<string, number> = { pi: Math.PI, 'π': Math.PI, tau: 2 * Math.PI, 'τ': 2 * Math.PI, e: Math.E };

const FUNCS: Record<string, [number, (...a: number[]) => number]> = {
  sin: [1, Math.sin], cos: [1, Math.cos], tan: [1, Math.tan], asin: [1, Math.asin], acos: [1, Math.acos],
  atan: [1, Math.atan], atan2: [2, Math.atan2], sqrt: [1, Math.sqrt], exp: [1, Math.exp], log: [1, Math.log],
  ln: [1, Math.log], log2: [1, Math.log2], log10: [1, Math.log10], abs: [1, Math.abs], floor: [1, Math.floor],
  ceil: [1, Math.ceil], round: [1, Math.round], min: [2, Math.min], max: [2, Math.max],
};

const isIdStart = (c: string) => c === '_' || /\p{L}/u.test(c);
const isIdChar = (c: string) => c === '_' || /[\p{L}\p{N}]/u.test(c);
const isDigit = (c: string) => c >= '0' && c <= '9';

function tokenize(src: string): Tok[] {
  const out: Tok[] = [];
  const chars = Array.from(src);
  let i = 0;
  while (i < chars.length) {
    const c = chars[i];
    if (/\s/.test(c)) { i++; continue; }
    if (isDigit(c) || (c === '.' && i + 1 < chars.length && isDigit(chars[i + 1]))) {
      let j = i;
      while (j < chars.length && (isDigit(chars[j]) || chars[j] === '.')) j++;
      if (j < chars.length && (chars[j] === 'e' || chars[j] === 'E')) {
        let k = j + 1;
        if (k < chars.length && (chars[k] === '+' || chars[k] === '-')) k++;
        if (k < chars.length && isDigit(chars[k])) {
          j = k;
          while (j < chars.length && isDigit(chars[j])) j++;
        }
      }
      const text = chars.slice(i, j).join('');
      if ((text.match(/\./g) || []).length > 1) throw new ExprError(`Número mal formado «${text}»`);
      out.push({ k: 'num', v: text, pos: i });
      i = j;
      continue;
    }
    if (isIdStart(c)) {
      let j = i + 1;
      while (j < chars.length && isIdChar(chars[j])) j++;
      out.push({ k: 'id', v: chars.slice(i, j).join(''), pos: i });
      i = j;
      continue;
    }
    if (c === '*' && chars[i + 1] === '*') { out.push({ k: 'op', v: '^', pos: i }); i += 2; continue; }
    if ('+-*/%^'.includes(c)) { out.push({ k: 'op', v: c, pos: i }); i++; continue; }
    if (c === '·' || c === '×') { out.push({ k: 'op', v: '*', pos: i }); i++; continue; }
    if (c === '(') { out.push({ k: 'lp', v: c, pos: i }); i++; continue; }
    if (c === ')') { out.push({ k: 'rp', v: c, pos: i }); i++; continue; }
    if (c === ',') { out.push({ k: 'comma', v: c, pos: i }); i++; continue; }
    throw new ExprError(`Carácter no válido «${c}» en la posición ${i + 1}`);
  }
  out.push({ k: 'end', v: '', pos: chars.length });
  // Multiplicación implícita: 2pi, 3(…), )x
  const res: Tok[] = [];
  out.forEach((t, idx) => {
    const prev = out[idx - 1];
    if (prev && ((prev.k === 'num' && (t.k === 'id' || t.k === 'lp')) || (prev.k === 'rp' && (t.k === 'id' || t.k === 'num' || t.k === 'lp')))) {
      res.push({ k: 'op', v: '*', pos: t.pos });
    }
    res.push(t);
  });
  return res;
}

type Node =
  | { t: 'num'; v: number }
  | { t: 'var'; name: string }
  | { t: 'un'; op: string; a: Node }
  | { t: 'bin'; op: string; a: Node; b: Node }
  | { t: 'call'; name: string; args: Node[] };

function parse(src: string): Node {
  if (src.length > 240) throw new ExprError('La expresión es demasiado larga');
  if (!src.trim()) throw new ExprError('La expresión está vacía');
  const toks = tokenize(src);
  let i = 0;
  let depth = 0;
  const peek = () => toks[i];
  const take = () => toks[i++];
  const enter = () => { if (++depth > 48) throw new ExprError('Expresión demasiado anidada'); };

  function expr(): Node {
    enter();
    let n = term();
    while (peek().k === 'op' && (peek().v === '+' || peek().v === '-')) {
      const op = take().v;
      n = { t: 'bin', op, a: n, b: term() };
    }
    depth--;
    return n;
  }
  function term(): Node {
    let n = unary();
    while (peek().k === 'op' && '*/%'.includes(peek().v)) {
      const op = take().v;
      n = { t: 'bin', op, a: n, b: unary() };
    }
    return n;
  }
  function unary(): Node {
    const t = peek();
    if (t.k === 'op' && (t.v === '+' || t.v === '-')) {
      take();
      enter();
      const n: Node = { t: 'un', op: t.v, a: unary() };
      depth--;
      return n;
    }
    return power();
  }
  function power(): Node {
    const base = atom();
    if (peek().k === 'op' && peek().v === '^') {
      take();
      enter();
      const e = unary();
      depth--;
      return { t: 'bin', op: '^', a: base, b: e };
    }
    return base;
  }
  function atom(): Node {
    const t = take();
    if (t.k === 'num') return { t: 'num', v: parseFloat(t.v) };
    if (t.k === 'id') {
      if (peek().k === 'lp') {
        take();
        const args: Node[] = [];
        if (peek().k !== 'rp') {
          args.push(expr());
          while (peek().k === 'comma') { take(); args.push(expr()); }
        }
        if (take().k !== 'rp') throw new ExprError(`Falta «)» tras los argumentos de ${t.v}`);
        return { t: 'call', name: t.v, args };
      }
      return { t: 'var', name: t.v };
    }
    if (t.k === 'lp') {
      const n = expr();
      if (take().k !== 'rp') throw new ExprError('Falta «)»');
      return n;
    }
    if (t.k === 'end') throw new ExprError('La expresión está incompleta');
    throw new ExprError(`Símbolo inesperado «${t.v}» en la posición ${t.pos + 1}`);
  }
  const n = expr();
  if (peek().k !== 'end') throw new ExprError(`Símbolo inesperado «${peek().v}» en la posición ${peek().pos + 1}`);
  return n;
}

function ev(n: Node, env: Record<string, number>): number {
  switch (n.t) {
    case 'num': return n.v;
    case 'var':
      if (n.name in env) return env[n.name];
      if (n.name in CONSTANTS) return CONSTANTS[n.name];
      throw new ExprError(`Variable desconocida «${n.name}»`);
    case 'un': { const v = ev(n.a, env); return n.op === '-' ? -v : v; }
    case 'bin': {
      const a = ev(n.a, env);
      const b = ev(n.b, env);
      switch (n.op) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': if (b === 0) throw new ExprError('División entre cero'); return a / b;
        case '%': if (b === 0) throw new ExprError('Módulo entre cero'); return a % b;
        case '^': { const r = Math.pow(a, b); if (Number.isNaN(r)) throw new ExprError('La potencia produce un número complejo'); return r; }
      }
      throw new ExprError('Operador desconocido');
    }
    case 'call': {
      const spec = FUNCS[n.name];
      if (!spec) throw new ExprError(`Función desconocida «${n.name}»`);
      if (n.args.length !== spec[0]) throw new ExprError(`${n.name} espera ${spec[0]} argumento(s)`);
      const r = spec[1](...n.args.map((a) => ev(a, env)));
      if (Number.isNaN(r)) throw new ExprError(`Valor fuera del dominio de ${n.name}`);
      return r;
    }
  }
}

export function evaluate(value: number | string, env: Record<string, number> = {}): number {
  const r = typeof value === 'number' ? value : ev(parse(value), env);
  if (!Number.isFinite(r)) throw new ExprError('El resultado no es un número finito');
  return r;
}

export function tryEvaluate(value: number | string, env: Record<string, number> = {}): { value?: number; error?: string } {
  try {
    return { value: evaluate(value, env) };
  } catch (err) {
    return { error: (err as Error).message };
  }
}

export function freeVariables(src: string): Set<string> {
  const found = new Set<string>();
  const walk = (n: Node): void => {
    if (n.t === 'var') { if (!(n.name in CONSTANTS)) found.add(n.name); }
    else if (n.t === 'un') walk(n.a);
    else if (n.t === 'bin') { walk(n.a); walk(n.b); }
    else if (n.t === 'call') n.args.forEach(walk);
  };
  walk(parse(src));
  return found;
}

export function isIdentifier(name: string): boolean {
  if (!name || name.length > 24) return false;
  const chars = Array.from(name);
  return isIdStart(chars[0]) && chars.every(isIdChar) && !(name in CONSTANTS) && !(name in FUNCS);
}
