export interface C {
  re: number;
  im: number;
}

export const c = (re: number, im = 0): C => ({ re, im });
export const add = (a: C, b: C): C => ({ re: a.re + b.re, im: a.im + b.im });
export const mul = (a: C, b: C): C => ({ re: a.re * b.re - a.im * b.im, im: a.re * b.im + a.im * b.re });
export const scale = (a: C, s: number): C => ({ re: a.re * s, im: a.im * s });
export const expi = (t: number): C => ({ re: Math.cos(t), im: Math.sin(t) });
export const abs2 = (a: C): number => a.re * a.re + a.im * a.im;
export const arg = (a: C): number => Math.atan2(a.im, a.re);

export type Matrix = C[][];

export function matmul(a: Matrix, b: Matrix): Matrix {
  const n = a.length;
  const m = b[0].length;
  const k = b.length;
  const out: Matrix = [];
  for (let i = 0; i < n; i++) {
    const row: C[] = [];
    for (let j = 0; j < m; j++) {
      let acc = c(0);
      for (let t = 0; t < k; t++) acc = add(acc, mul(a[i][t], b[t][j]));
      row.push(acc);
    }
    out.push(row);
  }
  return out;
}

export function identity(n: number): Matrix {
  return Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => c(i === j ? 1 : 0)));
}

/** U controlada por k cúbits (bits bajos, como en Qiskit). */
export function controlled(u: Matrix, k: number): Matrix {
  if (k === 0) return u;
  const dt = u.length;
  const full = identity(dt << k);
  const mask = (1 << k) - 1;
  for (let a = 0; a < dt; a++) {
    for (let b = 0; b < dt; b++) full[(a << k) | mask][(b << k) | mask] = u[a][b];
  }
  return full;
}

export function isUnitary(u: Matrix, tol = 1e-6): boolean {
  const n = u.length;
  if (!u.every((r) => r.length === n)) return false;
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      let acc = c(0);
      for (let t = 0; t < n; t++) acc = add(acc, mul({ re: u[t][i].re, im: -u[t][i].im }, u[t][j]));
      const target = i === j ? 1 : 0;
      if (Math.abs(acc.re - target) > tol || Math.abs(acc.im) > tol) return false;
    }
  }
  return true;
}
