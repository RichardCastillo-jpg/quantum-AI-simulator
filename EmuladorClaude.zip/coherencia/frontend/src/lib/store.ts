// Almacén reactivo mínimo: estado inmutable + suscriptores.

export type Listener<T> = (state: T, prev: T) => void;

export class Store<T extends object> {
  private state: T;
  private listeners = new Set<Listener<T>>();
  private batching = 0;
  private pendingPrev: T | null = null;

  constructor(initial: T) {
    this.state = initial;
  }

  get(): T {
    return this.state;
  }

  set(patch: Partial<T> | ((s: T) => Partial<T>)): void {
    const prev = this.state;
    const delta = typeof patch === 'function' ? patch(prev) : patch;
    this.state = { ...prev, ...delta };
    if (this.batching) {
      if (!this.pendingPrev) this.pendingPrev = prev;
      return;
    }
    this.emit(prev);
  }

  batch(fn: () => void): void {
    this.batching++;
    try {
      fn();
    } finally {
      this.batching--;
      if (!this.batching && this.pendingPrev) {
        const prev = this.pendingPrev;
        this.pendingPrev = null;
        this.emit(prev);
      }
    }
  }

  private emit(prev: T): void {
    for (const fn of [...this.listeners]) fn(this.state, prev);
  }

  subscribe(fn: Listener<T>): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  /** Llama a ``fn`` solo cuando cambia (por referencia) el valor seleccionado. */
  select<S>(selector: (s: T) => S, fn: (value: S, prev: S) => void): () => void {
    let last = selector(this.state);
    return this.subscribe((s) => {
      const next = selector(s);
      if (next !== last) {
        const prev = last;
        last = next;
        fn(next, prev);
      }
    });
  }
}
