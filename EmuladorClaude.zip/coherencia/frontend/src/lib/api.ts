// Cliente de la API REST. La URL base sale de la configuración en tiempo de ejecución
// (/env.js, escrito por el servidor del contenedor) o, por defecto, del mismo origen (/api),
// que el servidor del frontend reenvía al backend por la red interna de Docker.

import type {
  ApiErrorItem,
  Circuit,
  Health,
  Preset,
  SimConfig,
  SimOptions,
  SimResult,
  StepsResult,
  SubcircuitDef,
} from './types';

declare global {
  interface Window {
    __COHERENCIA__?: { apiUrl?: string };
  }
}

export function apiBase(): string {
  const configured = typeof window !== 'undefined' ? window.__COHERENCIA__?.apiUrl : undefined;
  return (configured ?? '').replace(/\/+$/, '');
}

export class ApiError extends Error {
  status: number;
  errors: ApiErrorItem[];
  constructor(message: string, status: number, errors: ApiErrorItem[] = []) {
    super(message);
    this.status = status;
    this.errors = errors;
  }
}

function parseError(status: number, body: any): ApiError {
  const detail = body?.detail;
  if (detail && typeof detail === 'object' && !Array.isArray(detail)) {
    return new ApiError(detail.message ?? 'Error de la API', status, detail.errors ?? []);
  }
  if (Array.isArray(detail)) {
    // Errores de esquema de FastAPI/Pydantic.
    const errors = detail.map((d: any) => ({ op_id: null, message: `${(d.loc ?? []).slice(1).join('.')}: ${d.msg}` }));
    return new ApiError('La petición no tiene el formato esperado', status, errors);
  }
  return new ApiError(typeof detail === 'string' ? detail : `Error HTTP ${status}`, status);
}

async function request<T>(method: string, path: string, body?: unknown, signal?: AbortSignal): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${apiBase()}${path}`, {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal,
    });
  } catch (err) {
    if ((err as Error)?.name === 'AbortError') throw err;
    throw new ApiError(`No se pudo contactar con el servidor (${apiBase() || window.location.origin}). Comprueba que la aplicación sigue en marcha: docker compose ps`, 0);
  }
  if (res.status === 204) return undefined as T;
  let data: any = null;
  const text = await res.text();
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = { detail: text };
    }
  }
  if (!res.ok) throw parseError(res.status, data);
  return data as T;
}

export const api = {
  health: (signal?: AbortSignal) => request<Health>('GET', '/api/health', undefined, signal),
  simulate: (circuit: Circuit, config: SimConfig, options: SimOptions = {}, signal?: AbortSignal) =>
    request<SimResult>('POST', '/api/simulate', { circuit, config, options }, signal),
  steps: (circuit: Circuit, config: SimConfig, signal?: AbortSignal) =>
    request<StepsResult>('POST', '/api/simulate/steps', { circuit, config }, signal),
  export: (circuit: Circuit) =>
    request<{ python: string; qasm3: string | null; qasm2: string | null; errors: string[] }>('POST', '/api/export', { circuit }),
  codeFromCircuit: (circuit: Circuit) =>
    request<{ code: string; line_map: Record<string, number>; warnings: string[] }>('POST', '/api/code/qiskit', { circuit }),
  codeToCircuit: (code: string, name: string, signal?: AbortSignal) =>
    request<{ circuit: Circuit; warnings: string[]; op_lines: Record<string, number> }>('POST', '/api/code/parse', { code, name }, signal),
  algorithms: () => request<Preset[]>('GET', '/api/algorithms'),
  algorithm: (key: string, params: Record<string, unknown>) => request<Circuit>('POST', `/api/algorithms/${key}`, params),
  subcircuits: () => request<SubcircuitDef[]>('GET', '/api/subcircuits'),
  createSubcircuit: (data: Partial<SubcircuitDef>) => request<SubcircuitDef>('POST', '/api/subcircuits', data),
  updateSubcircuit: (id: string, data: Partial<SubcircuitDef>) =>
    request<SubcircuitDef>('PUT', `/api/subcircuits/${encodeURIComponent(id)}`, data),
  deleteSubcircuit: (id: string, force = false) =>
    request<void>('DELETE', `/api/subcircuits/${encodeURIComponent(id)}${force ? '?force=true' : ''}`),
  validateSubcircuit: (data: Partial<SubcircuitDef>, id?: string) =>
    request<{ ok: boolean; message?: string; errors?: ApiErrorItem[]; ops?: number; depth?: number }>(
      'POST', `/api/subcircuits/validate${id ? `?sid=${encodeURIComponent(id)}` : ''}`, data),
  dependents: (id: string) => request<{ id: string; name: string }[]>('GET', `/api/subcircuits/${encodeURIComponent(id)}/dependents`),
};
