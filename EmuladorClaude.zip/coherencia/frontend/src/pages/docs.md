---
layout: ../layouts/LessonLayout.astro
title: "Documentación técnica"
section: docs
description: "Arquitectura, formato JSON de los circuitos, API REST, modelos de ruido y límites del servicio."
---

## Arquitectura

Coherencia es una aplicación cliente-servidor desacoplada que se despliega con `docker-compose`:

| Servicio | Tecnología | Puerto | Función |
| --- | --- | --- | --- |
| `backend` | FastAPI + Qiskit + Qiskit Aer | 8000 | Valida el JSON, lo traduce a `QuantumCircuit` y simula en Aer. CRUD de subcircuitos. |
| `frontend` | Astro (sitio estático) + servidor Node | 4321 | Páginas, editor, laboratorios. Reenvía `/api` al backend por la red interna. |
| volumen `qsim-data` | JSON en disco | — | Biblioteca de subcircuitos persistente. |

El flujo de una simulación es: **JSON → IR → motor → observables → análisis**.

1. **IR.** El circuito (columnas, ciclos, subcircuitos, parámetros con expresiones) se valida y se aplana a una lista
   de operaciones primitivas sobre cúbits globales: los ciclos se desenrollan, los subcircuitos se expanden con sus
   controles y condiciones, y los bloques QFT se descomponen.
2. **Motor.** Qiskit Aer ejecuta la IR traducida a `QuantumCircuit`: compuertas nativas cuando existen
   (`cx`, `ccx`, `mcx`, `cp`, `mcphase`, `cswap`…) y `UnitaryGate` exacta en el resto. El control clásico usa
   `if_test` (circuitos dinámicos). Un motor de referencia en NumPy implementa la misma IR de forma independiente
   y sirve para validar Aer en las pruebas.
3. **Observables.** Probabilidades, amplitudes, vectores de Bloch (por trazas parciales), pureza, ramas
   clásicas y distribución exacta de los registros.
4. **Análisis.** Los algoritmos precargados añaden su post-procesado (fracciones continuas en Shor, XEB y
   Porter–Thomas en los circuitos aleatorios, fidelidad en la teleportación…).

En modo **Statevector** las mediciones intermedias, los reinicios y las condiciones se resuelven con el
*principio de medición diferida*: cada medición se sustituye por una CNOT hacia un cúbit auxiliar, cada reinicio
por un SWAP con un auxiliar en |0⟩ y cada condición por un control sobre el auxiliar correspondiente. La
estadística es exactamente la del circuito dinámico. Con ruido se usa la matriz densidad (`density_matrix`).

## Modelo del circuito

```json
{
  "name": "Par de Bell",
  "num_qubits": 2,
  "num_clbits": 2,
  "initial_state": "00",
  "ops": [
    { "id": "a", "kind": "gate", "gate": "h", "col": 0, "targets": [0] },
    { "id": "b", "kind": "gate", "gate": "x", "col": 1, "targets": [1], "controls": [0] },
    { "id": "c", "kind": "measure", "col": 2, "targets": [0], "clbits": [0] },
    { "id": "d", "kind": "gate", "gate": "rz", "col": 3, "targets": [1],
      "params": ["i*pi/8"], "condition": [{ "clbit": 0, "value": 1 }] }
  ],
  "loops": [{ "id": "l1", "col_start": 3, "col_end": 3, "iterations": 4, "var": "i" }]
}
```

- `kind`: `gate`, `measure`, `reset`, `barrier` o `subcircuit`.
- `targets`, `controls`, `anticontrols`: índices de cúbit. CNOT es `x` con un control; Toffoli, `x` con dos.
- `params`: números o expresiones (`pi/4`, `2pi`, `sqrt(2)/2`, variables de ciclos y de subcircuitos).
- `condition`: lista de condiciones clásicas (todas deben cumplirse).
- `subcircuit_id`, `sub_params`, `clbits`: instancia de un subcircuito de la biblioteca y su asignación.
- `matrix`: para `unitary`, la matriz como `[fila][columna] = [re, im]`.
- Orden de bits de Qiskit: en las cadenas de bits el carácter de la derecha es q0 (o c0).

Compuertas disponibles: `id x y z h s sdg t tdg sx sxdg sy sw p rx ry rz u swap iswap rxx ryy rzz fsim qft iqft modmul unitary`.

## API REST

| Método | Ruta | Descripción |
| --- | --- | --- |
| GET | `/api/health` | Estado, motor y límites. |
| GET | `/api/gates` | Catálogo de compuertas con sus matrices. |
| POST | `/api/simulate` | Simula `{circuit, config, options}`. |
| POST | `/api/simulate/steps` | Estado después de cada columna (depurador). |
| POST | `/api/validate` | Valida un circuito sin simularlo. |
| POST | `/api/export` | Código Python de Qiskit, OpenQASM 3 y OpenQASM 2. |
| POST | `/api/code/qiskit` | Código Qiskit editable del circuito y qué línea crea cada operación. |
| POST | `/api/code/parse` | Traduce código Qiskit (`{code, name}`) a un circuito; los errores llevan `line`. |
| GET / POST | `/api/subcircuits` | Lista o crea subcircuitos. |
| GET / PUT / DELETE | `/api/subcircuits/{id}` | Lee, modifica o elimina (`?force=true` si otros lo usan). |
| POST | `/api/subcircuits/validate` | Valida un borrador con sus parámetros libres. |
| GET | `/api/algorithms` | Algoritmos precargados y sus parámetros. |
| POST | `/api/algorithms/{clave}` | Genera el circuito del algoritmo (cuerpo: parámetros). |

`config` admite `mode` (`statevector` o `shots`), `shots`, `seed` y `noise`. Hasta 5 cúbits, la respuesta incluye
`state.density = {n, re, im}`: la matriz densidad de los cúbits (con ruido, la del estado mixto; con mediciones
intermedias, la reducida sobre los cúbits originales), que alimenta las figuras 3D de Re ρ, Im ρ y |ρ|. Los errores de validación devuelven
**422** con `{"detail": {"message", "errors": [{"op_id", "message"}]}}`, de modo que la interfaz marca la operación
exacta que falla. La documentación interactiva de FastAPI está en `http://localhost:8000/docs`.

### Código Qiskit

El editor de código del simulador usa las dos últimas rutas. El código **no se ejecuta**: el backend lo analiza con
el módulo `ast` de Python y lo recorre con un intérprete propio que solo admite aritmética, listas, bucles,
condicionales, funciones definidas en el propio código y la API de circuitos de Qiskit. No hay `eval` ni `exec`, no
se puede importar nada salvo `qiskit`, `math` y `numpy` (simulados), ni acceder a atributos privados, archivos o red,
y hay límites de pasos, tamaño de las secuencias y recursión. Lo que solo sirve para ejecutar o dibujar
(`AerSimulator`, `transpile`, `print`, `plot_histogram`) se ignora con un aviso.

Al traducir, las operaciones se colocan en la primera columna libre sin que se crucen las líneas verticales de las
compuertas de varios cúbits, y una `UnitaryGate` cuya matriz coincide con una compuerta conocida (por ejemplo T) se
convierte en esa compuerta.

## Modelos de ruido

El ruido se inserta como canales de Kraus explícitos después de cada compuerta lógica:

- **Despolarizante:** E(ρ) = (1 − λ)ρ + λ·I/2ⁿ con λ = p1 en compuertas de 1 cúbit y λ = p2 en las de 2. En
  compuertas de 3 o más cúbits se aplica λ = p2 a cada cúbit por separado.
- **Relajación térmica:** amortiguamiento de amplitud γ = 1 − e^(−t/T1) compuesto con desfase puro para que la
  coherencia decaiga como e^(−t/T2). Requiere T2 ≤ 2·T1. Las compuertas de 2 o más cúbits usan `time_2q`.
- **Lectura:** cada bit medido se invierte con probabilidad `readout` (también en mediciones intermedias, por lo
  que afecta al control clásico).

Las compuertas aritméticas (`modmul`) y las unitarias personalizadas reciben el ruido como cualquier compuerta de
su número de cúbits.

## Límites del servicio

Configurables con variables de entorno del backend:

| Variable | Por defecto | Significado |
| --- | --- | --- |
| `QSIM_MAX_QUBITS` | 22 | Cúbits para vector de estado. |
| `QSIM_MAX_DENSITY_QUBITS` | 10 | Cúbits (incluidos auxiliares) para matriz densidad exacta. |
| `QSIM_MAX_STEP_QUBITS` | 12 | Cúbits del depurador paso a paso. |
| `QSIM_MAX_OPS` | 20000 | Operaciones tras desenrollar ciclos. |
| `QSIM_MAX_SHOTS` | 100000 | Disparos por ejecución. |
| `QSIM_ENGINE` | `qiskit` | `reference` usa el motor NumPy. |
| `CORS_ORIGINS` | `http://localhost:4321,…` | Orígenes permitidos para llamadas directas. |
