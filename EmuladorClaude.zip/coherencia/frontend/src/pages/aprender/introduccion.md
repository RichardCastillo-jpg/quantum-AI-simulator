---
layout: ../../layouts/LessonLayout.astro
title: "Cúbits, superposición y medición"
kicker: "Lección 1"
description: "Qué es un cúbit, cómo se describe con amplitudes complejas, qué ocurre al medirlo y cómo se combinan varios cúbits."
---

## El cúbit

Un bit clásico vale 0 o 1. Un **cúbit** se describe con dos números complejos, sus **amplitudes**:

<span class="eq">|ψ⟩ = α|0⟩ + β|1⟩,   con |α|² + |β|² = 1</span>

Los kets <span class="ket">|0⟩</span> y <span class="ket">|1⟩</span> forman la *base computacional*. Mientras nadie mide, el cúbit
está en una **superposición** de ambos: no es que valga 0 o 1 y no lo sepamos, sino que las dos posibilidades
coexisten con amplitudes que pueden sumarse o cancelarse.

Cada amplitud tiene un módulo y una **fase**. La fase global (multiplicar todo el estado por el mismo e<sup>iγ</sup>)
no tiene ningún efecto observable; la **fase relativa** entre amplitudes sí, porque decide cómo interfieren.

> En el simulador, la fase de cada amplitud se dibuja como un color: la rueda de colores es el plano complejo.
> Dos barras del mismo color tienen la misma fase; colores opuestos indican fases opuestas.

## Medir

Al medir en la base computacional, el resultado es aleatorio y sigue la **regla de Born**:

<span class="eq">P(0) = |α|²     P(1) = |β|²</span>

Tras la medición el estado *colapsa* al resultado obtenido y la superposición se pierde. Por eso un único disparo
da muy poca información: en el modo **Shots** el simulador repite el circuito muchas veces y muestra el
histograma de resultados; en el modo **Statevector** muestra directamente las probabilidades exactas.

## La esfera de Bloch

Como la fase global no importa, cualquier estado puro de un cúbit puede escribirse con dos ángulos:

<span class="eq">|ψ⟩ = cos(θ/2)|0⟩ + e<sup>iφ</sup> sin(θ/2)|1⟩</span>

El par (θ, φ) es un punto de una esfera de radio 1: el polo norte es <span class="ket">|0⟩</span>, el polo sur
<span class="ket">|1⟩</span> y el ecuador contiene las superposiciones equilibradas, como
<span class="ket">|+⟩ = (|0⟩+|1⟩)/√2</span> sobre el eje x. Las compuertas de un cúbit son **rotaciones** de esa
esfera: X gira π en torno al eje x, Z gira π en torno al eje z, H intercambia los ejes x y z.

Si el cúbit está entrelazado con otros o ha sufrido ruido, su estado ya no es puro y el vector queda **dentro**
de la esfera: su longitud |r| mide la pureza. Un cúbit de un par de Bell tiene |r| = 0: por sí solo es
completamente aleatorio.

## Varios cúbits

Con n cúbits el estado tiene 2<sup>n</sup> amplitudes, una por cada cadena de bits. Para dos cúbits:

<span class="eq">|ψ⟩ = a|00⟩ + b|01⟩ + c|10⟩ + d|11⟩</span>

Este simulador usa la convención de **Qiskit**: en <span class="ket">|q₂ q₁ q₀⟩</span> el bit de la
**derecha** es q0. Así, el estado <span class="ket">|001⟩</span> significa q0 = 1 y el resto en 0. La misma regla se
aplica a los bits clásicos y al estado inicial que eliges en el panel de ejecución.

Los estados de varios cúbits que se pueden escribir como producto de estados individuales, como
<span class="ket">|0⟩⊗|+⟩</span>, se llaman *separables*. Los que no, **entrelazados**.

## Entrelazamiento

El ejemplo más simple es el par de Bell, que se prepara con una Hadamard y una CNOT:

<span class="eq">|Φ⁺⟩ = (|00⟩ + |11⟩)/√2</span>

Al medir, los dos cúbits dan siempre el mismo resultado, aunque cada uno por separado sea un 50 % aleatorio.
Ninguna asignación de estados individuales reproduce esa correlación: la información está en el conjunto, no
en las partes. En las esferas de Bloch del simulador lo verás como dos vectores de longitud cero.

## Interferencia

La razón por la que los algoritmos cuánticos funcionan es que las amplitudes, a diferencia de las
probabilidades, pueden cancelarse. Aplicar H dos veces devuelve <span class="ket">|0⟩</span>:

<span class="eq">H H |0⟩ = H (|0⟩+|1⟩)/√2 = |0⟩</span>

En el segundo paso, los dos caminos que llevan a <span class="ket">|1⟩</span> llegan con fases opuestas y se anulan.
El [interferómetro de Mach–Zehnder](/aprender/mach-zehnder) es exactamente este circuito construido con luz:
cada divisor de haz es una H y un desfasador añade la fase P(φ) entre los dos caminos.

## Qué probar ahora

1. En el [simulador](/simulador), coloca una H en q0 y una CNOT de q0 a q1: verás el par de Bell.
2. Añade una Z antes de la CNOT y observa cómo cambia el color (la fase) de una de las barras.
3. Cambia al modo Shots con 100 disparos y compara el histograma con las probabilidades exactas.
