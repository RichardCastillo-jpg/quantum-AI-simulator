---
layout: ../../layouts/LessonLayout.astro
title: "Compuertas cuánticas"
kicker: "Lección 2"
description: "Cada compuerta es una matriz unitaria. Aquí están todas las del simulador, con su nombre, su efecto y su matriz."
---

Una compuerta de n cúbits es una matriz **unitaria** de tamaño 2ⁿ × 2ⁿ (U†U = I): conserva la norma del estado
y siempre puede deshacerse. Las matrices de esta página siguen la convención de Qiskit y son exactamente las que
usa el emulador; el inspector del simulador también muestra la matriz de la compuerta seleccionada.

## Compuertas de Pauli e identidad

<div class="gate-row"><span class="sym cat-pauli">I</span><p><span class="name">Identidad (I)</span>No modifica el estado. Con un modelo de ruido activo representa un tiempo de espera, útil para ver la decoherencia.</p><table class="mat"><tr><td>1</td><td>0</td></tr><tr><td>0</td><td>1</td></tr></table></div>

<div class="gate-row"><span class="sym cat-pauli">X</span><p><span class="name">NOT cuántico (X)</span>Invierte el estado, |0⟩ ↔ |1⟩. En la esfera de Bloch es una rotación de π en torno al eje x.</p><table class="mat"><tr><td>0</td><td>1</td></tr><tr><td>1</td><td>0</td></tr></table></div>

<div class="gate-row"><span class="sym cat-pauli">Y</span><p><span class="name">Pauli Y</span>Rotación de π en torno al eje y: combina la inversión de bit con la de fase.</p><table class="mat"><tr><td>0</td><td>−i</td></tr><tr><td>i</td><td>0</td></tr></table></div>

<div class="gate-row"><span class="sym cat-pauli">Z</span><p><span class="name">Inversión de fase (Z)</span>Añade una fase de π al estado |1⟩ y deja |0⟩ igual. Rotación de π en torno al eje z.</p><table class="mat"><tr><td>1</td><td>0</td></tr><tr><td>0</td><td>−1</td></tr></table></div>

## Superposición

<div class="gate-row"><span class="sym cat-clifford">H</span><p><span class="name">Hadamard (H)</span>Crea superposición: |0⟩ → (|0⟩+|1⟩)/√2 y |1⟩ → (|0⟩−|1⟩)/√2. Aplicada dos veces devuelve el estado original.</p><div class="mwrap"><span class="m">1/√2 ·</span><table class="mat"><tr><td>1</td><td>1</td></tr><tr><td>1</td><td>−1</td></tr></table></div></div>

<div class="gate-row"><span class="sym cat-clifford">√X</span><p><span class="name">Raíz de NOT (SX)</span>Media rotación en torno a x: dos √X seguidas equivalen a X. Es una compuerta nativa de los procesadores de IBM.</p><div class="mwrap"><span class="m">½ ·</span><table class="mat"><tr><td>1+i</td><td>1−i</td></tr><tr><td>1−i</td><td>1+i</td></tr></table></div></div>

## Fases

<div class="gate-row"><span class="sym cat-phase">S</span><p><span class="name">Fase S</span>Añade π/2 a |1⟩. Es la raíz cuadrada de Z: S·S = Z.</p><table class="mat"><tr><td>1</td><td>0</td></tr><tr><td>0</td><td>i</td></tr></table></div>

<div class="gate-row"><span class="sym cat-phase">S†</span><p><span class="name">S daga (Sdg)</span>Inversa de S: añade −π/2 a |1⟩.</p><table class="mat"><tr><td>1</td><td>0</td></tr><tr><td>0</td><td>−i</td></tr></table></div>

<div class="gate-row"><span class="sym cat-phase">T</span><p><span class="name">Fase T</span>Añade π/4 a |1⟩. T·T = S. Junto con H y CNOT permite aproximar cualquier compuerta.</p><table class="mat"><tr><td>1</td><td>0</td></tr><tr><td>0</td><td>e<sup>iπ/4</sup></td></tr></table></div>

<div class="gate-row"><span class="sym cat-phase">T†</span><p><span class="name">T daga (Tdg)</span>Inversa de T: añade −π/4 a |1⟩.</p><table class="mat"><tr><td>1</td><td>0</td></tr><tr><td>0</td><td>e<sup>−iπ/4</sup></td></tr></table></div>

<div class="gate-row"><span class="sym cat-phase">P</span><p><span class="name">Fase arbitraria P(φ)</span>Añade una fase φ a |1⟩. Z, S y T son casos particulares (φ = π, π/2, π/4).</p><table class="mat"><tr><td>1</td><td>0</td></tr><tr><td>0</td><td>e<sup>iφ</sup></td></tr></table></div>

## Rotaciones

Las rotaciones giran el estado un ángulo θ en torno a un eje de la esfera de Bloch. Sus parámetros admiten
expresiones como `pi/4`, `2*pi/3` o `i*pi/8` (con la variable de un ciclo for).

<div class="gate-row"><span class="sym cat-rotation">RX</span><p><span class="name">RX(θ)</span>Rotación de ángulo θ en torno al eje x.</p><table class="mat"><tr><td>cos θ/2</td><td>−i sin θ/2</td></tr><tr><td>−i sin θ/2</td><td>cos θ/2</td></tr></table></div>

<div class="gate-row"><span class="sym cat-rotation">RY</span><p><span class="name">RY(θ)</span>Rotación de ángulo θ en torno al eje y. Mueve amplitudes reales entre |0⟩ y |1⟩.</p><table class="mat"><tr><td>cos θ/2</td><td>−sin θ/2</td></tr><tr><td>sin θ/2</td><td>cos θ/2</td></tr></table></div>

<div class="gate-row"><span class="sym cat-rotation">RZ</span><p><span class="name">RZ(θ)</span>Rotación de ángulo θ en torno al eje z. Igual que P(θ) salvo una fase global.</p><table class="mat"><tr><td>e<sup>−iθ/2</sup></td><td>0</td></tr><tr><td>0</td><td>e<sup>iθ/2</sup></td></tr></table></div>

<div class="gate-row"><span class="sym cat-rotation">U</span><p><span class="name">U(θ, φ, λ)</span>La compuerta general de un cúbit: cualquier otra es un caso particular.</p><table class="mat"><tr><td>cos θ/2</td><td>−e<sup>iλ</sup> sin θ/2</td></tr><tr><td>e<sup>iφ</sup> sin θ/2</td><td>e<sup>i(φ+λ)</sup> cos θ/2</td></tr></table></div>

<div class="gate-row"><span class="sym cat-rotation">√Y</span><p><span class="name">√Y y √W</span>Raíces de Y y de W = (X+Y)/√2. Junto con √X forman el conjunto de compuertas de los circuitos aleatorios de los experimentos de ventaja cuántica.</p><span class="m">√P = ½(1+i)·I + ½(1−i)·P</span></div>

## Compuertas de varios cúbits

<div class="gate-row"><span class="sym cat-multi">CX</span><p><span class="name">CNOT (X controlada)</span>Aplica X al cúbit objetivo solo si el de control está en |1⟩. Es la compuerta que crea entrelazamiento. Matriz con el control como bit menos significativo.</p><table class="mat"><tr><td>1</td><td>0</td><td>0</td><td>0</td></tr><tr><td>0</td><td>0</td><td>0</td><td>1</td></tr><tr><td>0</td><td>0</td><td>1</td><td>0</td></tr><tr><td>0</td><td>1</td><td>0</td><td>0</td></tr></table></div>

<div class="gate-row"><span class="sym cat-multi">CCX</span><p><span class="name">Toffoli (CCNOT)</span>Aplica X al objetivo solo si los dos controles están en |1⟩. Con ella se construye cualquier función booleana reversible, como el sumador de la biblioteca de subcircuitos.</p><span class="m">|a, b, c⟩ → |a, b, c ⊕ ab⟩</span></div>

<div class="gate-row"><span class="sym cat-multi">SWAP</span><p><span class="name">SWAP</span>Intercambia los estados de dos cúbits: |01⟩ ↔ |10⟩.</p><table class="mat"><tr><td>1</td><td>0</td><td>0</td><td>0</td></tr><tr><td>0</td><td>0</td><td>1</td><td>0</td></tr><tr><td>0</td><td>1</td><td>0</td><td>0</td></tr><tr><td>0</td><td>0</td><td>0</td><td>1</td></tr></table></div>

<div class="gate-row"><span class="sym cat-multi">RZZ</span><p><span class="name">RXX, RYY, RZZ, iSWAP y fSim</span>Interacciones de dos cúbits habituales en hardware y en algoritmos variacionales: exp(−iθ P⊗P/2) para P = X, Y, Z; iSWAP intercambia con fase i; fSim(θ, φ) es la compuerta de los procesadores de Google.</p><span class="m">RZZ(θ) = diag(e<sup>−iθ/2</sup>, e<sup>iθ/2</sup>, e<sup>iθ/2</sup>, e<sup>−iθ/2</sup>)</span></div>

## Controles para cualquier compuerta

En el simulador **cualquier** compuerta (o subcircuito) puede llevar controles. Un control ● exige |1⟩; un
anticontrol ○ exige |0⟩. Así se obtienen CZ, fases controladas (las de la QFT), Hadamard controlada, rotaciones
multicontroladas o un subcircuito entero controlado. La matriz controlada es exacta:

<span class="eq">C(U) = |0⟩⟨0| ⊗ I + |1⟩⟨1| ⊗ U</span>

## Bloques

<div class="gate-row"><span class="sym cat-block">QFT</span><p><span class="name">Transformada cuántica de Fourier</span>Lleva |x⟩ a (1/√N) Σ<sub>y</sub> e<sup>2πi·xy/N</sup>|y⟩. Se expande en Hadamards, fases controladas y SWAPs; QFT† es su inversa.</p></div>

<div class="gate-row"><span class="sym cat-block">×a</span><p><span class="name">Multiplicación modular ×a mod N</span>|y⟩ → |a·y mod N⟩ para y &lt; N (y deja igual el resto). Es una permutación, por tanto unitaria si a y N son coprimos. Controlada, es el corazón del algoritmo de Shor.</p></div>

<div class="gate-row"><span class="sym cat-block">U</span><p><span class="name">Unitaria personalizada</span>Escribe tú la matriz de 1 o 2 cúbits; el simulador comprueba que sea unitaria antes de aplicarla.</p></div>

## Medición y control clásico

<div class="gate-row"><span class="sym cat-measure">M</span><p><span class="name">Medición</span>Proyecta el cúbit en la base computacional y guarda el resultado en un bit clásico.</p></div>

<div class="gate-row"><span class="sym cat-measure">|0⟩</span><p><span class="name">Reinicio</span>Devuelve el cúbit a |0⟩ en mitad del circuito.</p></div>

Cualquier compuerta puede condicionarse a un bit clásico ("aplicar X si c1 = 1"). Es lo que hace la
teleportación: medir y corregir en tiempo real. En modo Shots el emulador ejecuta estos **circuitos dinámicos**
disparo a disparo; en modo Statevector los resuelve de forma exacta con el *principio de medición diferida*:
cada medición intermedia se sustituye por una CNOT hacia un cúbit auxiliar y cada condición por un control
cuántico, lo que da exactamente las mismas probabilidades.
