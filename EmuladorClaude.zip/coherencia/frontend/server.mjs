// Servidor de producción del frontend (sin dependencias).
//
// * Sirve el sitio estático generado por `astro build` (carpeta dist/).
// * Publica /env.js con la configuración en tiempo de ejecución (PUBLIC_API_URL).
// * Reenvía /api/* al backend por la red interna de Docker (BACKEND_URL), de modo que el
//   navegador habla con un único origen. Si el cliente cancela la petición (AbortController),
//   también se cancela la petición al backend.

import { createReadStream, existsSync, statSync } from 'node:fs';
import { request as httpRequest } from 'node:http';
import { request as httpsRequest } from 'node:https';
import { createServer } from 'node:http';
import { extname, join, normalize, resolve } from 'node:path';
import { createGzip } from 'node:zlib';

const PORT = Number(process.env.PORT || 4321);
const HOST = process.env.HOST || '0.0.0.0';
const DIST = resolve(process.env.DIST_DIR || './dist');
const BACKEND_URL = new URL(process.env.BACKEND_URL || 'http://localhost:8000');
const PUBLIC_API_URL = (process.env.PUBLIC_API_URL || '').trim();

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
};
const COMPRESSIBLE = new Set(['.html', '.js', '.mjs', '.css', '.json', '.svg', '.txt', '.map']);

function log(req, status, started) {
  const ms = (performance.now() - started).toFixed(1);
  if (process.env.QUIET !== '1') console.log(`${req.method} ${req.url} → ${status} (${ms} ms)`);
}

function proxy(req, res, started) {
  const target = new URL(req.url, BACKEND_URL);
  const send = target.protocol === 'https:' ? httpsRequest : httpRequest;
  const headers = { ...req.headers, host: target.host };
  delete headers.origin; // misma procedencia para el backend: no necesita CORS
  const upstream = send(
    target,
    { method: req.method, headers, timeout: 120_000 },
    (up) => {
      res.writeHead(up.statusCode || 502, up.headers);
      up.pipe(res);
      up.on('end', () => log(req, up.statusCode, started));
    },
  );
  upstream.on('timeout', () => upstream.destroy(new Error('timeout')));
  upstream.on('error', (err) => {
    if (res.headersSent) {
      res.destroy();
      return;
    }
    res.writeHead(502, { 'content-type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ detail: { message: `No se pudo contactar con el backend (${BACKEND_URL.origin}): ${err.message}`, errors: [] } }));
    log(req, 502, started);
  });
  // Cancelación: si el navegador aborta la petición, se aborta la del backend.
  res.on('close', () => {
    if (!res.writableEnded) upstream.destroy();
  });
  req.pipe(upstream);
}

function resolveFile(urlPath) {
  let path = decodeURIComponent(urlPath.split('?')[0]);
  path = normalize(path).replace(/^(\.\.[/\\])+/, '');
  let file = join(DIST, path);
  if (!file.startsWith(DIST)) return null;
  if (existsSync(file) && statSync(file).isDirectory()) file = join(file, 'index.html');
  else if (!existsSync(file) && !extname(file) && existsSync(`${file}.html`)) file = `${file}.html`;
  else if (!existsSync(file) && !extname(file) && existsSync(join(file, 'index.html'))) file = join(file, 'index.html');
  return existsSync(file) && statSync(file).isFile() ? file : null;
}

function serveFile(req, res, file, status, started) {
  const ext = extname(file).toLowerCase();
  const headers = {
    'content-type': MIME[ext] || 'application/octet-stream',
    'x-content-type-options': 'nosniff',
    'cache-control': req.url.startsWith('/_astro/') ? 'public, max-age=31536000, immutable' : 'no-cache',
  };
  const gzip = COMPRESSIBLE.has(ext) && /\bgzip\b/.test(req.headers['accept-encoding'] || '');
  if (gzip) headers['content-encoding'] = 'gzip';
  res.writeHead(status, headers);
  if (req.method === 'HEAD') {
    res.end();
    log(req, status, started);
    return;
  }
  const stream = createReadStream(file);
  (gzip ? stream.pipe(createGzip()) : stream).pipe(res);
  res.on('finish', () => log(req, status, started));
}

const server = createServer((req, res) => {
  const started = performance.now();
  const url = req.url || '/';
  if (url.startsWith('/api/') || url === '/api') {
    proxy(req, res, started);
    return;
  }
  if (url.split('?')[0] === '/env.js') {
    res.writeHead(200, { 'content-type': 'text/javascript; charset=utf-8', 'cache-control': 'no-store' });
    res.end(`window.__COHERENCIA__ = ${JSON.stringify({ apiUrl: PUBLIC_API_URL })};\n`);
    log(req, 200, started);
    return;
  }
  if (url.split('?')[0] === '/healthz') {
    res.writeHead(200, { 'content-type': 'text/plain' });
    res.end('ok');
    return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { allow: 'GET, HEAD' });
    res.end();
    return;
  }
  const file = resolveFile(url);
  if (file) {
    serveFile(req, res, file, 200, started);
    return;
  }
  const notFound = join(DIST, '404.html');
  if (existsSync(notFound)) serveFile(req, res, notFound, 404, started);
  else {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    res.end('No encontrado');
    log(req, 404, started);
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Coherencia (frontend) en http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`);
  console.log(`  estáticos: ${DIST}`);
  console.log(`  /api → ${BACKEND_URL.origin}${PUBLIC_API_URL ? `  (el navegador usará ${PUBLIC_API_URL})` : ''}`);
});

for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => server.close(() => process.exit(0)));
