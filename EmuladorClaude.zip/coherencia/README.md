# Coherencia · emulador cuántico

Coherencia es un emulador de circuitos cuánticos para la web. Permite construir circuitos arrastrando compuertas, ejecutarlos en **Qiskit Aer** y ver al instante cómo cambian las amplitudes, la fase, la interferencia y el entrelazamiento. Incluye algoritmos completos (Shor, circuitos cuánticos aleatorios con XEB, teleportación, Deutsch, Grover…), modelos de ruido y un módulo de aprendizaje con dos laboratorios de óptica cuántica.

```
docker compose up --build
```

Después abre **http://localhost:4321**. La API queda en http://localhost:8000 (documentación interactiva en http://localhost:8000/docs).

---

## 1. Arquitectura del sistema

La aplicación es cliente-servidor, está desacoplada y se despliega con contenedores:

```
 Navegador ──HTTP──▶ frontend (Astro + Node, :4321) ──/api──▶ backend (FastAPI + Qiskit Aer, :8000)
                         │  sitio estático                       │  validación, traducción, simulación
                         │  /env.js (configuración)              │  CRUD de subcircuitos
                         └──────── red interna qsim-net ─────────┘
                                                                  └──▶ volumen qsim-data (/data, JSON)
```

| Componente | Tecnología | Responsabilidad |
| --- | --- | --- |
| **backend** | Python 3.12, FastAPI, Qiskit 2.x, Qiskit Aer 0.17 | Valida el circuito JSON, lo traduce a `QuantumCircuit` (con subcircuitos, ciclos `for`, parámetros, control clásico y ruido) y lo ejecuta en Aer en modo *Statevector* o *Shots*. Gestiona el CRUD de subcircuitos. |
| **frontend** | Astro 5 (sitio estático) + TypeScript sin framework + servidor Node sin dependencias | Páginas de inicio, simulador, algoritmos, **Aprender** (lecciones en Markdown y laboratorios de óptica) y documentación. Consume la API con `fetch`, ejecuta de forma reactiva (control de frecuencia y cancelación) y sincroniza las vistas. |
| **persistencia** | volumen Docker `qsim-data` | Un archivo JSON por subcircuito en `/data/subcircuits`, con escrituras atómicas. Sobrevive a los reinicios. |

**Comunicación entre servicios.** El servidor del frontend (`frontend/server.mjs`) reenvía `/api/*` a `BACKEND_URL` (`http://backend:8000`) por la red interna de Docker, de modo que el navegador habla con un único origen. Si el navegador cancela una petición obsoleta, el reenvío también se cancela. Si se prefiere que el navegador llame directamente al backend, basta con definir `PUBLIC_API_URL=http://localhost:8000`: el frontend lo publica en `/env.js` y entonces actúa la política **CORS** del backend (`CORS_ORIGINS`).

### Flujo de una simulación

```
JSON del circuito ─▶ IR (operaciones primitivas) ─▶ + ruido (canales de Kraus) ─▶ Qiskit Aer ─▶ observables ─▶ análisis
```

1. **IR** (`backend/app/core/ir.py`). Se validan índices, aridades, parámetros y conflictos por columna; las expresiones (`pi/4`, `i*pi/8`, `sqrt(2)`) se evalúan con un analizador seguro (sin `eval`); los ciclos `for` (anidables) se desenrollan; los subcircuitos (recursivos, con detección de ciclos) se expanden propagando controles, anticontroles y condiciones; los bloques QFT se descomponen. Los errores se devuelven con el `op_id` exacto para resaltar la compuerta en la interfaz.
2. **Ruido** (`core/noise.py`). Despolarizante y relajación térmica como canales de Kraus explícitos tras cada compuerta; error de lectura simétrico.
3. **Motor** (`engines/qiskit_engine.py`). La IR se traduce a `QuantumCircuit`: compuertas nativas de Aer cuando existen (`cx`, `ccx`, `mcx`, `cp`, `mcphase`, `cswap`…) y `UnitaryGate` exacta en el resto, `if_test` para el control clásico, instrucciones `kraus` para el ruido y `ReadoutError` para la lectura.
   * *Statevector*: estado exacto. Las mediciones intermedias, reinicios y condiciones se resuelven con el **principio de medición diferida** (`core/deferred.py`), y con ruido se usa la matriz densidad.
   * *Shots*: circuito dinámico real, disparo a disparo, con memoria por disparo opcional.
4. **Observables** (`core/analysis.py`): probabilidades, amplitudes, vectores de Bloch por traza parcial, pureza y entropía, ramas clásicas y distribución exacta de los registros.
5. **Análisis** (`algorithms/`): fracciones continuas de Shor, XEB lineal y Porter–Thomas, fidelidad de teleportación, veredicto de Deutsch, etc.

Además se incluye un **motor de referencia en NumPy** (`engines/reference.py`), independiente de Qiskit, que implementa la misma IR. Las pruebas comparan ambos motores compuerta a compuerta y sobre circuitos aleatorios, de modo que la base matemática queda verificada de forma cruzada.

## 2. Funcionalidades (según el documento de diseño)

| Requisito | Implementación |
| --- | --- |
| Compuertas H, X, CNOT, Toffoli, SWAP, I, T, S, Z, T†, S†, P(φ), RZ, SX, Y, RX, RY | Todas, con matrices idénticas a las de Qiskit. Extra: √X†, √Y, √W, U(θ,φ,λ), iSWAP, RXX/RYY/RZZ, fSim, QFT/QFT†, multiplicación modular y unitaria personalizada. **Cualquier** compuerta admite controles y anticontroles. |
| Ciclo for | Selecciona columnas → *Repetir*. Ciclos anidables con variable utilizable en los parámetros (`RZ(i*pi/8)`). |
| Configuración | Cúbits, bits clásicos, estado inicial (cadena de bits), modo *Shot*/*Statevector*, disparos, semilla y ruido (ninguno, despolarizante, relajación térmica, lectura). |
| Editor de circuitos | Cuadrícula con arrastrar y soltar (ratón y táctil), selección en dos clics de control y objetivo (tres para Toffoli), eliminación individual (Supr, arrastrar fuera, menú contextual), mover, duplicar, deshacer/rehacer, selección por rectángulo y atajos de teclado. |
| Subcircuitos | Guardar desde una selección o el circuito completo (nombre, descripción, cúbits, parámetros, composición de otros subcircuitos), insertar arrastrando con validación de cúbits disponibles, vista de inspección (compuertas internas, orden de capas, flujo de cúbits), edición completa, renombrar, duplicar y eliminar. Al editar se actualizan las instancias y se re-ejecuta. |
| Resultados | Estado dominante, estado en notación de Dirac (kets con valores exactos como 1/√2 o e^{iπ/4}, y el estado de cada cúbit con su transición en el depurador), histograma (coloreado por fase en modo exacto) en **2D o 3D**, tabla de amplitudes (con ramas clásicas), esferas de Bloch 3D interactivas por cúbit con animación desde el estado inicial. La vista 3D se puede girar, desplazar y acercar, muestra las probabilidades y la **matriz densidad** (Re ρ, Im ρ y \|ρ\| con la fase como color, hasta 5 cúbits) y exporta la figura en PNG con fondo blanco para artículos. |
| Teoría (**Aprender**) | Tres lecciones en Markdown: introducción, compuertas (nombre, efecto y matriz de cada una) y uso del simulador. |
| Algoritmos precargados | Sección propia (`/algoritmos`) y menú en el simulador: teleportación (3 cúbits, 2 bits, 2 H + 2 CNOT, correcciones X/Z dinámicas), Deutsch (4 oráculos con X y CNOT), y además **Shor**, **circuitos cuánticos aleatorios (RQC)**, Grover, Bernstein–Vazirani, QFT, Bell y GHZ. |
| Módulo Aprende | Interferómetro de Mach–Zehnder (esquema óptico animado, deslizador de φ, BS₂ y bloqueo de brazo conmutables, teoría frente a emulador, fotón único o ráfaga de N) y bombas de Elitzur–Vaidman (activa, defectuosa y prueba a ciegas, colapso visible, registro 50/25/25). Todo lo calcula el emulador. |
| Programar en Qiskit | Pestaña **Código** del simulador: el circuito aparece como código Qiskit editable y, al revés, lo que escribes en Qiskit se convierte en el circuito y se re-ejecuta (histograma, amplitudes y esferas). Detalles en la sección 3. |
| Ejecución automática | Reactiva ante cualquier cambio; *debounce* en cambios discretos y *throttle* en deslizadores; cancelación con `AbortController` (y del reenvío al backend); actualización simultánea de todas las vistas; botón de pausa con cambios pendientes. Mientras recalcula, los resultados anteriores se atenúan en lugar de desaparecer. |

## 3. Mejora adicional: depurador cuántico paso a paso

La mejora elegida es una **máquina del tiempo del circuito**. El botón *Depurar paso a paso* del simulador abre una línea de tiempo con un paso por columna (con los ciclos `for` ya desenrollados). Al moverla:

* el editor resalta la columna actual y atenúa las posteriores;
* las esferas de Bloch se animan de un paso al siguiente;
* el histograma, la tabla de amplitudes y la pureza muestran el estado **después de esa columna**;
* se puede reproducir automáticamente y funciona con ruido (matriz densidad) y con mediciones intermedias (medición diferida).

Se implementa en el backend (`POST /api/simulate/steps`): el circuito se ejecuta **una sola vez** en Aer con instrucciones `save_statevector` (o `save_density_matrix` si hay ruido) al final de cada paso, y el servidor devuelve solo los observables de cada instantánea. Permite ver dónde aparece el entrelazamiento, por qué una interferencia se cancela o cómo el ruido acorta los vectores de Bloch, algo que el estado final por sí solo no muestra.

### Editor de código Qiskit sincronizado

La pestaña **Código** del panel derecho muestra el circuito como un programa de Qiskit y se mantiene sincronizada en los dos sentidos, como el editor de IBM Quantum:

* **Del circuito al código.** Cualquier cambio en la cuadrícula reescribe el código: los ciclos `for` siguen siendo bucles de Python, las expresiones (`i*π/8`) se escriben en Python (`i*pi/8`), los subcircuitos se convierten en funciones que devuelven un `QuantumCircuit` y los nombres de los cúbits se conservan como registros.
* **Del código al circuito.** Al dejar de escribir (o con Ctrl+Enter) el código se traduce al circuito, que se vuelve a simular. Se admiten la API habitual de Qiskit (`qc.h`, `cx`, `ccx`, `mcx`, `cp`, `measure`, `measure_all`, `reset`, `barrier`, `initialize`, `if_test` con `else`, `append`, `compose`, `to_gate`, `inverse`, `control(ctrl_state=…)`, `QFT`/`QFTGate`, `UnitaryGate`, registros…) junto con variables, bucles, condicionales, listas por comprensión y funciones propias. Las líneas que solo sirven para ejecutar o dibujar (`AerSimulator`, `transpile`, `print`, `plot_histogram`) se ignoran.
* **Selección cruzada.** Seleccionar una compuerta resalta su línea y hacer clic en una línea selecciona su compuerta. Los errores se señalan en su línea, en español.

**Seguridad.** El código **no se ejecuta**: el backend lo analiza con `ast` y lo recorre con un intérprete propio (`backend/app/services/qiskit_code.py`) que solo conoce aritmética, colecciones, control de flujo, funciones definidas en el propio código y los objetos de Qiskit propios de un circuito. No hay `eval`, `exec`, `import` real, acceso a atributos privados ni a archivos o red, y hay límites de pasos, tamaño y recursión. Las pruebas comprueban que el código generado de todos los algoritmos y subcircuitos reproduce exactamente el mismo estado al volver a interpretarlo.

**Otras mejoras incluidas:** controles y anticontroles sobre cualquier compuerta o subcircuito; parámetros con nombre en los subcircuitos; resolución exacta de circuitos dinámicos en modo *Statevector*; ramas clásicas en la tabla de amplitudes; validación cruzada con un motor NumPy independiente; exportación a código Python de Qiskit, OpenQASM 3 y OpenQASM 2; enlaces que contienen el circuito para compartirlo; importación y descarga en JSON; persistencia local del trabajo.

## 4. Guía de ejecución con Docker

### Requisitos

* Docker 24 o posterior con Docker Compose v2 (`docker compose version`).
* Unos 2 GB libres para las imágenes (Qiskit Aer incluye binarios nativos).

### Arrancar

```bash
docker compose up --build          # primera vez (construye las imágenes)
docker compose up -d               # siguientes veces, en segundo plano
```

| Servicio | URL |
| --- | --- |
| Interfaz web | http://localhost:4321 |
| API REST | http://localhost:8000/api/health |
| Documentación interactiva de la API | http://localhost:8000/docs |

El frontend espera a que el backend esté sano (healthcheck) antes de arrancar.

### Operaciones habituales

```bash
docker compose logs -f backend                      # registros del motor
docker compose run --rm backend pytest              # pruebas del backend (incluye la validación cruzada con Qiskit)
docker compose down                                 # detener
docker compose down -v                              # detener y borrar la biblioteca de subcircuitos (volumen)
```

### Variables de entorno

| Variable | Servicio | Por defecto | Descripción |
| --- | --- | --- | --- |
| `CORS_ORIGINS` | backend | `http://localhost:4321,http://127.0.0.1:4321` | Orígenes autorizados para llamadas directas. |
| `DATA_DIR` | backend | `/data` | Carpeta de la biblioteca de subcircuitos (volumen). |
| `QSIM_ENGINE` | backend | `qiskit` | `reference` usa el motor NumPy. |
| `QSIM_MAX_QUBITS` | backend | `22` | Límite de cúbits del vector de estado. |
| `QSIM_MAX_DENSITY_QUBITS` | backend | `10` | Límite de la matriz densidad (ruido exacto). |
| `QSIM_MAX_STEP_QUBITS` | backend | `12` | Límite del depurador paso a paso. |
| `QSIM_MAX_SHOTS` | backend | `100000` | Disparos por ejecución. |
| `BACKEND_URL` | frontend | `http://backend:8000` | Destino interno del reenvío `/api`. |
| `PUBLIC_API_URL` | frontend | vacío | Si se define, el navegador llama directamente a esa URL (CORS). |

Para cambiar puertos, edita la sección `ports` de `docker-compose.yml` (por ejemplo `"8080:4321"`). Si cambias el puerto del frontend y usas `PUBLIC_API_URL`, añade el nuevo origen a `CORS_ORIGINS`.

### Desarrollo sin Docker

```bash
# Backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
DATA_DIR=./data uvicorn app.main:app --reload --port 8000
pytest

# Frontend (en otra terminal; Vite reenvía /api a localhost:8000)
cd frontend
npm install
npm run dev            # http://localhost:4321
npm run build && npm start   # versión de producción con server.mjs
```

## 5. Estructura del proyecto

```
backend/
  app/
    main.py                 FastAPI, CORS, arranque
    config.py               límites y variables de entorno
    api/routes.py           rutas REST
    core/                   expresiones, compuertas, modelos, IR, medición diferida, ruido, observables
    engines/                Qiskit Aer y motor de referencia NumPy
    algorithms/             teleportación, Deutsch, Grover, BV, QFT, Shor, RQC (+ análisis)
    services/               simulación, exportación y traductor código Qiskit ⇄ circuito
    storage/subcircuits.py  biblioteca persistente en JSON
  tests/                    pruebas unitarias, de API y validación cruzada Aer ↔ NumPy
frontend/
  src/pages/                inicio, simulador, algoritmos, aprender (lecciones .md y laboratorios), docs
  src/ui/                   editor, inspector, resultados, Bloch 3D, laboratorios
  src/lib/                  tipos, cliente de la API, ejecución automática, expresiones, compuertas
  src/styles/               sistema de diseño
  server.mjs                servidor estático + proxy /api + /env.js
docker-compose.yml
```

## 6. API en resumen

| Método | Ruta | Uso |
| --- | --- | --- |
| `POST` | `/api/simulate` | `{circuit, config, options}` → probabilidades, amplitudes, Bloch, conteos, análisis |
| `POST` | `/api/simulate/steps` | Estado después de cada columna (depurador) |
| `GET/POST` | `/api/subcircuits` | Listar / crear |
| `GET/PUT/DELETE` | `/api/subcircuits/{id}` | Leer / editar / eliminar (`?force=true`) |
| `GET` | `/api/algorithms` · `POST /api/algorithms/{clave}` | Algoritmos precargados |
| `POST` | `/api/export` | Python (Qiskit), OpenQASM 3 y 2 |
| `POST` | `/api/code/qiskit` | Circuito → código Qiskit editable (con el mapa operación → línea) |
| `POST` | `/api/code/parse` | Código Qiskit → circuito (errores con número de línea) |
| `GET` | `/api/health`, `/api/gates` | Estado y catálogo |

El formato completo del circuito y los modelos de ruido están documentados en la página **Documentación** de la aplicación (`/docs`).

## 7. Convenciones

* **Orden de bits de Qiskit:** en `|q₂q₁q₀⟩` y en los resultados, el carácter de la derecha es q0 (o c0).
* Las matrices controladas ponen los controles en los bits menos significativos, como `qiskit.circuit.library`.
* Las compuertas de 3 o más cúbits reciben ruido despolarizante como canales independientes de 1 cúbit con `p2`.
